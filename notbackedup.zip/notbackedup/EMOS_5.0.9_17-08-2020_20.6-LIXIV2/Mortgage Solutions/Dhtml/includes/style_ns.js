if (document.layers) {
	writeStr = ''+
	'<style type="text/css">'+
	'	ul								{ margin-top:0px; margin-bottom:0px }'+
	'</style>';
	document.write(writeStr);
}
