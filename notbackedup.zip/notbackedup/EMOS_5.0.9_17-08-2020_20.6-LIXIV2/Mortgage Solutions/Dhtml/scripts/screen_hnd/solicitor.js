//<script>
//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.0  $
//	$Author:   maheedhv  $
//	$Workfile:   solicitor.js  $
//	$Modtime:   Aug 01 2005 14:20:42  $	
//============================================================-->

//===========================
// Declare global variables
//===========================
var G_bSolicitorDirty=false;


//=====================================================================
//	Function Name:	SolicitorScreenShow
//	Parameters:		nil
//	Return:			nil
//	Description:	Initialise the Solicitor Screen for new application.
//					Add Solicitor node if there is no solicitor in the master XML. 
//=====================================================================
function SolicitorScreenShow()
{
	try
	{
		G_pScreenSaveFunction = saveSolicitor;
	
		ds_solicitor.src = ds_solicitor.src;
		var oLoadSol = xml_master.XMLDocument.documentElement.selectSingleNode("//Solicitor");
		if (oLoadSol.hasChildNodes)
		{
			//retrieve Solicitor details node if it's exists in application;
			var oNewLoadSol=ds_solicitor.XMLDocument.documentElement;
			ds_solicitor.XMLDocument.replaceChild(oLoadSol.cloneNode(true), oNewLoadSol);
			ds_solicitor.XMLDocument.documentElement.selectSingleNode('SolicitorID').text = "";
		}
		else
		{	
			//INITIALISE 
			InitilizeAppBRS(ds_solicitor.XMLDocument.documentElement);
		}
		
		SetFocusOnElement("inpSolicitorName");
		SetSolicitorDirty();
	}
	catch (e)
	{
		displayError(e,'SolicitorScreenShow');	
	}
}


//=====================================================================
//	Function Name:	saveSolicitor
//	Parameters:		nil
//	Return:			nil
//	Description:	Save Solicitor to master XML,Validate and FlushToDisk.
//=====================================================================
function saveSolicitor()
{
	try
	{
		if (!G_bSolicitorDirty) return;
		
		var oNewSol = ds_solicitor.XMLDocument.documentElement.cloneNode(true);
        	var oSaveSol = xml_master.XMLDocument.documentElement;
        	var oReplSol = oSaveSol.selectSingleNode('Solicitor');
		if (oNewSol.text)
		{
			var sSolNm = (oNewSol)? oNewSol.selectSingleNode("SolicitorName").text:'';
			var sCompNm = (oNewSol)? oNewSol.selectSingleNode("CompanyName").text:'';
			allValid = (sSolNm.length>0) || (sCompNm.length>0) || (!oNewSol);
				if(allValid)
					oNewSol.selectSingleNode('SolicitorID').text = 1;
				else
					//oNewSol.selectSingleNode('SolicitorID').text = "";
					SetSolicitorClear(oNewSol);
		}
        
        	// Move Solicitor details from stub xml to master xml
        	oSaveSol.replaceChild(oNewSol, oReplSol); 
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Solicitor"));
		EvaluateAppBRS(xml_master.XMLDocument.documentElement, true);
		G_bSolicitorDirty=false;
		FlushToDisk();
		SolicitorScreenShow();
	}
	catch (e)
	{
		displayError(e,'saveSolicitor');
	}
}


//=====================================================================
//	Function Name:	ClearSolicitor
//	Parameters:		nil
//	Return:			nil
//	Description:	Set screen clear.
//=====================================================================
function SetSolicitorClear(oNewSol)
{
	try
	{
		oNewSol.selectSingleNode('SolicitorID').text = "";
		oNewSol.selectSingleNode('AddressLine1').text = "";
		oNewSol.selectSingleNode('AddressLine2').text = "";
		oNewSol.selectSingleNode('AddressLine3').text = "";
		oNewSol.selectSingleNode('City').text = "";
		oNewSol.selectSingleNode('State').text = "";
		oNewSol.selectSingleNode('Postcode').text = "";
		oNewSol.selectSingleNode('PhoneNumber').text = "";
		oNewSol.selectSingleNode('FaxNumber').text = "";
	}
	catch (e)
	{
		displayError(e,'SetSolicitorClear');
	}
}
//=====================================================================
//	Function Name:	SetSolicitorDirty
//	Parameters:		nil
//	Return:			nil
//	Description:	Set screen dirty.
//=====================================================================
function SetSolicitorDirty()
{
	G_bSolicitorDirty=true;
}


//==============================================================
//	Function Name:	CallSearchAddress
//	Parameters:		Nil
//	Return:			
//	Description:	
//==============================================================
function CallSearchAddress()
{
	try
	{
		var sCity = ds_solicitor.XMLDocument.documentElement.selectSingleNode("City").text;
		if (sCity)
		{
			var oReturn =  window.showModalDialog("CityStatePostcodeSelector.html", sCity, "dialogHeight:335px;dialogWidth:550px;help:No;resizable:No;status:No;scroll:No;");
			if (oReturn) 
			{ 
				oResults = oReturn.split(';');
				var oAdr = ds_solicitor.XMLDocument.documentElement
				oAdr.selectSingleNode("City").text =oResults[0];
				oAdr.selectSingleNode("State").text=oResults[1];
				oAdr.selectSingleNode("Postcode").text =oResults[2];
			}
		}
		else
		{
			VBMsgBox("Please enter part of the city, town or suburb name into the 'City' field.", G_iVB_WARNING, G_sAPPLICATION_TITLE);
			return;
		}
	}
	catch (e)
	{
		displayError(e,"CallSearchAddress");
	}
}

