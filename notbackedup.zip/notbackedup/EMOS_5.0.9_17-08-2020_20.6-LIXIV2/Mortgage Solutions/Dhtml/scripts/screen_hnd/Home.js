//<script>
//==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Eugene Elutine, Tim Heide
//	Workfile:  
//	ModTtime: 2003/03/05
//  File: Home.js	
//============================================================
//Globals
var G_bAppDetailsDirty = false;

//==============================================================
//	Function Name:	HomeScreenShow
//	Parameters:		Nil	
//	Return:			Nil
//	Description:	Initialise the home screen
//==============================================================
function HomeScreenShow()
{
	try
	{
		G_pScreenSaveFunction = saveApplication;
	
		ds_home.src=ds_home.src;
		var oAppDtls = xml_master.XMLDocument.documentElement.selectSingleNode("//AppDetails");
	
		if (oAppDtls.hasChildNodes)
		{
			//retrieve AppDetails node if it's exists in application;
			var oRepl=ds_home.XMLDocument.documentElement;
			ds_home.XMLDocument.replaceChild(oAppDtls.cloneNode(true), oRepl);
		}
		else
		{	
			//initilise dso
			InitilizeAppBRS(ds_home.XMLDocument.documentElement);
			SetAppDetailsDirty();
		}
		addFileRefDetails();
		SetFocusOnElement("inpNomBranchBSB");
	}
	catch (e)
	{
		displayError(e,"HomeScreenShow");
	}	
}

//==============================================================
//	Function Name:	saveApplication
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Saves the application
//==============================================================
function saveApplication()
{
	try
	{
		if (!G_bAppDetailsDirty) return;
		var oNewAppDtls = ds_home.XMLDocument.documentElement.cloneNode(true);
		var oRepl = xml_master.XMLDocument.documentElement.selectSingleNode("AppDetails");
		xml_master.XMLDocument.documentElement.replaceChild(oNewAppDtls, oRepl);
		
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("AppDetails"));
		EvaluateAppBRS(xml_master.XMLDocument.documentElement, true);
		FlushToDisk();
		G_bAppDetailsDirty = false;
		HomeScreenShow();
	}
	catch (e)
	{
		displayError(e,"saveApplication");
	}
}

//==============================================================
//	Function Name:	openBranchSearch
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Shows the branch search screen
//==============================================================
function openBranchSearch()
{
	try
	{
		var BSB =  window.showModalDialog("branchSelector.htm", "", "dialogHeight:335px;dialogWidth:550px;help:No;resizable:No;status:No;scroll:No;");
		if (BSB) 
		{ 
			var oAppDtls = ds_home.XMLDocument.documentElement;
			oAppDtls.selectSingleNode("NominatedBSB").text=BSB;
			GetBSBName();
		}
	}
	catch (e)
	{
		displayError(e,"openBranchSearch");
	}
}

//==============================================================
//	Function Name:	GetBSBName
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Sets the selected branch name
//==============================================================
function GetBSBName()
{
	try
	{
		var oAppDtls=ds_home.XMLDocument.documentElement;
		var sBSB=oAppDtls.selectSingleNode("NominatedBSB").text;
	
		var oR = getRDRowObject('A_TSR_BRANCH','@PCD_USER_KEY="' + sBSB + '"');
		var sBSBName = (oR)? oR.P_BR_NAME:"";
		
		oAppDtls.setAttribute("NominatedBranchName", sBSBName);
	  /* 
	  Commented as the req. 9 was removed - Start
	  //WR1970 - 'if' Added To open the Branch locator window if an invalid branch id is entered - Start
		if(sBSBName==""&&sBSB!="")
		{
			openBranchSearch();
		}
	  //WR1970 - 'if' Added To open the Branch locator window if an invalid branch id is entered - End
	  Commented as the req. 9 was removed - End
	  */
	}
	catch (e)
	{
		displayError(e,"GetBSBName");
	}
}

//==============================================================
//	Function Name:	ValNominatedBSB
//	Parameters:		oAppDtls - (XML Node) 
//	Return:			boolean - Valid Flag
//	Description:	Validates the nominated BSB
//==============================================================
function ValNominatedBSB(oAppDtls)
{
	try
	{
		if (!oAppDtls) return false;
		var oNomBSB = oAppDtls.selectSingleNode("NominatedBSB");
		if (!oNomBSB)  return false;
		var sBSB = oNomBSB.text;
		var oR = getRDRowObject('A_TSR_BRANCH','@PCD_USER_KEY="' + sBSB + '"');
		return (oR)? true:false;
	}
	catch (e)
	{
		displayError(e,"ValNominatedBSB");
	}
}

//==============================================================
//	Function Name:	SetAppDetailsDirty
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Sets flag to save application
//==============================================================
function SetAppDetailsDirty()
{
	G_bAppDetailsDirty = true;
}