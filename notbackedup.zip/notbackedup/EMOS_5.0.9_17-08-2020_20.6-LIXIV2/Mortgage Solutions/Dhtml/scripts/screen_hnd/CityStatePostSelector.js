// <SCRIPT/>
//==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Arshad
//	Workfile:  
//	ModTtime: 2018/12/14
//  File: CityStatePostSelector.js	
//============================================================

// Address selector window java scripts
var G_selectedRow = 0;


//==============================================================
//	Function Name:	SearchAddress
//	Parameters:		Nil
//	Return:			
//	Description:	
//==============================================================
function SearchAddress()
{
	try
	{
		
		var sCity = window.dialogArguments;
		//var sCity = ds_Addr.XMLDocument.documentElement.selectSingleNode("City").text;
		ds_AdrSearchRes.src=ds_AdrSearchRes.src;
		var oRes=ds_AdrSearchRes.XMLDocument.documentElement;
		oRes.removeChild(oRes.childNodes(0));
		sCity=sCity.toUpperCase();
		
		// ensure that no invalid ' string combinations appear in the search string for city
		sCity = sCity.replace(/"/g,'')
		var oSR= getRDRows('A_E_TSR_PC','starts-with(@C,"' + sCity + '")');
		var sPrompt="No records found.";
		if (oSR.length==0)
		{
			document.all.aSearchOK.focus();	
		}		
		else
		{
			tblAddrSearchHdr.style.width="100%";
			if (oSR.length==1)
			{
				sPrompt="1 record found:";
			}
			else
			{
				sPrompt=oSR.length + " records found:";
				if(oSR.length > 11)
					tblAddrSearchHdr.style.width="97%";
			}
		}
		document.all.spnRes.innerText=sPrompt;
	
		for (i=0; i<oSR.length; i++)
			oRes.appendChild(oSR(i).cloneNode(true));
	}
	catch (e)
	{
		displayError(e,"SearchAddress");
	}
}

//==============================================================
//	Name:		searchIfEnter
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Calls search branches if enter is pressed
//==============================================================
function searchIfEnter()
{
	if (event.keyCode==13) SearchAddress();
}

//==============================================================
//	Name:		selectAddress
//	Parameters:	RecNo - (numeric) record number of selected occupation
//	Return:		Nil	
//	Purpose:	Sets the 'G_selectedRow' variable with the selected occupation recno
//==============================================================
function selectAddress(RecNo)
{
	G_selectedRow = RecNo;
}

//==============================================================
//	Name:		closeIfEnter
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Close the window if enter on HTML element
//==============================================================
function closeIfEnter()
{
	if (event.keyCode==13 && G_selectedRow>0) closeWindow(true);
}

//==============================================================
//	Name:		closeWindow
//	Parameters:	bOk - (boolean) Flag indicating if OK was pressed
//	Return:		String - Window return value. Selected occupation code.	
//	Purpose:	Closes the window and returns the selected occupation
//==============================================================
function closeWindow(bOk)
{	
	try
	{
		var oValue = null;
	
		if (bOk && G_selectedRow>0)
		{
			var oRes=ds_AdrSearchRes.XMLDocument.documentElement.selectSingleNode("//res");
			oValue = oRes.childNodes(G_selectedRow-1).getAttribute("C");
			oValue += ";" + oRes.childNodes(G_selectedRow-1).getAttribute("S");
			oValue += ";" + oRes.childNodes(G_selectedRow-1).getAttribute("P");
		}
	
		window.returnValue=oValue; 
		window.close();
	} 
	catch(e)
	{
		displayError(e,"closeWindow");
	}
}


//==============================================================
//	Name:		initAddressSearchScr
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Initialises the Address (City,State,PC) search screen.
//==============================================================
function initAddressSearchScr()
{
	try
	{	
		ds_AdrSearchRes.XMLDocument.async = false;
		ds_AdrSearchRes.XMLDocument.setProperty("SelectionLanguage","XPath");
		clearSearchResults();
		initRefData();
		SearchAddress();
	} 
	catch(e)
	{
		displayError(e,"initAddressSearchScr");
	}
	
}


//==============================================================
//	Name:		clearSearchResults
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Clear the search results
//==============================================================
function clearSearchResults()
{
	try
	{
		G_selectedRow = 0;
		ds_AdrSearchRes.src=ds_AdrSearchRes.src
		var oOCC=ds_AdrSearchRes.XMLDocument.documentElement.selectSingleNode("//res");
		var oCleanOCC=oOCC.cloneNode(false);
		oOCC.parentNode.replaceChild(oCleanOCC, oOCC);
	} 
	catch(e)
	{
		displayError(e,"clearSearchResults");
	}
}
