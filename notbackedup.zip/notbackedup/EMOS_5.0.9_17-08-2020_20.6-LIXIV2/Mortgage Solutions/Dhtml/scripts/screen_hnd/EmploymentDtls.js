//<!--==========================================================
//	(C) Copyright 1996 - 2005
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		K.Arshad,NS
//	Workfile:	EmploymentDtls.js
//	ModTtime:	04/05/2012
//============================================================-->


var G_oEmpDtls
var G_sModeOpenned;
var G_imgEmpty="../images/empty_cross.gif";
var G_imgValid="../images/blue_asteric.gif";
var G_FirstChange=true;
var G_selectedAdrRec = 0;
//==============================================================
//	Name:		InitializeEmpPopup
//	Purpose:	Disables/Enables, hides/shows and resets/defaults
//				customer employment controls.
//	Parameters:	
//				
//==============================================================
function InitializeEmpPopup()
{
	try
	{
		var oEmpDtlsPassed;
		oEmpDtlsPassed=window.dialogArguments;
		
		initRefData();
		initXMLObject(xml_ClickHelp);
		initXMLObject(ds_EmpDtlsPopup);
		initXMLObject(xml_AppBRS);
		
		// Card 388
		initXMLObject(ds_AdrSearchRes);
		//G_imgEmpty= xml_AppBRS.XMLDocument.documentElement.getAttribute("imgEmpty");
		//G_imgValid= xml_AppBRS.XMLDocument.documentElement.getAttribute("imgValid");

		populateList("A_TS_CIS_EMPLOYMENT_TYPES", document.all.cboEmptType, null, 'TYPE_CODE', 'CODE_DESC', false);
		populateList("A_TS_CIS_EMPLOYER_TYPES", document.all.cboEmprType, null, 'TYPE_CODE', 'CODE_DESC', true);

		populateList("A_TS_COUNTRY_CODES", document.all.cboCountry, "EMPOVR", 'C', 'D',false,true);
		
	//populateList("A_TS_COUNTRY_CODES", document.all.cboCountry, null, 'C', 'D');
		ds_EmpDtlsPopup.src=ds_EmpDtlsPopup.src;
	
		ds_EmpDtlsPopup.XMLDocument.replaceChild(oEmpDtlsPassed,ds_EmpDtlsPopup.XMLDocument.documentElement);
	
		G_sModeOpenned=VBTrim(ds_EmpDtlsPopup.XMLDocument.documentElement.getAttribute('Mode'));
		
		var sHeading;
		
		if (G_sModeOpenned=='Edit')
			sHeading='Edit Employment Details';
			
		if (G_sModeOpenned=='Create')
			sHeading='New Employment Details';
		
		document.all.spnHead.innerText =sHeading;
		ds_EmpDtlsPopup.XMLDocument.documentElement.removeAttribute("Mode");
		
		InitilizeAppBRS(ds_EmpDtlsPopup.XMLDocument.documentElement);
				
		CheckEmploymentType(0,0);

		if (G_sModeOpenned=='Edit')
			LoadOccCodes(1,0);

		if (G_sModeOpenned=='Create')
			LoadOccCodes(0,0);

		//LoadOccCodes(0,0);
		CheckEmploymentStatus(G_sModeOpenned);		
		checkOverseasAddr(true);
		HandleEmploymentType();
		
	}
	catch(e)
	{
		displayError(e,"InitializeEmpPopup");
	}	
}


//==============================================================
//	Name:		CheckEmploymentType
//	Purpose:	Disables/Enables, hides/shows and resets/defaults
//				customer employment controls.
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//				bPrevEmp - (boolean) set to true for previous employment
//==============================================================
function CheckEmploymentType(bSelect,bPrevEmp)
{
	try
	{
		var oDSO = ds_EmpDtlsPopup;
		var sCboEmptType = "cboEmptType";
		var sCboOccCd = "cboOccCd";
		var sEmpTbl ="tblEmployerDtls";
		var sEmpTimeSp="spnET";
	
		var oEmp = oDSO.XMLDocument.documentElement;
		var sEmpType = (bSelect)? oEmp.selectSingleNode("EmploymentType").text:document.all(sCboEmptType).value;
		var sOccCd = (bSelect)? oEmp.selectSingleNode("OccupationCode").text:document.all(sCboOccCd).value;
		var bNonEmpOcc = getSingleRDRow("A_TS_NON_EMPLMT_OCCD",'@OCCUPATION_CODE="'+ sOccCd + '"');
	}
	catch(e)
	{
		displayError(e,"CheckEmploymentType");
	}	
			
}

//==============================================================
//	Name:		LoadOccCodes
//	Purpose:	Loads occupation cods list box, 
//				resets customer Occupation Code 
//	Parameters:	bSelect - (boolean) set to true to stop reset happening.
//				bPrevEmp - (boolean) set to true for previous employment
//==============================================================
function LoadOccCodes(bSelect, bPrevEmp)
{
	try
	{
		var oDSO = ds_EmpDtlsPopup;
		var sCboEmpType = "cboEmptType";
		var sCboOccCd = "cboOccCd";
		var sCriteria="";
		
		//populate occupation codes for employment type
		var sEmpType = (bSelect)? oDSO.XMLDocument.documentElement.selectSingleNode("EmploymentType").text:document.all(sCboEmpType).value;
		
		//if the type is Not Employed then only populate list with appropriate occupations
		if (sEmpType=="NE") 
		{	
			//get the none employment type codes and merge them into a criteria string
			var rNECodes = getRDRows("A_TS_NON_EMPLMT_OCCD",null);
			if (rNECodes)
			{
				for (var i=0; i < rNECodes.length; i++)
				{
					if (sCriteria) sCriteria = sCriteria + ' or ';
					sCriteria = sCriteria + '@OCCUPATION_CODE="' + rNECodes.item(i).getAttribute("OCCUPATION_CODE") + '"'
				}
			}
		}
		else if (sEmpType.length==0)
		{
			//Empty the occupation list if no employment type is entered
			sCriteria = "@OCCUPATION_CODE=''";
		}
		
		//populate the list with the appropriate occupation codes
		 populateList("A_TS_CIS_OCCUPATIONS", document.all(sCboOccCd), sCriteria, 'OCCUPATION_CODE', 'CODE_DESC',false);
		
		//reset occupation code and group
		//if (!bSelect) oDSO.XMLDocument.documentElement.selectSingleNode("OccupationCode").text = "";
	}
	catch(e)
	{
		displayError(e,"LoadOccCodes");
	}		
}


//==============================================================
//	Name:		HandleEmploymentStatus
//	Purpose:	Handles the Screen changes for various employment
//				status values.
//	Parameters:	
//				
//	Returns:	
//==============================================================
function HandleEmploymentStatus()
{
	try
	{
		var sEmpStat=getListText(cboEmptStat);
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmploymentStatusDesc").text=sEmpStat;
		
		CheckEmploymentStatus();
		InitilizeAppBRS(ds_EmpDtlsPopup.XMLDocument.documentElement);	//WR1970 - Added to replace the red crosses with the blue astrics when selection changes for Employment status.
	}
	catch (e)
	{
		displayError(e, "HandleEmploymentStatus")
	}
}

//==============================================================
//	Name:		CheckEmploymentStatus
//	Purpose:	Handles the Screen changes for various employment
//				status values.
//	Parameters:	G_sModeOpenned
//				
//	Returns:	
//==============================================================
function CheckEmploymentStatus(G_sModeOpenned)
{
	try
	{
		var sEmpStat=ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmploymentStatusDesc").text;

		ClearAllFields();
		switch(sEmpStat)
		{
		    case "Current Employment - Primary":
		        SetForCurrEmp(G_sModeOpenned);
		        document.getElementById("trANZStaff").style.display = "block";
		        window.dialogHeight = 42.0;
		        break
		    case "Current Employment - Secondary":
		        SetForCurrEmp(G_sModeOpenned);
		        document.getElementById("trANZStaff").style.display = "block";
				window.dialogHeight=42.0;
				break
			case "Current - Unemployed":
				SetForCurrEmp(G_sModeOpenned);
				cboEmptType.selectedIndex=3;
				CheckEmploymentType(0,0);
				LoadOccCodes(0,0);
				SetForNE();
				document.getElementById("trANZStaff").style.display = "none";
				window.dialogHeight=11.5;
				break
		case "Previous Employment":
		        SetForPrevEmp(G_sModeOpenned);
		        document.getElementById("trANZStaff").style.display = "none";
				window.dialogHeight=32.5;
				break;
		default:
				InitiatizeScreen();
		}
		// Starts Added for Pop Up Validation in Employment Screen
		if (G_sModeOpenned=='Edit')
		{
			var btest=EvaluateAppBRS(ds_EmpDtlsPopup.XMLDocument.documentElement);
		}
		// Ends Added for Pop Up Validation in Employment Screen
		
	}
	catch (e)
	{
		displayError(e, "CheckEmploymentStatus")
	}
}


//==============================================================
//	Name:		SetForCurrEmp
//	Purpose:	Sets the screen for current employments
//				
//	Parameters:	
//				
//	Returns:	
//==============================================================
function SetForCurrEmp(G_sModeOpenned)
{
	try
	{
		document.getElementById("spnEmpType").innerHTML="Employment Type";
		document.getElementById("spnOccu").innerHTML="Occupation";
		document.getElementById("spnEmprType").innerHTML="Employer Type";
		document.getElementById("spnEmprName").innerHTML="Employer Name";
		document.getElementById("spnEmpTime").innerHTML="Time at Employment";
		
		document.getElementById("trCurrEmpGIncome").style.display="block"
		document.getElementById("trCurrEmpNIncome").style.display="block"
		document.getElementById("trCurrEmpIncVer").style.display="block"
		document.getElementById("trCurrEmpProb").style.display="block"
		
		document.getElementById("trEmplType").style.display="block"
		document.getElementById("tblEmplrInfo").style.display="block";
		document.getElementById("trEmpTime").style.display="block";	
		document.getElementById("trEmpOcc").style.display="block";
		
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("valid_EmployerType",G_imgValid);
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("valid_EmployerAddress1",G_imgValid);
		
		if (G_sModeOpenned!="Edit")
		{		
			cboEmptType.selectedIndex=-1;
			CheckEmploymentType(0,0);
			LoadOccCodes(0,0);
		}
	}
	catch (e)
	{
		displayError(e, "SetForCurrEmp")
	}
}


//==============================================================
//	Name:		SetForPrevEmp
//	Purpose:	Sets the screen for current employments
//				
//	Parameters:	
//				
//	Returns:	
//==============================================================
function SetForPrevEmp(G_sModeOpenned)
{
	try
	{
		document.getElementById("spnEmpType").innerHTML="Previous Employment Type";
		document.getElementById("spnOccu").innerHTML="Previous Occupation";
		document.getElementById("spnEmprType").innerHTML="Previous Employer Type";
		document.getElementById("spnEmprName").innerHTML="Previous Employer Name";
		document.getElementById("spnEmpTime").innerHTML="Time at Employment";
		
		document.getElementById("trCurrEmpGIncome").style.display="none"
		document.getElementById("trCurrEmpNIncome").style.display="none"
		document.getElementById("trCurrEmpIncVer").style.display="none"
		document.getElementById("trCurrEmpProb").style.display="none"
		document.getElementById("trANZStaff").style.display = "none"
		
		document.getElementById("trEmplType").style.display="block"
		document.getElementById("tblEmplrInfo").style.display="block";
		document.getElementById("trEmpTime").style.display="block";
		document.getElementById("trEmpOcc").style.display="block";
		
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("valid_EmployerType",G_imgEmpty);
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("valid_EmployerAddress1",G_imgEmpty);		
		
		if (G_sModeOpenned!="Edit")
		{
			cboEmptType.selectedIndex=-1;
			CheckEmploymentType(0,0);
			LoadOccCodes(0,1);
		}
		
	}
	catch (e)
	{
		displayError(e, "SetForPrevEmp")
	}
}


//==============================================================
//	Name:		SetForNE
//	Purpose:	Sets the screen for Not Employed
//				
//	Parameters:	
//				
//	Returns:	
//==============================================================
function SetForNE()
{
	try
	{
		document.getElementById("spnEmpTime").innerHTML="Time Unemployed";
		
		document.getElementById("trCurrEmpGIncome").style.display="none"
		document.getElementById("trCurrEmpNIncome").style.display="none"
		document.getElementById("trCurrEmpIncVer").style.display="none"
		document.getElementById("trCurrEmpProb").style.display="none"
		
		document.getElementById("trEmplType").style.display="none"
		
		document.getElementById("tblEmplrInfo").style.display="none";
		document.getElementById("trEmpTime").style.display="block";	
		document.getElementById("trEmpOcc").style.display="block";	
		
	}
	catch (e)
	{
		displayError(e, "SetForNE")
	}
}


//==============================================================
//	Name:		InitiatizeScreen
//	Purpose:	Initializes the screen if the default employment 
//				Type is null
//	Parameters:	
//				
//	Returns:	
//==============================================================
function InitiatizeScreen()
{
	try
	{
		document.getElementById("trCurrEmpGIncome").style.display="none"
		document.getElementById("trCurrEmpNIncome").style.display="none"
		document.getElementById("trCurrEmpIncVer").style.display="none"
		document.getElementById("trCurrEmpProb").style.display="none"
		
		document.getElementById("trEmplType").style.display="none"
		document.getElementById("tblEmplrInfo").style.display="none";
		document.getElementById("trEmpTime").style.display="none";
		document.getElementById("trEmpOcc").style.display="none";	
		document.getElementById("trANZStaff").style.display = "none";
		
		window.dialogHeight=8;
	}
	catch (e)
	{
		displayError(e, "InitiatizeScreen")
	}
}
//==============================================================
//	Name:		SaveDetails
//	Purpose:	Handles the click event of the save button
//				
//	Parameters:	
//				
//	Returns:	
//==============================================================
function SaveDetails()
{
	try
	{
		
		SetEmpStatus();
		
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("EmploymentTypeDescription",getListText(cboEmptType));
		GetOCCGroup();
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("OccupationCodeDescription",getListText(cboOccCd));
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("EmployerTypeDescription",getListText(cboEmprType));
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("CountryDescription", getListText(document.all.cboCountry));
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerName").text=document.getElementById("inpEmpName").value;
		
		var btest=EvaluateAppBRS(ds_EmpDtlsPopup.XMLDocument.documentElement);
		
		if(ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmploymentStatusDesc").text=="Previous Employment")
		{
			ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("valid_EmployerType",G_imgEmpty);
			ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("valid_EmployerAddress1",G_imgEmpty);
		}
		
		if(btest==true)
		{	
			window.returnValue = ds_EmpDtlsPopup.XMLDocument.documentElement.cloneNode(true);
			window.close();
		}
		else
			VBMsgBox('Please enter valid employment details.',G_iVB_WARNING,G_sAPPLICATION_TITLE);
	}
	catch (e)
	{
		displayError(e, "SaveDetails")
	}
}

//==============================================================
//	Function Name:	GetOCCGroup
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Sets the selected occupation group
//==============================================================
function GetOCCGroup()
{
	try
	{
		var oAppDtls =ds_EmpDtlsPopup.XMLDocument.documentElement;
		var sOCC=oAppDtls.selectSingleNode("OccupationCode").text;
	
		var oOCC = getSingleRDRow('A_TS_CIS_OCCUPATIONS','@OCCUPATION_CODE="' + sOCC + '"');
		var sOccGrpCode = (oOCC)? oOCC.getAttribute("OCCUPATION_GROUP"):"";
		
		//set the occupation code
		oAppDtls.selectSingleNode("OccupationGroup").text=sOccGrpCode;
		
		//Set the occupation group description for the full report
		var oOccGrp= getSingleRDRow('A_TS_OCGR_CODES','@OCGR_CODE="' + sOccGrpCode + '"');
		var sOccGrpCode = (oOccGrp)? oOccGrp.getAttribute("CODE_DESC"):"";
		oAppDtls.setAttribute("OccupationGroupDescription", sOccGrpCode);
	}
	catch (e)
	{
		displayError(e,"GetOCCGroup");
	}
}

//==============================================================
//	Name:		EmpTypeSetScreen
//	Purpose:	Handles the change event of the employment type 
//				dropdown listbox.
//	Parameters:	
//				
//	Returns:	
//==============================================================
function EmpTypeSetScreen()
{
	try
	{
		var sEmpType=document.getElementById("cboEmptType").options(document.getElementById("cboEmptType").selectedIndex).value;
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmploymentType").text=sEmpType;
		HandleEmploymentType();
		//ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("OccupationCode").text="";
		ClearAllFields();
		//document.getElementById("cboOccCd").selectedIndex=-1;
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmploymentType").text=sEmpType;
	}
	catch (e)
	{
		displayError(e,"EmpTypeSetScreen");
	}
}

//==============================================================
//	Name:		HandleEmploymentType
//	Purpose:	Sets the screen layout based on the user selection
//				for the employment type field  
//	Parameters:	
//				
//	Returns:	
//==============================================================
function HandleEmploymentType()
{
	try
	{
		var sEmpTypeSelected=ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmploymentType").text;
		var sEmplStat=ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmploymentStatusDesc").text;
		if (sEmpTypeSelected=="NE")
		{
			SetForNE();
			window.dialogHeight=13;
			document.getElementById("trANZStaff").style.display = "none";
			if(sEmplStat=="Current Employment - Secondary" || sEmplStat=="Current Employment - Primary")
			{
				document.getElementById("spnEmpType").innerHTML="Employment Type";
				document.getElementById("spnOccu").innerHTML="Occupation";
		
				document.getElementById("trEmplType").style.display="block"
				document.getElementById("trEmpTime").style.display="block";	
				document.getElementById("trEmpOcc").style.display="block";
			}
			if(sEmplStat=="Previous Employment")
			{
				document.getElementById("spnEmpType").innerHTML="Previous Employment Type";
				document.getElementById("spnOccu").innerHTML="Previous Occupation";
		
				document.getElementById("trEmplType").style.display="block"
				document.getElementById("trEmpTime").style.display="block";	
				document.getElementById("trEmpOcc").style.display="block";
			}
			document.getElementById("spnEmpTime").innerHTML="Time Unemployed";
		}
		else
		{
			if(sEmplStat=="Current Employment - Secondary" || sEmplStat=="Current Employment - Primary")
			{
				document.getElementById("spnEmpType").innerHTML="Employment Type";
				document.getElementById("spnOccu").innerHTML="Occupation";
				document.getElementById("spnEmprType").innerHTML="Employer Type";
				document.getElementById("spnEmprName").innerHTML="Employer Name";
				document.getElementById("spnEmpTime").innerHTML="Time at Employment";
		
				document.getElementById("trCurrEmpGIncome").style.display="block"
				document.getElementById("trCurrEmpNIncome").style.display="block"
				document.getElementById("trCurrEmpIncVer").style.display="block"
				document.getElementById("trCurrEmpProb").style.display="block"
		
				document.getElementById("trEmplType").style.display="block"
				document.getElementById("tblEmplrInfo").style.display="block";
				document.getElementById("trEmpTime").style.display="block";
				document.getElementById("trEmpOcc").style.display = "block";
				document.getElementById("trANZStaff").style.display = "block";
				
				window.dialogHeight=42.0;
				
			}
			if(sEmplStat=="Previous Employment")
			{
				document.getElementById("spnEmpType").innerHTML="Previous Employment Type";
				document.getElementById("spnOccu").innerHTML="Previous Occupation";
				document.getElementById("spnEmprType").innerHTML="Previous Employer Type";
				document.getElementById("spnEmprName").innerHTML="Previous Employer Name";
				document.getElementById("spnEmpTime").innerHTML="Time at Employment";
		
				document.getElementById("trCurrEmpGIncome").style.display="none"
				document.getElementById("trCurrEmpNIncome").style.display="none"
				document.getElementById("trCurrEmpIncVer").style.display="none"
				document.getElementById("trCurrEmpProb").style.display="none"
		
				document.getElementById("trEmplType").style.display="block"
				document.getElementById("tblEmplrInfo").style.display="block";
				document.getElementById("trEmpTime").style.display="block";
				document.getElementById("trEmpOcc").style.display="block";
				document.getElementById("trANZStaff").style.display = "none";	
				
				window.dialogHeight=32.5;
				
			}
		}	
			
	}
	catch (e)
	{
		displayError(e,"HandleEmploymentType");
	}
}

//==============================================================
//	Name:		SetEmpStatus
//	Purpose:	Sets the value for employment status fields in the DSO
//	Parameters:	
//				
//	Returns:	
//==============================================================
function SetEmpStatus()
{
	try
	{
		var sStat=getListText(cboEmptStat);
		
		switch(sStat)
		{
		case "Current Employment - Primary":	
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PreviousEmployment").text="0";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PrimaryEmployment").text="-1";
				break
		case "Current Employment - Secondary":
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PreviousEmployment").text="0";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PrimaryEmployment").text="0";
				break
		case "Current - Unemployed":
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PreviousEmployment").text="0";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PrimaryEmployment").text="-1";
				
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("GrossMonthlyIncome").text="0";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("NetMonthlyIncome").text="0";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerType").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerName").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerAddress1").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerAddress2").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerAddress3").text="";
				//Card 388
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerOverseasAddress").text="0";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerCountry").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerCity").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerState").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerPostcode").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerPhoneNumber").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerFaxNumber").text="";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("ProbationaryPeriod").text=0;
				break;
		case "Previous Employment":
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PreviousEmployment").text="-1";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PrimaryEmployment").text="0";
				ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("ProbationaryPeriod").text=0;
				break;
		}
		ds_EmpDtlsPopup.XMLDocument.documentElement.setAttribute("EmploymentStatus",sStat);
		
	}
	catch (e)
	{
		displayError(e, "SetEmpStatus")
	}
}


//==============================================================
//	Function Name:	openOccupationSearch
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Shows the occupation search screen
//==============================================================
function openOccupationSearch()
{
	try
	{
		var oAppDtls =ds_EmpDtlsPopup.XMLDocument.documentElement;
		var sEmpType = oAppDtls.selectSingleNode("EmploymentType").text
		if (sEmpType)
		{
			var bNotEmployed = (sEmpType=="NE")? -1:0;
			var OCC =  window.showModalDialog("occupationSelector.htm", bNotEmployed, "dialogHeight:335px;dialogWidth:550px;help:No;resizable:No;status:No;scroll:No;");
			if (OCC) 
			{ 
				oAppDtls.selectSingleNode("OccupationCode").text=OCC;
			}
		}
		else
		{
			var sMsg = "Employment Type must be selected before you can find an Occupation";
			VBMsgBox(sMsg, G_iVB_INFO, G_sAPPLICATION_TITLE);
		}
	}
	catch (e)
	{
		displayError(e,"openOccupationSearch");
	}
}

//==============================================================
//	Function Name:	clearAllFields
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Clears all the text boxes on the screen.
//==============================================================
function ClearAllFields()
{
	try
	{
		ClearDSOFields();
		document.getElementById("inpEmpName").value="";
		document.getElementById("inpEmpAddr1").value="";
		document.getElementById("inpEmpAddr2").value="";
		document.getElementById("inpEmpAddr3").value="";
		//Card 388
		document.getElementById("chkOverseasAddress").checked = false;		
		document.getElementById("cboCountry").selectedIndex=-1;
		document.getElementById("inpEmpCity").value="";
		document.getElementById("inpState").value="";
		document.getElementById("cboState").selectedIndex=-1;
		document.getElementById("inpPostCode").value="";
		document.getElementById("inpEmpPhone").value="";
		document.getElementById("inpEmpFax").value="";
		document.getElementById("employmenyYears").value="0";
		document.getElementById("employmenyMonths").value="0";
		document.getElementById("inpEmpGrossInc").value="0";
		document.getElementById("inpEmpNetInc").value="0";
		document.getElementById("cboEmprType").selectedIndex=-1;
		document.getElementById("chkEmpProb").checked = false;
		document.getElementById("trANZStaff").checked = false;
		
	}
	catch (e)
	{
		displayError(e,"ClearAllFields");
	}
}

//==============================================================
//	Function Name:	ClearDSOFields()
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Clears all the text boxes on the screen.
//==============================================================
function ClearDSOFields()
{
	try
	{

		if (G_FirstChange)
		{			
			G_FirstChange=false;
			return;
		}	
		
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmploymentType").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerType").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PrimaryEmployment").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("OccupationGroup").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("OccupationCode").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("PreviousEmployment").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("YearsInEmployment").text="0";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("MonthsInEmployment").text="0";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerName").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerAddress1").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerAddress2").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerAddress3").text="";
		//Card 388
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerOverseasAddress").text="0";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerCountry").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerCity").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerState").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerPostcode").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerPhoneNumber").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerFaxNumber").text="";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("GrossMonthlyIncome").text="0";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("NetMonthlyIncome").text="0";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("IncomeVerified").text="0";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("ProbationaryPeriod").text = "0";
		ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("ANZStaff").text = "0";
	}
	catch (e)
	{
		displayError(e,"ClearDSOFields()");
	}
}

//Start : Card 388
//==============================================================
//	Function Name:	SearchAddress
//	Parameters:		Nil
//	Return:			
//	Description:	
//==============================================================
function SearchAddress()
{
	try
	{
	
		var sCity = ds_EmpDtlsPopup.XMLDocument.documentElement.selectSingleNode("EmployerCity").text;
		if (!sCity) 
		{
			VBMsgBox("Please enter part of the city, town or suburb name into the 'City' field.", G_iVB_WARNING, G_sAPPLICATION_TITLE);
			return;
		}
		ds_AdrSearchRes.src=ds_AdrSearchRes.src;
		var oRes=ds_AdrSearchRes.XMLDocument.documentElement;
		oRes.removeChild(oRes.childNodes(0));
	
		sCity=sCity.toUpperCase();
		//WR1970 - Changed the hieght of divSearchList when the address window is opened from securities screen
		//document.all.divSearchList.style.height=(G_bSecAddress)? "180px":"195px";
		document.all.divSearchResults.style.display="block";
		tblEmplrStatus.style.display="none";
		tblEmplrInfo.style.display="none";
		tblEmplrIncome.style.display="none";		
		
		// ensure that no invalid ' string combinations appear in the search string for city
		sCity = sCity.replace(/"/g,'')
		var oSR= getRDRows('A_E_TSR_PC','starts-with(@C,"' + sCity + '")');
	
		var sPrompt="No records found.";
		if (oSR.length==0)
		{
			document.all.aSearchOK.focus();	
		}		
		else
		{
			tblAddrSearchHdr.style.width="100%";
			if (oSR.length==1)
			{
				sPrompt="1 record found:";
			}
			else
			{
				sPrompt=oSR.length + " records found:";
				if(oSR.length > 11)
					tblAddrSearchHdr.style.width="97%";
			}
		}
		document.all.spnRes.innerText=sPrompt;
	
		for (i=0; i<oSR.length; i++)
			oRes.appendChild(oSR(i).cloneNode(true));
	}
	catch (e)
	{
		displayError(e,"SearchAddress");
	}
}

//==============================================================
//	Function Name:	checkOverseasAddr
//	Parameters:		bSelect - (boolean) Flag select from file or screen
//	Return:			Nil
//	Description:	Handles over seas addresseses
//==============================================================
function checkOverseasAddr(bSelect)
{
	try
	{
		var oAdr = ds_EmpDtlsPopup.XMLDocument.documentElement;
	
		var bOS = (bSelect)? (oAdr.selectSingleNode("EmployerOverseasAddress").text=="-1"):document.all.chkOverseasAddress.status;
		DisableElement(document.all.cboCountry,bOS);
	
		document.all.inpState.style.display = (bOS)? "":"none";
		document.all.cboState.style.display = (bOS)? "none":"";
		document.all.aFind.style.display = (bOS)? "none":"";
		if (!bOS && !bSelect) oAdr.selectSingleNode("EmployerCountry").text="";
		if (!bSelect) oAdr.selectSingleNode("EmployerState").text="";
	}
	catch (e)
	{
		displayError(e,"checkOverseasAddr");
	}
}

//==============================================================
//	Function Name:	SelectRec
//	Parameters:		RecNo- (numeric) Record number of selected city
//	Return:			Nil
//	Description:	Set global variable of selected city from search
//==============================================================
function SelectRec(RecNo)
{
	G_selectedAdrRec = RecNo;
}

//==============================================================
//	Function Name:	closeIfEnter
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Selects the chosen city and closes the search table
//==============================================================
function closeIfEnter()
{
	if (event.keyCode==13 && G_selectedAdrRec>0) SelectCity(true);
}

//==============================================================
//	Function Name:	SelectCity
//	Parameters:		bOk - (boolean) flag for yes select the city
//	Return:			Nil
//	Description:	Takes the details of a city in the search table
//					and adds them to the address DSO.
//==============================================================
function SelectCity(bOk)
{
	try
	{
		divSearchResults.style.display="none";
		tblEmplrStatus.style.display="block";
		tblEmplrInfo.style.display="block";
		tblEmplrIncome.style.display="block";
		if (bOk && G_selectedAdrRec>0)
		{
			var oR=ds_AdrSearchRes.XMLDocument.documentElement.childNodes(G_selectedAdrRec-1);
			var oAdr = ds_EmpDtlsPopup.XMLDocument.documentElement
			oAdr.selectSingleNode("EmployerCity").text =oR.getAttribute("C");
			oAdr.selectSingleNode("EmployerState").text=oR.getAttribute("S");
			oAdr.selectSingleNode("EmployerPostcode").text =oR.getAttribute("P");
			document.getElementById('inpEmpPhone').focus();
		}
	}
	catch (e)
	{
		displayError(e,"SelectCity");
	}
}

//End : Card 388
