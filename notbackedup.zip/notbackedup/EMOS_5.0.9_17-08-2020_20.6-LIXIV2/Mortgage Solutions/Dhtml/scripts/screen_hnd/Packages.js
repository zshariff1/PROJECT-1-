//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//**Start Encode**
//
//	$Revision:   1.21  $
//	$Author:   Sidiq K  $
//	$Workfile:   packages.js  $
//	$Modtime:   Jul 11 2014 20:32:24  $	
//============================================================-->
//<SCRIPT>

//Global Variables
var G_bPackagesDirty = false; //flag indicating that the purpose details have been changed
var G_ValueChange = false;

function PackagesScreenShow() 
{
    try 
	{
        G_pScreenSaveFunction = SaveLoanPackagesValue;
		
        ds_packages.src = ds_packages.src;
        var oPackages = xml_master.XMLDocument.documentElement.selectSingleNode("//Packages");

        if (oPackages.hasChildNodes) {
            //retrieve AppDetails node if it's exists in application;
            var oRepl = ds_packages.XMLDocument.documentElement;
            //ds_packages.XMLDocument.replaceChild(oPackages.cloneNode(true), oRepl);
			LoadTransactionAcntHold(true);
        }
        else {
            //initilise dso
			LoadTransactionAcntHold(false);
            InitilizeAppBRS(ds_packages.XMLDocument.documentElement);
            SetPackageDirty();
        }
        
        have_breakfree();
        use_existingbf();
        require_newbreakfreepk(); 
		//19.6
		require_newbreakfreepkCC();
		check_breakfreetype();
		
		if(ds_packages.recordset.fields('PrimaryCardHolder') != null)
			var selectedValuetxt = ds_packages.recordset.fields('PrimaryCardHolder').value;
			if(selectedValuetxt != "") {
				UpdatePackCustCombo(selectedValuetxt);
			}
	}
    catch (e) 
	{
        displayError(e, "PackagesScreenShow");
    }
}


//Save the Packages Details
function SaveLoanPackagesValue(bNoReselect) 
{
    try
	{

        if (!G_bPackagesDirty) return;

        if (!G_bPackagesDirty) return;
        if (document.getElementById('inpuseexistingbf_Y').checked)
            ClearSDKFields();
			HideSDKFields();
        if (document.getElementById('inpreqnewbf_N').checked)
            ClearSDKFields();
			HideSDKFields();
		//Rel 19.6	
		if (document.getElementById('inpreqcc_N').checked) 
            		ClearSDKFields();
			HideSDKFields();
			
        if ((document.getElementById('inpbreakfreecard1').checked) || (document.getElementById('inpbreakfreecard3').checked) || (document.getElementById('inpbreakfreecard4').checked) || (document.getElementById('inpbreakfreecard5').checked))
            ClearNodeValues("QantasCardNumber");
			
		if ((document.getElementById('cbocustACH').value != "") && (document.getElementById('cbocustACH').value != "0")) {
			ClearAddCardHoldCtrl();
		}
        var oPackNode = ds_packages.XMLDocument.documentElement;
		if ((oPackNode.selectSingleNode("PrimaryCardHolder") != null) && (oPackNode.selectSingleNode("AdditionalCardHolderCustID") != null)) {
			if((oPackNode.selectSingleNode("PrimaryCardHolder").text) == (oPackNode.selectSingleNode("AdditionalCardHolderCustID").text)) {
				ClearNodeValues("AdditionalCardHolder");
				ClearNodeValues("AdditionalCardHolderCustID");
			}
		}
		
		//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
		enable_taxresidenttab_packagepage();
		//REL 18.1 New Code Ended
		
        var oNewPck = oPackNode.cloneNode(true);
        var oSavePck = xml_master.XMLDocument.documentElement;
        var oReplPck = oSavePck.selectSingleNode('Packages');
        // Move Packages details from stub xml to master xml
        oSavePck.replaceChild(oNewPck, oReplPck);   
        EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Packages"));
        EvaluateAppBRS(xml_master.XMLDocument.documentElement, true);
        FlushToDisk();
		
		
		// Added for Production Issue of TaxResident Details - Start
		var breakfree_type = document.getElementById("cboBreakfreeCard").value;
		var producttype = G_Product_Type;
		if ((producttype == "RC") || (breakfree_type == "New Credit Card"))
		{
			if((oPackNode.selectSingleNode("AdditionalCardHolderCustID") != null)){
				var oPckAddCardHoldID = oPackNode.selectSingleNode("AdditionalCardHolderCustID").text;
				G_ACHBrkFreeCard = oPckAddCardHoldID;
			}
			loadApplicationXML(G_sApplicationFilePath);
		}
		else {
			loadApplicationXML(G_sApplicationFilePath);
		}
		// Added for Production Issue of TaxResident Details - End
		
		require_newbreakfreepk(); 
		
		AddUpdLiability();
        CalculateBFCCTotals();
        G_bPackagesDirty = false;
        if (!bNoReselect) PackagesScreenShow();
    }
    catch (e) 
	{
        displayError(e, 'SaveLoanPackagesValue');
    }
}

//Check whether customer has existing Discount Package
function have_breakfree()
 {
    try 
	{  
        var hbreakfree = ds_packages.recordset.fields('HaveBreakFreePackage');
        if (hbreakfree == -1) {
            document.getElementById("useexistingbfsubscr").style.display = "block";
            document.getElementById("reqbfsubscr").style.display = "none";
			//New Code for not displaying the RequireANZAssuredFacility if user selects Yes
			document.getElementById("RequireANZAssuredFacility").style.display = "block";
			
        }
        else if (hbreakfree == -2) {
            document.getElementById("useexistingbfsubscr").style.display = "none";            
            document.getElementById("reqbfsubscr").style.display = "block";
            document.getElementById("reqnewbfsubscr").style.display = "none";
			//New Code for not displaying the RequireANZAssuredFacility if user selects No
			document.getElementById("RequireANZAssuredFacility").style.display = "none";	
			
			// CFDS - 561 Starts
			ClearNodeValues("DiscountPackage");
			ClearNodeValues("DiscountPackageDescription");
			// CFDS - 561 Ends
			
		    if (ds_packages.XMLDocument.documentElement.selectSingleNode("UseExistingPackage")) {
				ClearNodeValues("UseExistingPackage");
                
				//New Code
				document.getElementById("AssuredFacilitySelected").style.display = "none";
				document.getElementById("AssuredCoverTemporaryExpense").style.display = "none";	
				document.getElementById("Note").style.display = "none";
				document.getElementById("AssuredConsentToBeConsidered").style.display = "none"; 
            }
		}
        else {
            document.getElementById("useexistingbfsubscr").style.display = "none";
        }
		HideSDKFields();
    }
    catch (e) 
	{
        displayError(e, "have_breakfree");
    }
}
//Check whether customer wish to use existing package
function use_existingbf() 
{
    try 
	{
        var useexistingbf = ds_packages.recordset.fields('UseExistingPackage');
        
        if (useexistingbf == -1) {
            document.getElementById("reqnewbfsubscr").style.display = "none";
            document.getElementById("reqbfsubscr").style.display = "none"; 
					
            if (ds_packages.XMLDocument.documentElement.selectSingleNode("RequireNewPackage")) {
				ClearNodeValues("RequireNewPackage");
            }
			
			if (ds_packages.XMLDocument.documentElement.selectSingleNode("RequireCreditCard")) {
				ClearNodeValues("RequireCreditCard");
			}
			
            document.getElementById("Cardholderntype").style.display = "none";
	    //Card - 312 Starts
			document.getElementById("AdditionalCardHolderDet").style.display = "none"; 
			ClearAddCardHoldCtrl();
			document.getElementById("NominatedTransactionAccountType").style.display = "none";
				ClearTransactionActHold();
			document.getElementById("breakfreecardscr").style.display = "none";
            document.getElementById("breakfreeamountscr").style.display = "none";
            document.getElementById("anzqffscr").style.display = "none";
            document.getElementById("anzrewardsblackscr").style.display = "none";

            ds_packages.recordset.fields('DiscountPackage') = "PSPX"
            ds_packages.recordset.fields('DiscountPackageDescription') = "Existing Breakfree"
			
			//New Code for displaying the RequireANZAssuredFacility if user selects No
			document.getElementById("RequireANZAssuredFacility").style.display = "block";
        }
        else if (useexistingbf == -2) {
        document.getElementById("reqnewbfsubscr").style.display = "block";
        ds_packages.recordset.fields('DiscountPackage') = "";
        ds_packages.recordset.fields('DiscountPackageDescription') = "";
		
		//New Code for not displaying the AssuredCoverTemporaryExpense & Note
		document.getElementById("RequireANZAssuredFacility").style.display = "none";
		document.getElementById("AssuredFacilitySelected").style.display = "none";
		document.getElementById("AssuredCoverTemporaryExpense").style.display = "none";
		document.getElementById("Note").style.display = "none";
		document.getElementById("AssuredConsentToBeConsidered").style.display = "none";
        }
    }
    catch (e) 
	{
        displayError(e, "use_existingbf");
    }
}
//Check whether the customer needs new package
function require_newbreakfreepk() 
{
    try 
	{
		
		var reqbreakfree = ds_packages.recordset.fields('RequireNewPackage');
		var reqbreakfreeCC = ds_packages.recordset.fields('RequireCreditCard'); 						

        var oCusts = xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer")
        for (var i = 0; i < oCusts.length; i++) {
            var selCustomerType = oCusts(i).selectSingleNode("CustomerType").text;
        }
		
		if (reqbreakfreeCC == -1) 
		{
            document.getElementById("Cardholderntype").style.display = "block";			
			//AdditionalCardHolderType - Card 312 Starts
			document.getElementById("AdditionalCardHolderDet").style.display = "block";
			PopulatePackCustCombo(cbocustACH);
			if(ds_packages.recordset.fields('AdditionalCardHolder') == "Not In Application")
			{
				document.getElementById("AdditionalCardHolderType").style.display = "block";
			} 
			else
			{
				ClearAddCardHoldCtrl();
			}
            //Rel 19.6			
			
			var objel_cboBfCard = document.getElementById("cboBreakfreeCard").value;
			var ds_brkfrtype;
			if(ds_packages.XMLDocument.documentElement.selectSingleNode("BreakFreeType") != null)
			{
				ds_brkfrtype = ds_packages.XMLDocument.documentElement.selectSingleNode("BreakFreeType").text;
			}
			
			if ((objel_cboBfCard == "Existing Card - No Change") || (ds_brkfrtype == "Existing Card - No Change"))
			{
				document.getElementById("breakfreecardscr").style.display = "none";
			}
			else if (((ds_brkfrtype == "New Credit Card")) || (objel_cboBfCard == "New Credit Card") || (objel_cboBfCard == "Existing Card - Change to Platinum or Black") || (ds_brkfrtype == "Existing Card - Change to Platinum or Black"))
			{
				document.getElementById("breakfreecardscr").style.display = "block";
			}
			
            document.getElementById("breakfreeamountscr").style.display = "block";
			document.getElementById("NominatedTransactionAccountType").style.display="block";
			// Commented for 19.7 Release
			//PopulatePackCustCombo(cboTransaAcntHold); 
			
			ds_packages.recordset.fields('DiscountPackage') = "PSPW"
            ds_packages.recordset.fields('DiscountPackageDescription') = "New Breakfree"
			
            populateList("A_TS_BREAKFREECARD_CODES", document.all.cboBreakfreeCard, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);
            populateList("A_TS_CREDITCARD_CODES", document.all.cboCreditCard, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);
            populatePholderCombo();
			
			// New Code for making fields Visible / Invisible based on Yes / No values
			document.getElementById("RequireANZAssuredFacility").style.display = "block";
			var RAAF = ds_packages.recordset.fields('RequireANZAssuredFacility');
			var TE = ds_packages.recordset.fields('AssuredCoverTemporaryExpense');
			var AAF = ds_packages.recordset.fields('AssuredFacilitySelected');
			var CAPR = ds_packages.recordset.fields('AssuredConsentToBeConsidered');
			if (RAAF == -1)
			{
				document.getElementById("AssuredCoverTemporaryExpense").style.display = "block";
				if (TE == -1)
				{
					document.getElementById("AssuredFacilitySelected").style.display = "block";
				
					if (AAF == 1000)
					{
						document.getElementById("AssuredConsentToBeConsidered").style.display = "block";
					}
					else if (AAF == 0 || AAF == 500)
					{
						document.getElementById("AssuredConsentToBeConsidered").style.display = "none";
					}
					
				}
				else if (TE == -2)
				{
					document.getElementById("AssuredCoverTemporaryExpense").style.display = "block";
					document.getElementById("Note").style.display = "block";
				}
				
			}
			/*
			else if (RAAF == -2)
			{
				document.getElementById("Note").style.display = "block";
			}
			*/
        }
        else if (reqbreakfreeCC == -2)
		{			
			var vhbreakfree = ds_packages.recordset.fields('HaveBreakFreePackage');
            ds_packages.recordset.fields('DiscountPackage') = ""
            ds_packages.recordset.fields('DiscountPackageDescription') = ""
	    document.getElementById("AdditionalCardHolderDet").style.display = "none"; 
	    ClearAddCardHoldCtrl();
	    document.getElementById("NominatedTransactionAccountType").style.display="block"; //19.6
			
            if (vhbreakfree == -2) {
                ds_packages.recordset.fields('DiscountPackage') = "";
                ds_packages.recordset.fields('DiscountPackageDescription') = "";
				
            }
            HideSDKFields();
			// Commented for 19.7 Release
			//PopulatePackCustCombo(cboTransaAcntHold); // Rel 19.6
			
			// New Code for making fields Visible / Invisible based on Yes / No values
			document.getElementById("RequireANZAssuredFacility").style.display = "block";	
			
			var anzAssured = ds_packages.recordset.fields('RequireANZAssuredFacility');
			var tempExp = ds_packages.recordset.fields('AssuredCoverTemporaryExpense');
			var assuredSelected = ds_packages.recordset.fields('AssuredFacilitySelected');
			if (anzAssured==-1){
			document.getElementById("AssuredCoverTemporaryExpense").style.display = "block";	
			
				if(tempExp==-1)
				//document.getElementById("Note").style.display = "block";
				document.getElementById("AssuredFacilitySelected").style.display = "block";
					
					if(assuredSelected==1000)
					{
							document.getElementById("AssuredConsentToBeConsidered").style.display = "block";
					}
					else if(assuredSelected== 500 || assuredSelected==0)
					{
						document.getElementById("AssuredConsentToBeConsidered").style.display = "none";
					}
				
				else if(tempExp==-2)
				{
					document.getElementById("AssuredFacilitySelected").style.display = "none";
					document.getElementById("Note").style.display = "block";
				}
				
				//document.getElementById("AssuredConsentToBeConsidered").style.display = "block";
			}
			else if(anzAssured=-2)
			{
				document.getElementById("AssuredCoverTemporaryExpense").style.display = "none";
				document.getElementById("Note").style.display = "none";
				document.getElementById("AssuredFacilitySelected").style.display = "none";
				document.getElementById("AssuredConsentToBeConsidered").style.display = "none";
			}			
			
			var RAAF = ds_packages.recordset.fields('RequireANZAssuredFacility');
			var TE = ds_packages.recordset.fields('AssuredCoverTemporaryExpense');
			var AAF = ds_packages.recordset.fields('AssuredFacilitySelected');
			var CAPR = ds_packages.recordset.fields('AssuredConsentToBeConsidered');			
        }
		else
		{
			ds_packages.recordset.fields('RequireCreditCard').value = 0;
			// CFDS - 561 Starts
			ClearNodeValues("DiscountPackage");
			ClearNodeValues("DiscountPackageDescription");
			// CFDS - 561 Ends
			ClearTransactionActHold();
		}	
    }
    catch (e) 
	{
        displayError(e, "require_newbreakfreepk");
    }
}

//Rel 19.6  start
function require_newbreakfreepkCC() 
{
    try 
	{		
		var HaveBreakFreePackageCC = ds_packages.recordset.fields('HaveBreakFreePackage');
		var UseExistingPackageCC = ds_packages.recordset.fields('UseExistingPackage');
		var RequireNewPackageCC = ds_packages.recordset.fields('RequireNewPackage');
		var RequireCreditCardCC = ds_packages.recordset.fields('RequireCreditCard');
		
        var oCusts = xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer")
        for (var i = 0; i < oCusts.length; i++) {
            var selCustomerType = oCusts(i).selectSingleNode("CustomerType").text;
        }
		
			// Release 19.6 - display color
			if (HaveBreakFreePackageCC == -1 && UseExistingPackageCC == -2 && RequireNewPackageCC == -1) {            			
				document.getElementById("trReqccd").className="tblHilite2";
				document.getElementById("inpreqcc_Y").className="tblHilite2";
				document.getElementById("inpreqcc_N").className="tblHilite2";
				
				document.getElementById("PrimaryCardHolderName").className="tblHilite3";
				document.getElementById("breakfreeType").className="tblHilite2";
				document.getElementById("trCreditCard").className="tblHilite3";
				
				//Eligible Credit Card starts
				document.getElementById("eligible").className="tblHilite2";
				document.getElementById("tr1").className="tblHilite2";
				document.getElementById("inpbreakfreecard1").className="tblHilite2";
				document.getElementById("inpbreakfreecard2").className="tblHilite2";
				
				document.getElementById("tr2").className="tblHilite2";
				document.getElementById("inpbreakfreecard3").className="tblHilite2";
				document.getElementById("inpbreakfreecard4").className="tblHilite2";
				
				document.getElementById("tr3").className="tblHilite2";
				document.getElementById("inpbreakfreecard7").className="tblHilite2";
				document.getElementById("inpbreakfreecard5").className="tblHilite2";
				
				document.getElementById("tr4").className="tblHilite2";
				document.getElementById("inpbreakfreecard6").className="tblHilite2";
				//Eligible Credit Card ends
			}
			
			else if(HaveBreakFreePackageCC == -2 && RequireNewPackageCC == -1)
			{
				document.getElementById("trReqccd").className="tblHilite3";
				document.getElementById("inpreqcc_Y").className="tblHilite3";
				document.getElementById("inpreqcc_N").className="tblHilite3";
				
				document.getElementById("PrimaryCardHolderName").className="tblHilite2";
				document.getElementById("breakfreeType").className="tblHilite3";
				document.getElementById("trCreditCard").className="tblHilite2";
				
				//Eligible Credit Card starts
				document.getElementById("eligible").className="tblHilite3";
				document.getElementById("tr1").className="tblHilite3";
				document.getElementById("inpbreakfreecard1").className="tblHilite3";
				document.getElementById("inpbreakfreecard2").className="tblHilite3";
				
				document.getElementById("tr2").className="tblHilite3";
				document.getElementById("inpbreakfreecard3").className="tblHilite3";
				document.getElementById("inpbreakfreecard4").className="tblHilite3";
				
				document.getElementById("tr3").className="tblHilite3";
				document.getElementById("inpbreakfreecard7").className="tblHilite3";
				document.getElementById("inpbreakfreecard5").className="tblHilite3";
				
				document.getElementById("tr4").className="tblHilite3";
				document.getElementById("inpbreakfreecard6").className="tblHilite3";
				//Eligible Credit Card ends
			}
		
		
        if (HaveBreakFreePackageCC == -1 && UseExistingPackageCC == -2 && RequireNewPackageCC == -1) {            			
			document.getElementById("reqccd").style.display="block";	
        }
		
		else if(HaveBreakFreePackageCC == -2 && RequireNewPackageCC == -1 ){
			document.getElementById("reqccd").style.display="block";
		}
        else{ 			
			document.getElementById("reqccd").style.display="none";			
			ds_packages.recordset.fields('RequireCreditCard').value = "";			
		}
    }
    catch (e) 
	{
        displayError(e, "require_newbreakfreepkCC");
    }
}

function ClearCC()
{
	document.getElementById("inpreqcc_Y").checked = false;	
	document.getElementById("inpreqcc_N").checked = false;
	//ds_packages.XMLDocument.documentElement.selectSingleNode("RequireCreditCard");
	
}


//Rel 19.6  End

//Populate the list of customer in the Primary card holder
function populatePholderCombo() 
{
    try 
	{
        var df = cboprimarycardholder.dataFld;
        var ds = cboprimarycardholder.dataSrc;
        cboprimarycardholder.dataFld = "";
        cboprimarycardholder.dataSrc = "";

        // clear list
        for (i = cboprimarycardholder.options.length - 1; i >= 0; i--)
            cboprimarycardholder.options.remove(i);

        var emptopt = document.createElement("OPTION");
        cboprimarycardholder.options.add(emptopt);
        emptopt.value = "";
        emptopt.innerText = "";

        var oCusts = xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer")
        for (var i = 0; i < oCusts.length; i++) {
            var sID = oCusts(i).selectSingleNode("CustomerID").text;
            var sName = oCusts(i).selectSingleNode("CustomerName").text;
            var opt = document.createElement("OPTION");
            cboprimarycardholder.options.add(opt);
            opt.value = sID;
            opt.innerText = sName;
        }

        cboprimarycardholder.dataSrc = ds;
        cboprimarycardholder.dataFld = df;
    }
    catch (e) 
	{
        displayError(e, 'populatePholderCombo');
    }
}

//Populate the list of customer in the Additional card holder
function populateAholderCombo() 
{
    try 
	{
        var df = cboadditionalcardholder.dataFld;
        var ds = cboadditionalcardholder.dataSrc;
        cboadditionalcardholder.dataFld = "";
        cboadditionalcardholder.dataSrc = "";

        // clear list
        for (i = cboadditionalcardholder.options.length - 1; i >= 0; i--)
            cboadditionalcardholder.options.remove(i);

        var emptopt = document.createElement("OPTION");
        cboadditionalcardholder.options.add(emptopt);
        emptopt.value = "";
        emptopt.innerText = "";

        var oCusts = xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer")
        for (var i = 0; i < oCusts.length; i++) {
            var sID = oCusts(i).selectSingleNode("CustomerID").text;
            var sName = oCusts(i).selectSingleNode("CustomerName").text;
            var opt = document.createElement("OPTION");
            cboadditionalcardholder.options.add(opt);
            opt.value = sName;
            opt.innerText = sName;
        }

        cboadditionalcardholder.dataSrc = ds;
        cboadditionalcardholder.dataFld = df;
    }
    catch (e) 
	{
        displayError(e, 'populateAholderCombo');
    }
}
//check the fields mandatory if the BreakFreeCard is ANZ Rewards Black
function check_carddeclaration()
 {
    try
	{
        var cardtype = ds_packages.recordset.fields('BreakFreeCard');
        if (cardtype == -2) {
            var oPck = (ds_packages.XMLDocument.documentElement.selectSingleNode("BreakFreeType"))
            document.getElementById("anzrewardsblackscr").style.display = "none";
            if (oPck && (oPck.text == "New Credit Card")) {
                document.getElementById("anzqffscr").style.display = "block";                
            }
        }
        else if (cardtype == -5) {
            document.getElementById("anzrewardsblackscr").style.display = "block";
            document.getElementById("anzqffscr").style.display = "none";
        }
        else if (cardtype == -6) {
            var oPck = (ds_packages.XMLDocument.documentElement.selectSingleNode("BreakFreeType"))
            document.getElementById("anzrewardsblackscr").style.display = "block";
            if (oPck && (oPck.text == "New Credit Card")) {
                document.getElementById("anzqffscr").style.display = "block";                
            }
        }
        else {
            document.getElementById("anzqffscr").style.display = "none";
            document.getElementById("anzrewardsblackscr").style.display = "none";
        }
    }
    catch (e)
	{
        displayError(e, "check_carddeclaration");
    }
}
function check_breakfreetype()
 {
	try
	{
		var oPck = (ds_packages.XMLDocument.documentElement.selectSingleNode("BreakFreeType"));
		var oPckRCC = (ds_packages.XMLDocument.documentElement.selectSingleNode("RequireCreditCard"));
		
		if (oPck && (oPck.text == "Existing Card - No Change")) {
			ds_packages.recordset.fields('DiscountPackage') = "PSPW"
			ds_packages.recordset.fields('DiscountPackageDescription') = "New Breakfree"
			document.all.CC_Limit.value = "0";
			document.all.CC_Limit.disabled = true;
			document.all.breakfreecard.value = "0";
			document.getElementById("breakfreecardscr").style.display = "none";
			document.getElementById("trCreditCard").style.display = "none";
			
		}
		if (oPck && (oPck.text == "New Credit Card" || oPck.text == "Existing Card - Change to Platinum or Black")) {
			ds_packages.recordset.fields('DiscountPackage') = "PSPW"
			ds_packages.recordset.fields('DiscountPackageDescription') = "New Breakfree"
			document.all.CC_Limit.disabled = false;
			if(oPckRCC.text == -1 ){
				document.getElementById("breakfreecardscr").style.display = "block";
				document.getElementById("trCreditCard").style.display = "block";
			}
		}
		if (oPck && (oPck.text == "Existing Card - No Change" || oPck.text == "Existing Card - Change to Platinum or Black")) {
			document.getElementById("anzqffscr").style.display = "none";
		}
		check_carddeclaration();
	}
	catch(e)
	{
		displayError(e,"check_breakfreetype");
	}
}

function check_creditcardtype() 
{
    var oPck = (ds_packages.XMLDocument.documentElement.selectSingleNode("CreditCardType"))
    ds_packages.XMLDocument.documentElement.selectSingleNode("BreakFreeCard").text = "";
    if (oPck && (oPck.text == "Rewards cards with flexible rewards options")) {
        document.all.inpbreakfreecard1.disabled = true;
        document.all.inpbreakfreecard2.disabled = true;
        document.all.inpbreakfreecard3.disabled = false;
		document.all.inpbreakfreecard4.disabled = true;
        document.all.inpbreakfreecard5.disabled = false;
		document.all.inpbreakfreecard6.disabled = true;
		document.all.inpbreakfreecard7.disabled = false;
		
		document.all.inpbreakfreecard1.checked = false;
        document.all.inpbreakfreecard2.checked = false;
        document.all.inpbreakfreecard4.checked = false;
        document.all.inpbreakfreecard6.checked = false;
		
		document.getElementById("creditcarddisclaimertext").innerHTML="Note: These Cards incur an additional Rewards Program Services Fee";
    }
    if (oPck && (oPck.text == "ANZ Frequent Flyer cards with Qantas points")) {
        document.all.inpbreakfreecard1.disabled = true;
        document.all.inpbreakfreecard2.disabled = false;
		document.all.inpbreakfreecard3.disabled = true;
        document.all.inpbreakfreecard4.disabled = true;
        document.all.inpbreakfreecard5.disabled = true;
        document.all.inpbreakfreecard6.disabled = false;
        document.all.inpbreakfreecard7.disabled = true;
		
		document.all.inpbreakfreecard1.checked = false;
        document.all.inpbreakfreecard3.checked = false;
        document.all.inpbreakfreecard4.checked = false;
        document.all.inpbreakfreecard5.checked = false;
        document.all.inpbreakfreecard7.checked = false;
        
		document.getElementById("creditcarddisclaimertext").innerHTML="Note: These Cards incur an additional Rewards Program Services Fee";
    }
	if (oPck && (oPck.text == "A card with a low ongoing interest rate on everyday purchases")) {
        document.all.inpbreakfreecard1.disabled = true;
        document.all.inpbreakfreecard2.disabled = true;
        document.all.inpbreakfreecard3.disabled = true;
        document.all.inpbreakfreecard4.disabled = false;
		document.all.inpbreakfreecard5.disabled = true;
        document.all.inpbreakfreecard6.disabled = true;
        document.all.inpbreakfreecard7.disabled = true;
		
		document.all.inpbreakfreecard1.checked = false;
        document.all.inpbreakfreecard2.checked = false;
        document.all.inpbreakfreecard3.checked = false;
        document.all.inpbreakfreecard5.checked = false;
        document.all.inpbreakfreecard6.checked = false;
		document.all.inpbreakfreecard7.checked = false;
		
		document.getElementById("creditcarddisclaimertext").innerHTML="";
    }
    if (oPck && (oPck.text == "Simple Everyday card")) {
        document.all.inpbreakfreecard1.disabled = false;
		document.all.inpbreakfreecard2.disabled = true;
        document.all.inpbreakfreecard3.disabled = true;
        document.all.inpbreakfreecard4.disabled = false;
		document.all.inpbreakfreecard5.disabled = true;
        document.all.inpbreakfreecard6.disabled = true;
        document.all.inpbreakfreecard7.disabled = true;
		
		document.all.inpbreakfreecard2.checked = false;
        document.all.inpbreakfreecard3.checked = false;
        document.all.inpbreakfreecard5.checked = false;
        document.all.inpbreakfreecard6.checked = false;
		document.all.inpbreakfreecard7.checked = false;
		
		document.getElementById("creditcarddisclaimertext").innerHTML="";
    }
    if (oPck && (oPck.text == "All cards")) {
        document.all.inpbreakfreecard1.disabled = false;
		document.all.inpbreakfreecard2.disabled = false;
        document.all.inpbreakfreecard3.disabled = false;
        document.all.inpbreakfreecard4.disabled = false;
        document.all.inpbreakfreecard5.disabled = false;
        document.all.inpbreakfreecard6.disabled = false;
        document.all.inpbreakfreecard7.disabled = false;
	
		document.getElementById("creditcarddisclaimertext").innerHTML="Note: Some Cards incur an additional Rewards Program Services Fee";
    }
    check_carddeclaration();
}

//Set the flag for save the packages details
function SetPackageDirty()
{
    G_bPackagesDirty = true;
}

//==============================================================
// Card - 312 Starts
//	Name:		ValPKGDateOfBirth 
//	Purpose:	Validates Package Customer date of birth
//	Return:		boolean - true, if date of birth is valid,
//							otherwise - false
//==============================================================
function ValPkgDateOfBirth(oPackages)
{
	try
	{
		if((oPackages.selectSingleNode("AdditionalCardHolderFirstName") != null) || (oPackages.selectSingleNode("AdditionalCardHolderMiddleName") != null) || (oPackages.selectSingleNode("AdditionalCardHolderSurname") != null))
		{	
			var oPckFirstNam = oPackages.selectSingleNode("AdditionalCardHolderFirstName").text;
			var oPckMidNam = oPackages.selectSingleNode("AdditionalCardHolderMiddleName").text;
			var oPckSurNam = oPackages.selectSingleNode("AdditionalCardHolderSurname").text;
			
			if(((oPckFirstNam != '') && (oPckFirstNam != undefined)) || ((oPckMidNam != '') && (oPckMidNam != undefined)) || ((oPckSurNam != '') 
			&& (oPckSurNam != undefined)))
			{
					if((oPackages.selectSingleNode("AdditionalCardHolderDateOfBirth")!= null))
					var oPckDOB = oPackages.selectSingleNode("AdditionalCardHolderDateOfBirth").text;
					if((oPckDOB != '') && (oPckDOB != undefined))
					{
							var re = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
							if((oPckDOB.match(re)))
							{
								return (VBValidateAge18(oPckDOB));
							}
							else 
							{
								oPackages.selectSingleNode("AdditionalCardHolderDateOfBirth").text = "";
								return false;
							}
							
					}
			}
			else
			{
				oPackages.selectSingleNode("AdditionalCardHolderDateOfBirth").text = "";
				return true;
			}
		}	
			
	}
	catch(e)
	{
		displayError(e,"ValPkgDateOfBirth");
	}
}
// Card - 312 Ends


//==============================================================
// Card - 312 Starts
//	Name:		ValPKGAdditionalCardHolder
//	Purpose:	Validates Package AdditionalCardHolder
//	Return:		boolean - true, if value's are valid,
//							otherwise - false
//==============================================================
function ValPKGAdditionalCardHolder(oPackages)
{
	try
	{
		var valid_ACH;
		if((oPackages.selectSingleNode("AdditionalCardHolderCustID") != null)){
			var oPckAddCardHoldID = oPackages.selectSingleNode("AdditionalCardHolderCustID").text;
			if(((oPckAddCardHoldID != '') && (oPckAddCardHoldID != undefined) && (oPckAddCardHoldID == "0"))){
			
				if((oPackages.selectSingleNode("AdditionalCardHolderFirstName") != null) || 
					(oPackages.selectSingleNode("AdditionalCardHolderMiddleName") != null) || 
						(oPackages.selectSingleNode("AdditionalCardHolderSurname") != null) ||
							(oPackages.selectSingleNode("AdditionalCardHolderTitle") != null) ||
								(oPackages.selectSingleNode("AdditionalCardHolderDateOfBirth") != null))
					{
					
						var oPckFirstNam = oPackages.selectSingleNode("AdditionalCardHolderFirstName").text;
						var oPckMidNam = oPackages.selectSingleNode("AdditionalCardHolderMiddleName").text;
						var oPckSurNam = oPackages.selectSingleNode("AdditionalCardHolderSurname").text;
						var oPckTitle = oPackages.selectSingleNode("AdditionalCardHolderTitle").text;
						var oPckDOB = oPackages.selectSingleNode("AdditionalCardHolderDateOfBirth").text;
							if(((oPckFirstNam != '') && (oPckFirstNam != undefined)) || ((oPckMidNam != '') && (oPckMidNam != undefined)) || 
								((oPckSurNam != '') && (oPckSurNam != undefined)) && ((oPckTitle != '') && (oPckTitle != undefined)) &&
									((oPckDOB != '') && (oPckDOB != undefined)))
							{
								valid_ACH = true;
							}
							else
							{
								oPackages.selectSingleNode("AdditionalCardHolderTitle").text = "";
								oPackages.selectSingleNode("AdditionalCardHolderFirstName").text = "";
								oPackages.selectSingleNode("AdditionalCardHolderMiddleName").text = "";
								oPackages.selectSingleNode("AdditionalCardHolderSurname").text = "";
								oPackages.selectSingleNode("AdditionalCardHolderDateOfBirth").text = "";
								valid_ACH = false;
							}
					}
					else
					{
						valid_ACH = true;
					}
			}
			else
			{
				oPackages.selectSingleNode("AdditionalCardHolderTitle").text = "";
				oPackages.selectSingleNode("AdditionalCardHolderFirstName").text = "";
				oPackages.selectSingleNode("AdditionalCardHolderMiddleName").text = "";
				oPackages.selectSingleNode("AdditionalCardHolderSurname").text = "";
				oPackages.selectSingleNode("AdditionalCardHolderDateOfBirth").text = "";
				valid_ACH = true;
			}
		}
		else
		{
			valid_ACH = true;
		}
		return valid_ACH;
	}
	catch(e)
	{
		displayError(e,"ValPKGAdditionalCardHolder");
	}
}
// Card - 312 Ends


//Clear the xml nodes
function ClearSDKFields(sFlag) 
{
    try 
	{      
		ClearNodeValues("PrimaryCardHolder");
		ClearNodeValues("PrimaryCardHolderName");
		ClearNodeValues("AdditionalCardHolder");
		ClearNodeValues("AdditionalCardHolderCustID");
		ClearNodeValues("BreakFreeType");
		ClearNodeValues("BreakFreeCard");
		ClearNodeValues("BreakFreeAmount");
		ClearNodeValues("AnzBlockCardDec");
		ClearNodeValues("QantasCardNumber");
		ClearNodeValues("CreditCardType");
		
		// Commented for 19.7 - 19.6 - Starts
		/*var reqbreakfreeCreditCard = ds_packages.recordset.fields('RequireCreditCard');
		if((document.getElementById("inpreqcc_N").checked == false) || (reqbreakfreeCreditCard != -2))
		{
			ClearNodeValues("TransactionAccountHolderCustID");
			ClearNodeValues("TransactionAccountHolder");
			ClearNodeValues("AccountType");
		}*/
		// Commented for 19.7 - 19.6 - Ends
		
    }
    catch (e) 
	{
        displayError(e, "ClearSDKFields()");
    }
}

function HideSDKFields()
{
	try 
	{ 
		document.getElementById("Cardholderntype").style.display = "none";
		//AdditionalCardHolderType - 312 
		
		var reqbreakfreeCreditCard = ds_packages.recordset.fields('RequireCreditCard');
		//Rel 19.6
		if((document.getElementById("inpreqcc_Y").checked) || (document.getElementById("inpreqcc_N").checked) || (reqbreakfreeCreditCard== -2))
		{
			document.getElementById("NominatedTransactionAccountType").style.display = "block"; 
			document.getElementById("breakfreeamountscr").style.display = "block"; 
			document.getElementById("RequireANZAssuredFacility").style.display = "block"; 
		}
		else
		{
			document.getElementById("NominatedTransactionAccountType").style.display = "none"; 
			ClearTransactionActHold();
			document.getElementById("breakfreeamountscr").style.display = "none";
			document.getElementById("RequireANZAssuredFacility").style.display = "none"; 
		}
		
		document.getElementById("AdditionalCardHolderDet").style.display = "none"; 
		document.getElementById("AdditionalCardHolderType").style.display = "none";
		document.getElementById("breakfreecardscr").style.display = "none";
		document.getElementById("breakfreeamountscr").style.display = "none";
		document.getElementById("anzqffscr").style.display = "none";
		document.getElementById("anzrewardsblackscr").style.display = "none";
		}
			
    catch (e) 
	{
        displayError(e, "HideSDKFiles()");
    }
}

//Release 19.6
function HideOptionalCC()
{
	if ((document.getElementById("NominatedTransactionAccountType") != undefined) && (document.getElementById("NominatedTransactionAccountType") != null))
	{	
		document.getElementById("NominatedTransactionAccountType").style.display="none";
		ClearTransactionActHold();
	}
	
	if ((document.getElementById("RequireANZAssuredFacility") != undefined) && (document.getElementById("RequireANZAssuredFacility") != null))
	{	
		document.getElementById("RequireANZAssuredFacility").style.display="none";
	}	
}



/*
The below function ClearOtherQuestion clears all the selection values when user clicks Yes/No again for the question "Does the customer have an existing Breakfree Package?<" 
Issue was happening when user select the option until CreditCard and clicking "Yes/No" for the above question and the values for some fileds was retaining and screen was not behaving properly.
*/
function ClearOtherQuestion()
{
		ClearNodeValues("RequireNewPackage");
		ClearNodeValues("PrimaryCardHolder");
		ClearNodeValues("PrimaryCardHolderName");
		ClearNodeValues("AdditionalCardHolder");
		ClearNodeValues("AdditionalCardHolderCustID");
		ClearNodeValues("AdditionalCardHolderTitle");
		ClearNodeValues("AdditionalCardHolderFirstName");
		ClearNodeValues("AdditionalCardHolderMiddleName");
		ClearNodeValues("AdditionalCardHolderSurname");
		ClearNodeValues("AdditionalCardHolderDateOfBirth");
		ClearNodeValues("AccountType");
		ClearNodeValues("ChargeFeeToThisAccount");
		ClearNodeValues("BreakFreeType");
		ClearNodeValues("BreakFreeCard");
		ds_packages.XMLDocument.documentElement.selectSingleNode("BreakFreeAmount").text = 0;
		ClearNodeValues("AnzBlockCardDec");
		ClearNodeValues("QantasCardNumber");
		ClearNodeValues("CreditCardType");
	    		
}

//New Code Begin BreakFree Changes added on 28/02/2018 
//==============================================================
//	Name:		Visible/Invisible Packages tab new fields
//	Purpose:	Visible/Invisible Packages tab new fields
//	Parameters:	RAAF (-1/-2)
//==============================================================
function Require_ANZAssuredFacility(RAAF) 
{
	try 
	{  
		if (RAAF == -1) 
		{
			document.getElementById("AssuredCoverTemporaryExpense").style.display = "block";
			document.getElementById("Note").style.display = "none";
			document.getElementById("AssuredFacilitySelected").style.display = "none"; 
			document.getElementById("AssuredConsentToBeConsidered").style.display = "none"; 
        }
        else if (RAAF == -2) 
		{
            document.getElementById("AssuredCoverTemporaryExpense").style.display = "none";
			document.getElementById("Note").style.display = "none";
			document.getElementById("AssuredFacilitySelected").style.display = "none"; 
			document.getElementById("AssuredConsentToBeConsidered").style.display = "none"; 
        }    
    }
    catch (e) 
	{
        displayError(e, "Require_ANZAssuredFacility");
    }
}

//New Code Begin BreakFree Changes added on 28/02/2018 
//==============================================================
//	Name:		Visible/Invisible Packages tab new fields
//	Purpose:	Visible/Invisible Packages tab new fields
//	Parameters:	RCTE (-1/-2)
//==============================================================
function Required_Cover_for_Temporary_Expenses(RCTE) 
{
	try 
	{ 
		if (RCTE == -1) {	
			document.getElementById("Note").style.display = "none";
			document.getElementById("AssuredFacilitySelected").style.display = "block"; 
			document.getElementById("AssuredConsentToBeConsidered").style.display = "none"; 
        }
        else if (RCTE == -2) {
			document.getElementById("Note").style.display = "block";
			document.getElementById("AssuredFacilitySelected").style.display = "none"; 
			document.getElementById("AssuredConsentToBeConsidered").style.display = "none"; 
        } 
	}
	catch (e) 
	{
        displayError(e, "Required_Cover_for_Temporary_Expenses");
    }	
}

//New Code Begin BreakFree Changes added on 28/02/2018 
//==============================================================
//	Name:		Visible/Invisible Packages tab new fields
//	Purpose:	Visible/Invisible Packages tab new fields
//	Parameters:	AAF (500/1000)
//==============================================================
function ANZAssuredFacility(AAF) 
{
	try 
	{ 
		if (AAF == 500 || AAF == 0) {
			document.getElementById("AssuredConsentToBeConsidered").style.display = "none"; 
        }
        else if (AAF == 1000) {
            document.getElementById("AssuredConsentToBeConsidered").style.display = "block"; 
        }    
    }
    catch (e) 
	{
        displayError(e, "ANZAssuredFacility");
    }
}

//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//==============================================================
//	Name:		Enable/Disabled Tax Residence Details tab
//	Purpose:	Disables/Enables Tax Residence Details tab
//	Parameters:	Blank / Non Blank
//==============================================================
function enable_taxresidenttab_packagepage()
{	
	try
	{
		var have_breakfree;
		if (document.getElementById("inphavebfpackage_Y").checked == true)
			have_breakfree = document.getElementById("inphavebfpackage_Y").value;
		else
			have_breakfree = "-2";
			
		var breakfree_type = document.getElementById("cboBreakfreeCard").value;
		var producttype = G_Product_Type;   //document.getElementById("lbProductType").value;
		
		G_breakfree_Type= breakfree_type;
		G_havebreakfree = have_breakfree;
		if (producttype == "RC" || (breakfree_type == "New Credit Card"))
		{	
			//alert("IN PACK");
			DisableElement(document.getElementById("inpAustralia_Y"), true);
			DisableElement(document.getElementById("inpAustralia_N"), true);
			G_Sub_Prd_Typ=2;	
		}
		else
		{	
			//alert("IN PACK-2");
			var oCustDocEl = ds_cust.XMLDocument.documentElement;
			//oCustDocEl.selectSingleNode("TaxResidentAustralia").text = "";G_Tax = "";
			DisableElement(document.getElementById("inpAustralia_Y"), false);
			DisableElement(document.getElementById("inpAustralia_N"), false);
			DeleteTaxResidentRecords();			
			G_Sub_Prd_Typ=3;				
		}
	}
	catch(e)
	{
		displayError(e,"enable_taxresidenttab_packagepage");
	}
}
//REL 18.1 New Code Ended

//New Code Begin BreakFree Changes added on 03/02/2018 
//==============================================================
//	Name:		Clear Packages tab new fields
//	Purpose:	Visible/Invisible Packages tab new fields
//	Parameters:	Blank
//==============================================================
function ClearPackagesDependencyQuestions_Field0()
{
	ClearNodeValues("RequireANZAssuredFacility");
	ClearNodeValues("AssuredCoverTemporaryExpense");
	ClearNodeValues("AssuredFacilitySelected");
	ClearNodeValues("AssuredConsentToBeConsidered");
}

//Release 19.6 - Clear Combo Primary Card Holders name, Breakfree Type, Credit Card Product Type
/*function ClearPackages_RCC()
{
	ClearNodeValues("PrimaryCardHolder");
	ClearNodeValues("BreakFreeType");
	ClearNodeValues("CreditCardType");
	ClearNodeValues("BreakFreeAmount");
}*/

//New Code Begin BreakFree Changes added on 28/02/2018 
//==============================================================
//	Name:		Clear Packages tab new fields
//	Purpose:	Visible/Invisible Packages tab new fields
//	Parameters:	Blank
//==============================================================
function ClearPackagesDependencyQuestions_Field1()
{

	ClearNodeValues("AssuredCoverTemporaryExpense");
	ClearNodeValues("AssuredFacilitySelected");
	ClearNodeValues("AssuredConsentToBeConsidered");
}

//New Code Begin BreakFree Changes added on 28/02/2018 
//==============================================================
//	Name:		Clear Packages tab new fields
//	Purpose:	Visible/Invisible Packages tab new fields
//	Parameters:	Blank
//==============================================================
function ClearPackagesDependencyQuestions_Field2()
{
	ClearNodeValues("AssuredFacilitySelected");
	ClearNodeValues("AssuredConsentToBeConsidered");
}

//New Code Begin BreakFree Changes added on 28/02/2018 
//==============================================================
//	Name:		Clear Packages tab new fields
//	Purpose:	Visible/Invisible Packages tab new fields
//	Parameters:	Blank
//==============================================================
function ClearPackagesDependencyQuestions_Field3()
{
	ClearNodeValues("AssuredConsentToBeConsidered");
}

//New Code Begin BreakFree Changes added on 28/02/2018 
//==============================================================
//	Name:		
//	Purpose:	Dynamic validation of Packages tab new fields
//	Parameters:	Blank
//==============================================================
function Check_Does_Customer_Assured_Facility()
{
	var CDCAF = ds_packages.XMLDocument.documentElement.selectSingleNode("RequireANZAssuredFacility").text
	if (CDCAF == -2)
	{
		if (ds_packages.XMLDocument.documentElement.selectSingleNode("AssuredCoverTemporaryExpense")) 
		{
			ds_packages.XMLDocument.documentElement.selectSingleNode("AssuredCoverTemporaryExpense").text = "";
		}
		Require_ANZAssuredFacility(-2);
	}
	
}
//Populate the list of customer in the Additional card holder

//==============================================================
//	Name:		PopulatePackCustCombo
//	Purpose:	Populates the Customer Name for each customer's
//	Parameters:	Empty
//==============================================================
function PopulatePackCustCombo(cboid) {
    try 
    {
        var df = cboid.dataFld;
        var ds = cboid.dataSrc;
        cboid.dataFld = ""; cboid.dataSrc = "";
                                
        // clear list
        for (i = cboid.options.length - 1; i >= 0; i--)
            cboid.options.remove(i);

        var emptopt = document.createElement("OPTION");
        cboid.options.add(emptopt);
        emptopt.value = ""; emptopt.innerText = "";
		
		if(cboid.id == 'cbocustACH'){
			var emptdefopt = document.createElement("OPTION");
			cboid.options.add(emptdefopt);
			emptdefopt.value = "0";
			emptdefopt.innerText = "Not In Application";
		}
		
			var oCusts = xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer")
				if(oCusts.length > 0){
					for (var i = 0; i < oCusts.length; i++) {
						var sID = oCusts(i).selectSingleNode("CustomerID").text;
						var sName = oCusts(i).selectSingleNode("CustomerName").text;
									var opt = document.createElement("OPTION");
									cboid.options.add(opt);
									opt.value = sID; opt.innerText = sName;
					}
				}

        cboid.dataSrc = ds; cboid.dataFld = df;
		if(cboid.id == 'cbocustACH'){
			var selectedValuetxt = document.getElementById("cboprimarycardholder").value;
			UpdatePackCustCombo(selectedValuetxt);
		}
    }
    catch (e) 
    {
        displayError(e, 'PopulatePackCustCombo');
    }
}

//==============================================================
//	Name:		Check_CustACHType
//	Purpose:	Disables/Enables the Additional Card Holder if selected value is  "Not In Application"
//	Parameters:	Drop-Down Value - related to AdditionalCardHolder
//==============================================================

function Check_CustACHType(bSelect)
{
	try
	{
		if(document.getElementById("cbocustACH").value == "0")
			document.getElementById("AdditionalCardHolderType").style.display = "block";//AdditionalCardHolderDet
		else
			ClearAddCardHoldCtrl();
	}
	catch (e)
	{
                     displayError(e,'Check_CustACHType');
                }              
}

//==============================================================
//            Name:                  GetAdditionalCardHolderID
//            Purpose:              Gets AdditionalCardHolder description from the list box.
//            Parameters:       Drop-Down Value - related to Additional Card Holder
//==============================================================
function GetAdditionalCardHolderID()
{
	try
	{
		var oPack = ds_packages.XMLDocument.documentElement;
		if(oPack.selectSingleNode("AdditionalCardHolder") != null){
			oPack.selectSingleNode("AdditionalCardHolder").text = getListText(window.event.srcElement);
		}
	}
	catch(e)
	{
        displayError(e,"GetAdditionalCardHolderID");
    }              
}


//==============================================================
//            Name:                  GetPrimaryCardHolderName
//            Purpose:              Gets PrimaryCardHolderName description from the list box.
//            Parameters:       Drop-Down Value - related to Primary Card Holder
//==============================================================
function GetPrimaryCardHolderName()
{
	try
	{
		var oPack = ds_packages.XMLDocument.documentElement;
		if(oPack.selectSingleNode("PrimaryCardHolderName") != null){
			oPack.selectSingleNode("PrimaryCardHolderName").text = getListText(window.event.srcElement)
		}
	}
	catch(e)
	{
		displayError(e,"GetPrimaryCardHolderName");
	}              
}


//==============================================================
//            Name:                  GetAdditionalCardHolderID
//            Purpose:              Gets TransactionAccountHolder description from the list box.
//            Parameters:       Drop-Down Value - related to Transaction Account Holder
//==============================================================
function GetTransactionAccountHolderID()
{
	try
	{
		var oPack = ds_packages.XMLDocument.documentElement;
		if(oPack.selectSingleNode("TransactionAccountHolder") != null){
			oPack.selectSingleNode("TransactionAccountHolder").text = getListText(window.event.srcElement)
		}
	}
	catch(e)
	{
        displayError(e,"GetTransactionAccountHolderID");
    }              
}

//==============================================================
//            Name:                  UpdatePackCustCombo
//            Purpose:              Sets the Customer Name in AdditionalCardHolder DropDown depending on the PrimaryCardHolderName
//            Parameters:       Drop-Down Value - related to Primary Card Holder
//==============================================================

function UpdatePackCustCombo(pValue) {
    try 
	{
		var cboid = document.getElementById('cbocustACH');
		var cbopholdid = document.getElementById('cboprimarycardholder');
        if(cbopholdid.options.length > 0){
			if(pValue !=""){
				cboid.innerHTML = "";
					for (i = 0; i < cbopholdid.options.length; i++){
						var option = cbopholdid.options[i];
						if(pValue != option.value){
							// add list in drop-down
							var opt = document.createElement("OPTION");
							cboid.options.add(opt);opt.value = option.value;opt.innerText = option.text;
							if(i == 0){
								var emptdefopt = document.createElement("OPTION");
								cboid.options.add(emptdefopt);emptdefopt.value = "0";emptdefopt.innerText = "Not In Application";
							}
						}
					}
			}
			else{
					cboid.innerHTML = "";
					for (i = 0; i < cbopholdid.options.length; i++){
						var option = cbopholdid.options[i];
							var opt = document.createElement("OPTION");
							cboid.options.add(opt);opt.value = option.value;opt.innerText = option.text;
							if(i == 0){
								var emptdefopt = document.createElement("OPTION");
								cboid.options.add(emptdefopt);emptdefopt.value = "0";emptdefopt.innerText = "Not In Application";
							}
					}
			}
				
		}
	}
    catch (e) 
	{
        displayError(e, 'UpdatePackCustCombo');
    }
}

//==============================================================
//            Name:             ClearAddCardHoldCtrl
//            Purpose:          Clears the AdditionalCardHolder selected value change from NotInApplication
//            Parameters:       Drop-Down Value - related to AdditionalCardHolder
//==============================================================
function ClearAddCardHoldCtrl()
{
	try
	{
		document.getElementById("AdditionalCardHolderType").style.display = "none"; 
		ClearNodeValues("AdditionalCardHolderTitle");
		ClearNodeValues("AdditionalCardHolderFirstName");
		ClearNodeValues("AdditionalCardHolderMiddleName");
		ClearNodeValues("AdditionalCardHolderSurname");
		ClearNodeValues("AdditionalCardHolderDateOfBirth");
	}
	catch (e) 
	{
        displayError(e, 'ClearAddCardHoldCtrl');
    }
}

//Release 19.6
function HideAssured_TempExp()
{
	try
	{
		document.getElementById("AssuredCoverTemporaryExpense").style.display="none";
		document.getElementById("Note").style.display="none";
		document.getElementById("AssuredFacilitySelected").style.display="none";
		document.getElementById("AssuredConsentToBeConsidered").style.display="none";
	}
	catch (e) 
	{
        displayError(e, 'HideAssured_TempExp');
    }
}

//==============================================================
//            Name:             ClearNodeValues
//            Purpose:          Clears the Node Values
//            Parameters:       XML Node Name
//==============================================================
function ClearNodeValues(NodeName)
{
	try
	{
		var oPackNode = ds_packages.XMLDocument.documentElement;
		if(oPackNode.selectSingleNode(NodeName) != null) {
			oPackNode.selectSingleNode(NodeName).text = "";
		}
	}
	catch (e) 
	{
        displayError(e, 'ClearNodeValues');
    }
}

//==============================================================
// Name:    	ClearTransactionActHold - 19.7 Release
// Purpose:     Clears the Node Values of TransactionAccountHolder
// Parameters:   
//==============================================================
function ClearTransactionActHold()
{
	try
	{
		// Clearing TransactionAccountHolder from Packages - Starts
			var oSavePck = xml_master.XMLDocument.documentElement;
			if((oSavePck != null) || (oSavePck != undefined))
			{
				var oPakTNode= oSavePck.selectSingleNode("Packages/TransactionCustomers");
				if((oPakTNode != undefined) || (oPakTNode != null))
				{
					if(oPakTNode.childNodes.length > 0)
					{
						for (var i=0; i < oPakTNode.childNodes.length; i++)
						{
							if((oPakTNode.childNodes(i) != null) || (oPakTNode.childNodes(i) != undefined))
							{
								oPakTNode.childNodes(i).selectSingleNode("CustomerID").text = "";
								oPakTNode.childNodes(i).selectSingleNode("TransactionAccountHolder").text = 0;
								oPakTNode.childNodes(i).setAttribute("CustomerName","");
							}
						}
					}
				}	
			}
			
			// Clearing TransactionAccountHolder from Packages - Ends
	
	}
	catch(e)
	{
		displayError(e, 'ClearTransactionActHold');
	}
}


function LoadTransactionAcntHold(bFlag)
{
	try
	{
		// 19.7 Starts
		var oPack = ds_packages.XMLDocument.documentElement;
		var oMDocEl=xml_master.XMLDocument.documentElement;
		var oLoadPack = oMDocEl.selectSingleNode('Packages').cloneNode(true);
		
		oMDocEl.transformNodeToObject(xsl_PackageCustRefresh.XMLDocument, xml_temp.XMLDocument);
		var oCustList=xml_temp.XMLDocument.documentElement.cloneNode(true);
		if(bFlag)
		{
			oLoadPack.replaceChild(oCustList,oLoadPack.selectSingleNode('TransactionCustomers'));
			ds_packages.XMLDocument.replaceChild(oLoadPack,oPack);
			if((ds_packages.recordset.fields('RequireCreditCard') != null) || (ds_packages.recordset.fields('RequireCreditCard') != undefined))
			{
				var reqbreakfreeCC = ds_packages.recordset.fields('RequireCreditCard');
				if((reqbreakfreeCC == "") || (reqbreakfreeCC == "0"))
				{
					ClearTransactionActHold();
				}
			}
		}
		else
		{
			oPack.replaceChild(oCustList,oPack.selectSingleNode('TransactionCustomers'));
		}
		
		// 19.7 Ends
	}
	catch(e)
	{
		displayError(e, 'LoadTransactionAcntHold');
	}

}