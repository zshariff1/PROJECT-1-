//<!--==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Eugene Elutine
//	Workfile:  
//	ModTtime: 2003/03/04
//  File: AddressDtls.js	
//============================================================-->
//	Revision: 2
//	Author: Arshad K
//	Workfile:  
//	ModTtime: 2005/03/15
//  File: AddressDtls.js	
//============================================================-->
//<SCRIPT>

//Globals
var G_Addr; 
var G_selectedAdrRec = 0;
var G_bSecAddress = false;

//WR1970 - Created new variables for showing error crosses and warning message
var G_imgError
var G_imgValid
var G_bShowWarning1=false;
var G_bShowWarning2=false;

//==============================================================
//	Function Name:	initAddressDtlsDlg
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Initialise the address dialog
//==============================================================
function initAddressDtlsDlg()
{
	try
	{
		document.all.tblAddrDtls.style.display = "block";
		var oAddr = window.dialogArguments;
		
		G_bSaveIsAllowed=true;
		initRefData();
		initXMLObject(xml_ClickHelp);
		initXMLObject(ds_Addr);
		initXMLObject(ds_AdrSearchRes);
		initXMLObject(xml_AppBRS);
		initXMLObject(xml_refStreetTypes);
		
		//WR1970 - Initializing the variables which shows the warning message
		G_imgError= xml_AppBRS.XMLDocument.documentElement.getAttribute("imgError");
		G_imgValid= xml_AppBRS.XMLDocument.documentElement.getAttribute("imgValid");
		
		//populateList("A_TS_COUNTRY_CODES", document.all.cboCountry, null, 'C', 'D');
		
		//WR1970 - Added code to populate the new street type dropdown list
		PopulateStreetTypes();
		
				
		ds_Addr.src=ds_Addr.src;
	
		//G_bSecAddress = (oAddr.getAttribute("SecurityAddress")=="-1");

		//****************************>
		//document.all.chkOverseasAddress.disabled = G_bSecAddress;
		//DisableElement(document.all.cboCountry, (!G_bSecAddress));
		//DisableElement(document.all.inpAddrLine3,(!G_bSecAddress));
		//document.all.trSecAdr.style.display = (G_bSecAddress)? "":"none";
		


		//WR1970 - Hiding the Overseas Address for security
		//document.all.trOverseasAddress.style.display = (G_bSecAddress) ? "none" : "block";




		//G_Addr = oAddr.cloneNode(true);

		//ds_Addr.XMLDocument.appendChild(oAddr);


        //checkOverseasAddr(true);
		

        //var AdrId = GetIntVal(ds_Addr.XMLDocument.documentElement.selectSingleNode("//AddressID").text);

        //document.all.divCaption.innerText = (AdrId > 0) ? "Edit Address Details" : "New Address";
        //****************************<

		ds_Addr.XMLDocument.documentElement.selectSingleNode("AddressType").text = "Standard Street Address";
	
		InitilizeAppBRS(ds_Addr.XMLDocument.documentElement);
		ds_Addr.XMLDocument.documentElement.setAttribute("valid_StreetNo",G_imgValid);
		ds_Addr.XMLDocument.documentElement.setAttribute("OpenMode","Initial");

		
		//WR1970 - Added new function Call
		HandleAddrType();
		
	}
	catch (e)
	{
		displayError(e,"initAddressDtlsDlg");
	}
} 

//==============================================================
//	Function Name:	saveAddressDtls
//	Parameters:		bConfirmSave - flag shows that save is confirmed
//	Return:			Address Node
//	Description:	Saves the address details to address DSO then returns it
//==============================================================
function saveAddressDtls(bConfirmSave)
{
	try
	{
		var oAddr = ds_Addr.XMLDocument.documentElement;
		//get country code description
		//****************>
        //oAddr.setAttribute("CountryDescription", getListText(document.all.cboCountry));
        //****************<
	
		//WR1970 - Added new function to format and save the address
		if(oAddr.selectSingleNode("AddressType").text=="Standard Street Address")
		{
			var sAddrLine1=GenerateAddrLine1(oAddr);
			oAddr.selectSingleNode("AddressLine1").text=sAddrLine1;
		}
	
		//add address details to use in relationship tables
		var sAdrDtls = oAddr.selectSingleNode("AddressLine1").text + " " +
					    oAddr.selectSingleNode("AddressLine2").text + " " +
						oAddr.selectSingleNode("City").text + " " +
						oAddr.selectSingleNode("State").text + " " +
						oAddr.selectSingleNode("Postcode").text + " " +
						oAddr.getAttribute("CountryDescription");
						
		oAddr.setAttribute("AddressDetails",sAdrDtls);
		var bRes = EvaluateAppBRS(oAddr);
		
		//WR1970 - new validation call to check street number and street type.
		var bRulesOk = validateStreetNo(oAddr);
							
		if (G_bSaveIsAllowed) 
		{
			if (bRes)	
			{
				if(!bRulesOk)
				{
					var sParam=document.all.divCaption.innerText;
					
					if (G_bShowWarning1)
						sParam= sParam + "|1";
					else
						sParam= sParam + "|2"
					
					var bProceed=window.showModalDialog("AddressWarn.htm",sParam ,"dialogHeight:150px;dialogWidth:600px;help:No;resizable:No;status:No;scroll:No;");
				}
				if (bConfirmSave || bProceed || bRulesOk)
				{
					window.returnValue = ds_Addr.XMLDocument.documentElement.cloneNode(true);
					ds_Addr.XMLDocument.documentElement.removeAttribute("OpenMode");
					window.close();
				}
			}
			else
			{
				VBMsgBox('Please enter valid address details.',G_iVB_WARNING,G_sAPPLICATION_TITLE);
			}
			
			
		}
		else
		{
			promptSaveProhibited('Address');
			window.close();
		}
	}
	catch (e)
	{
		displayError(e,"saveAddressDtls");
	}
}

//==============================================================
//	Function Name:	checkOverseasAddr
//	Parameters:		bSelect - (boolean) Flag select from file or screen
//	Return:			Nil
//	Description:	Handles over seas addresseses
//==============================================================
function checkOverseasAddr(bSelect)
{
	try
	{
		var oAdr = ds_Addr.XMLDocument.documentElement;
	
		var bOS = (bSelect)? (oAdr.selectSingleNode("OverseasAddress").text=="-1"):document.all.chkOverseasAddress.status;
		DisableElement(document.all.cboCountry,bOS);
	
		document.all.inpState.style.display = (bOS)? "":"none";
		document.all.cboState.style.display = (bOS)? "none":"";
		document.all.aFind.style.display = (bOS)? "none":"";
		if (!bOS && !bSelect) oAdr.selectSingleNode("Country").text="";
		if (!bSelect) oAdr.selectSingleNode("State").text="";
	}
	catch (e)
	{
		displayError(e,"checkOverseasAddr");
	}
}



//==============================================================
//	Function Name:	SearchAddress
//	Parameters:		Nil
//	Return:			
//	Description:	
//==============================================================
function SearchAddress()
{
	try
	{
	
		G_selectedAdrRec = 0;
		var sCity = ds_Addr.XMLDocument.documentElement.selectSingleNode("City").text;
		if (!sCity) 
		{
			VBMsgBox("Please enter part of the city, town or suburb name into the 'City' field.", G_iVB_WARNING, G_sAPPLICATION_TITLE);
			return;
		}
		ds_AdrSearchRes.src=ds_AdrSearchRes.src;
		var oRes=ds_AdrSearchRes.XMLDocument.documentElement;
		oRes.removeChild(oRes.childNodes(0));
	
		sCity=sCity.toUpperCase();
		
        //******************>
		//document.all.trSecAdr.style.display = "none";
        //******************<
		
        //WR1970 - Changed the hieght of divSearchList when the address window is opened from securities screen
		document.all.divSearchList.style.height=(G_bSecAddress)? "180px":"195px";
		document.all.divSearchResults.style.display="block";
		tblAddrDtls.style.display="none";
		
		// ensure that no invalid ' string combinations appear in the search string for city
		sCity = sCity.replace(/"/g,'')
		var oSR= getRDRows('A_TSR_PC','starts-with(@C,"' + sCity + '")');
	
		var sPrompt="No records found.";
		if (oSR.length==0)
		{
			document.all.aSearchOK.focus();	
		}		
		else
		{
			if (oSR.length==1)
			{
				sPrompt="1 record found:";
			}
			else
			{
				sPrompt=oSR.length + " records found:";
			}
		}
		document.all.spnRes.innerText=sPrompt;
	
		for (i=0; i<oSR.length; i++)
			oRes.appendChild(oSR(i).cloneNode(true));
	}
	catch (e)
	{
		displayError(e,"SearchAddress");
	}
}

//==============================================================
//	Function Name:	SelectRec
//	Parameters:		RecNo- (numeric) Record number of selected city
//	Return:			Nil
//	Description:	Set global variable of selected city from search
//==============================================================
function SelectRec(RecNo)
{
	G_selectedAdrRec = RecNo;
}

//==============================================================
//	Function Name:	closeIfEnter
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Selects the chosen city and closes the search table
//==============================================================
function closeIfEnter()
{
	if (event.keyCode==13 && G_selectedAdrRec>0) SelectCity(true);
}

//==============================================================
//	Function Name:	SelectCity
//	Parameters:		bOk - (boolean) flag for yes select the city
//	Return:			Nil
//	Description:	Takes the details of a city in the search table
//					and adds them to the address DSO.
//==============================================================
function SelectCity(bOk)
{
	try
	{
		divSearchResults.style.display="none";
		tblAddrDtls.style.display="block";
		
        //***********************>
		//document.all.trSecAdr.style.display = (G_bSecAddress) ? "" : "none";
        //***********************<

		if (bOk && G_selectedAdrRec>0)
		{
			var oR=ds_AdrSearchRes.XMLDocument.documentElement.childNodes(G_selectedAdrRec-1);
			var oAdr = ds_Addr.XMLDocument.documentElement
			oAdr.selectSingleNode("City").text =oR.getAttribute("C");
			oAdr.selectSingleNode("State").text=oR.getAttribute("S");
			oAdr.selectSingleNode("Postcode").text =oR.getAttribute("P");
		}
	}
	catch (e)
	{
		displayError(e,"SelectCity");
	}
}

//==============================================================
//	Function Name:	cancelSaveAddressDtls
//	Parameters:		none
//	Description:	cancel saving address, returns screen to edit 
//					address details
//==============================================================
function cancelSaveAddressDtls()
{
	try
	{
		tblAddrDtls.style.display="block";
		divWarning.style.display="none";
		document.all.trSecAdr.style.display = (G_bSecAddress)? "":"none";
		inpAdr1.focus();
	}
	catch (e)
	{
		displayError(e,"cancelSaveAddressDtls");
	}
}

//==============================================================
//	Function Name:	ValCity
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the city
//==============================================================
function ValCity(oAddr)
{
	try
	{
		return ValAddressFld(oAddr,"City","@C");
	}
	catch (e)
	{
		displayError(e,"ValCity");
	}
}

//==============================================================
//	Function Name:	ValState
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the state
//==============================================================
function ValState(oAddr)
{
	try
	{
		return ValAddressFld(oAddr,"State","@S");
	}
	catch (e)
	{
		displayError(e,"ValState");
	}
}

//==============================================================
//	Function Name:	ValPostcode
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the postcode
//==============================================================
function ValPostcode(oAddr)
{
	try
	{
		return ValAddressFld(oAddr,"Postcode","@P");
	}
	catch (e)
	{
		displayError(e,"ValPostcode");
	}
}

//==============================================================
//	Function Name:	ValAddressFld
//	Parameters:		oAddr - (XML Node) Address node
//					sFldName - (string) DSO field name
//					sAttr - (string) Ref data attribute name
//	Return:			Boolean - Valid flag
//	Description:	Validates given address fields
//==============================================================
function ValAddressFld(oAddr,sFldName,sAttr)
{
	var valid = false;
		
	try
	{
		if (!oAddr) return valid;
		var bOversea = (oAddr.selectSingleNode("OverseasAddress").text=="-1");
		if (bOversea)
			valid = true;		
		else
		{
			//must be not empty and valid
			var sVal = oAddr.selectSingleNode(sFldName).text.toUpperCase();
			valid = !(sVal=="");
			//check ref data
			
			// ensure that no invalid ' string combinations appear in the search string
			sVal = sVal.replace(/"/g, '');
			valid = valid && (getSingleRDRow("A_TSR_PC", sAttr + '="' + sVal + '"')!=null)
		}	

		return valid;		
	}
	catch (e)
	{
		displayError(e,"ValAddressFld");
	}
}

//==============================================================
//	Function Name:	ValCountry
//	Parameters:		oAddr - (XML Node) Address node
//	Return:			Boolean - Valiod flag
//	Description:	Validates the country
//==============================================================
function ValCountry(oAddr)
{
	try
	{
		var valid = false;
		if (!oAddr) return valid;
		var bOversea = (oAddr.selectSingleNode("OverseasAddress").text=="-1");
		var sVal = oAddr.selectSingleNode("Country").text;
		valid = (bOversea && !(sVal==""))||(sVal=="" && !bOversea);
		
		return valid;
	}
	catch (e)
	{
		displayError(e,"ValCountry");
	}
	
}

//==============================================================
//	Function Name:	ValCityStatePC
//	Parameters:		oAddr - (XML Node) Address node
//	Return:			Boolean - Valiod flag
//	Description:	Validates city state and post code combo
//==============================================================
function ValCityStatePC(oAddr)
{	
	try
	{
		var valid = false;
		
		if (!oAddr) return valid;
		var bOversea = (oAddr.selectSingleNode("OverseasAddress").text=="-1");
		if (bOversea)
		{
			valid = true;
		}		
		else
		{
			//must be valid combination
			var sCity = oAddr.selectSingleNode("City").text.toUpperCase();
			var sState = oAddr.selectSingleNode("State").text;
			var sPC = oAddr.selectSingleNode("Postcode").text;
			
			// ensure that no invalid ' string combinations appear in the search string
			sCity = sCity.replace(/"/g, '');
			sState = sState.replace(/"/g, '');
			var sCheck='@P="' + sPC + '" and @C="' + sCity + '" and @S="' + sState +'"';
			valid = (getSingleRDRow("A_TSR_PC", sCheck)!=null);
		}	
		return valid;		
	}
	catch (e)
	{
		displayError(e,"ValCityStatePC");
	}
}

//WR1970 - New functions added  -->

//==============================================================
//	Function Name:	HandleAddrType
//	Parameters:		None
//	Return:			None
//	Description:	Changes the screen based on the address type
//					selected by the user.
//==============================================================
function HandleAddrType()
{
	try
	{
		var sAddrType;
		sAddrType = ds_Addr.XMLDocument.documentElement.selectSingleNode("AddressType").text;

		var sMode=ds_Addr.XMLDocument.documentElement.getAttribute("OpenMode");
		
		switch(sAddrType)
		{
		case "Standard Street Address":	
				
				document.getElementById("NonStdLine1").style.display="none";
				document.getElementById("NonStdLine2").style.display="none";
				
				document.getElementById("StdLine1").style.display="block";
				document.getElementById("StdLine2").style.display="block";
				
				//Clear the fields
				ds_Addr.XMLDocument.documentElement.selectSingleNode("AddressLine1").text="";
				ds_Addr.XMLDocument.documentElement.selectSingleNode("AddressLine2").text="";
				
				break;
				
		case "Non Standard Address":
				
				document.getElementById("NonStdLine1").style.display="block";
				document.getElementById("NonStdLine2").style.display="block";
				
				document.getElementById("StdLine1").style.display="none";
				document.getElementById("StdLine2").style.display="none";
				
				//Clear the fields
				ds_Addr.XMLDocument.documentElement.selectSingleNode("UnitNo").text="";
				ds_Addr.XMLDocument.documentElement.selectSingleNode("StreetNo").text="";
				ds_Addr.XMLDocument.documentElement.setAttribute("valid_StreetNo",G_imgValid);
				ds_Addr.XMLDocument.documentElement.selectSingleNode("StreetName").text="";
				ds_Addr.XMLDocument.documentElement.selectSingleNode("StreetType").text="";

				break;
		}
		if (sMode!="Edit")
		{
			ds_Addr.XMLDocument.documentElement.selectSingleNode("City").text="";
			ds_Addr.XMLDocument.documentElement.selectSingleNode("State").text="";
			ds_Addr.XMLDocument.documentElement.selectSingleNode("Postcode").text="";
			ds_Addr.XMLDocument.documentElement.selectSingleNode("Country").text="";
		}
		ds_Addr.XMLDocument.documentElement.setAttribute("OpenMode","ChangeType");
	}
	catch (e)
	{
		displayError(e,"HandleAddrType");
	}
}

//==============================================================
//	Function Name:	PopulateStreetTypes
//	Parameters:		None
//	Return:			None
//	Description:	Populates the Street Type List Box
//==============================================================
function PopulateStreetTypes()
{
	try
	{
		var oRefDataStreet=xml_refStreetTypes.XMLDocument.documentElement.selectSingleNode("/StreetTypes");
		var iTypesNo=oRefDataStreet.selectNodes("/StreetTypes/R").length;
		var iIndex;
		var sHTML=document.getElementById("cboStreetType").outerHTML;
		
			
		for(iIndex=0;iIndex<iTypesNo;iIndex++)
		{
			var opt = document.createElement("OPTION");
			document.getElementById("cboStreetType").options.add (opt);
			opt.value = oRefDataStreet.childNodes(iIndex).getAttribute("ABBR");
			opt.innerText = oRefDataStreet.childNodes(iIndex).getAttribute("TYPE");
		}
	}
	catch (e)
	{
		displayError(e,"PopulateStreetTypes");
	}
}

//==============================================================
//	Function Name:	validateStreetNo
//	Parameters:		None
//	Return:			Boolean
//	Description:	Validates the street No
//==============================================================
function validateStreetNo(oAddrPassed)
{
	try
	{


        	var sAddrType=oAddrPassed.selectSingleNode("AddressType").text;
		var sStreetNo=oAddrPassed.selectSingleNode("StreetNo").text;
		var sUnitNo=oAddrPassed.selectSingleNode("UnitNo").text;
		
		if (sAddrType=="Non Standard Address")
		{
			G_bShowWarning2=true;
			ds_Addr.XMLDocument.documentElement.setAttribute("valid_StreetNo",G_imgValid);
		}
		else
		{
			G_bShowWarning2=false;
		}
		if (sAddrType=="Standard Street Address")
		{
			switch(true)
			{
			case (sUnitNo=="" && sStreetNo==""):	
					G_bShowWarning1=true;
					break
			case (sUnitNo==""):
					if (VBIsNumeric(sStreetNo.substr(0,1)))
					{
						G_bShowWarning1=false;
					}
					else
					{
						G_bShowWarning1=true;
					}
					break
			case (VBIsNumeric(sUnitNo.substr(0,1))):
					G_bShowWarning1=false;
					break
			case (!VBIsNumeric(sUnitNo.substr(0,1))):	
					G_bShowWarning1=true;
					break
			}
		}	
		
		if (G_bShowWarning1)
		ds_Addr.XMLDocument.documentElement.setAttribute("valid_StreetNo",G_imgError);		
		
		if(G_bShowWarning1 || G_bShowWarning2)
		{
			return false;
		}
		else
		{
			ds_Addr.XMLDocument.documentElement.setAttribute("valid_StreetNo",G_imgValid)
			return true;
		}
	}
	catch (e)
	{
		displayError(e,"validateStreetNo");
	}
}

//==============================================================
//	Function Name:	valStreetName
//	Parameters:		None
//	Return:			Boolean
//	Description:	Validates the street name
//==============================================================
function valStreetName()
{
	try
	{
		var oAddr = ds_Addr.XMLDocument.documentElement
		var sAddrType=oAddr.selectSingleNode("AddressType").text;
		var sStreetName=oAddr.selectSingleNode("StreetName");

		if (sAddrType=="Non Standard Address")
		{
			return true;
		}
		if (sAddrType=="Standard Street Address")
		{
			return CheckMandatoryFld(sStreetName);
		}
	}
	catch (e)
	{
		displayError(e,"valStreetName");
	}
}


//==============================================================
//	Function Name:	valStreetType
//	Parameters:		None
//	Return:			Boolean
//	Description:	Validates Street Type
//==============================================================
function valStreetType()
{
	try
	{
		var oAddr = ds_Addr.XMLDocument.documentElement
		var sAddrType=oAddr.selectSingleNode("AddressType").text;
		var sStreetType=oAddr.selectSingleNode("StreetType");

		if (sAddrType=="Non Standard Address")
		{
			return true;
		}
		if (sAddrType=="Standard Street Address")
		{
			return CheckMandatoryFld(sStreetType);
		}
	}
	catch (e)
	{
		displayError(e,"valStreetType");
	}
}

//==============================================================
//	Function Name:	GenerateAddrLine1
//	Parameters:		The Address node
//	Return:			String, The generated address
//	Description:	Generates the address line 1 combining the
//					user inputs.
//==============================================================
function GenerateAddrLine1(oAddrNode)
{
	try
	{
		
		var sStreetNo=oAddrNode.selectSingleNode("StreetNo").text;
		var sUnitNo=oAddrNode.selectSingleNode("UnitNo").text;
		var sAddr="";
		
		if(sStreetNo!="" &&  sUnitNo!="")
		{
			sAddr= sAddr + sUnitNo + "/" + sStreetNo;
		}
		else
		{
			if (sStreetNo!="")
				sAddr= sAddr + sStreetNo;
			if (sUnitNo!="")
				sAddr= sAddr + sUnitNo;
			
		}
		sAddr=sAddr + " " + oAddrNode.selectSingleNode("StreetName").text +
		" " + oAddrNode.selectSingleNode("StreetType").text;
		
		return sAddr;
		
	}
	catch (e)
	{
		displayError(e,"GenerateAddrLine1");
	}
}


//==============================================================
//	Function Name:	AddrTypeChange
//	Parameters:		None
//	Return:			None
//	Description:	Handles the Change Event of the Address Type 
//					field
//==============================================================
function AddrTypeChange()
{
	try
	{
		sAddrType=getListText(cboAddrType)
	//WR1970 - To fix the ST bug #49 - Start
		InitilizeAppBRS(ds_Addr.XMLDocument.documentElement);
		var AdrId=GetIntVal(ds_Addr.XMLDocument.documentElement.selectSingleNode("//AddressID").text);
		if (isNaN(AdrId)||AdrId==0) 
		{	
			ds_Addr.XMLDocument.documentElement.setAttribute("valid_StreetNo",G_imgValid);
			ds_Addr.XMLDocument.documentElement.setAttribute("OpenMode","Initial");
		}
		else
		{
			validateStreetNo(ds_Addr.XMLDocument.documentElement);
			ds_Addr.XMLDocument.documentElement.setAttribute("OpenMode","Edit");
		}
		HandleAddrType();
		//document.all.chkOverseasAddress.status=0;
		
        //****************************
        //checkOverseasAddr();
        //****************************

	//WR1970 - To fix the ST bug #49 - End
		ds_Addr.XMLDocument.documentElement.selectSingleNode("AddressType").text=sAddrType;
		ds_Addr.XMLDocument.documentElement.selectSingleNode("AddressLine1").text="";
		HandleAddrType();
		
	}
	catch (e)
	{
		displayError(e,"AddrTypeChange");
	}
}

//==============================================================
//	Function Name:	initAddressWarn
//	Parameters:		None
//	Return:			None
//	Description:	Used by the warning message popup window to
//					initialize the message.
//==============================================================
function initAddressWarn()
{
	try
	{
		var sTempArr=window.dialogArguments.split("|");
		document.all.divCaption.innerText=sTempArr[0];
		var iMsgCode=Number(sTempArr[1]);
		if (iMsgCode==1)
		{
			document.getElementById("spnMessage1").innerHTML="The address you have entered may not be valid and may cause a Referral Credit Decision!";
			document.getElementById("spnMessage2").innerHTML="Please check that a valid Unit No. or Street No. has been used.";
			document.getElementById("spnMessage3").innerHTML="";
		}
		else
		{
			document.getElementById("spnMessage1").innerHTML="By entering a Non Standard Address you may cause a Referral Credit Decision!";
			document.getElementById("spnMessage2").innerHTML="";
			document.getElementById("spnMessage3").innerHTML="";
		}
		
	}
	catch (e)
	{
		displayError(e,"initAddressWarn");
	}
}

//WR1970_CMR005_point3 - Show appropriate click help - Function added
//==============================================================
//	Function Name:	fnShowClickHelp
//	Parameters:		None
//	Return:			None
//	Description:	Used to display the related click help for 
//					"City/Suburb, State and Postcode combination" text.
//==============================================================
function fnShowClickHelp()
{
	try
	{
		if(G_bSecAddress)
		{
			popup('CityStatePostcodeComboSecurity');
		}
		else
		{
			popup('CityStatePostcodeComboCustomer');
		}
	}
	catch (e)
	{
		displayError(e,"fnShowClickHelp");
	}
}