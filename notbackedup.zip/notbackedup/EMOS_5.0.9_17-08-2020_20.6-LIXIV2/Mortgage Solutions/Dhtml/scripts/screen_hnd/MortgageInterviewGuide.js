//<!--==========================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		Suresh K C
//	Workfile:	MortgageInterviewGuide.js
//	ModTtime:	29/04/2011
//============================================================-->
//<SCRIPT>

//Global Variables
var G_bMIGDirty = false;	//flag indicating that the customer details have been changed

var G_iCurerntMIGTabIndex = 0;		//selected MIG tab index

// tab images
var aMIGTabImgs = Array ("objectives", "refinance", "financialCircumstances", "furtherinvestments");

//==============================================================
//	Name:		MortgageInterviewGuideScreenShow
//	Purpose:	Shows customer screen. 
//				Loads list boxes on the first show.
//==============================================================
function MortgageInterviewGuideScreenShow()
{
	try
	{
		G_pScreenSaveFunction = SaveMortgageInterviewGuide;
		ds_MortgageInterviewGuide.src=ds_MortgageInterviewGuide.src;
		
		PopulateMIGScreenDropdownControls();
		InitMortgageInterviewGuide();

		SetMIGDetailsDirty();

	}
	catch(e)
	{
		displayError(e,"MortgageInterviewGuideScreenShow");
	}
}

//==============================================================
//	Name:		SaveMortgageInterviewGuide
//	Purpose:	Save the MIG details
//==============================================================

function SaveMortgageInterviewGuide()
{
	try
	{
		//Clear the Reason for refinancing and Refinancing costs if loan the purpose is not refinance
		if(document.getElementById('rdoIsRefinanceLoan_N').checked)
			ClearRefinancingCosts(true);
		
		//Clear the financial circumstance details if the financial circumstance not changed
		if(document.getElementById('rdoIsChangeInFinancialStatus_N').checked)
			ClearFinancialCircumstances();
		
		//Clear the further investments details if loan is not for further investments
		if(document.getElementById('rdoIsLoanForInvestment_N').checked)
			ClearFurtherInvestments();
		
		//Check if any loan details modified
		if (!G_bMIGDirty) return;
		
		var oNewMIGDetails = ds_MortgageInterviewGuide.XMLDocument.documentElement.cloneNode(true);
		var oMIG = xml_master.XMLDocument.documentElement.selectSingleNode("MIG");
		xml_master.XMLDocument.documentElement.replaceChild(oNewMIGDetails, oMIG);
		
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("MIG"));
		EvaluateAppBRS(xml_master.XMLDocument.documentElement, true);
		
		// Save the loan details to file
		FlushToDisk();
		G_bMIGDirty=false;
		
		//Reload the retails
		MortgageInterviewGuideScreenShow();
	}
	catch(e)
	{
		displayError(e,"SaveMortgageInterviewGuide");
	}
}

//==============================================================
//	Name:		InitMortgageInterviewGuide
//	Purpose:	Initialize the MIG details
//==============================================================

function InitMortgageInterviewGuide()
{
	try
	{
		//Load the application details to stub
		
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode("//MIG");
		if (oMIGDetails.hasChildNodes)
		{
			//retrieve MIG details node if it's exists in application;
			var oNewMIGDetails=ds_MortgageInterviewGuide.XMLDocument.documentElement;
			ds_MortgageInterviewGuide.XMLDocument.replaceChild(oMIGDetails.cloneNode(true), oNewMIGDetails);
		}
		else
		{	
			//initilise 
			InitilizeAppBRS(ds_MortgageInterviewGuide.XMLDocument.documentElement);
		}
	}
	catch(e)
	{
		displayError(e,"InitMortgageInterviewGuide");
	}
}

//==============================================================
//	Name:			PopulateMIGScreenDropdownControls
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Populate the dropdown controls on MIG screen
//==============================================================

function PopulateMIGScreenDropdownControls()
{
	try
	{
		//populate dropdown controls if they are not loaded
		if (!G_oScreens["ScrMortgageInterviewGuide"].ListsPopulated) 
		{
			populateList("A_TS_CUST_LOAN_PURPOSE_DECL", document.all.cboCustLoanPurposeDecl, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_INT_RATE_PREFERENCE_CODES", document.all.cboInterestRatePreference, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);
			
			populateList("A_TS_REPAYMENT_PREFERENCE_CODES", document.all.cboRepaymentPreferences, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_ACCESSTOFUNDS_CODES", document.all.cboAccessToFunds, null, 'FUNDS_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_RESONFORREFINANCE_CODES", document.all.cboReasonForRefinance, null, 'REFINANCE_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_REPAYMENTPLAN_CODES", document.all.cboRepaymentPlan, null, 'REPAYMENT_CODE', 'CODE_DESC', false, true);
		    populateList("A_TS_REASONFORINTERESTONLY", document.all.cboReasonforIntOnly, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);
			G_oScreens["ScrMortgageInterviewGuide"].ListsPopulated = true;
		}
		
	}
	catch(e)
	{
		displayError(e,"PopulateMIGScreenDropdownControls");
	}
}

//==============================================================
//	Name:			SaveIntGuide
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Switch the tabs on MIG screen
//==============================================================

function SwitchMIGTab(iTabIdx, sFocusControl)
{
	try
	{
		var oTabs = document.all.ScrMortgageInterviewGuide.all.MIGTab;		// tabs
	
		//faded tab
		var currimg=document.all.ScrMortgageInterviewGuide.all.imgMIGTab(iTabIdx).src;
		if (currimg.indexOf("_faded.gif")>=0) return;

		if (G_iCurerntMIGTabIndex != null) 	
		{
			oTabs(G_iCurerntMIGTabIndex).style.display = "none";
			document.all.ScrMortgageInterviewGuide.all.imgMIGTab(G_iCurerntMIGTabIndex).src = "../images/tabs/" + aMIGTabImgs[G_iCurerntMIGTabIndex] + ".gif";
		}
			
		oTabs(iTabIdx).style.display = "block";
		
		document.all.ScrMortgageInterviewGuide.all.imgMIGTab(iTabIdx).src = "../images/tabs/" + aMIGTabImgs[iTabIdx] + "_dn.gif";
		G_iCurerntMIGTabIndex = iTabIdx;
		window.scrollTo(0,0); 
		if (sFocusControl && document.all(sFocusControl)) document.all(sFocusControl).focus();
		
		//control the tab contents
		MIGTabContentDisplay();
	}
	catch(e)
	{
		displayError(e,"SwitchMIGTab");
	}
}

//==============================================================
//	Function Name:	MIGTabContentDisplay
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Display the tab content according to tab selection
//==============================================================
function MIGTabContentDisplay()
{
	try 
	{
		switch (G_iCurerntMIGTabIndex)
		{	
			//Case 0 is added as part of eMOS-APRA change
			case 0:
				//	HideshowReasonForIntOnly('sOnLoad');
				//	HideshowOtherReason('sOnLoad');
			break;
			
			case 1:
				if (!document.getElementById('rdoIsRefinanceLoan_N').checked)
				{
					document.getElementById('rdoIsRefinanceLoan_Y').checked = true;
					RefinanceDiv('true');
					
					if (document.getElementById('rdoIsPayoutQuoteFromOFI_N').checked)
					{
						DisableRefinancingCosts(true);
					}
				}

				break;
			
			case 2:
				if (!document.getElementById('rdoIsChangeInFinancialStatus_N').checked)
				{
					document.getElementById('rdoIsChangeInFinancialStatus_Y').checked = true;
					FinancialCircumstanceDiv('true');
				}
				
				break;
		
			case 3:
				if (!document.getElementById('rdoIsLoanForInvestment_N').checked)
				{
					document.getElementById('rdoIsLoanForInvestment_Y').checked = true;
					FurtherInvestmentsDiv('true');
					
					if (!document.getElementById('rdoIsInvestmentAsSecurity_N').checked)
					{
						document.getElementById('rdoIsInvestmentAsSecurity_Y').checked = true;
						FurInvInstructionDiv('true');
					}
				}
				
				break;

			default:
			
		}
	}
	catch(e)
	{
		displayError(e,"MIGTabContentDisplay");
	}
}

//==============================================================
//	Function Name:	SetMIGDetailsDirty
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Sets flag to save application
//==============================================================
function SetMIGDetailsDirty()
{
	G_bMIGDirty = true;
}

//==============================================================
//	Function Name:	RefinanceDiv
//	Parameters:		Div tag id
//	Return:			Nil
//	Description:	Show/hide refinance related fields
//==============================================================
function RefinanceDiv(showOrhide) 
{
	try 
	{	
		//Show/hide refinance reason and refinancing costs details
		if(showOrhide == 'true') 
		{
			showDiv('divRefinance');
			
			var oIsPayoutQuoteFromOFI = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG/IsPayoutQuoteFromOFI');
			
			if (!oIsPayoutQuoteFromOFI || oIsPayoutQuoteFromOFI.text == 1)
			{
				DisableRefinancingCosts(false);
			}
			else 
			{
				if (oIsPayoutQuoteFromOFI.text == 0)
					DisableRefinancingCosts(true);
			}			
		}
		else 
		{
			hideDiv('divRefinance');
			//Switch to Further investments tab
			SwitchMIGTab(2, 'rdoIsChangeInFinancialStatus_Y');
		}
		SpecifyOtherRefinanceReason();
	}
	catch(e)
	{
		displayError(e,"RefinanceDiv");
	}
}

//==============================================================
//	Function Name:	DisableRefinancingCosts
//	Parameters:		true or false
//	Return:			Nil
//	Description:	Enable/Disable the refinancing cost controls fields.
//==============================================================
function DisableRefinancingCosts(bDisable)
{
	try
	{
		document.getElementById('txtCurrentOutstandingBalance').disabled=bDisable;
		document.getElementById('txtPlusAccruedInterest').disabled=bDisable;
		document.getElementById('txtOFIRefinancingCost').disabled=bDisable;
		document.getElementById('txtOtherBankFees').disabled=bDisable;
		document.getElementById('txtOtherCosts').disabled=bDisable;
		
		if (bDisable) ClearRefinancingCosts(false);
	}
	catch(e)
	{
		displayError(e,"DisableRefinancingCosts");
	}
}


//==============================================================
//	Function Name:	FinancialCircumstanceDiv
//	Parameters:		Div tag id
//	Return:			Nil
//	Description:	Show/hide refinance related fields
//==============================================================
function FinancialCircumstanceDiv(showOrhide) 
{
	try
	{	
		//Show/Hide financial circumstance details
		if(showOrhide == 'true')
		{
			showDiv('divFinanciCircumstance');
		}
		else
		{
			hideDiv('divFinanciCircumstance');
		}
		SpecifyOtherRepaymentPlan();

	}
	catch(e)
	{
		displayError(e,"FinancialCircumstanceDiv");
	}
}

//==============================================================
//	Function Name:	FurtherInvestmentsDiv
//	Parameters:		Div tag id
//	Return:			Nil
//	Description:	Show/hide further investments related fields
//==============================================================
function FurtherInvestmentsDiv(showOrhide) 
{
	try
	{	
		//Show/Hide further investments details
		if(showOrhide == 'true')
		{
			showDiv('divFurtherInvestments');
			
			if (!document.getElementById('rdoIsInvestmentAsSecurity_N').checked)
			{
				document.getElementById('rdoIsInvestmentAsSecurity_Y').checked = true;
				FurInvInstructionDiv('true');
			}
		}
		else 
		{
			hideDiv('divFurtherInvestments');
			FurInvInstructionDiv('false');
		}
	}
	catch(e)
	{
		displayError(e,"FurtherInvestmentsDiv");
	}
}

//==============================================================
//	Function Name:	FurInvInstructionDiv
//	Parameters:		Div tag id
//	Return:			Nil
//	Description:	Show/hide further investments instruction
//==============================================================
function FurInvInstructionDiv(showOrhide) 
{
	try
	{	
		if(showOrhide == 'true') 
		{
			showDiv('divFurInvInstruction');
		}
		else 
		{
			hideDiv('divFurInvInstruction');
		}
	}
	catch(e)
	{
		displayError(e,"FurInvInstructionDiv");
	}
}

//==============================================================
//	Function Name:	showDiv
//	Parameters:		Div tag id
//	Return:			Nil
//	Description:	Show the div tag content
//==============================================================
function showDiv(divName) 
{
	try
	{
		var objDivStyle = eval('document.all.' + divName + '.style');		
		objDivStyle.visibility = 'visible';
		objDivStyle.display = "block";
	}
	catch(e)
	{
		displayError(e,"showDiv");
	}
}


//==============================================================
//	Function Name:	hideDiv
//	Parameters:		Div tag id
//	Return:			Nil
//	Description:	Hide the div tag content
//==============================================================
function hideDiv(divName)
{
	
	try
	{
		var objDivStyle = eval('document.all.' + divName + '.style');
		objDivStyle.visibility = 'hidden';
		objDivStyle.display = "none";
	}
	catch(e)
	{
		displayError(e,"hideDiv");
	}
}


//==============================================================
//	Function Name:	TotalAmountToRefinance
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Calculate Total Amount To Refinance
//==============================================================
function TotalAmountToRefinance()
{
	try
	{
		//Sum up the amount to refinance
		var CurrentOutstandingBalance = document.getElementById('txtCurrentOutstandingBalance').value;
		var PlusAccruedInterest =  document.getElementById('txtPlusAccruedInterest').value;
		var OFIRefinancingCost = document.getElementById('txtOFIRefinancingCost').value;
		var OtherBankFees = document.getElementById('txtOtherBankFees').value;
		var OtherCosts = document.getElementById('txtOtherCosts').value;
		
		document.getElementById('txtTotalAmountToRefinance').value = parseInt(CurrentOutstandingBalance)+ parseInt(PlusAccruedInterest) +  parseInt(OFIRefinancingCost) +  parseInt(OtherBankFees) +  parseInt(OtherCosts);
	}
	catch(e)
	{
		displayError(e,"TotalAmountToRefinance");
	}
}

//==============================================================
//	Function Name:	ClearRefinancingCosts
//	Parameters:		clearAll - if true - clear the all controls, only refinancing costs otherwise
//	Return:			Nil
//	Description:	Clear reason for refinancing and refinancing costs
//==============================================================
function ClearRefinancingCosts(clearAll)
{
	try
	{
		//clear reason for refinancing
		if(clearAll)
		{
			document.getElementById('cboReasonForRefinance').value = '';
			document.getElementById('txtOtherRefinanceReason').value = '';
			document.getElementById('rdoIsPayoutQuoteFromOFI_N').checked = true;
			document.getElementById('txtRefinanceComments').value = '';
		}
		
		//clear refinancing costs
		document.getElementById('txtCurrentOutstandingBalance').value = 0;
		document.getElementById('txtPlusAccruedInterest').value = 0;
		document.getElementById('txtOFIRefinancingCost').value = 0;
		document.getElementById('txtOtherBankFees').value = 0;
		document.getElementById('txtOtherCosts').value = 0;
		TotalAmountToRefinance();

	}
	catch(e)
	{
		displayError(e,"ClearRefinancingCosts");
	}
}

//==============================================================
//	Function Name:	SpecifyOtherRefinanceReason
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Show/hide text box to enter other refinance reason
//==============================================================
function SpecifyOtherRefinanceReason()
{
	try
	{
		if(document.getElementById('cboReasonForRefinance').value == 'Other')
		{
			showDiv('divOtherRefinanceReason');
		}
		else
		{
			hideDiv('divOtherRefinanceReason');	
			document.getElementById('txtOtherRefinanceReason').value='';
		}
	}
	catch(e)
	{
		displayError(e,"SpecifyOtherRefinanceReason");
	}
}

//==============================================================
//	Function Name:	SpecifyOtherRepaymentPlan
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Show/hide text box to enter other repayment plan
//==============================================================
function SpecifyOtherRepaymentPlan()
{
	try
	{
		if(document.getElementById('cboRepaymentPlan').value == 'Other (please specify)')
		{
			showDiv('divOtherRepaymentPlan');
		}
		else
		{
			hideDiv('divOtherRepaymentPlan');	
			document.getElementById('txtRepaymentPlanText').value='';
		}
	}
	catch(e)
	{
		displayError(e,"SpecifyOtherRepaymentPlan");
	}
}

//==============================================================
//	Function Name:	ClearFinancialCircumstances
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Clear Financial Circumstances related values
//==============================================================
function ClearFinancialCircumstances()
{
	try
	{
		document.getElementById('txtChangeInFinancialStatus').value = '';
		document.getElementById('cboRepaymentPlan').value = '';
		document.getElementById('txtRepaymentPlanText').value = '';
	}
	catch(e)
	{
		displayError(e,"ClearFinancialCircumstances");
	}
}

//==============================================================
//	Function Name:	ClearFurtherInvestments
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Clear Further Investments related values
//==============================================================
function ClearFurtherInvestments()
{
	try
	{
		document.getElementById('rdoIsInvestmentAsSecurity_N').checked = true;
	}
	catch(e)
	{
		displayError(e,"ClearFurtherInvestments");
	}
}
//==============================================================
//	Function Name:	HideshowReasonForIntOnly
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Show/hide text box to enter other interest only reason
//==============================================================
function HideshowReasonForIntOnly(sParmeter)
{
	try
	{
		var oRepaymentPreferences = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG/RepaymentPreference');		
		var oReasonforIntOnly = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG/ReasonForInterestOnly');
		var oOtherReasonIntOnly = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG/OtherReasonIntOnly');	

		//if((sParmeter=='sOnLoad') &&((oReasonforIntOnly===null) || (oOtherReasonIntOnly===null))) return; 
		if((sParmeter=='sOnLoad') &&(oRepaymentPreferences===null|| oRepaymentPreferences.text=='P & I')) return; 
		
		if (sParmeter=='sOnLoad')
		{				
			if((document.getElementById('cboRepaymentPreferences').value != 'P & I')&&((oRepaymentPreferences.text=='Interest Only' || oRepaymentPreferences.text=='Interest in Advance' )||(document.getElementById('cboRepaymentPreferences').value == 'Interest Only' ||  document.getElementById('cboRepaymentPreferences').value == 'Interest in Advance')))
			{
				showDiv('rowcboReasonforIntOnly');			
								
			}
			else
			{
				hideDiv('rowcboReasonforIntOnly');	
				document.getElementById('cboReasonforIntOnly').value = '';
				hideDiv('rowcboReasonforIntOnly');	
				document.getElementById('txtOtherReason').value = '';				
			}
			
		}
		else
		{
			if((document.getElementById('cboRepaymentPreferences').value == 'Interest Only' ||  document.getElementById('cboRepaymentPreferences').value == 'Interest in Advance'))
			{
				showDiv('rowcboReasonforIntOnly');								
				hideDiv('rowtxtOtherReason');					
				document.getElementById('cboReasonforIntOnly').value = '';
				document.getElementById('txtOtherReason').value = '';	
			}
			else
			{
				hideDiv('rowcboReasonforIntOnly');	
				document.getElementById('cboReasonforIntOnly').value = '';
				hideDiv('rowtxtOtherReason');	
				document.getElementById('txtOtherReason').value = '';	
			}
		}
	}
	catch(e)
	{
		displayError(e,"HideshowReasonForIntOnly");
	}
}
//==============================================================
//	Function Name:	HideshowOtherReason
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Show/hide text box to enter other interest only reason
//==============================================================
function HideshowOtherReason(sParameter)
{	
	try
	{
		var oReasonforIntOnly = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG/ReasonForInterestOnly');
		var oOtherReasonIntOnly = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG/OtherReasonIntOnly');		
		
		//if((sParameter=='sOnLoad')&&((oReasonforIntOnly===null) || (oOtherReasonIntOnly===null))) return; 
		if((sParameter=='sOnLoad')&&((oReasonforIntOnly===null))) return; 

		
		if (sParameter=='sOnLoad')
		{
			if((oReasonforIntOnly.text== 'Other (please provide reason in description box)')||(document.getElementById('cboReasonforIntOnly').value == 'Other (please provide reason in description box)'))
			{
				showDiv('rowtxtOtherReason');
			}
			else
			{
				hideDiv('rowtxtOtherReason');	
				document.getElementById('txtOtherReason').value = '';
			}			
		}
		else
		{
			if((document.getElementById('cboReasonforIntOnly').value == 'Other (please provide reason in description box)'))
			{
				showDiv('rowtxtOtherReason');				
			}
			else
			{
				hideDiv('rowtxtOtherReason');	
				document.getElementById('txtOtherReason').value = '';
			}			
		}
	}
	catch(e)
	{
		displayError(e,"HideshowOtherReason");
	}
}

