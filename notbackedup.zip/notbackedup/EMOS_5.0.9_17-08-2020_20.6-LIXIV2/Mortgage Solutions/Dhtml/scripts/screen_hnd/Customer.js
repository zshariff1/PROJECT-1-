//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		E.Elutin,NS
//	Workfile:	Customer.js
//	ModTtime:	04/05/2012
//============================================================-->
//<SCRIPT>

//Global Variables
var G_bCustomerDirty = false;	//flag indicating that the customer details have been changed
var G_SelectedCustomer = 0;		//selected customer record (row) number 

var G_iCurCustTabIdx = 0;		//selected customer tab index

var G_bCustProdRelRefresh = false; //flag to indicate if the customer prod relation needs to be updated.
var G_RefreshAllRelCust = false;

//customer tab images
//var aCustTabImgs = Array ("personal_details", "address_details", "employment_details", "relation_details"); commented on 01/02/2018
//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
var aCustTabImgs = Array ("personal_details", "address_details", "employment_details", "relation_details","tax_resident_details"); 
//New Code Ended

//==============================================================
//	Name:		CustomerScreenShow
//	Purpose:	Shows customer screen. 
//				Loads list boxes on the first show.
//==============================================================
function CustomerScreenShow()
{

	try
	{
		if (!G_oScreens["ScrCustDetails"].ListsPopulated) 
		{
			//Populate Lists
			//personal details
			//WR1970 - Removed the populate list call for customer type.
			populateList("A_TS_HOUSING_STATUSES", document.all.cboCurrentHousing, null, 'STATUS_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_CIS_MARITAL_STATUSES", document.all.cboMaritalStatus, null, 'STATUS_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_CUS_REL_CODES", document.all.cboCustRelCust, "@CATEGORY='CUCU'", 'RELATIONSHIP_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_CUS_GTRRELPB_CODES", document.all.cboGuarantorRelationshipPrimaryBorrower, null, 'RELATIONSHIP_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_CUS_NATUREOFCHANGE_CODES", document.all.cboCustNatureOfChange, null, 'NATURE_CODE', 'CODE_DESC', false, true);
			populateList("A_TS_CUS_MITIGANTCHANGE_CODES", document.all.cboCustomerMitigants, null, 'MITIGANT_CODE', 'CODE_DESC', false, true);
			
			// Card - 256 Starts  
			populateList("A_TS_CUS_RELPB_CODES", document.all.cboRelationshipPrimaryBorrower, "@CATEGORY='GTR'", 'RELATIONSHIP_CODE', 'CODE_DESC', false, true);
			
			G_oScreens["ScrCustDetails"].ListsPopulated = true;
		}
	
		G_bStayInCustScreen=false;
		G_bCustomerDirty = true;
		CheckCompDtsDependents();
		var oN = xml_master.XMLDocument.selectSingleNode("//Customer");
		if (oN) 
		{
			SelectCustomer(1,true);
		}
		else
		{
			G_SelectedCustomer=0;
			document.all.tblCustomerDtlsTab.style.display = 'none';
		}
		G_pScreenSaveFunction = SaveCustomer;
		ShowAddCustomerButton();
	}
	catch(e)
	{
		displayError(e,"CustomerScreenShow");
	}
}

//==============================================================
//	Name:		AddCustomer
//	Purpose:	Adds new customer record
//==============================================================
function AddCustomer()
{
	try
	{
		if (G_SelectedCustomer>0) SaveCustomer();
		
		//WR1970 - Added to incorporate cancel button click in cust screen warning
		if(G_bStayInCustScreen)
		{
			G_bStayInCustScreen=false;
			return;
		}
		
		var oCustomers = xml_master.XMLDocument.documentElement.selectSingleNode("Customers");
		ds_cust.src=ds_cust.src;
		var oNewCust = ds_cust.XMLDocument.documentElement.cloneNode(true)
		InitilizeAppBRS(oNewCust)

		//set id
		oNewCust.selectSingleNode("CustomerID").text = allocateNewID("maxCustomerID");
		
		var remAdrCh=oNewCust.selectSingleNode("CustomerAddresses")
		remAdrCh.removeChild(remAdrCh.selectSingleNode("CustomerAddress"))
	
		var remEmpCh=oNewCust.selectSingleNode("CustomerEmployments")
		remEmpCh.removeChild(remEmpCh.selectSingleNode("EmploymentDetails"))
		//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
		var remTaxResidentCh=oNewCust.selectSingleNode("TaxResidents")
		remTaxResidentCh.removeChild(remTaxResidentCh.selectSingleNode("TaxResidentDetails"))
		//REL 18.1 New Code ended
		oCustomers.appendChild(oNewCust);
		var RecNo = oCustomers.childNodes.length;
		
		ShowAddCustomerButton();
	
		SelectCustomer(RecNo, true);
		G_bCustomerDirty = true;
		G_RefreshAllRelCust=true;
		//New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
		document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + "_faded.gif";	
		document.getElementById("inpAustralia_Y").checked = false;			
		document.getElementById("inpAustralia_N").checked = false;
		
		G_Tax = "";
		document.getElementById("taxcountries").style.display = "none";
		//New Code ended
	}
	catch(e)
	{
		displayError(e,"AddCustomer");
	}
	
}

//==============================================================
//	Name:		SelectCustomer
//	Purpose:	Displays selected customer details. 
//	Parameters:	recNo 	- (numeric) selected customer record number
//				bFromScreen - (boolean) set to true when selection happaen 
//							from the screen (tab 1 will appear and focus 
//							set on the Full Customer Name.) 
//							False - tab won't be switched.
//==============================================================
function SelectCustomer(recNo, bFromScreen)
{
	try
	{
		if (G_SelectedCustomer>0) SaveCustomer(true);
		
		//WR1970 - Added to incorporate cancel button click in cust screen warning
		if(G_bStayInCustScreen)
		{
			if (G_SelectedCustomer > 1)
			{
				if((document.all.CustRowSelector != undefined) || (document.all.CustRowSelector != null))
				{
					document.all.CustRowSelector(G_SelectedCustomer-1).focus();
					document.all.CustRowSelector(G_SelectedCustomer-1).checked=true;
				}
			}
			G_bStayInCustScreen=false;
			//return;	/*Commented "return" statement to fix issue - Defect# 9483[Open file over existing]*/
		}
	
		var oCusts = xml_master.XMLDocument.documentElement.selectSingleNode("Customers");
		if (recNo > oCusts.childNodes.length) recNo = oCusts.childNodes.length;
		if ((!recNo)&&(oCusts.childNodes.length)) recNo = 1;
			
		G_SelectedCustomer = recNo;
		
		if (!recNo) return; 
	
		var oSelected = oCusts.childNodes(recNo-1);
		ds_cust.XMLDocument.async=false;
		ds_cust.src = ds_cust.src;
		ds_cust.XMLDocument.replaceChild(oSelected.cloneNode(true),ds_cust.XMLDocument.documentElement);
		
		var oCustDocEl = ds_cust.XMLDocument.documentElement;
	
		//enable/disable fields 
		CheckDriverLicense(true);
		CheckHomePhone(true);
		CheckWorkPhone(true);
		CheckMobilePhone(true);
		CheckFaxNumber(true);
		CheckEmailAddress(true);
		CheckMaritalStatus(true);
		CheckNumOfDependents(true);
		ChkGFinancecircumstances(true);
		//Card 253 & 254
		CheckResidentStatus(true);
		CheckGuarantorCustType(true);
		ChkExistingCustomer(true);
		Check_CustMitigChange(true);
		Check_CustNatOfChange(true);
		
		if (oCustDocEl.selectSingleNode("CustomerName").text=="New Entry")
			oCustDocEl.selectSingleNode("CustomerName").text="";
	
		document.all.tblCustomerDtlsTab.style.display="block";

		if (bFromScreen) 
		{	
			SwitchCustomerTab(0);
			SetFocusOnElement("cboCustTitle");
		}
	
		//initilize customer addresses with XSL
		oSelected.setAttribute("current","1")
		xml_master.XMLDocument.documentElement.transformNodeToObject(xsl_CustAdrRefresh.XMLDocument, xml_temp.XMLDocument);
		oSelected.setAttribute("current","0")

		var oR=oCustDocEl.selectSingleNode("//CustomerAddresses");
		var oN=xml_temp.XMLDocument.documentElement.cloneNode(true);
		ds_cust.XMLDocument.documentElement.replaceChild(oN,oR);
		
		
		// REMOVE ADDRESS FROM Customer
		var oMDocEl=xml_master.XMLDocument.documentElement;
		var oCustAddrs = oMDocEl.selectNodes("//CustomerAddresses/CustomerAddress");
		var aRCS = oCustAddrs.length;
		if(aRCS > 0){
			for (var arr = 0; arr < aRCS; arr++)
			{
				var node = oCustAddrs(arr);
				var CAdrId = node.selectSingleNode("AddressID").text;
				var oAddr = oMDocEl.selectSingleNode("//Addresses/Address[AddressID="+CAdrId+"]");
				if(oAddr != null){
				}
				else {
					oCustAddrs(arr).parentNode.removeChild(oCustAddrs(arr));
					var oRCustAddrs = oCustDocEl.selectNodes("//CustomerAddresses/CustomerAddress");
					if(oRCustAddrs.length > 0)
						for (var c=oRCustAddrs.length-1; c>=0; c--)
						{
							var node_stub = oCustAddrs(arr);
							var CAdrId_stub = node_stub.selectSingleNode("AddressID").text;
							var oAddr_stub = oMDocEl.selectSingleNode("//Addresses/Address[AddressID="+CAdrId_stub+"]");
							if(oAddr_stub != null){}
							else{
								oRCustAddrs(c).parentNode.removeChild(oRCustAddrs(c));
							}
						}
				}
			}
		}
		
		
		
		
		//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
		var oTaxResidentRecs=ds_cust.XMLDocument.documentElement.selectSingleNode("TaxResidents");		
		var iTaxResidentRecCount=oTaxResidentRecs.childNodes.length;		
		iTaxResidentRecCount=iTaxResidentRecCount-1
		//REL 18.1 New Code Ended
		
		var oEmpRecs=ds_cust.XMLDocument.documentElement.selectSingleNode("CustomerEmployments");
		var iEmpRecCount=oEmpRecs.childNodes.length;
		iEmpRecCount=iEmpRecCount-1
		var iIndex
		//WR1970 - Added New code for handling the add employment button
		ShowHideAddEmpRecBtn();
		//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
		ShowHideAddTaxResidentRecBtn();
		//REL 18.1 New Code Ended

		//WR1970_CMR002 Removed the code for CMR002 Changes
		
		//initilize customer related customers XSL
		
		/* var oMDocEl=xml_master.XMLDocument.documentElement;
		oMDocEl.transformNodeToObject(xsl_CustRelCustRefresh.XMLDocument, xml_temp.XMLDocument);
		var oRelCusts=oCustDocEl.selectSingleNode("RelatedCustomers");
		var oNRelCusts=xml_temp.XMLDocument.documentElement.cloneNode(true);
		ds_cust.XMLDocument.documentElement.replaceChild(oNRelCusts,oRelCusts);
		
		 */ 
		
		SetRowSelectors(document.all.CustRowSelector, recNo);
		
		if (bFromScreen)
		{
		    CheckCompDtsDependents();
		}
		//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes	
		var bSelect= oCustDocEl.selectSingleNode("CustomerType").text;	
		G_Cust_ID=recNo;
		G_Customer_Type=bSelect;
		LookUpTaxResidentDetails(bSelect,oCustDocEl);
		
		
	}
	catch(e)
	{
		displayError(e,"SelectCustomer");
	}
}

// CFDS - 442 - Starts

//==============================================================
//	Name:		LookUpTaxResidentDetails
//	Purpose:	Disables/Enables controls for the customer addresses. 
//	Parameters:	tblCA 	- (HTML TABLE element) customer addresses table
//==============================================================
function LookUpTaxResidentDetails(bSelect,oCustDocEl)
{
	try
	{
		var oCustTax = oCustDocEl; 
		if (G_Product_Type == "RC" || G_breakfree_Type == "New Credit Card") 
		{
			var iCustId = oCustDocEl.selectSingleNode("CustomerID").text;
			document.all.tblCustomerDtlsTab.style.display="block";
			//alert("TEST==> " + G_ACHBrkFreeCard);
			if(G_ACHBrkFreeCard != "")
			{
				if(G_ACHBrkFreeCard == iCustId) {
					document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + ".gif";
					CommonTaxResident(oCustTax);
				}
				else {
					if(bSelect != "GTR") {
						document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + ".gif";
						CommonTaxResident(oCustTax);
					}
					else {
						ClearTaxResident(oCustTax);
					}
					
				}
			}
			else
			{
				if(bSelect != "GTR") {
					document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + ".gif";
					CommonTaxResident(oCustTax);
				}
				else {
					ClearTaxResident(oCustTax);
				}
			}
		}
		else //if ((bSelect == "GTR")) 
		{
			ClearTaxResident(oCustTax);
		}
		
		if ((document.getElementById("inpAustralia_Y").disabled == false) && (document.getElementById("inpAustralia_Y").checked == true || document.getElementById("inpAustralia_N").checked == true))
				G_Sub_Prd_Typ = 5;
		else if (G_Sub_Prd_Typ == 2 && document.getElementById("inpAustralia_Y").checked == false && document.getElementById("inpAustralia_N").checked == false)
			G_Sub_Prd_Typ = 2;
		else 
			G_Sub_Prd_Typ = 3;
		
	}
	catch(e)
	{
		displayError(e,"LookUpTaxResidentDetails");
	}
}

//==============================================================
//	Name:		CommonTaxResident
//	Purpose:	Common Tax Resident for XML Node Values	
//	Parameters:	oCustTax - Current Selected Customer 
//==============================================================
function CommonTaxResident(oCustTax)
{
	try
	{
		if (oCustTax.selectSingleNode("TaxResidentAustralia").text == "Y") {
			document.getElementById("taxcountries").style.display = "none"; 
			G_Tax="Y";
		}
		else if (oCustTax.selectSingleNode("TaxResidentAustralia").text == "N") {
			document.getElementById("taxcountries").style.display = "block"; 
			G_Tax="N";
		}
		else {
			document.getElementById("taxcountries").style.display = "none"; 
			oCustTax.selectSingleNode("TaxResidentAustralia").text = ""; G_Tax="";
			document.getElementById("inpAustralia_Y").checked = false;	document.getElementById("inpAustralia_N").checked = false;
			// CFDS - 442 - Starts
			if((oCustTax.selectSingleNode("TaxResidents/TaxResidentDetails") != null) && (oCustTax.selectSingleNode("TaxResidents/TaxResidentDetails").hasChildNodes))
			{
				var oNewCust = oCustTax;
				var remTaxResidentCh=oNewCust.selectSingleNode("TaxResidents")
				remTaxResidentCh.removeChild(remTaxResidentCh.selectSingleNode("TaxResidentDetails"));
			}
			// CFDS - 442 - Ends
		}
	}
	catch(e)
	{
		displayError(e,"CommonTaxResident");
	}
	
}

//==============================================================
//	Name:		ClearTaxResident
//	Purpose:	Clear Tax Resident for XML Node Values	
//	Parameters:	oCustTax - Current Selected Customer 
//==============================================================
function ClearTaxResident(oCustTax)
{
	try
	{
		//var oNewCust = ds_cust.XMLDocument.documentElement.cloneNode(true)
		document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + "_faded.gif";
		oCustTax.selectSingleNode("TaxResidentAustralia").text = ""; 
		G_Tax = "";
		document.getElementById("inpAustralia_Y").checked = false;	document.getElementById("inpAustralia_N").checked = false;
		// CFDS - 442 - Starts
			if((oCustTax.selectSingleNode("TaxResidents/TaxResidentDetails") != null) && (oCustTax.selectSingleNode("TaxResidents/TaxResidentDetails").hasChildNodes))
			{
				var oNewCust = oCustTax;
				var remTaxResidentCh=oNewCust.selectSingleNode("TaxResidents")
				remTaxResidentCh.removeChild(remTaxResidentCh.selectSingleNode("TaxResidentDetails"));
			}
		// CFDS - 442 - Ends
		
	}
	catch(e)
	{
		displayError(e,"ClearTaxResident");
	}
	
}

// CFDS - 442 Ends

//==============================================================
//	Name:		disableCustAddrsCtls
//	Purpose:	Disables/Enables controls for the customer addresses. 
//	Parameters:	tblCA 	- (HTML TABLE element) customer addresses table
//==============================================================
function disableCustAddrsCtls(tblCA)
{
	//window.status=Date();
	//dissable customer address controls for non-linked addresses
	try
	{
		if (tblCA.readyState!="complete") return;
	
		var oCustAddrs=ds_cust.XMLDocument.documentElement.selectSingleNode("/Customer/CustomerAddresses");
		var c=oCustAddrs.childNodes.length;
		
		for (var iA=0; iA < c; iA++)
		{
			if (oCustAddrs.childNodes(iA).getAttribute("Linked")!="0")
				continue;
			if (c==1)
			{
				DisableElement(tblCA.all.inpCAYY);
				DisableElement(tblCA.all.inpCAMM);
				DisableElement(tblCA.all.cboCustAddrUsg);
			}
			else
			{
				DisableElement(tblCA.all.inpCAYY(iA));
				DisableElement(tblCA.all.inpCAMM(iA));
				DisableElement(tblCA.all.cboCustAddrUsg(iA));
			}
		}
	}
	catch (e) 
	{ 
		//ignore error: it's happen due to asynchronous event  
	}
}

//==============================================================
//	Name:		disableCustRelCustCtls
//	Purpose:	Disables/Enables controls for the customer relationships. 
//	Parameters:	tblCRC 	- (HTML TABLE element) customer relationships table
//==============================================================
function disableCustRelCustCtls(tblCRC)
{
	try
	{
		if (tblCRC.readyState!="complete") return;
	
		//var oRelCusts=ds_custRelCust.XMLDocument.documentElement
		var oRelCusts=ds_cust.XMLDocument.documentElement.selectSingleNode("RelatedCustomers");
		var c=oRelCusts.childNodes.length;
	
		for (var i=0; i < c; i++)
		{
			if (oRelCusts.childNodes(i).getAttribute("Linked")!="0")
				continue;
			if (c==1)
			{
				if (tblCRC.all.cboCustRelCust)	DisableElement(tblCRC.all.cboCustRelCust);
			}
			else
			{
				if (tblCRC.all.cboCustRelCust(i)) DisableElement(tblCRC.all.cboCustRelCust(i));
			}
		}
	}
	catch (e) 
	{ 
		//ignore error: it's happen due to asynchronous event  
	}
}

//==============================================================
//	Name:		DeleteCustomer
//	Purpose:	Deletes customer. 
//	Parameters:	recNo - (numeric) customer record number
//==============================================================
function DeleteCustomer(recNo)
{
	try
	{
		if (!ConfirmDelete()) return;

		var oDocEl = xml_master.XMLDocument.documentElement;

		var oCusts = oDocEl.selectSingleNode("Customers");
		var iCurrentSelected = G_SelectedCustomer;
		
		G_RefreshAllRelCust=true;
		
	
		//find which one to select after deleting
		var iReselect = iCurrentSelected
		if (iCurrentSelected > recNo) iReselect--;
		var bFirstTab=false;
		
		//WR1970 - Deleting the current record
		if(iCurrentSelected=recNo)
			G_bStayInCustScreen=false;
		
		if (iCurrentSelected!=recNo) 
			SaveCustomer();
			
			//WR1970 - Added to incorporate cancel button click in cust screen warning
			if(G_bStayInCustScreen)
			{
				G_bStayInCustScreen=false;
				return;
			}
					
		else
		{
			bFirstTab=true;
			G_bCustomerDirty=false;	
		}
	
		var sDelCustID = oCusts.childNodes(recNo-1).selectSingleNode("CustomerID").text;	
		
		// SPOUSE CHECK STARTS - DELETE
		var sDelCustSpouseID = oCusts.childNodes(recNo-1).selectSingleNode("SpouseID").text;
		var sDelCustMaritalStat =  oCusts.childNodes(recNo-1).selectSingleNode("MaritalStatus").text;	
		// SPOUSE CHECK ENDS - DELETE
		
		
		// DELETE CUSTOMER FOR SPOUSE STARTS
			
			var rRelSpouseID = oCusts.childNodes(recNo-1).selectSingleNode("SpouseID").text;
			var rRelSpouseName = oCusts.childNodes(recNo-1).selectSingleNode("SpouseName").text;
			var oCustSpList=oDocEl.selectNodes("//Customers/Customer[SpouseID="+ sDelCustID +"]");
			if(oCustSpList.length > 0 ){
				for (var i=0; i<oCustSpList.length; i++){
					if(oCustSpList(i) !=  null){
						oCustSpList(i).selectSingleNode("MaritalStatus").text = ""; 
						oCustSpList(i).selectSingleNode("SpouseID").text = ""; 
						oCustSpList(i).selectSingleNode("SpouseName").text = ""; 
					}
				}
			}
			
		// DELETE CUSTOMER FOR SPOUSE ENDS
		
		
		
		// remove Customer from Customer's
		var sDelCustName = oCusts.childNodes(recNo-1).selectSingleNode("CustomerName").text;
		oCusts.removeChild(oCusts.childNodes(recNo-1));
		//remove form customer-to-customer relationships
		var oRelCus=oDocEl.selectNodes("RelatedCustomers/RelatedCustomer[CustomerID1=" + sDelCustSpouseID + " or CustomerID2=" + sDelCustID + "]");
		for (var i=oRelCus.length-1; i>=0; i--)
			oRelCus(i).parentNode.removeChild(oRelCus(i));
	
		//remove customer from IDN if any and reset IDN CustomerSignedID
		var oIDN=oDocEl.selectSingleNode("IDN");
		var oIDNCustomer=oIDN.selectSingleNode("InterviewCustomers/Customer[CustomerID=" + sDelCustID + "]");
		if (oIDNCustomer) oIDNCustomer.parentNode.removeChild(oIDNCustomer);
		var oCustSigned=oIDN.selectSingleNode("CustomerSignedID");
		if (oCustSigned && oCustSigned.text==sDelCustID) oCustSigned.text="";
		//remove customer from SOP if any 
		var oSOPs=oDocEl.selectNodes("StatementsOfPosition/StatementOfPosition/SPCustomers/SPCustomer[CustomerID=" + sDelCustID + "]");
		var bSOPupd=false;
		if (oSOPs)
		{
			bSOPupd = true
			for (var i=oSOPs.length-1; i>=0; i--)
				oSOPs(i).parentNode.removeChild(oSOPs(i));
		}
		
		// Removing AdditionalCardHolder from Packages - Start
		var oPakNode=oDocEl.selectNodes("Packages");
		if((oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID") != null)){
			if(oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text != "") {
				var oACH = oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text;
				sXpath="//Customers/Customer[CustomerID='" + oACH + "']/CustomerID";
				if(oDocEl.selectSingleNode(sXpath) != null) {
					G_ACHBrkFreeCard = oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text;
				}
				else {
					if(oACH != "0")
					{
						G_ACHBrkFreeCard = "";
						oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text ="";
					}
				}
				if(oACH == sDelCustID){
					oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text = "";
					oPakNode.item(0).selectSingleNode("AdditionalCardHolder").text = "";
				}
				
			}
		}	
		// Removing AdditionalCardHolder from Packages - End
		
		// Removing PrimaryCardHolder from Packages - Starts
		if((oPakNode.item(0).selectSingleNode("PrimaryCardHolder") != null)){
			if(oPakNode.item(0).selectSingleNode("PrimaryCardHolder").text != "") {
				var oPCH = oPakNode.item(0).selectSingleNode("PrimaryCardHolder").text;
				if(oPCH == sDelCustID){
					oPakNode.item(0).selectSingleNode("PrimaryCardHolder").text = "";
					oPakNode.item(0).selectSingleNode("PrimaryCardHolderName").text = "";
				}
			}
		}
		// Removing PrimaryCardHolder from Packages - Ends
		
		// Removing TransactionAccountHolder from Packages - Starts
		
		var oPakTNode=oDocEl.selectNodes("Packages/TransactionCustomers/Customer[CustomerID=" + sDelCustID + "]");
		if(oPakTNode.length > 0)
		{
			for (var i=oPakTNode.length-1; i>=0; i--)
			{
				if((oPakTNode(i) != null) || (oPakTNode(i) != undefined))
				{
					oPakTNode(i).parentNode.removeChild(oPakTNode(i));				
				}
			}
		}	
		
		// Removing TransactionAccountHolder from Packages - Ends
		
		//WR1970 - Removing customer from security given by section when the customer is deleted
		//remove customer from Security if any
		var oSecs=oDocEl.selectNodes("Securities/Security/SecuritiesGivenBy/SecurityGivenBy[CustomerID=" + sDelCustID + "]");
		var bSecupd=false;
		if (oSecs)
		{
			bSecupd = true
			for (var i=oSecs.length-1; i>=0; i--)
			{
				oSecs(i).parentNode.removeChild(oSecs(i));				
			}
		}
		
		//WR1970 - Updating the SecurityGivenBy1 and SecurityGivenBy2 when a customer is deleted
		var oSec=oDocEl.selectNodes("Securities/Security");
		if(oSec)
		{		
			for(var i=oSec.length-1; i>=0; i--)
			{
				UpdateSecurityGivenBy(oSec(i));
			}
		}
	
		if (oCusts.childNodes.length)
			SelectCustomer(iReselect,bFirstTab);
		else
		{
			//hide customer details tabs
			tblCustomerDtlsTab.style.display="none";
			G_SelectedCustomer=0;
		}		
		
		//Refresh the related customers nodes for all the products.
		
		ShowAddCustomerButton();
	
		EvaluateAppBRS(oCusts,true);
		
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
		{
			//RefreshAllrelCusts();
			HandleAddRemoveCustomer(sDelCustID,"D");
		}
		
		//Validation of Packages - Starts
		var oLoadPack = oDocEl.selectSingleNode("Packages");
		if (oLoadPack.hasChildNodes){
			EvaluateAppBRS(oDocEl.selectSingleNode("Packages"));
		}
		//Validation of Packages - Ends
		
		if (bSOPupd) EvaluateAppBRS(oDocEl.selectSingleNode("StatementsOfPosition"));
		//WR1970 - Validating for Security Screen
		if (bSecupd) EvaluateAppBRS(oDocEl.selectSingleNode("Securities"));
		EvaluateAppBRS(oDocEl.selectSingleNode("IDN"));
		EvaluateAppBRS(oDocEl.selectSingleNode("Purposes"));
		EvaluateAppBRS(oDocEl,true);
		addFileRefDetails();

		FlushToDisk();	
	}
	catch(e)
	{
		displayError(e,"DeleteCustomer");
	}
}

//==============================================================
//	Name:		SaveCustomer
//	Purpose:	Saves selected customer. 
//	Parameters:	NoReselect - (boolean) should be set to true to 
//								stop customer re-selection. 
//==============================================================
function SaveCustomer(NoReselect)
{
	try
	{
		if (!G_bCustomerDirty) return;
		
		
		//WR1970 - New validation and popup message if no contact numbers are entered 
		var bContinue;
		bContinue=checkContactNos(ds_cust.XMLDocument.documentElement);

		G_bStayInCustScreen=false;
		if (!bContinue) 
		{
		//SelectCustomer(G_SelectedCustomer);	
			G_bStayInCustScreen=true;
			G_GoBackToCust=G_SelectedCustomer;
			return;
		}		
		
		//set ID
		var CustID = ds_cust.recordset.fields("CustomerID").value;
		G_Cust_ID=CustID;
			var CustSpouseID = ds_cust.recordset.fields("SpouseID").value;
		var CustMaritalStat = ds_cust.recordset.fields("MaritalStatus").value;	
		var oCust = ds_cust.XMLDocument.documentElement;
		
		//get type codes descriptions
		var oCustTab= document.all.ScrCustDetails.all.tblCustomerDtlsTab;
		
		//set the customer name fields = WR MT0419
		setCustomerName();
		var sCustName = oCust.selectSingleNode("CustomerName").text;
		oCust.setAttribute("CustomerTypeDescription",getListText(oCustTab.all.cboCustomerType));
		oCust.setAttribute("GenderDescription",getListText(oCustTab.all.cboGender));
		oCust.setAttribute("MaritalStatusDescription",getListText(oCustTab.all.cboMaritalStatus));
		oCust.setAttribute("HousingStatusDescription",getListText(oCustTab.all.cboCurrentHousing));
		//Card 253
		oCust.setAttribute("ResidentStatusDescription",getListText(oCustTab.all.cboResidentStatus));
		oCust.setAttribute("MitigateDescription",getListText(oCustTab.all.cboCustomerMitigants));
		oCust.setAttribute("NatureOfChangeDescription",getListText(oCustTab.all.cboCustNatureOfChange));
		oCust.setAttribute("RelationshipPrimaryBorrowerDescription",getListText(oCustTab.all.cboGuarantorRelationshipPrimaryBorrower)); 
		
		var bCustSelectType = oCust.selectSingleNode("CustomerType").text;			
		if (bCustSelectType=="GTR"){
			ChkGuarantorFinandLegal(true);
		} 
		
		// NEWLY ADDED FOR SPOUSE STARTS
			if(CustSpouseID != ""){
				UpdateCustSpouseName(CustSpouseID,CustID);
			}
		// NEWLY ADDED FOR SPOUSE ENDS
		
		//remove not linked customer addresses
		var oRemCustAddrs = oCust.selectNodes("//CustomerAddress[Type='']");
		for (var c=oRemCustAddrs.length-1; c>=0; c--)
		{
			oRemCustAddrs(c).parentNode.removeChild(oRemCustAddrs(c));
		}
		
		//WR1970_CMR002 Removed for CMR002 Changes

		//remove related customers from under customer and save it to master
		var oRelCusts=oCust.selectSingleNode("RelatedCustomers").cloneNode(true);
		//var oRelCusts=ds_custRelCust.documentElement.cloneNode(true);
		var oNewCust=oCust.cloneNode(true);
		var oRemRelCusts=oNewCust.selectSingleNode("RelatedCustomers");
		for (var i=oRemRelCusts.childNodes.length-1; i>=0; i--)
			oRemRelCusts.removeChild(oRemRelCusts.childNodes(i));
			
		//save customer to master
		var xPath = "Customers/Customer[CustomerID=" + CustID + "]";
		var oMDocEl=xml_master.XMLDocument.documentElement;
		var oReplCust = oMDocEl.selectSingleNode(xPath);
		oMDocEl.selectSingleNode("Customers").replaceChild(oNewCust,oReplCust);
		
		//save related customers
		// NEW REQUIREMENT STARTS - 421
		
		xml_master.XMLDocument.documentElement.transformNodeToObject(xsl_CustRelCustRefresh.XMLDocument, xml_temp.XMLDocument);
		var oReplCustRel = xml_temp;
		
		if(oMDocEl.getElementsByTagName("RelatedCustomers").length > 0){
			var oRCS = oMDocEl.selectSingleNode("//Application");
			if(oRCS!= null){
				var oRemmovAddrs  = oMDocEl.selectSingleNode("//Application/RelatedCustomers");
				if(oRemmovAddrs!= null){
					oMDocEl.removeChild(oRemmovAddrs);
					var cRCS=oReplCustRel.childNodes.length;
					for (var c=0; c<cRCS; c++){
						if (oReplCustRel.childNodes(c).getAttribute("Linked")!= "0")
						oRCS.appendChild(oReplCustRel.childNodes(c).cloneNode(true));
					}
				}
				
			}
		}
		
		// NEW REQUIREMENT ENDS - 421
	
	
		// REMOVE ADDRESS FROM Customer
		var oMDocEl=xml_master.XMLDocument.documentElement;
		var oCustAddrs = oMDocEl.selectNodes("//CustomerAddresses/CustomerAddress");
		var aRCS = oCustAddrs.length;
		if(aRCS > 1){
			for (var arr = 0; arr < aRCS; arr++)
			{
				var node = oCustAddrs(arr);
				var CAdrId = node.selectSingleNode("AddressID").text;
				var oAddr = oMDocEl.selectSingleNode("//Addresses/Address[AddressID="+CAdrId+"]");
				if(oAddr != null){
				}
				else {
					oCustAddrs(arr).parentNode.removeChild(oCustAddrs(arr));
					var oRCustAddrs = oCust.selectNodes("//CustomerAddresses/CustomerAddress");
					if(oRCustAddrs.length > 0)
						for (var c=oRCustAddrs.length-1; c>=0; c--)
						{
							var node_stub = oCustAddrs(arr);
							var CAdrId_stub = node_stub.selectSingleNode("AddressID").text;
							var oAddr_stub = oMDocEl.selectSingleNode("//Addresses/Address[AddressID="+CAdrId_stub+"]");
							if(oAddr_stub != null){}
							else{
								oRCustAddrs(c).parentNode.removeChild(oRCustAddrs(c));
							}
							
						}
				}
			}
		}
		
		//recalculate SOP totals
		var oSOP=oMDocEl.selectSingleNode("StatementsOfPosition/StatementOfPosition[SPCustomers/SPCustomer/CustomerID='"+CustID+"']");
		if (oSOP) CalculateTotals(oSOP);
		
		
		
		//updating security given by customer names
		var oSec = oMDocEl.selectNodes("Securities/Security");
		
		if (oSec) 
		{
			for(var i=oSec.length-1; i>=0; i--)
			{
				UpdateSecCustName(oSec(i), CustID, sCustName);
				UpdateSecurityGivenBy(oSec(i));
			}
		}
				


		//Refresh the related customers for all products and run AppBRS at purpose level.
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
		{
			if (G_bCustProdRelRefresh && !G_RefreshAllRelCust)
			{
				var sXPath ="//Purposes/Purpose/Products/Product/RelatedCustomers/RelatedCustomer[CustomerID='"+CustID+"']"
				var oProdRelCusts = oMDocEl.selectNodes(sXPath);
				var cRCount=oProdRelCusts.length;
				var oProdRelCust;
				var oParentNode;

				if (cRCount>0)
				{
					for (var iCindex=0; iCindex<cRCount; iCindex++)
					{
						oProdRelCust=oProdRelCusts(iCindex);
						oProdRelCust.setAttribute("customerName",sCustName);
					}
				}
				
				sXpath="//Purposes/Purpose/Products/Product[DepositDetails/PortfolioPrimaryAccount='-1']";
				var oPrimAccProd=oMDocEl.selectSingleNode(sXpath);
				if(oPrimAccProd)
					LinkCutomerToProduct(oPrimAccProd);
								
				G_bCustProdRelRefresh=false;
			}
			
			if (G_RefreshAllRelCust)
			{
				
				HandleAddRemoveCustomer(CustID,"A");
				
				//HandleAddRemoveCustomer(ds_cust.XMLDocument.documentElement);
				G_RefreshAllRelCust=false;
			}	
			
		}
		
		// Saving Tax Resident Details for Customer 
		LookUpTaxResidentDetailsSave(bCustSelectType,oCust);
		
			
		//Added for Validating the Packages Screen - Starts 
		var oLoadPack = oMDocEl.selectSingleNode("Packages");
		if (oLoadPack.hasChildNodes){
			var oPakNode=oMDocEl.selectNodes("Packages");
			
					// Updating PrimaryCardHolder,TransactionAccountHolder,AdditionalCardHolder Name in Packages - Starts
					if((oPakNode.item(0).selectSingleNode("PrimaryCardHolder") != null)){
						if(oPakNode.item(0).selectSingleNode("PrimaryCardHolder").text != "") {
							var oPCH = oPakNode.item(0).selectSingleNode("PrimaryCardHolder").text;
							if(oPCH == CustID){
								if(oPakNode.item(0).selectSingleNode("PrimaryCardHolderName") != null)
								{
									oPakNode.item(0).selectSingleNode("PrimaryCardHolderName").text = sCustName;
								}
							}
						}
					}
					if((oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID") != null)){
						if(oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text != "") {
							var oACH = oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text;
							if(oACH == CustID){
								if(oPakNode.item(0).selectSingleNode("AdditionalCardHolder") != null)
								{
									oPakNode.item(0).selectSingleNode("AdditionalCardHolder").text = sCustName;
								}
							}
						}
					}
					
					var oPakTNode=oMDocEl.selectNodes("Packages/TransactionCustomers/Customer");
					if(oPakTNode.length > 0)
					{
						for(var iIndex=0; iIndex<oPakTNode.length; iIndex++)
						{
							if(oPakTNode.item(iIndex).selectSingleNode("CustomerID").text == CustID)
								oPakTNode.item(iIndex).setAttribute("CustomerName", sCustName);				
						}
					}	
					
					// Updating PrimaryCardHolder,TransactionAccountHolder,AdditionalCardHolder Name in Packages - Ends
			
			
			EvaluateAppBRS(oMDocEl.selectSingleNode("Packages"));
		}
		
		//Added for Validating the Packages Screen - Ends
			
		EvaluateAppBRS(oNewCust);
		EvaluateAppBRS(oMDocEl.selectSingleNode("Customers"),true);
		//validate SOP because new direct owner may be saved
		EvaluateAppBRS(oMDocEl.selectSingleNode("StatementsOfPosition"));
		EvaluateAppBRS(oMDocEl.selectSingleNode("Purposes"));
		EvaluateAppBRS(oMDocEl,true);
		addFileRefDetails();
		
		FlushToDisk();  
		
		G_bCustomerDirty=false;
		if (!NoReselect) SelectCustomer(G_SelectedCustomer);
	
	}
	catch(e)
	{
		displayError(e,"SaveCustomer");
	}
}


//==============================================================
//	Name:		LookUpTaxResidentDetailsSave
//	Purpose:	Disables/Enables controls for the customer addresses. 
//	Parameters:	tblCA 	- (HTML TABLE element) customer addresses table
//==============================================================
function LookUpTaxResidentDetailsSave(bSelect,oCustDocEl)
{
	try
	{
		var oCustTax = oCustDocEl; 
		if (G_Product_Type == "RC" || G_breakfree_Type == "New Credit Card") 
		{
			var iCustId = oCustDocEl.selectSingleNode("CustomerID").text;
			//alert("SAVE==> " + G_ACHBrkFreeCard);
			if(G_ACHBrkFreeCard != "")
			{
				if(G_ACHBrkFreeCard == iCustId) {
					document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + ".gif";
					CommonTaxResidentSave(oCustTax);
				}
				else
				{
					if(bSelect != "GTR") {
						document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + ".gif";
						CommonTaxResidentSave(oCustTax);
					}
					else {
						ClearTaxResident(oCustTax);
					}
				}
			}
			else
			{
				if(bSelect != "GTR") {
					document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + ".gif";
					CommonTaxResidentSave(oCustTax);
				}
				else {
					ClearTaxResident(oCustTax);
				}
			}
		}
		else //if ((bSelect == "GTR")) 
		{
			ClearTaxResident(oCustTax);
		}
		
	}
	catch(e)
	{
		displayError(e,"LookUpTaxResidentDetailsSave");
	}
}


function CommonTaxResidentSave(oCustTax)
{
	try
	{
		if (document.getElementById('inpAustralia_Y').checked == true) {
			oCustTax.selectSingleNode("TaxResidentAustralia").text = "Y"; G_Tax="Y";
			document.getElementById("taxcountries").style.display = "none";
		}
		else if (document.getElementById('inpAustralia_N').checked == true) {
			oCustTax.selectSingleNode("TaxResidentAustralia").text = "N"; G_Tax="N";
			document.getElementById("taxcountries").style.display = "block"; 
		}
		else {
			document.getElementById("taxcountries").style.display = "none"; 
			oCustTax.selectSingleNode("TaxResidentAustralia").text = ""; G_Tax="";
			document.getElementById("inpAustralia_Y").checked = false;	document.getElementById("inpAustralia_N").checked = false;
			// CFDS - 442 - Starts
			if((oCustTax.selectSingleNode("TaxResidents/TaxResidentDetails") != null) && (oCustTax.selectSingleNode("TaxResidents/TaxResidentDetails").hasChildNodes))
			{
				var oNewCust = oCustTax;
				var remTaxResidentCh=oNewCust.selectSingleNode("TaxResidents")
				remTaxResidentCh.removeChild(remTaxResidentCh.selectSingleNode("TaxResidentDetails"));
			}
			// CFDS - 442 - Ends
		}
	}
	catch(e)
	{
		displayError(e,"CommonTaxResidentSave");
	}
}

//==============================================================
//	Name:		CheckDriverLicense
//	Purpose:	Disables/Enables and resets/defaults driver licence control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckDriverLicense(bSelect)
{
	try
	{
		var sDL=(bSelect)? ds_cust.recordset.fields("DriversLicenseNumber").value:document.all.DrivLic.value;

		if ((!bSelect)&&(sDL.length==0)) ds_cust.recordset.fields("DriversLicenseState").value="";

		DisableElement(document.all.cboDrivLicState, (sDL.length>0)); 
	}
	catch(e)
	{
		displayError(e,"CheckDriverLicense");
	}
}
//==============================================================
//	Name:		CheckHomePhone
//	Purpose:	Disables/Enables and resets/defaults home phone control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckHomePhone(bSelect)
{
	try
	{
		var sDL=(bSelect)? ds_cust.recordset.fields("HomePhoneNumber").value:document.all.HomePh.value;
		if ((!bSelect)&&(sDL.length==0)) ds_cust.recordset.fields("HomePhonePreferred").value="";

		DisableElement(document.all.chomephone, (sDL.length>0)); 
	}
	catch(e)
	{
		displayError(e,"CheckHomePhone");
	}
}
//==============================================================
//	Name:		CheckWorkPhone
//	Purpose:	Disables/Enables and resets/defaults work phone control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckWorkPhone(bSelect)
{
	try
	{
		var sDL=(bSelect)? ds_cust.recordset.fields("BusinessPhoneNumber").value:document.all.WorkPh.value;
		if ((!bSelect)&&(sDL.length==0)) ds_cust.recordset.fields("BusinessPhonePreferred").value="";

		DisableElement(document.all.chkworkphone, (sDL.length>0)); 
	}
	catch(e)
	{
		displayError(e,"CheckWorkPhone");
	}
}
//==============================================================
//	Name:		CheckMobilePhone
//	Purpose:	Disables/Enables and resets/defaults mobile phone control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckMobilePhone(bSelect)
{
	try
	{
		var sDL=(bSelect)? ds_cust.recordset.fields("MobilePhoneNumber").value:document.all.MobPh.value;
		if ((!bSelect)&&(sDL.length==0)) ds_cust.recordset.fields("MobilePhonePreferred").value="";

		DisableElement(document.all.chkmobilephone, (sDL.length>0)); 
	}
	catch(e)
	{
		displayError(e,"CheckMobilePhone");
	}
}
//==============================================================
//	Name:		CheckFaxNumber
//	Purpose:	Disables/Enables and resets/defaults fax number control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckFaxNumber(bSelect)
{
	try
	{
		var sDL=(bSelect)? ds_cust.recordset.fields("FaxNumber").value:document.all.FaxNum.value;
		if ((!bSelect)&&(sDL.length==0)) ds_cust.recordset.fields("FaxPreferred").value="";

		DisableElement(document.all.chkfax, (sDL.length>0)); 
	}
	catch(e)
	{
		displayError(e,"CheckFaxNumber");
	}
}
//==============================================================
//	Name:		CheckEmailAddress
//	Purpose:	Disables/Enables and resets/defaults EmailAddress control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckEmailAddress(bSelect)
{
	try
	{
		var sDL=(bSelect)? ds_cust.recordset.fields("EmailAddress").value:document.all.inpEmail.value;
		if ((!bSelect)&&(sDL.length==0)) ds_cust.recordset.fields("EmailAddressPreferred").value="";
		DisableElement(document.all.chkemail, (sDL.length>0)); 
		
	}
	catch(e)
	{
		displayError(e,"CheckEmailAddress");
	}
}
//==============================================================
//	Name:		disableChkBoxes
//	Purpose:	Disables/Enables and resets/defaults EmailAddress control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================

function disableChkBoxes(id)
{

	try
	{
		if(document.getElementById(id).checked ==true){
			 document.getElementById('chomephone').disabled =true;
			 document.getElementById('chkworkphone').disabled =true;
			 document.getElementById('chkmobilephone').disabled =true;
			 document.getElementById('chomephone').checked =false;
			 document.getElementById('chkworkphone').checked =false;
			 document.getElementById('chkmobilephone').checked =false;
			 document.getElementById(id).disabled = false;
			 document.getElementById(id).checked = true;
		}
		else{
			 document.getElementById('chomephone').disabled =false;
			 document.getElementById('chkworkphone').disabled =false;
			 document.getElementById('chkmobilephone').disabled =false;
		}
 		 if(document.getElementById('HomePh').value==""){
		   document.getElementById('chomephone').checked==false;document.getElementById('chomephone').disabled =true;
		 } 
		 if(document.getElementById('WorkPh').value==""){
		   document.getElementById('chkworkphone').checked==false;document.getElementById('chkworkphone').disabled =true;
		 } 
		 if(document.getElementById('MobPh').value==""){
		   document.getElementById('chkmobilephone').checked==false;document.getElementById('chkmobilephone').disabled =true;
		 } 
	}
	catch(e)
	{
		displayError(e,"disableChkBoxes");
	}
}

//==============================================================
//	Name:		CheckMaritalStatus
//	Purpose:	Disables/Enables and resets/defaults spouse name control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckMaritalStatus(bSelect)
{
	try
	{
		var sMS = (bSelect)? ds_cust.recordset.fields("MaritalStatus").value:document.all.cboMaritalStatus.value;
		var nSurNam = (bSelect)? ds_cust.recordset.fields("CustomerSurname").value:document.all.inpCustSurname.value;
		
		if ((!bSelect)&&((sMS!="M")&&(nSurNam != ""))){
				ds_cust.recordset.fields("SpouseID").value="0";
				ds_cust.recordset.fields("SpouseName").value="Not In Application";
				
			}
			else{
				if ((sMS=="M")&&(nSurNam != "")){
					PopulateCustSpouseNameCombo();}
			}
			DisableElement(document.all.cbocustspousename, ((sMS=="M")&&(nSurNam != "")));
			
		
	}
	catch(e)
	{
		displayError(e,"CheckMaritalStatus");
	}
}

//==============================================================
//	Name:		CheckNumOfDependents
//	Purpose:	Disables/Enables and resets/defaults age of dependents control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckNumOfDependents(bSelect)
{
	try
	{
		var ND = (bSelect)? ds_cust.recordset.fields("NumberOfDependents").value:document.all.inpNumOfDep.value;
		ND = GetIntVal(ND);
		if (!bSelect)
		{
			if (ND==0) ds_cust.recordset.fields("AgeOfDependents").value="";
		}
		DisableElement(document.all.inpAgeOfDep,(ND>0));
	}
	catch(e)
	{
		displayError(e,"CheckNumOfDependents");
	}
}
// Start : Card 253 & 254

//==============================================================
//	Name:		CheckResidentStatus
//	Purpose:	Disables/Enables and resets/defaults Resident Status control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckResidentStatus(bSelect)
{
	try
	{
		var sRS = (bSelect)? ds_cust.recordset.fields("ResidentStatus").value:document.all.cboResidentStatus.value;
	
		if ((!bSelect)&&(sRS!="TemporaryResident")) ds_cust.recordset.fields("VisaSubclass").value="";
	
		DisableElement(document.all.txtVisaSubclass, (sRS=="TemporaryResident"));
	}
	catch(e)
	{
		displayError(e,"CheckResidentStatus");
	}
}

//==============================================================
//	Name:		CheckGuarantorCustType
//	Purpose:	Disables/Enables and resets/defaults Guarantor Customer Type control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckGuarantorCustType(bSelect)
{
	try
	{
		var sRS = (bSelect)? ds_cust.recordset.fields("CustomerType").value:document.all.cboCustomerType.value;
	
		if ((!bSelect)&&(sRS!="GTR")) 
		{
			ds_cust.recordset.fields("ServiceGuarantor").value="";
			ds_cust.recordset.fields("FinancialAdvReq").value="0";
			ds_cust.recordset.fields("LegalAdvReq").value="0"; 
			ds_cust.recordset.fields("RelationshipPrimaryBorrower").value="";
		}
	
		DisableElement(document.all.chkServiceGuarantor, (sRS=="GTR"));
		DisableElement(document.all.chkFinAdvReq, (sRS=="GTR"));
		DisableElement(document.all.chkLegalAdvReq, (sRS=="GTR")); 
		//cboGuarantorRelationshipPrimaryBorrower
		DisableElement(document.all.cboGuarantorRelationshipPrimaryBorrower, (sRS=="GTR"));
		//DisableElement(document.all.chkFinLegalAdvReq, (sRS=="GTR"));
	}
	catch(e)
	{
		displayError(e,"CheckGuarantorCustType");
	}
}

// End : Card 253 & 254

//==============================================================
//	Name:		VE_AgeOfDep
//	Purpose:	Prohibits entering any symbols other then comma or digits
//==============================================================
function VE_AgeOfDep()
{
	try
	{
		var KeyCode=window.event.keyCode;
		if (KeyCode==32) KeyCode=44;
		if ((KeyCode<48||KeyCode>57)&&(KeyCode!=44)) KeyCode=0;
		window.event.keyCode=KeyCode;
	}
	catch(e)
	{
		displayError(e,"VE_AgeOfDep");
	}	
}

//==============================================================
//	Name:		OrderAgeOfDep
//	Purpose:	Orders the integers in asending order for easier
//				comparison in transformation to remove duplicated
//				dependents
//==============================================================
function OrderAgeOfDep(bSelect)
{
	try
	{
		//get the age list
		var sAgeList = new String(VBReplace(ds_cust.recordset.fields("AgeOfDependents").value," ",""));
		//put the list in an array
		var arrAgesStr = sAgeList.split(",");
		var arrAgesInt = new Array();
		var i=0;
		var sTemp="";
		//place all the valid integers into an integer array
		while (arrAgesStr.length>0)
		{
			sTemp = arrAgesStr.shift();
			if (sTemp.length>0 && sTemp.length<4 && !isNaN(sTemp))
			{
				arrAgesInt[i] = parseInt(sTemp,10);
				i++;
			}
		}
		
		//sort the array
		arrAgesInt.sort(sortNumbers);
		sAgeList="";
		while (arrAgesInt.length>0)
		{
			if (sAgeList.length>0)
				sAgeList = sAgeList + ",";
			sAgeList = sAgeList + arrAgesInt.shift();
		}
		
		//reset the re-ordered age list
		ds_cust.recordset.fields("AgeOfDependents").value = sAgeList;
	}
	catch(e)
	{
		displayError(e,"OrderAgeOfDep");
	}	
}

//==============================================================
//	Name:		sortNumbers
//	Purpose:	Used in sorting a numerical array
//==============================================================
function sortNumbers(a, b) { return a - b} 

//==============================================================
//	Name:		linkAddress
//	Purpose:	Links address to the customer. 
//	Parameters:	RecNo - (numeric) address record number
//==============================================================
function linkAddress(RecNo)
{
	try
	{
		if (RecNo-1<0) return;
	
		var oCustAddrs=ds_cust.XMLDocument.documentElement.selectSingleNode("/Customer/CustomerAddresses");
		var oA = oCustAddrs.childNodes(RecNo-1);
		var bLinked=(oA.getAttribute("Linked")!="0");
	
		oA.selectSingleNode("YearsAtAddress").text=(bLinked)? "0":"";
		oA.selectSingleNode("MonthsAtAddress").text=(bLinked)? "0":"";
		oA.selectSingleNode("Type").text = (bLinked)? "CR":"";
		if (bLinked)
			InitilizeAppBRS(oA);
		else
			oA.setAttribute("valid_MonthsAtAddress","");
		
		var oCATbl = document.all.tblCustAddrs.all;
		var bMltRec = (oCATbl.inpCAYY.length>0);
		var oCboUsg = (bMltRec)? oCATbl.cboCustAddrUsg(RecNo-1):oCATbl.cboCustAddrUsg;
		var oInpYY = (bMltRec)? oCATbl.inpCAYY(RecNo-1):oCATbl.inpCAYY;
		var oInpMM = (bMltRec)? oCATbl.inpCAMM(RecNo-1):oCATbl.inpCAMM;
		
		DisableElement(oCboUsg, bLinked);
		DisableElement(oInpYY, bLinked);
		DisableElement(oInpMM,bLinked);
		
		oA.setAttribute("TypeDescription",getListText(oCboUsg));
	}
	catch(e)
	{
		displayError(e,"linkAddress");
	}	
}

//==============================================================
//	Name:		GetAddressUsageDesc
//	Purpose:	Gets address usage description from the lis box.
//	Parameters:	RecNo - (numeric) address record number
//==============================================================
function GetAddressUsageDesc(RecNo)
{
	try
	{
		if (RecNo-1<0) return;
		var oCustAddrs=ds_cust.XMLDocument.documentElement.selectSingleNode("/Customer/CustomerAddresses");
		var oA = oCustAddrs.childNodes(RecNo-1);
		oA.setAttribute("TypeDescription",getListText(window.event.srcElement));
	}
	catch(e)
	{
		displayError(e,"GetAddressUsageDesc");
	}	
}

//==============================================================
//	Name:		linkCustCust
//	Purpose:	Links customers.
//	Parameters:	RecNo - (numeric) related customer record number
//==============================================================
function linkCustCust(RecNo)
{
	try
	{
		if (RecNo-1<0) return;
	
		var oCustRelCust=ds_cust.XMLDocument.documentElement.selectSingleNode("RelatedCustomers");
	
		var oRC = oCustRelCust.childNodes(RecNo-1);
		var bLinked=(oRC.getAttribute("Linked")!="0");
			
		oRC.selectSingleNode("Relationship").text =(bLinked)? "REL":"";
		
		var oCRTbl = document.all.tblCustRelCust.all;
		var bMltRec = (oCRTbl.chkCustRelCust.length>0);
		var oCboRel = (bMltRec)? oCRTbl.cboCustRelCust(RecNo-1):oCRTbl.cboCustRelCust;
		
		DisableElement(oCboRel,(bLinked));
		oRC.setAttribute("RelationshipDescription",getListText(oCboRel));
		
	}
	catch(e)
	{
		displayError(e,"linkCustCust");
	}	
}

//==============================================================
//	Name:		GetCustomerRelDesc
//	Purpose:	Gets customer relationship description from the lis box.
//	Parameters:	RecNo - (numeric) related customer record number
//==============================================================
function GetCustomerRelDesc(RecNo)
{
	try
	{
		if (RecNo-1<0) return;
		var oCustRelCust=ds_cust.XMLDocument.documentElement.selectSingleNode("RelatedCustomers");
		var oRC = oCustRelCust.childNodes(RecNo-1);
		oRC.setAttribute("RelationshipDescription",getListText(window.event.srcElement));
	}
	catch(e)
	{
		displayError(e,"GetCustomerRelDesc");
	}	
}

//==============================================================
//	Name:		DeleteCustomerAddress
//	Purpose:	Deletes customer address link
//	Parameters:	recNo - (numeric) address record number
//==============================================================
function DeleteCustomerAddress(recNo)
{
	try
	{
		var oCustAdd = ds_cust.XMLDocument.documentElement;
		var cust_recNo = recNo;
		var sec_recNo  = "";
		DeleteCustomerSecurityAddress(cust_recNo,sec_recNo,oCustAdd,"C");
	}
	catch(e)
	{
		displayError(e,"DeleteCustomerAddress");
	}		
}

//==============================================================
//	Name:		AddUpdateCustomerAddress
//	Purpose:	Updates or add new address item.
//	Parameters:	recNo - (numeric) address record number for edit address
//==============================================================
function AddUpdateCustomerAddress(recNo)
{
	try
	{
		var AdrId = 0;
		var oCustAddrs=ds_cust.XMLDocument.documentElement.selectSingleNode("/Customer/CustomerAddresses")
		var oCustAdr;
		var bSecurityAddr=false;
		if (recNo)
		{
			oCustAdr = oCustAddrs.childNodes(recNo-1);
			var AdrId = oCustAdr.selectSingleNode("AddressID").text;
			var sSecAdrPath="Securities/Security[AddressID='"+AdrId+"']";
			bSecurityAddr = (xml_master.XMLDocument.documentElement.selectSingleNode(sSecAdrPath))? true:false;
		}
	
		var oAdr = AddUpdateAddress(AdrId, bSecurityAddr);
		if (oAdr)
		{
			//add new cust address from stub
			if (!oCustAdr) oCustAdr=xml_AddrLnkStub.XMLDocument.documentElement.selectSingleNode("//CustomerAddress").cloneNode(true);
			oCustAdr.setAttribute("AddressDetails", oAdr.getAttribute("AddressDetails"));
			var CustUpAdr = oAdr.getAttribute("AddressDetails");
			if(CustUpAdr != "")
				UpdateAssetAddr(CustUpAdr,AdrId);
				UpdateLiabilityAddr(CustUpAdr,AdrId);
			if (!recNo) 
			{
				oCustAdr.selectSingleNode("AddressID").text=oAdr.selectSingleNode("AddressID").text;
				oCustAddrs.appendChild(oCustAdr);
				disableCustAddrsCtls(document.all.tblCustAddrs);
			}
		}
		G_Sub_Prd_Typ=5;
	}
	catch(e)
	{
		displayError(e,"AddUpdateCustomerAddress");
	}	
}


//==============================================================
//	Name:		SwitchCustomerTab
//	Purpose:	Switches customer tabs
//	Parameters:	iTabIdx			- (numeric) selected tab index
//				sFocusControl	- (string) name of the control to set focus on
//==============================================================
function SwitchCustomerTab(iTabIdx, sFocusControl)
{	
	try
	{
		var oTabs = document.all.ScrCustDetails.all.CustDetailsTab;		// product tabs
	
		//faded
		var currimg=document.all.ScrCustDetails.all.imgCustDetailsTab(iTabIdx).src;
		if (currimg.indexOf("_faded.gif")>=0) return;
				
		if (G_iCurCustTabIdx != null) 	
		{
			oTabs(G_iCurCustTabIdx).style.display = "none";
			document.all.ScrCustDetails.all.imgCustDetailsTab(G_iCurCustTabIdx).src = "../images/tabs/" + aCustTabImgs[G_iCurCustTabIdx] + ".gif";
		}
			
		oTabs(iTabIdx).style.display = "block";
		document.all.ScrCustDetails.all.imgCustDetailsTab(iTabIdx).src = "../images/tabs/" + aCustTabImgs[iTabIdx] + "_dn.gif";
		G_iCurCustTabIdx = iTabIdx;
		window.scrollTo(0,0) 
		if (sFocusControl && document.all(sFocusControl)) document.all(sFocusControl).focus();
		
		//WR1970 - New function added to check if the 
		ShowHideSaveButton(aCustTabImgs[iTabIdx])
	}
	catch(e)
	{
		displayError(e,"SwitchCustomerTab");
	}	
}

//==============================================================
//	Name:		ShowAddCustomerButton
//	Purpose:	Hides/Displays add customer button.
//==============================================================
function ShowAddCustomerButton()
{
	try
	{
		var nCusts=xml_master.XMLDocument.documentElement.selectNodes("Customers/Customer").length;
		document.all.AddCustCmd.style.display = (nCusts<12)? "":"none";
		document.all.MaxCustMsg.style.display = (nCusts>=12)? "":"none";
	}
	catch(e)
	{
		displayError(e,"ShowAddCustomerButton");
	}	
}

//==============================================================
//	Name:		ShowAddCountryButton
//	Purpose:	Hides/Displays add country button.
//==============================================================
function ShowAddCountryButton()
{
	try
	{
		var nCountries=xml_master.XMLDocument.documentElement.selectNodes("Customers/Countries").length;
		document.all.AddCountryCmd.style.display = (nCountries<6)? "":"none";
		document.all.MaxCountriesMsg.style.display = (nCountries>=6)? "":"none";
	}
	catch(e)
	{
		displayError(e,"ShowAddCountryButton");
	}	
}
//==============================================================
//	Function Name:	setCustomerName
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Concatinates the First, Middle and Surname fields
//					into 1 40 length customer full name, Mailing title
//					and formal salutation
//==============================================================
function setCustomerName()
{
	try
	{
		var sCustFullName = new String("");
		var sMailingTitle = new String("");
		var sFormalSalutation = new String("");
		var sFirstNameArr = new Array();
		var sMidNameArr = new Array();
		var oCust = ds_cust.XMLDocument.documentElement;
		var bContinue = -1;
		var i=0;
		var x=0;
		
		//get the various name fields
		var sFirstName = new String(VBTrim(oCust.selectSingleNode("CustomerFirstName").text));
		var sMiddleNames = new String(VBTrim(oCust.selectSingleNode("CustomerMiddleName").text));
		var sSurname = new String(VBTrim(oCust.selectSingleNode("CustomerSurname").text));
		var sTitle = new String(VBTrim(oCust.selectSingleNode("CustomerTitle").text));
		
		//create the first and last name arrays
		createNameArray(sFirstNameArr, sFirstName, -1);
		createNameArray(sMidNameArr, sMiddleNames, -1);
	
		//concat names until we get one <= 40 charactors
		while (bContinue)
		{
			//concat the names
			sCustFullName = VBTrim(VBReplace(sFirstNameArr[i] + " " + sMidNameArr[x] + " " + sSurname,"  "," "));
			
			//if new customer name is less then forty chars then exit the loop
			if (sCustFullName.length <= 40)
				bContinue = 0;
			
			//increment the index's for first and middle names
			(x < sMidNameArr.length-1)?x++:i++;
		}
		
		//create the mailing title &  formal salutation
		sFormalSalutation = VBTrim(VBReplace(sTitle + " " + sSurname,"  "," "));
		sMailingTitle = VBTrim(VBReplace(sTitle + " " + sFirstName.charAt(0).toUpperCase() + " " + sSurname,"  "," "));
		
		//remove the title if the formal salutation is too long
		if (sFormalSalutation.length > 40)
			sFormalSalutation = VBTrim(VBReplace(sSurname,"  "," "));
		
		//set mailing title = to the formal salutation if it is too big
		if (sMailingTitle.length > 40)
			sMailingTitle = sFormalSalutation
			
		//set the customer name fields
		oCust.selectSingleNode("CustomerName").text=sCustFullName;
		oCust.selectSingleNode("MailingTitle").text=sMailingTitle;
		oCust.selectSingleNode("Salutation").text=sFormalSalutation;
	
	}
	catch (e)
	{
		displayError(e,"setCustomerName");
	}
}

//==============================================================
//	Function Name:	createNameArray
//	Parameters:		p_sName - String containing 1 or more names
//	Return:			Array (String)
//	Description:	Takes a string and breaks it into the options
//==============================================================
function createNameArray(p_oArray,p_sName,p_bIntials)
{
	var sName="";
	var sInitials = new String("");
	var sNameArr = p_sName.split(" ");
	
	//loop through each name
	for (var i=0;i<sNameArr.length; i++)
	{
		//concatinate the names minus 1 each time
		for (var x=0;x<(sNameArr.length-i);x++)
			sName = sName + sNameArr[x] + " "
		
		//add the name to the name array
		p_oArray[p_oArray.length] = VBTrim(sName);
		sName = "";
		
		//Create a string with the initials
		if (p_bIntials)
			 sInitials = sInitials + sNameArr[i].charAt(0) + " ";
	}
	
	//create the inital array if required
	if (p_bIntials)
	{
		//Upper case the initials and trim excess space
		sInitials = VBTrim(sInitials.toUpperCase());
		//add initials to name array
		createNameArray (p_oArray,sInitials,0);
	}
	else
	{
		//add a blank name to end of the array
		p_oArray[p_oArray.length] = "";
	}
}

//==============================================================
//	Name:		SetCustomerDirty
//	Purpose:	Sets customer details changed flag
//==============================================================
function SetCustomerDirty()
{
	G_bCustomerDirty = true;
}
//WR1970- New Functions Added
//==============================================================
//	Name:		checkContactNos
//	Parameters:	None
//	Return:		boolean
//	Purpose:	Checks if the contact number is entered and sets
//				flag if the application is getting saved for the
//				first time.

//==============================================================
function checkContactNos(oCustNode)
{
	try
	{
		var iIsContactNoChecked
		iIsContactNoChecked=oCustNode.getAttribute("ContactNosValidated");
		iIsContactNoChecked=Number(iIsContactNoChecked);
		if(iIsContactNoChecked==0)
		{
			var oCustNode=oCustNode;
			
			var iCustId=oCustNode.selectSingleNode("CustomerID").text;
			
			if(!iCustId)
				return;
			
			var sHomePh=oCustNode.selectSingleNode("HomePhoneNumber").text;
			var sWorkPh=oCustNode.selectSingleNode("BusinessPhoneNumber").text;
			var sMobilePh=oCustNode.selectSingleNode("MobilePhoneNumber").text;
			var bAllNull= (sHomePh.length==0)&&(sWorkPh.length==0)&&(sMobilePh.length==0);
			var bResponse
			//Update the atribute value in XML
			oCustNode.setAttribute("ContactNosValidated","1")
			
			if (bAllNull)
			{
				bResponse=window.showModalDialog('ContactPhWarn.htm','','dialogHeight:175px;dialogWidth:670px;help:No;resizable:No;status:No;scroll:No;');
				G_bStayInCustScreen=false;
				return(bResponse);
			}
			else
			{
				G_bStayInCustScreen=false;
				return(true);
			}
		}
		else
		{
			G_bStayInCustScreen=false;
			return(true);
		} 
	}
	catch (e)
	{
		displayError(e,"checkContactNos");
	}
}

//WR1970_CMR002 Removed the function CHeckCustType and HandleEmpTab for CMR002 Changes


//==============================================================
//	Name:		AddUpdateEmpRecord
//	Purpose:	Updates or adds new Employment Record item.
//	Parameters:	recNo - (numeric) Employment record number for edit record
//==============================================================
function AddUpdateEmpRecord(recNo)
{
	try
	{
		var oEmpRecEdit;
		var oEmpRecs = ds_cust.XMLDocument.documentElement.selectSingleNode("//CustomerEmployments");
	
		if (!recNo) 
		{ 
			//Deafulting the screen appearance
			oEmpRecEdit = ds_CustEmpDtls.XMLDocument.documentElement.cloneNode(true);
			oEmpRecEdit=SetDefaultEmpRec(oEmpRecEdit);
			oEmpRecEdit.setAttribute("Mode","Create")
		}
		else
		{
			var oReplEmpRec =oEmpRecs.childNodes(recNo-1)// oEmpRecs.selectSingleNode("EmploymentDetails[EmploymentRecID="+recNo+"]");
			oReplEmpRec=SetEmpAttributes(oReplEmpRec);
			oEmpRecEdit = oReplEmpRec.cloneNode(true);
			oEmpRecEdit.setAttribute("Mode","Edit")
		}
	
		oEmpRecEdit=window.showModalDialog("EmploymentDtls.htm", oEmpRecEdit,"dialogHeight:525px;dialogWidth:600px;help:No;resizable:No;status:No;scroll:No;");
		
		if (oEmpRecEdit==null) return;
	
		oEmpRecEdit=SetEmpAttributes(oEmpRecEdit);
		
		if (recNo)
			oEmpRecs.replaceChild(oEmpRecEdit,oReplEmpRec);
		else
			oEmpRecs.appendChild(oEmpRecEdit);
		
		SetCustomerDirty();

		ShowHideAddEmpRecBtn();
		ShowHideSaveButton("employment_details")
		
	}
	catch(e)
	{
		displayError(e,"AddUpdateEmpRecord");
	}	
}

//==============================================================
//  REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//	Name:		AddUpdateTaxResidentRecord
//	Purpose:	Updates or adds new Tax Resident Record item.
//	Parameters:	recNo - (numeric) Tax Resident record number for edit record
//==============================================================
function AddUpdateTaxResidentRecord(recNo)
{
	try
	{		
		var oTaxResidentRecEdit;
		var oTaxResidentRecs = ds_cust.XMLDocument.documentElement.selectSingleNode("//TaxResidents");
				
		if (!recNo) 
		{ 
			//Deafulting the screen appearance
			oTaxResidentRecEdit = ds_TaxResident.XMLDocument.documentElement.cloneNode(true);
			oTaxResidentRecEdit = SetDefaultTaxResidentRec(oTaxResidentRecEdit);
			oTaxResidentRecEdit.setAttribute("Mode","Create")
		}
		else
		{						
			var oReplTaxResidentRec =oTaxResidentRecs.childNodes(recNo-1)// oEmpRecs.selectSingleNode("EmploymentDetails[EmploymentRecID="+recNo+"]");
			oReplTaxResidentRec=SetTaxResidentAttributes(oReplTaxResidentRec);
			oTaxResidentRecEdit = oReplTaxResidentRec.cloneNode(true);
			oTaxResidentRecEdit.setAttribute("Mode","Edit")
		}
		
		oTaxResidentRecEdit=window.showModalDialog("TaxResidentDtls.htm", oTaxResidentRecEdit,"dialogHeight:500px;dialogWidth:600px;help:No;resizable:No;status:No;scroll:No;");
		
		if (oTaxResidentRecEdit==null) return;
		
		if (GetAllTaxCompanyNames(oTaxResidentRecEdit.getAttributeNode("TaxCountry").text,recNo-1))  return;
			
		//oTaxResidentRecEdit=SetTaxResidentAttributes(oTaxResidentRecEdit);
		
		if (recNo)
			oTaxResidentRecs.replaceChild(oTaxResidentRecEdit,oReplTaxResidentRec);
		else
			oTaxResidentRecs.appendChild(oTaxResidentRecEdit);
		
		SetCustomerDirty();
		
		ShowHideAddTaxResidentRecBtn();
		ShowHideSaveButton("tax_resident_details")
	}
	catch(e)
	{
		displayError(e,"AddUpdateTaxResidentRecord");
	}	
}
//REL 18.1 New Code Ended 
//  REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//Check whether customer selected tax country other than australia no option
function display_taxcountriestable() {
    try 
	{
		var oCustTaxs = ds_cust.XMLDocument.documentElement;
		
		if (document.getElementById('inpAustralia_Y').checked == true) {
			oCustTaxs.selectSingleNode("TaxResidentAustralia").text = "Y";
			document.getElementById("taxcountries").style.display = "none";
			G_Tax="Y";
		}
        else if (document.getElementById('inpAustralia_N').checked == true) {
			oCustTaxs.selectSingleNode("TaxResidentAustralia").text = "N";
			document.getElementById("taxcountries").style.display = "block"; 
			G_Tax="N";
        }
    }
    catch (e) 
	{
        displayError(e, "display_taxcountriestable");
    }
}

//==============================================================
//  REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//	Name:		GetAllTaxCompanyNames
//	Purpose:	To get all Company Names in the array//				
//	Parameters:	Blank
//==============================================================
function GetAllTaxCompanyNames(companyname,RowNum)
{
	try
	{
		var i;
		var ContContry;
						
		var oTaxResidentRecs = ds_cust.XMLDocument.documentElement.selectSingleNode("//TaxResidents");
		G_taxcompanyname[0]="";
		G_taxcompanyname[1]="";
		G_taxcompanyname[2]="";
		G_taxcompanyname[3]="";
		G_taxcompanyname[4]="";
		G_taxcompanyname[5]="";
		ContContry=0;
		if (oTaxResidentRecs.childNodes.length>0)
		{
			//remove the tax resident node
			for (i=0; i<oTaxResidentRecs.childNodes.length; i++)
			{                                              
				G_taxcompanyname[i] = oTaxResidentRecs.childNodes(i).getAttributeNode("TaxCountry").value; 
											
				if (companyname==G_taxcompanyname[i] && i!= RowNum && G_taxcompanyname[i]!="") 
				{								
					ContContry=ContContry+1;					
				}
								
			}              
							
			if (ContContry>0) return true;
		}
					
	}
	catch(e)
	{
		displayError(e,"GetAllTaxCompanyNames");
	}
}
//REL 18.1 New Code Ended 
//==============================================================
//	Name:		SetEmpAttributes
//	Purpose:	Sets various Attributes for the EmploymentNode.
//	Parameters:	recNo - (numeric) Employment record number for edit record
//==============================================================
function SetEmpAttributes(oEmpNodePassed)
{
	try
	{
		var iPreviousEmp=oEmpNodePassed.selectSingleNode("PreviousEmployment").text;
		var iPrimaryEmp=oEmpNodePassed.selectSingleNode("PrimaryEmployment").text;
		var sEmploymentType=oEmpNodePassed.selectSingleNode("EmploymentType").text;
		var sEmploymentStat
		
		if (iPreviousEmp=="-1")
			sEmploymentStat="Previous Employment";
		else
			if (iPrimaryEmp=="-1")
			{
				if(sEmploymentType=="NE")
					sEmploymentStat="Current - Unemployed";
				else
					sEmploymentStat="Current Employment - Primary";
			}
			else
				sEmploymentStat="Current Employment - Secondary";
		
		oEmpNodePassed.setAttribute("EmployerName",oEmpNodePassed.selectSingleNode("EmployerName").text);
		oEmpNodePassed.setAttribute("EmploymentStatus",sEmploymentStat);
		oEmpNodePassed.setAttribute("YearsAtEmp",oEmpNodePassed.selectSingleNode("YearsInEmployment").text);
		oEmpNodePassed.setAttribute("MonthsAtEmp",oEmpNodePassed.selectSingleNode("MonthsInEmployment").text);	
		
		return oEmpNodePassed;
		
	}
	catch(e)
	{
		displayError(e,"SetEmpAttributes");
	}
}

//==============================================================
//	Name:		SetTaxResidentAttributes
//	Purpose:	Sets various Attributes for the EmploymentNode.
//	Parameters:	recNo - (numeric) Employment record number for edit record
//==============================================================
function SetTaxResidentAttributes(oTaxNodePassed)
{
	try
	{
		oTaxNodePassed.setAttribute("cboCountry",oTaxNodePassed.selectSingleNode("cboCountry").text);
		oTaxNodePassed.setAttribute("CountryTIN",oTaxNodePassed.selectSingleNode("CountryTIN").text);
		if (oTaxNodePassed.selectSingleNode("CountryTIN").text != "")
		{			
			oTaxNodePassed.selectSingleNode("NoTinReason").text="";
			oTaxNodePassed.setAttribute("NoTinReason",oTaxNodePassed.selectSingleNode("NoTinReason").text);
		}
		else
		{
			oTaxNodePassed.setAttribute("NoTinReason",oTaxNodePassed.selectSingleNode("NoTinReason").text);
		}
		oTaxNodePassed.setAttribute("inpExplanation",oTaxNodePassed.selectSingleNode("inpExplanation").text);	
		
		return oTaxNodePassed;
		
	}
	catch(e)
	{
		displayError(e,"SetTaxResidentAttributes");
	}
}
//==============================================================
//	Name:		SetDefaultEmpRec
//	Purpose:	Sets the default values for the fields
//	Parameters:	The nwe employment record
//==============================================================
function SetDefaultEmpRec(oNewEmpRec)
{
	try
	{
		var oEmpRecNodes=ds_cust.XMLDocument.documentElement.selectNodes("CustomerEmployments/EmploymentDetails[PrimaryEmployment=-1]");
		
		if(oEmpRecNodes.length<1)
		{
			oNewEmpRec.selectSingleNode("EmploymentStatusDesc").text="Current Employment - Primary"
			oNewEmpRec.selectSingleNode("PreviousEmployment").text="0"
			oNewEmpRec.selectSingleNode("PrimaryEmployment").text="-1"	
		}
		else
		{
			oNewEmpRec.selectSingleNode("EmploymentStatusDesc").text=""
			oNewEmpRec.selectSingleNode("PreviousEmployment").text=""
			oNewEmpRec.selectSingleNode("PrimaryEmployment").text=""
		}
		return 	oNewEmpRec;
			
	}
	catch(e)
	{
		displayError(e,"SetDefaultEmpRec");
	}
}
//  REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//==============================================================
//	Name:		SetDefaultTaxResidentRec
//	Purpose:	Sets the default values for the fields
//	Parameters:	The nwe employment record
//==============================================================
function SetDefaultTaxResidentRec(oNewTaxResidentRec)
{
	try
	{
		var oTaxResidentRecNodes=ds_cust.XMLDocument.documentElement.selectNodes("TaxResidents/TaxResidentDetails[cboCountry=-1]");
		
		if(oTaxResidentRecNodes.length<1)
		{
			oNewTaxResidentRec.selectSingleNode("cboCountry").text="<-- Please Select -->";
			oNewTaxResidentRec.selectSingleNode("CountryTIN").text="";			
			oNewTaxResidentRec.selectSingleNode("NoTinReason").text="<-- Please Select -->";			
		}
		else
		{			
			oNewTaxResidentRec.selectSingleNode("cboCountry").text="";
			oNewTaxResidentRec.selectSingleNode("CountryTIN").text="";
			oNewTaxResidentRec.selectSingleNode("NoTinReason").text="";
		}
		return 	oNewTaxResidentRec;
			
	}
	catch(e)
	{
		displayError(e,"SetDefaultTaxResidentRec");
	}
}
//REL 18.1 New Code Ends
//==============================================================
//	Name:		DeleteEmpRecord
//	Purpose:	Deletes the Employment Details record selected
//				by the user after showing the cofirmation msg;
//	Parameters:	The employment record number
//==============================================================
function DeleteEmpRecord(EmpRecNo)
{
	try
	{
		var oEmpRecs = ds_cust.XMLDocument.documentElement.selectSingleNode("//CustomerEmployments");
		var sPrompt =  "";
		
		if (!ConfirmDelete(sPrompt)) return;
		//remove the employment node
		var oEmpRec = oEmpRecs.childNodes(EmpRecNo-1);
		oEmpRec.parentNode.removeChild(oEmpRec);
		
		var CustID = ds_cust.recordset.fields("CustomerID").value;
		var oCust = ds_cust.XMLDocument.documentElement;
		var oNewCust=oCust.cloneNode(true);
		
		SetCustomerDirty();
		//saveCurrentScreen();
		
		//FlushToDisk();
		ShowHideAddEmpRecBtn();
		ShowHideSaveButton("employment_details")
	}
	catch(e)
	{
		displayError(e,"DeleteEmpRecord");
	}
}

//==============================================================
// REL 18.1  New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//	Name:		DeleteTaxResidentRecord
//	Purpose:	Deletes the Employment Details record selected
//				by the user after showing the cofirmation msg;
//	Parameters:	The employment record number
//==============================================================
function DeleteTaxResidentRecord(TaxResidentRecNo)
{
	try
	{
		var oTaxResidentRecs = ds_cust.XMLDocument.documentElement.selectSingleNode("//TaxResidents");
		var sPrompt =  "";
		
		if (!ConfirmDelete(sPrompt)) return;
		//remove the tax resident node
		var oTaxResidentRec = oTaxResidentRecs.childNodes(TaxResidentRecNo-1);
		oTaxResidentRec.parentNode.removeChild(oTaxResidentRec);
		
		var CustID = ds_cust.recordset.fields("CustomerID").value;
		var oCust = ds_cust.XMLDocument.documentElement;
		var oNewCust=oCust.cloneNode(true);
		
		SetCustomerDirty();
		//saveCurrentScreen();
		
		//FlushToDisk();
		ShowHideAddTaxResidentRecBtn();
		ShowHideSaveButton("tax_resident_details")
	}
	catch(e)
	{
		displayError(e,"DeleteTaxResidentRecord");
	}
}
//REL 18.1 New Code Ended 
//==============================================================
//  REL 18.1 New Code Begin Tax Resident added on 05/03/2018 for tax resident crs changes
//	Name:		DeleteTaxResidentRecord
//	Purpose:	Deletes the Tax Residence Details record selected
//				by the user after showing the cofirmation msg;
//	Parameters:	Blank
//==============================================================
function DeleteTaxResidentRecords()
{
	try
	{
		var i;		
		var oTaxResidentRecs = ds_cust.XMLDocument.documentElement.selectSingleNode("//TaxResidents");
		var sPrompt =  "";	
		var countriescnt = oTaxResidentRecs.childNodes.length;
		
		//if (!ConfirmDelete(sPrompt)) return;	
		
		if (oTaxResidentRecs.childNodes.length>0)
		{
			//remove the tax resident node			
			for (i=0; i<countriescnt; i++)
			{			
				var oTaxResidentRec = oTaxResidentRecs.childNodes(i);					
				oTaxResidentRecs.removeChild(oTaxResidentRecs.childNodes(0));				
			}			
			var CustID = ds_cust.recordset.fields("CustomerID").value;			
			var oCust = ds_cust.XMLDocument.documentElement;			
			var oNewCust=oCust.cloneNode(true);
		}
				
		SetCustomerDirty();
		//saveCurrentScreen();
		
		//FlushToDisk();
		/* ShowHideAddTaxResidentRecBtn();
		ShowHideSaveButton("tax_resident_details") */
		
	}
	catch(e)
	{
		displayError(e,"DeleteTaxResidentRecords");
	}
}
//REL 18.1 New Code Ended
//==============================================================
//	Name:		ShowHideAddEmpRecBtn
//	Purpose:	Shows/Hides the Add Employment Record Button
//				based on the number of employment records.
//	Parameters:	
//==============================================================
function ShowHideAddEmpRecBtn()
{
	try
	{
		var oEmpRecs=ds_cust.XMLDocument.documentElement.selectSingleNode("//CustomerEmployments");
		var nEmpRecs=oEmpRecs.childNodes.length;
		document.all.AddEmpRecCmd.style.display = (nEmpRecs<11)? "":"none";
		document.all.MaxEmpRecMsg.style.display = (nEmpRecs>=11)? "":"none";
		
	}
	catch(e)
	{
		displayError(e,"ShowHideAddEmpRecBtn");
	}
}
// REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//==============================================================
//	Name:		ShowHideAddTaxResidentRecBtn
//	Purpose:	Shows/Hides the Add Tax Resident Record Button
//				based on the number of tax residence records.
//	Parameters:	
//==============================================================
function ShowHideAddTaxResidentRecBtn()
{
	try
	{
		var oTaxRecs=ds_cust.XMLDocument.documentElement.selectSingleNode("//TaxResidents");		
		var nTaxRecs=oTaxRecs.childNodes.length;
		document.all.AddTaxResidentRecCmd.style.display = (nTaxRecs<6)? "":"none";
		document.all.MaxTaxResidentRecMsg.style.display = (nTaxRecs>=6)? "":"none";
		
	}
	catch(e)
	{
		displayError(e,"ShowHideAddTaxResidentRecBtn");
	}
}
// New Code Ended
//==============================================================
//	Name:		ShowHideSaveButton
//	Purpose:	Shows/Hides the Save current screen
//				based on the number of employment records and the tab selected.
//	Parameters:	
//==============================================================
function ShowHideSaveButton(sTabImage)
{
	try
	{
		if(sTabImage.indexOf("employment_details")==0)
		{
			var oCustEmps=ds_cust.XMLDocument.documentElement.selectSingleNode("//CustomerEmployments");
			var nEmpRecs=oCustEmps.childNodes.length;
			document.all.trSaveBtn.style.display = (nEmpRecs==0)? "none":"";
		}
		else
			document.all.trSaveBtn.style.display = "block";
		
	}
	catch(e)
	{
		displayError(e,"ShowHideSaveButton");
	}
}

//=============================================================================================
//	Name:		UpdateSecurityGivenBy
//	Parameters:	Security Node Object
//	Return:		Nil
//	Purpose:	Add/Update Customer Names to SecGivenBy1 and SecGivenBy2 when a customer is deleted.
//=============================================================================================
function UpdateSecurityGivenBy(oSec)
{
	try
	{
		var oCusts=oSec.selectNodes("SecuritiesGivenBy/SecurityGivenBy[@Linked='-1']");
		
		oSec.selectSingleNode("SecurityGivenBy1").text = "";
		oSec.selectSingleNode("SecurityGivenBy2").text = "";		
		
		if(oCusts.length > 0)
		{
			if(oCusts.length==1)
			{
				var sCustName = oCusts.item(0).getAttributeNode("CustomerName").value;
				oSec.selectSingleNode("SecurityGivenBy1").text = (sCustName!="") ? sCustName:"";
			}
			if(oCusts.length==2)
			{
				var sCustName1 = oCusts.item(0).getAttributeNode("CustomerName").value;
				oSec.selectSingleNode("SecurityGivenBy1").text = (sCustName1!="") ? sCustName1:"";
				var sCustName2 = oCusts.item(1).getAttributeNode("CustomerName").value;
				oSec.selectSingleNode("SecurityGivenBy2").text = (sCustName2!="") ? sCustName2:"";
			}
			if(oCusts.length>2)
			{
				var sLongName = "";
				var arNames;
				var iIndex;
				var sTempName;
				var iLastIndex;
				var sPrimCustName="";
				var sSecCustName="";
				var sGuaCustName="";
				var sCustName="";
				
				for(iIndex=0; iIndex<oCusts.length; iIndex++)
					if(oCusts(iIndex).getAttributeNode("CustomerTypeDescription").value == "Primary Co-owner")
						sPrimCustName = sPrimCustName + oCusts(iIndex).getAttributeNode("CustomerName").value
					else if(oCusts(iIndex).getAttributeNode("CustomerTypeDescription").value == "Other Co-owner" || oCusts(iIndex).getAttributeNode("CustomerTypeDescription").value == "Co-owner")
						sSecCustName = sSecCustName + oCusts(iIndex).getAttributeNode("CustomerName").value + "|";
					else
						sGuaCustName = sGuaCustName + oCusts(iIndex).getAttributeNode("CustomerName").value + "|";
						
				if(sPrimCustName.length>0)
					sCustName = sPrimCustName + "|";
					
				if(sSecCustName.length>0)
					sCustName = sCustName + sSecCustName;
					
				if(sGuaCustName.length>0)
					sCustName = sCustName + sGuaCustName;
					
				for(iIndex=0; iIndex<oCusts.length; iIndex++)
					arNames = arNames + oCusts(iIndex).getAttributeNode("CustomerName").value + "|";
				
				arNames = sCustName.split("|");
								
				for(iIndex=0; iIndex<arNames.length-1; iIndex++)
				{
					sTempName = sLongName + arNames[iIndex];
					
					if(sTempName.length <= 40)
					{
						sLongName = sTempName + ", ";
					}
					else
					{
						iLastIndex = iIndex;
						break;
					}
				}
				sLongName = VBMid(sLongName);
				
				oSec.selectSingleNode("SecurityGivenBy1").text = sLongName;
				
				if(iLastIndex < arNames.length)
				{
					sLongName = "";
					sTempName = "";
					for(iIndex=iLastIndex; iIndex<arNames.length-1; iIndex++)
					{
						sTempName = sLongName + arNames[iIndex];
						
						if(sTempName.length <= 40)
						{
							sLongName = sTempName + ", ";
						}
						else
							break;
					}
					sLongName = VBMid(sLongName);
					oSec.selectSingleNode("SecurityGivenBy2").text = sLongName;
				}
				else
				{
					oSec.selectSingleNode("SecurityGivenBy2").text = "";
				}
			}
		}
		
	}
	catch(e)
	{
		displayError(e, "UpdateSecurityGivenBy");
	}
}

//=============================================================================================
//	Name:		UpdateSecCustName
//	Parameters:	Security Node Object, CustID(string), sCustName(string)
//	Return:		Nil
//	Purpose:	Updates Customer Names SecurityGivenBy when a customername is modified.
//=============================================================================================
function UpdateSecCustName(oSec, CustID, sCustName)
{
	try
	{
		var oCusts=oSec.selectNodes("SecuritiesGivenBy/SecurityGivenBy[@Linked='-1']");
		
		if(oCusts)
		{
			for(var iIndex=0; iIndex<oCusts.length; iIndex++)
			{
				if(oCusts.item(iIndex).selectSingleNode("CustomerID").text == CustID)
					oCusts.item(iIndex).setAttribute("CustomerName", sCustName);				
			}
		}	
	}
	catch(e)
	{
		displayError(e, "UpdateSecCustName");
	}
}

//=============================================================================================
//	Name:		UpdateCustTypeDesc
//	Parameters:	Nil
//	Return:		Nil
//	Purpose:	Updating Customer Type Description.
//=============================================================================================
function UpdateCustTypeDesc()
{
	try
	{
	
		//Updating Customer Type Description.
			
		var oDocEl=xml_master.XMLDocument.documentElement;
		var oCust = oDocEl.selectNodes("Customers/Customer");
	
		if  (oCust.length > 0)
		{
			for(var i=0; i<oCust.length; i++)
			{
				if(oCust.item(i).getAttributeNode("CustomerTypeDescription").value == "Other Co-owner")
					oCust.item(i).setAttribute("CustomerTypeDescription", "Co-owner");
			}
				
		}	
		
		FlushToDisk();
				
	}
	catch (e)
	{
		displayError(e,"RemoveSecGivenby");	
	}
	
}


//=============================================================================================
//	Name:		RefreshAllrelCusts()
//	Parameters:	Nil
//	Return:		Nil
//	Purpose:	Updating Customer Type Description.
//=============================================================================================
function RefreshAllrelCusts()
{
	try
	{
		
		var oPurposes;
		
		oPurposes=xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		
		var oPurposeNode
		oPurposeNode=oPurposes.selectNodes("Purpose");              				
		var PurCount;
		PurCount=oPurposeNode.length;
		var ProdsNode,ProdNode;
		var PfPrimary,pfPrimaryCount;
		var poDepositNode;
		var iIndex,iSubIndex;
		pfPrimaryCount=0;
		for (iIndex=0;iIndex<PurCount;iIndex++)
		{
			ProdsNode=oPurposeNode(iIndex).selectSingleNode("Products");
			ProdNode=ProdsNode.selectNodes("Product");
			for (iSubIndex=0;iSubIndex<ProdNode.length;iSubIndex++)
			{
				LinkCutomerToProduct(ProdNode(iSubIndex));
			}
		}
			FlushToDisk();
	}
	catch (e)
	{
		displayError(e,"RefreshAllrelCusts");	
	}
	
}

//=============================================================================================
//	Name:		ResetRefreshCustFlag()
//	Parameters:	Nil
//	Return:		Nil
//	Purpose:	Reset the refresh cust relation falg on change of some fields in the UI.
//=============================================================================================
function ResetRefreshCustFlag()
{
	try
	{
		G_bCustProdRelRefresh=true;
	}
	catch (e)
	{
		displayError(e,"ResetRefreshCustFlag");	
	}
}


//=============================================================================================
//	Name:		HandleAddRemoveCustomer()
//	Parameters:	iCustomerID : The customer ID which triggered the refresh
//				sAction		: The action which triggered the refresh ("A" for Add, "D" for delete)
//	Return:		Nil
//	Purpose:	Reset the refresh cust relation falg on change of some fields in the UI.
//=============================================================================================
function HandleAddRemoveCustomer(iCustomerID,sAction)
{
	try
	{
		
		var oAppDocEl=xml_master.XMLDocument.documentElement;
		var sXPath ="//Purposes/Purpose/Products/Product/RelatedCustomers/RelatedCustomer[CustomerID='"+iCustomerID+"']"
		var oProdRelCusts = oAppDocEl.selectNodes(sXPath);
		var cRCount=oProdRelCusts.length;
		var oRelCustNodes,oRelCustNode;
		var iProdCount;
		
		var oReplProd;
		var oProdsNode;
		var oPurpNode;
		var iPurpId;
		var oPurpsNode;
		var oReplPurpose;
		
		//The action is a Save.
		if (sAction=="A")
		{
			//Check if the custmer ID exists in the related customers node, in that case its 
			//a save after modifying some data for existing customers, so we don't have to do anything
			
			
			if (cRCount != 0) return;
				//Otherwise this is a new customer addition so do the refresh.
			else
			{
				sXpath="//Purposes/Purpose/Products/Product/RelatedCustomers"
				oRelCustNodes = oAppDocEl.selectNodes(sXPath);
				
				iProdCount=oAppDocEl.selectNodes("//Purposes/Purpose/Products/Product").length;
				
				
				//If no relCustsNode it means no Product Nodes; so return.
				if (iProdCount==0)
					return;
				else
				{
					//Create a related Customer Node.
					sXpath="//Customers/Customer[CustomerID='" + iCustomerID + "']/CustomerName";
					ds_RelCusts.src=ds_RelCusts.src;
					
					oRelCustNode=ds_RelCusts.XMLDocument.documentElement.selectSingleNode("RelatedCustomer");
					oRelCustNode.setAttribute("customerName",oAppDocEl.selectSingleNode(sXpath).text)
					
					oRelCustNode.selectSingleNode("CustomerID").text=iCustomerID;
					
					if (oRelCustNode.selectSingleNode("RelationshipCode"))
						oRelCustNode.removeChild(oRelCustNode.selectSingleNode("RelationshipCode"));
					
					sXpath="//Customers/Customer[CustomerID='" + iCustomerID + "']/CustomerType"
					CreateChildNode(oRelCustNode,"Relationship",oAppDocEl.selectSingleNode(sXpath).text);
					CreateChildNode(oRelCustNode,"NominatedBorrower","N");
					CreateChildNode(oRelCustNode,"NominatedAddressType","");
					
					oProdNodes = oAppDocEl.selectNodes("//Purposes/Purpose/Products/Product");
					
					iProdCount=oProdNodes.length;
					
					var oMDocEl=xml_master.XMLDocument.documentElement;
					
					for (var iProductIndex=iProdCount-1;iProductIndex>=0;iProductIndex--)
					{
						
						oProdNode=oProdNodes(iProductIndex);
						var iProdID=oProdNode.selectSingleNode("ProductID").text;
						
						oRelCustNodeForProd=oProdNode.selectSingleNode("RelatedCustomers");
						oRelCustNodeForProd.appendChild(oRelCustNode);
						
						var xPath = "Purposes/Purpose/Products/Product[ProductID=" + iProdID + "]";
						oReplProd = oAppDocEl.selectSingleNode(xPath);
						
						oProdsNode =oReplProd.parentNode
						oPurpNode = oProdsNode.parentNode;
						iPurpId=oPurpNode.selectSingleNode("PurposeID").text;
						oPurpsNode = oPurpNode.parentNode;
						
						oProdsNode.replaceChild(oProdNode.cloneNode(true),oReplProd);
						oPurpNode.replaceChild(oProdsNode,oPurpNode.selectSingleNode("Products"));
						
						oReplPurpose=oAppDocEl.selectSingleNode("Purposes/Purpose[PurposeID="+iPurpId+"]");
						
						oAppDocEl.selectSingleNode("Purposes").replaceChild(oPurpNode,oReplPurpose)
						
						FlushToDisk(); 
					}
					
				}
			}
		}
		
		//Handle customer delete
		if (sAction=="D")
		{
			sXpath="//Purposes/Purpose/Products/Product"
			oRelCustNodes = oAppDocEl.selectNodes(sXPath);
			iProdCount=oRelCustNodes.length;
			//If no relCustsNode it means no Product Nodes; so return.
			
			if (iProdCount==0)
				return;
			else
			{
				oProdNodes = oAppDocEl.selectNodes("//Purposes/Purpose/Products/Product");
				iProdCount=oProdNodes.length;
				
				for (var iProductIndex=0;iProductIndex<iProdCount;iProductIndex++)
				{
					
					oProdNode=oProdNodes(iProductIndex);
					var iProdID=oProdNode.selectSingleNode("ProductID").text;
					oRelCustNodeForProd=oProdNode.selectSingleNode("RelatedCustomers");
					
					oRelCustNode= oRelCustNodeForProd.selectSingleNode("RelatedCustomer[CustomerID='" + iCustomerID + "']")
					if (oRelCustNode)
					{
					oRelCustNodeForProd.removeChild(oRelCustNode);
					}

					var xPath = "Purposes/Purpose/Products/Product[ProductID=" + iProdID + "]";
					oReplProd = oAppDocEl.selectSingleNode(xPath);
					
					oProdsNode =oReplProd.parentNode
					oPurpNode = oProdsNode.parentNode;
					iPurpId=oPurpNode.selectSingleNode("PurposeID").text;
					oPurpsNode = oPurpNode.parentNode;
						
					oProdsNode.replaceChild(oProdNode.cloneNode(true),oReplProd);
					oPurpNode.replaceChild(oProdsNode,oPurpNode.selectSingleNode("Products"));
						
					oReplPurpose=oAppDocEl.selectSingleNode("Purposes/Purpose[PurposeID="+iPurpId+"]");
					
					oAppDocEl.selectSingleNode("Purposes").replaceChild(oPurpNode,oReplPurpose)
					
					FlushToDisk(); 
				}
			}
		}
		G_bCustProdRelRefresh=false;
	}
	catch (e)
	{
		displayError(e,"HandleAddRemoveCustomer");	
	}
}


//=============================================================================================
//	Name:		CreateChildNode()
//	Parameters:	oParentNode		: The node for which child node needs to be created
//				sChildNodeName	: The name for the child node
//				sChildNodeValue	: The value for the child node
//	Return:		Nil
//	Purpose:	Adds a child node to the passed node.
//=============================================================================================
function CreateChildNode(oParentNode,sChildNodeName,sChildNodeValue)
{

	var xmlDocument = new ActiveXObject('Microsoft.XMLDOM');
	xmlDocument.appendChild(oParentNode);
	var oNewChild = xmlDocument.createElement(sChildNodeName);
	oNewChild.appendChild(xmlDocument.createTextNode(sChildNodeValue)) ;
	xmlDocument.documentElement.appendChild(oNewChild);
}


function CheckCompDtsDependents()
{
	try {
 	    var iPerRes = (ds_cust.recordset.fields("PermanentResident").value);
	    var iNewRes = (ds_cust.recordset.fields("NewResident").value);
	    var iNonRes = (ds_cust.recordset.fields("NonResident").value);

	    if ((iPerRes == '0') && (iNewRes == '0') && (iNonRes == '0')) {
	        DisableElement(document.all.inpPermRes, 1);
	        DisableElement(document.all.inpNonRes, 1);
	        DisableElement(document.all.inpNewRes, 1);
	    }
	    else {
	       	    if ((iPerRes == '-1') && (iNewRes =='0') && (iNonRes =='0'))
	        	{
	        	    ds_cust.recordset.fields("NewResident").value="0";
	        	    ds_cust.recordset.fields("NonResident").value = "0";
	        	    ds_cust.recordset.fields("PermanentResident").value = "-1";
	        	    DisableElement(document.all.inpNewRes, 0);
	        	    DisableElement(document.all.inpNonRes, 0);
	        	    DisableElement(document.all.inpPermRes, 1);
	            }
	            else 
	            {
	                if ((iPerRes == '0') && (iNewRes == '-1') && (iNonRes == '0')) {
	                    ds_cust.recordset.fields("PermanentResident").value = "0";
	                    ds_cust.recordset.fields("NonResident").value = "0";
	                    ds_cust.recordset.fields("NewResident").value = "-1";
	                    DisableElement(document.all.inpPermRes, 0);
	                    DisableElement(document.all.inpNonRes, 0);
	                    DisableElement(document.all.inpNewRes, 1);
	                    }
	                    else
	                        if ((iPerRes = '0') && (iNewRes = '0') && (iNonRes = '-1')) {
	                            ds_cust.recordset.fields("PermanentResident").value = "0";
	                            ds_cust.recordset.fields("NewResident").value = "0";
	                            ds_cust.recordset.fields("NonResident").value = "-1";
	                            DisableElement(document.all.inpNewRes, 0);
	                            DisableElement(document.all.inpPermRes, 0);
	                            DisableElement(document.all.inpNonRes, 1);
	                        }
	                }
	    }
	}
	catch(e)
	{
		displayError(e,"CheckCompDtsDependents");
	}
}
// REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//==============================================================
//	Name:		Enable/Disabled Tax Residence Details Tab
//	Purpose:	Disables/Enables Tax Residence Details TAb
//	Parameters:	Blank / Non Blank
//==============================================================
function enable_taxresidenttab()
{
	var oCustDocEl = ds_cust.XMLDocument.documentElement;
	var bSelect= oCustDocEl.selectSingleNode("CustomerType").text;	
	try
	{
		oCustDocEl.selectSingleNode("TaxResidentAustralia").text = "";	G_Tax = "";	
		document.getElementById("inpAustralia_Y").checked = false;	document.getElementById("inpAustralia_N").checked = false;
		if ((G_ACHBrkFreeCard == "")) {
			document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + "_faded.gif";
			oCustDocEl.selectSingleNode("TaxResidentAustralia").text = ""; G_Tax = "";
			document.getElementById("inpAustralia_Y").checked = false;	document.getElementById("inpAustralia_N").checked = false;
		}
		else if (((G_Product_Type == "RC" || G_breakfree_Type == "New Credit Card"))) {
			if ((G_ACHBrkFreeCard == "")) {
				document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + "_faded.gif";
				oCustDocEl.selectSingleNode("TaxResidentAustralia").text = ""; G_Tax = "";
				document.getElementById("inpAustralia_Y").checked = false;	document.getElementById("inpAustralia_N").checked = false;
			}
			else {
				document.all.ScrCustDetails.all.imgCustDetailsTab(4).src = "../images/tabs/" + aCustTabImgs[4] + ".gif";	
			}
		}
		
		
	}
	catch(e)
	{
		displayError(e,"enable_taxresidenttab");
	}
}
//New Code Ended

//======================= RelationShip with PrimaryBorrower Starts - Card 256 //

//==============================================================
//	Name:		disableCustRelPBCustCtls
//	Purpose:	Disables/Enables controls for the customer relationships. 
//	Parameters:	tblCRC 	- (HTML TABLE element) customer relationships table
//==============================================================
function disableCustRelPrimBorrowCtls(tblCRC)
{
	try
	{
		if (tblCRC.readyState!="complete") return;
		var oCustDocEl = ds_cust.XMLDocument.documentElement;
				if(oCustDocEl.selectSingleNode("CustomerType") != null)
				{
					var iCustType= oCustDocEl.selectSingleNode("CustomerType").text;
							if(tblCRC.rows.length > 0)
							{
								var tblnamrow = document.getElementById('tblCustRelCust');
								var tblrowcnt = tblnamrow.rows.length;
									if(tblrowcnt > 0)
									{
										for (var iRPB=1; iRPB < tblrowcnt; iRPB++)
										{
											var iRelCustType = tblnamrow.rows(iRPB).getElementsByTagName("span")[1].innerHTML;
													if(iCustType == "GTR")
													{
														if((iRelCustType == "SOL") || (iRelCustType == "COF"))
														continue;
														if (tblrowcnt-1 == 1){	
																	if (tblCRC.all.cboRelationshipPrimaryBorrower) {
																	DisableElement(tblCRC.all.cboRelationshipPrimaryBorrower);
																	(tblCRC.all.cboRelationshipPrimaryBorrower).value="";}
														}
														else{
																	if(tblCRC.all.cboRelationshipPrimaryBorrower(iRPB-1))  {
																	DisableElement(tblCRC.all.cboRelationshipPrimaryBorrower(iRPB-1)); 
																	(tblCRC.all.cboRelationshipPrimaryBorrower(iRPB-1)).value="";}
														}
													}
													if(!(iCustType== "GTR"))
													{
														if (tblrowcnt-1 == 1){	
																	if (tblCRC.all.cboRelationshipPrimaryBorrower) {
																	DisableElement(tblCRC.all.cboRelationshipPrimaryBorrower);
																	(tblCRC.all.cboRelationshipPrimaryBorrower).value="";}
														}
														else{
																	if(tblCRC.all.cboRelationshipPrimaryBorrower(iRPB-1))  {
																	DisableElement(tblCRC.all.cboRelationshipPrimaryBorrower(iRPB-1)); 
																	(tblCRC.all.cboRelationshipPrimaryBorrower(iRPB-1)).value="";}
														}
													}
										}

									}
							}
				}
				
	}
	catch (e) 
	{ 
		displayError("","disableCustRelPrimBorrowCtls");
		//ignore error: it's happen due to asynchronous event  
	}
}

//==============================================================
//	Name:		GetCustomerRelPrimaryBorrowerDesc
//	Purpose:	Gets customer relationship description from the list box.
//	Parameters:	RecNo - (numeric) related customer record number
//==============================================================
function GetGuarantorRelPrimaryBorrowerDesc(RecNo)
{
	try
	{
		if (RecNo-1<0) return;
		var oCustGtrRel = ds_cust.XMLDocument.documentElement;
		var obj = document.getElementsByName('cboRelPrimaryBorrower');
			for(var i=0;i< obj.length;i++)
			{
				if(obj[i].getAttribute("disabled"))
				{
					obj[i].value = "";
				}
			}
		oCustGtrRel.setAttribute("RelationshipPrimaryBorrowerDescription",getListText(window.event.srcElement)); 
		
	}
	catch(e)
	{
		displayError(e,"GetGuarantorRelPrimaryBorrowerDesc");
	}	
}

//====================================================================================
//	Name:		ValRelatedCustomers
//	Purpose:	Validating the RelationShip betweeen GTR and SOL or COF Customer's.
//	Parameters:	oCust - (XML node) customer Node
//======================================================================================
function ValRelatedCustomers(oCust)
{
	try
	{
		var oCusGTRtList = xml_master.XMLDocument.selectNodes("//Customers/Customer[CustomerType='GTR']");
		var oCusGTRtListCnt = oCusGTRtList.length;
		var oCustNOTGTRList = xml_master.XMLDocument.selectNodes("//Customers/Customer[CustomerType!='GTR']");
		var oCustNOTGTRListCnt = oCustNOTGTRList.length;
		if(oCust.selectSingleNode("CustomerType") != null){
				var rPrimBorrowCustType = oCust.selectSingleNode("CustomerType").text;
				if(!(rPrimBorrowCustType == "GTR"))
				{
					return true;
				}
				if(rPrimBorrowCustType == "GTR")
				{
				if(oCusGTRtListCnt > 0)
				{
						for (iGtr=0; iGtr < oCusGTRtList.length; iGtr++)
						{
							if(oCust.selectSingleNode("RelationshipPrimaryBorrower") != null)
							var rRelSpouseID = oCust.selectSingleNode("SpouseID").text;
							var rPrimBorrow = oCust.selectSingleNode("RelationshipPrimaryBorrower").text;
							var oAppDocEl = xml_master.XMLDocument.documentElement;
							var sXpath = "//Customers/Customer[CustomerID='" + rRelSpouseID + "']/CustomerType";
							if(rRelSpouseID != 0)
							{
							if(oAppDocEl.selectSingleNode(sXpath) != null)
							{
								var nSpType = oAppDocEl.selectSingleNode(sXpath).text;
								if(nSpType == "SOL" || nSpType == "COF" )
								{
									if((rPrimBorrow != ''))
									{ 
										if((rPrimBorrow != 'PBOR')) { return false; }
										else {	return true; }
									}
									else {	return false;	}
								}
								else if(nSpType != "SOL" || nSpType != "COF" )
								{
									if((rPrimBorrow != '')){
										return true;}
									else {
										return false;}
								}
								}
							}
								else 
								{
									if((rPrimBorrow != '')){ return true;}
									else { return false;}
								}

						}
					}
			}
		}
							
	}
	catch(e)
	{
		displayError(e,"ValRelatedCustomers");
	}
}
//==============================================================
//	Name:		ChkGFinancecircumstances
//	Purpose:	Links address to the customer. 
//	Parameters:	RecNo - (numeric) address record number
//==============================================================
function ChkGFinancecircumstances(bSelect,bFromDflt)
{
try
	{
		var bProgDraw = (bSelect || bFromDflt)? (ds_cust.recordset.fields("SignFinancecialCircumst").value=="-1"):document.all.chksigfinanceCircum.status;
		var bDisAmtTA =  !bProgDraw;
		
		DisableElement(document.all.cboCustNatureOfChange, !bDisAmtTA);
		DisableElement(document.all.cboCustomerMitigants, !bDisAmtTA);
		
		var SChkSig = document.all.chksigfinanceCircum.status;
		
		if (!bSelect){
				ds_cust.recordset.fields("CustomerNatureOfChange").value ="";
				ds_cust.recordset.fields("OtherCustomerNatureOfChange").value ="";
				ds_cust.recordset.fields("CustomerMitigants").value ="";
				ds_cust.recordset.fields("OtherCustomerMitigants").value ="";
				document.all.cboCustNatureOfChange.value="";
				document.all.cboCustomerMitigants.value="";
			}
		
		var sNature = document.all.cboCustNatureOfChange.value;
		var sMitigants = document.all.cboCustomerMitigants.value;
		
		if (!bSelect){
			if(!SChkSig){
				if((sNature == "") || (sNature != "Other")){
					DisableElement(document.all.txtNatureOfChange,!SChkSig);}
				if((sMitigants == "") || (sMitigants != "NatureOther")){
					DisableElement(document.all.txtMitigantChange,!SChkSig);}
			}
			
		}
		
	}
	catch(e)
	{
		displayError(e,"ChkGFinancecircumstances");
	}
	
}

// RelationShip with PrimaryBorrower Ends - Card 256

//==============================================================
//	Name:		ChkGuarantorFinandLegal
//	Purpose:	 sets the value for FinancialLegalAdvReq node 
//	Parameters:	 bSelect - On SelectCustomer this function will be called.
//==============================================================

function ChkGuarantorFinandLegal(bSelect)
{
	try
	{
		var sRS = ds_cust.recordset.fields("CustomerType").value;
		
		var iFinReq = (ds_cust.recordset.fields("FinancialAdvReq").value);
		var iLegReq = (ds_cust.recordset.fields("LegalAdvReq").value);
		if((bSelect) && (sRS=="GTR") && (iFinReq == '-1') && (iLegReq =='-1'))
			 ds_cust.recordset.fields("FinancialLegalAdvReq").value="-1";
		else 
			ds_cust.recordset.fields("FinancialLegalAdvReq").value="0";
		
	}
	catch(e)
	{
		displayError(e,"ChkGuarantorFinandLegal");
	}
} 

//==============================================================
//	Name:		Check_CustNatOfChange
//	Purpose:	Enable/Disabled the txtNatureOfChange
//	Parameters:	DropDown Value of cboCustNatureOfChange 
//==============================================================

function Check_CustNatOfChange(bSelect)
{
	try
	{
		var sRS = (bSelect)? ds_cust.recordset.fields("CustomerNatureOfChange").value:document.all.cboCustNatureOfChange.value;
		var bProgDraw = (bSelect)? (ds_cust.recordset.fields("SignFinancecialCircumst").value=="-1"):document.all.chksigfinanceCircum.status;
		var bDisAmtTA =  !bProgDraw;
		if ((!bSelect)&&(sRS!="NatureOther") && (!bDisAmtTA)) ds_cust.recordset.fields("OtherCustomerNatureOfChange").value="";
			DisableElement(document.all.txtNatureOfChange, (sRS=="NatureOther"));
	}
	catch (e)
	{
		displayError(e,'Check_CustNatOfChange');
	}              
}

//==============================================================
//	Name:		Check_CustMitigChange
//	Purpose:	Enable/Disabled the txtMitigantChange
//	Parameters:	DropDown Value of cboCustomerMitigants 
//==============================================================

function Check_CustMitigChange(bSelect)
{
	try
	{
		var sRS = (bSelect)? ds_cust.recordset.fields("CustomerMitigants").value:document.all.cboCustomerMitigants.value;
		var bProgDraw = (bSelect)? (ds_cust.recordset.fields("SignFinancecialCircumst").value=="-1"):document.all.chksigfinanceCircum.status;
		var bDisAmtTA =  !bProgDraw;
		if ((!bSelect)&&(sRS!="Other") && (!bDisAmtTA)) ds_cust.recordset.fields("OtherCustomerMitigants").value="";
			DisableElement(document.all.txtMitigantChange, (sRS=="Other"));
	}
	catch (e)
	{
		displayError(e,'Check_CustMitigChange');
	}              
}

//==============================================================
//	Name:		ChkExistingCustomer
//	Purpose:	Enable/Disabled the txtEstCustAccNumb
//	Parameters:	CheckBox Value of chkExistingCust 
//==============================================================

function ChkExistingCustomer(bSelect)
{
	try
	{
		var bProgDraw = (bSelect)? (ds_cust.recordset.fields("ExistingANZCustomer").value=="-1"):document.all.chkExistingCust.status;
		var bDisAmtTA =  !bProgDraw

		DisableElement(document.all.txtEstCustAccNumb, !bDisAmtTA);
		if (!bSelect){
			ds_cust.recordset.fields("ExistingCustomerAccountNumber").value ="";
			
		}
	}
	catch(e)
	{
		displayError(e,"ChkExistingCustomer");
	}                                
}


//Populate the list of customer in the Primary card holder

//==============================================================
//	Name:		PopulateCustSpouseNameCombo
//	Purpose:	Populates the Spouse Name for each customer's
//	Parameters:	Empty
//==============================================================

function PopulateCustSpouseNameCombo() {
    try 
	{
        var df = cbocustspousename.dataFld;
        var ds = cbocustspousename.dataSrc;
        cbocustspousename.dataFld = "";
        cbocustspousename.dataSrc = "";

        // clear list
        for (i = cbocustspousename.options.length - 1; i >= 0; i--)
            cbocustspousename.options.remove(i);

        var emptopt = document.createElement("OPTION");
        cbocustspousename.options.add(emptopt);
        emptopt.value = "0";
        emptopt.innerText = "Not In Application";
		
		var oCustDocEl = ds_cust.XMLDocument.documentElement;
		var iCustTypeName = oCustDocEl.selectSingleNode("CustomerName").text;
		var iCustTypeID = oCustDocEl.selectSingleNode("CustomerID").text;
		var oCusts = xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer")
		if(oCusts.length > 0){
			for (var i = 0; i < oCusts.length; i++) {
				var sID = oCusts(i).selectSingleNode("CustomerID").text;
				var sName = oCusts(i).selectSingleNode("CustomerName").text;
				if((iCustTypeName != sName))
				{
					if((sName.replace(/\s/g,'') != "NewEntry") && (sName != "")){
						var opt = document.createElement("OPTION");
						cbocustspousename.options.add(opt);
						opt.value = sID;
						opt.innerText = sName;
					}
				}
			}
		}
		cbocustspousename.dataSrc = ds;
        cbocustspousename.dataFld = df;
    }
    catch (e) 
	{
        displayError(e, 'PopulateCustSpouseNameCombo');
    }
}

//==============================================================
//	Name:		GetSpouseName
//	Purpose:	Gets SpouseName description from the list box.
//	Parameters:	Drop-Down Value - related to Spouse Name
//==============================================================
function GetSpouseName(nTAHVal)
{
	try
	{
		var oCust = ds_cust.XMLDocument.documentElement;
		if(oCust.selectSingleNode("SpouseName") != null){
			oCust.selectSingleNode("SpouseName").text = getListText(window.event.srcElement);
		}
		
	}
	catch(e)
	{
		displayError(e,"GetSpouseName");
	}	
}


//==============================================================
//	Name:		UpdateCustSpouseName
//	Purpose:	Gets SpouseID from the dropdown of SpouseName and it relates to each customer's when martial status is Married
//	Parameters:	Drop-Down Value - SpouseID and CustomerID
//==============================================================
function UpdateCustSpouseName(bSelectSpouseId,bCustID) {
    try 
	{
		var oCustDocEl = ds_cust.XMLDocument.documentElement;
		var iCustTypeID = oCustDocEl.selectSingleNode("CustomerID").text;
		var iCustTypeName = oCustDocEl.selectSingleNode("CustomerName").text;
		var nSpID = oCustDocEl.selectSingleNode("SpouseID").text;
		var oCusts = xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer");
			if(oCusts.length > 0){
				for (var i = 0; i < oCusts.length; i++) {
					var sID = oCusts(i).selectSingleNode("CustomerID").text;
					var oCustUpSp = xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer");
					if(bSelectSpouseId == sID)
					{
						var sXpath = "//Customers/Customer[CustomerID='" + sID + "']";
						var oCustSpList = xml_master.XMLDocument.selectNodes(sXpath);
						for (var j = 0; j < oCustUpSp.length; j++) {
							if(bSelectSpouseId == oCustUpSp(j).selectSingleNode("CustomerID").text){
								oCustUpSp(j).selectSingleNode("SpouseID").text = iCustTypeID;
								oCustUpSp(j).selectSingleNode("SpouseName").text = iCustTypeName;
							}
							else if((oCustUpSp(j).selectSingleNode("SpouseID").text == bSelectSpouseId)){
								oCustUpSp(j).selectSingleNode("SpouseID").text = "0";
								oCustUpSp(j).selectSingleNode("SpouseName").text = "Not In Application";
							}
							else if((oCustUpSp(j).selectSingleNode("SpouseID").text == iCustTypeID)){
								oCustUpSp(j).selectSingleNode("SpouseID").text = "0";
								oCustUpSp(j).selectSingleNode("SpouseName").text = "Not In Application";
							}
						}
					}
					else if((bSelectSpouseId == "0")){
						if(oCusts(i).selectSingleNode("SpouseID").text == bCustID){
							oCusts(i).selectSingleNode("SpouseID").text = "0";
							oCusts(i).selectSingleNode("SpouseName").text = "Not In Application";
						}
					}
				}
				
			}
		
		
    }
    catch (e) 
	{	
        displayError(e, 'UpdateCustSpouseName');
	}
}
