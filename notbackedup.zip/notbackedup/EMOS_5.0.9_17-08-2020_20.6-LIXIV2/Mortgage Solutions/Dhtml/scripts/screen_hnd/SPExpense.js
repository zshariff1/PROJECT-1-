//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.0  $
//	$Author:   maheedhv  $
//	$Workfile:   SPExpense.js  $
//	$Modtime:   Aug 01 2005 14:20:44  $	
//============================================================-->
//<SCRIPT>

//====================================================================
//	Function Name:	initExpenseDtlsDlg
//	Parameters:		nil
//					But all Expense records passed as window.dialogArguments from the main screen
//					when popup window opens.
//					All Expense records passed so that the criteria for the ExpenseType can be built 
//					to filter out some existing types.  
//	Return:			nil
//	Description:	Initialise the Expense pop-up window for Add/Edit.
//====================================================================
function initExpenseDtlsDlg()
{
	try
	{
		G_bSaveIsAllowed=true;
		initRefData();
		initXMLObject(ds_spExpense);
		initXMLObject(xml_ClickHelp)
		initXMLObject(xml_AppBRS);

		var oExpenses = window.dialogArguments;
		var idx = GetIntVal(oExpenses.getAttribute('RecIndex'));
		document.all.divCaption.innerText = (idx>=0) ? 'Edit Expenditure Details':'New Expenditure';
	
		ds_spExpense.src=ds_spExpense.src;
		var oExp = (idx>=0) ? oExpenses.childNodes(idx): oExpenses.childNodes(0);
		oExp.setAttribute('RecIndex',idx);
		ds_spExpense.XMLDocument.appendChild(oExp.cloneNode(true));

		
		sCriteria = '@TYPE_CAT="O"';  // Added the new selection criteria.
		
	  //WR1970 - Changed the criteria for selection of Expense Types for the combo box, from the Reference Data - End		
		
		
		// populate combo-boxes
		populateList("A_TS_EXPENSE_TYPES", document.all.tblExpenseDtls.all('cboExpenseType'), sCriteria, 'TYPE_CODE', 'CODE_DESC');				

		InitilizeAppBRS(ds_spExpense.XMLDocument.documentElement);				
	}
	catch (e)
	{
		displayError(e,'initExpenseDtlsDlg');	
	}
}


//====================================================================
//	Function Name:	saveExpenseDtls
//	Parameters:		bConfirmSave - flag shows that save is confirmed
//	Return:			Expense record back to main screen
//	Description:	When click on [save] in the popup window.
//====================================================================
function saveExpenseDtls(bConfirmSave)
{
	try
	{
		var oExpense = ds_spExpense.XMLDocument.documentElement;
		
		//copy type description
		oExpense.setAttribute('TypeDescription',getListText(document.all.cboExpenseType));
		//format the amount
		var sAmount = document.all.tblExpenseDtls.all.inpDeclaredAmount.value;
		oExpense.setAttribute('fmtAmount', VBFormatCurrency(sAmount,0));

		var bResult = EvaluateAppBRS(oExpense);

		if (G_bSaveIsAllowed) 
		{
			if (bResult)	
			{
				//check Expense Rules, ie. if it is "Total Living Expenses" ExpenseType then not show the Warning.
				var bRulesOk = check_ExpenseRules(oExpense);
				if (bConfirmSave || bRulesOk)
				{
					oExpense.removeAttribute("RecIndex");
					window.returnValue = ds_spExpense.XMLDocument.documentElement.cloneNode(true);
					window.close();
				}
			}
			else
				VBMsgBox('Please enter valid expenditure details.',G_iVB_WARNING,G_sAPPLICATION_TITLE);
		}
		else
		{
			promptSaveProhibited('Expenditure');
			window.close();
		}
	}
	catch (e)
	{
		displayError(e,'saveExpenseDtls');	
	}
}


//==============================================================================
//	Function Name:	check_ExpenseRules
//	Parameters:		oExpense - (XML Node) Expense Node
//	Return:			Boolean - true if the Expense details pass the rules
//	Description:	Validate: Some Expense Types
//==============================================================================
function check_ExpenseRules(oExpense)
{
	try
	{
		var sType = oExpense.selectSingleNode("ExpenseType").text;
		var iIdx = oExpense.getAttribute("RecIndex");

		// Check if adding a new record
		//		then check if Expense Type is 016 (Total Living Expenses) then true
		//		otherwise always true (pass the rule) - in case of editing.
		//var bRule1 = (iIdx=="-1")?(sType=="016"):true;
		
		// The testing condition should be tested for both adding and editing cases
		var bRule1 = false;
		//Enabled the warning message to all expenses
		//((sType=="020") || (sType=="021") || (sType=="022") || (sType=="023") || (sType=="024") || (sType=="025") || (sType=="026") || (sType=="027") || (sType=="028") || (sType=="029"));
		if (!bRule1)
		{	// If it doesn't pass the rule/s then show the warning.
			document.all.tblExpenseDtls.style.display="none";
			document.all.divWarning.style.display="block";
		}	
		return bRule1;
	}
	catch (e)
	{
		displayError(e,'check_ExpenseRules');
	}
}