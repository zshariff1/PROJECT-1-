//===========================
// Declare global variables
//===========================
var G_bSummaryDirty = false;


//==============================================================
//	Name:		SummaryScreenShow
//	Purpose:	Shows customer screen. 
//				Loads list boxes on the first show.
//==============================================================
function SummaryScreenShow()
{

	try
	{
		G_pScreenSaveFunction = saveSummary;
		G_bSummaryDirty=true;
		if (!G_oScreens["ScrSummary"].ListsPopulated) 
		{
			G_oScreens["ScrSummary"].ListsPopulated = true;
		}
		
		ds_summary.src=ds_summary.src;
		var oSummary = xml_master.XMLDocument.documentElement.selectSingleNode("//Summary");

		if (oSummary.hasChildNodes)
		{
			//retrieve AppDetails node if it's exists in application;
			var oRepl=ds_summary.XMLDocument.documentElement;
			ds_summary.XMLDocument.replaceChild(oSummary.cloneNode(true), oRepl);
		}
		else
		{	
			//initilise dso
			InitilizeAppBRS(ds_summary.XMLDocument.documentElement);
			SetSummaryDirty();
		}

		PaintContents()
		FillLVRValue();
		FillUMIValue();
	}
	catch(e)
	{
		displayError(e,"SummaryScreenShow");
	}
}
  
  
//==============================================================
//	Name:		PaintContents
//	Purpose:	Shows customer screen. 
//				Loads list boxes on the first show.
//==============================================================
 function PaintContents()
 {
	try 
	{
					
		var oXML = new ActiveXObject("MSXML2.DOMDocument");
		oXML.async = false;
		oXML.loadXML(xml_master.XMLDocument.xml);	

		var oXSL = new ActiveXObject("MSXML2.DOMDocument");
		oXSL.async = false;
		xsl_Summary.src='../xsl/SummaryPaint.xsl'
		oXSL.loadXML(xsl_Summary.XMLDocument.xml);
		
		var sHTML = oXML.documentElement.transformNode(oXSL.documentElement);
		document.getElementById("trSummarySection").innerHTML = sHTML;
	}
	catch(e)
	{
		displayError(e,"PaintContents");
	}
 }
 
 
//=======================================================================
//	Function Name:	saveSummary
//	Parameters:		bNoReselect - whether to perform the initialising functionality 
//	Return:			nil
//	Description:	Save Summary to the disk.
//======================================================================= 
function saveSummary(bNoReselect)
{
	try
	{
		var oNewSummary = ds_summary.XMLDocument.documentElement.cloneNode(true);
		var oReplSummary = xml_master.XMLDocument.documentElement.selectSingleNode("Summary");
		xml_master.XMLDocument.documentElement.replaceChild(oNewSummary, oReplSummary);

		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Summary"));
		EvaluateAppBRS(xml_master.XMLDocument.documentElement, true);
		FlushToDisk();
		G_bSummaryDirty = false;
		SummaryScreenShow();
	}
	catch (e)
	{
		displayError(e,'saveSummary');	
	}
}


//=======================================================================
//	Function Name:	SetSummaryDirty
//	Parameters:		nil
//	Return:			nil
//	Description:	Set screen dirty.
//======================================================================= 
function SetSummaryDirty()
{
	G_bSummaryDirty=true;
}


//=======================================================================
//	Function Name:	FillLVRValue
//	Parameters:		nil
//	Return:			nil
//	Description:	Fills the LVR value cell.
//======================================================================= 
function FillLVRValue()
{
	try 
	{
		var iLVR;
		
		var oPurposeNode,oSecuritiesNode,oPurpose,oSecurity,oPFNode;
		var iTotalAmtSought, iExistingLoan, iTotSecurity;
		var sSecType;
		var iCustStatedValue,iSecValue;
		
		iTotalAmtSought=0;
		iExistingLoan=0;
		iTotSecurity=0;
		
		oPurposeNode = xml_master.XMLDocument.documentElement.selectSingleNode ('Purposes');
		
		oPFNode = xml_master.XMLDocument.documentElement.selectSingleNode ('Portfolio')
		
		//Loop through the purposes to get the purpose amount
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '0' )
		{
			for (var iIndex=0; iIndex<oPurposeNode.childNodes.length; iIndex++)
			{
				oPurpose = oPurposeNode.childNodes(iIndex);
				iTotalAmtSought=iTotalAmtSought+parseInt(oPurpose.getAttribute("TotalAmount"));
			}
		}
		else
			 iTotalAmtSought = parseInt(oPFNode.getAttribute('PortfolioAmount'));
			 
			oSecuritiesNode = xml_master.XMLDocument.documentElement.selectSingleNode ('Securities');
		
		//Loop through the securities to get the security value and the existing loan amounts.
		for (var iIndex=0; iIndex<oSecuritiesNode.childNodes.length; iIndex++)
		{
			oSecurity = oSecuritiesNode.childNodes(iIndex);
			
			
			iExistingLoan=iExistingLoan+parseInt(oSecurity.selectSingleNode("ExistingLoanAmount").text);
			sSecType=oSecurity.selectSingleNode("SecurityType").text;
			if(sSecType=='B')
			{	
				iCustStatedValue=parseInt(oSecurity.selectSingleNode("CustomerStatedValue").text);
				iSecValue=parseInt(oSecurity.selectSingleNode("SecurityValue").text);
				if(iSecValue==0)
					iTotSecurity=iTotSecurity+iCustStatedValue;
				else
					iTotSecurity=iTotSecurity+iSecValue;
			}		
			else
				iTotSecurity=iTotSecurity+parseInt(oSecurity.selectSingleNode("SecurityValue").text);
		}
		
		//Calculate the LVR value
		iLVR=((iTotalAmtSought+iExistingLoan)/iTotSecurity)*100;
		iLVR=Number(iLVR);
	
		if(iTotSecurity==0)
		{
			iLVR="0.00";
		}
		else
		{		
			if (isNaN(iLVR))
				iLVR="0.00";
			else
			{
				//Round to two decimal points
				iLVR=VBRound(iLVR,2);				
			}
		}		
		//Display
		document.getElementById("tdLVRCell").innerHTML=VBReplace(VBFormatCurrency(iLVR,2),'$','') + "%";
	}
	catch(e)
	{
		displayError(e,"FillLVRValue");
	}
}


//=======================================================================
//	Function Name:	FillUMIValue
//	Parameters:		nil
//	Return:			nil
//	Description:	Fills the UMI cell.
//======================================================================= 
function FillUMIValue()
{
	try 
	{
		var iUMI;
		
		var oSOPs,oSOP;
		var iTotIncome, iTotExpence;
	
		iTotIncome=0;
		iTotExpence=0;
		
		oSOPs = xml_master.XMLDocument.documentElement.selectSingleNode ('StatementsOfPosition');
		
		//Loop through the purposes to get the purpose amount
		for (var iIndex=0; iIndex<oSOPs.childNodes.length; iIndex++)
		{
			oSOP = oSOPs.childNodes(iIndex);
			iTotIncome=iTotIncome+parseInt(oSOP.getAttribute("TotIncome"));
			iTotExpence=iTotExpence+parseInt(oSOP.getAttribute("TotExpense"));
		}
		
		//Calculate the UMI value
		iUMI=iTotIncome-iTotExpence;
		
		//Format to currency
		iUMI=VBFormatCurrency (iUMI,0);
		
		//Display
		document.getElementById("tdUMICell").innerHTML=iUMI;
	}
	catch(e)
	{
		displayError(e,"FillUMIValue");
	}
}


