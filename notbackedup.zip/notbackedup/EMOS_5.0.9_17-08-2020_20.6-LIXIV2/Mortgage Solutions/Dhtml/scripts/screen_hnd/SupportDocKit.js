//<SCRIPT>
//==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Mahesh Kumar
//	Workfile:  
//	ModTtime: 2005/04/20
//  File: SupportDocKit.js	
//============================================================

//====================================================================================
//	Function Name:	FillApplicantNames
//	Parameters:		oDocEl - Document object
//	Return:			Nil	
//	Description:	Filling the Applicant Names in page one of Supporting Document Kit
//====================================================================================
function FillApplicantNames(oDocEl)
{
	try
	{
				
		var oCusts=oDocEl.selectNodes("//Customers/Customer[@CustomerTypeDescription!='Guarantor']");
		var sLongName = "";
		var arNames;
		var nIndex;
		var sTempName;
								
		if(oCusts.length > 0)
		{
			if(oCusts.length > 1)
			{
				
				for(nIndex=0; nIndex<oCusts.length; nIndex++)
					arNames = arNames + oCusts(nIndex).selectSingleNode("CustomerName").text + "|";
				
				arNames = arNames.split("|");
				sLongName = oCusts(0).selectSingleNode("CustomerName").text +", ";
				
				for(nIndex=1; nIndex<arNames.length-1; nIndex++)
				{
					sTempName = sLongName + arNames[nIndex];
					
					if(sTempName.length <= 70)
					{
						sLongName = sTempName + ", ";
					}
					else
						break;
				}
				
				sLongName = VBMid(sLongName);
				
			}
			else
				sLongName =  oCusts(0).selectSingleNode("CustomerName").text;

		}
		document.getElementById("tdApplicantName").innerHTML= "&nbsp;" + sLongName.toUpperCase();
		
				
	}
	catch(e)
	{
		displayError(e, "FillApplicantNames");
	}			

}

//====================================================================================
//	Function Name:	FillSOPValues
//	Parameters:		oDocEl - Document object
//	Return:			Nil	
//	Description:	Filling the Statement of Position values in Page3
//====================================================================================		
function FillSOPValues(oDocEl)
{
	try
	{
		var oNodeList = oDocEl.selectNodes("//StatementsOfPosition/StatementOfPosition")
		var nLength = oNodeList.length;
		var nIndex;
		var iTotalAsset = 0;
		var iTotalLiability = 0;
		var iTotalIncome = 0;
		var iTotalExpenditure = 0;
		var iNetAsset = 0;
		var iUnComMonInc = 0;
		
		if(nLength > 0)
		{
			for(nIndex = 0; nIndex < nLength; nIndex++)
			{
				iTotalAsset = iTotalAsset + parseInt(oNodeList.item(nIndex).getAttributeNode("TotAsset").value);
				iTotalLiability = iTotalLiability + parseInt(oNodeList.item(nIndex).getAttributeNode("TotLiability").value);
				iTotalIncome = iTotalIncome + parseInt(oNodeList.item(nIndex).getAttributeNode("TotIncome").value);
				iTotalExpenditure = iTotalExpenditure + parseInt(oNodeList.item(nIndex).getAttributeNode("TotExpense").value);
			}
			
		}
		iNetAsset = iTotalAsset - iTotalLiability;
		iUnComMonInc = iTotalIncome - iTotalExpenditure;
		document.getElementById("tdTotalAsset").innerHTML= VBFormatCurrency(iTotalAsset, 0);
		document.getElementById("tdTotalLiabilities").innerHTML= VBFormatCurrency(iTotalLiability,0);
		document.getElementById("tdTotalIncome").innerHTML= VBFormatCurrency(iTotalIncome,0);
		document.getElementById("tdTotalExpense").innerHTML= VBFormatCurrency(iTotalExpenditure,0);
		document.getElementById("tdNetAssets").innerHTML= VBFormatCurrency(iNetAsset,0);
		document.getElementById("tdUnCommIncome").innerHTML= VBFormatCurrency(iUnComMonInc,0);
	}
	catch(e)
	{
		displayeError(e, "FillSOPValues");
	}
}

//====================================================================================
//	Function Name:	FillGuarantorSection
//	Parameters:		oDocEl - Document object
//	Return:			Nil	
//	Description:	Filling Guarantor's Declaration Section in Page3
//====================================================================================	
function FillGuarantorSection(oDocEl)
{
	try
	{
		var oCustGuar=oDocEl.selectNodes("//Customers/Customer[@CustomerTypeDescription='Guarantor']");
			
		var sHTML = "";
		var sCustGuarName = "";
		var nEvnIndex = 0;
						
		sHTML = sHTML + "<table border='0' width='100%' cellspacing='3' cellpadding='0'>"
	
		if(oCustGuar.length > 0)
		{
			for(var nIndex=0; nIndex<oCustGuar.length; nIndex++)
			{
				nEvnIndex = nIndex + 1;
				
				//Guarantor's Name
				sHTML = sHTML + "<tr>";
				sHTML = sHTML + "<td class='SDKNormalText' width='10%'>Guarantor's name:</td>";
				sHTML = sHTML + "<td colspan='3' class='SDKTDStyle' width='40%'>&nbsp;" + oCustGuar(nIndex).selectSingleNode("CustomerName").text.toUpperCase(); + "</td>";
				sHTML = sHTML + "<td class='SDKNormalText' width='10%' align='right'>Guarantor's name:</td>";
				if(nEvnIndex < oCustGuar.length)
				{
					sCustGuarName = oCustGuar(nEvnIndex).selectSingleNode("CustomerName").text;
					sCustGuarName = sCustGuarName.toUpperCase();
					sHTML = sHTML + "<td colspan='3' class='SDKTDStyle' width='40%'>&nbsp;" + sCustGuarName + "</td>";
				}
				else
					sHTML = sHTML + "<td colspan='3' class='SDKTDStyle' width='40%'>&nbsp;</td>";
				sHTML = sHTML + "</tr>";
				
				//Gurantor's Signature
				sHTML = sHTML + "<tr>";
				sHTML = sHTML + "<td class='SDKNormalText' width='10%' >Guarantor's signature:</td>";
				sHTML = sHTML + "<td class='SDKTDStyle' width='23%'><img src='../images/spacer.gif' width='0' height='0'/></td>";
				sHTML = sHTML + "<td class='SDKNormalText' width='7%' style='padding-left: 5px' align='center'>Date:</td>";
				sHTML = sHTML + "<td class='SDKTDStyle' width='10%' style='padding-left: 5px'><img src='../images/spacer.gif' width='0' height='0'/></td>";
				sHTML = sHTML + "<td class='SDKNormalText' width='10%' align='right'>Guarantor's signature:</td>";
				sHTML = sHTML + "<td class='SDKTDStyle' width='23%' style='padding-left: 5px'><img src='../images/spacer.gif' width='0' height='0'/></td>";
				sHTML = sHTML + "<td class='SDKNormalText' width='7%' style='padding-left: 5px' align='center'>Date:</td>";
				sHTML = sHTML + "<td class='SDKTDStyle' width='10%' style='padding-left: 5px'><img src='../images/spacer.gif' width='0' height='0'/></td>";
				sHTML = sHTML + "</tr>"	
				
				nIndex = nIndex + 1;		
				
			}
			
		}
		else
		{
			//Guarantor's Name
			sHTML = sHTML + "<tr>";
			sHTML = sHTML + "<td class='SDKNormalText' width='10%'>Guarantor's name:</td>";
			sHTML = sHTML + "<td colspan='3' class='SDKTDStyle' width='40%'><img src='../images/spacer.gif' width='0' height='0'/></td>";
			sHTML = sHTML + "<td class='SDKNormalText' width='10%' align='right'>Guarantor's name:</td>";
			sHTML = sHTML + "<td colspan='3' class='SDKTDStyle' width='40%'><img src='../images/spacer.gif' width='0' height='0'/></td>";
			sHTML = sHTML + "</tr>";
			
			//Gurantor's Signature
			sHTML = sHTML + "<tr>";
			sHTML = sHTML + "<td class='SDKNormalText' width='10%' >Guarantor's signature:</td>";
			sHTML = sHTML + "<td class='SDKTDStyle' width='23%'><img src='../images/spacer.gif' width='0' height='0'/></td>";
			sHTML = sHTML + "<td class='SDKNormalText' width='7%' style='padding-left: 5px' align='center'>Date:</td>";
			sHTML = sHTML + "<td class='SDKTDStyle' width='10%' style='padding-left: 5px'><img src='../images/spacer.gif' width='0' height='0'/></td>";
			sHTML = sHTML + "<td class='SDKNormalText' width='10%' align='right'>Guarantor's signature:</td>";
			sHTML = sHTML + "<td class='SDKTDStyle' width='23%' style='padding-left: 5px'><img src='../images/spacer.gif' width='0' height='0'/></td>";
			sHTML = sHTML + "<td class='SDKNormalText' width='7%' style='padding-left: 5px' align='center'>Date:</td>";
			sHTML = sHTML + "<td class='SDKTDStyle' width='10%' style='padding-left: 5px'><img src='../images/spacer.gif' width='0' height='0'/></td>";
			sHTML = sHTML + "</tr>"			
				
		}
		
		sHTML = sHTML + "</table>";
		
		document.getElementById("tdGuaSign").innerHTML = sHTML;
		
	}
	catch(e)
	{
		displayError(e, "FillGuarantorSection");
	}
}

//====================================================================================
//	Function Name:	CheckBreakfree
//	Parameters:		oDocEl - Document object
//	Return:			Nil	
//	Description:	Hide/Show Breakfree page
//====================================================================================	
function CheckBreakfree(oDocEl)
{
	try
	{
		//var oProd=oDocEl.selectNodes("//Products/Product[@DiscountPackageDescription='Break Free']");
		var oPurp=oDocEl.selectNodes("//Purposes/Purpose");
		var sDiscPack = oDocEl.getAttributeNode("DiscountPack").value;

		if(sDiscPack == "PSPW" && oPurp.length>0)
		{
			document.getElementById("tblBreakfree").style.display = 'block';
			document.getElementById("tdPageNumber").innerHTML = "Page 6";
		}
		else
		{
			document.getElementById("tblBreakfree").style.display = 'none';
			document.getElementById("tdPageNumber").innerHTML = "Page 4";
		}
	}
	catch(e)
	{
		displayError(e, "CheckBreakfree");
	}
}