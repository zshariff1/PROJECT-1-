//<!--==========================================================
//	(C) Copyright 1996 - 2005
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		K.Raghuram
//	Workfile:	TaxResidentDtls.js
//	ModTtime:	08/02/2018
//============================================================-->
//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes--> 
// New Js file for Add/Edit Tax Residence Details Pop up Screen --> 

var G_oEmpDtls
var G_sModeOpenned;
var G_imgEmpty="../images/empty_cross.gif";
var G_imgValid="../images/blue_asteric.gif";
var G_FirstChange=true;
//==============================================================
//	Name:		InitializeTaxResidentPopup
//	Purpose:	Disables/Enables, hides/shows and resets/defaults
//				customer tax resident controls.
//	Parameters:	
//				
//==============================================================
function InitializeTaxResidentPopup()
{
	try
	{				 
		var oTaxDtlsPassed;
		oTaxDtlsPassed=window.dialogArguments;
		
		initRefData();
		initXMLObject(xml_ClickHelp);
		initXMLObject(ds_TaxResidentDet);			
		initXMLObject(xml_AppBRS);
		
		G_imgEmpty= xml_AppBRS.XMLDocument.documentElement.getAttribute("imgEmpty");
		G_imgValid= xml_AppBRS.XMLDocument.documentElement.getAttribute("imgValid");

		//addDefaultValue();
		populateList("A_TS_COUNTRY_CODES_NEW", document.all.cboTaxResidenttType, null, 'CODE', 'NAME', true);				
		
		ds_TaxResidentDet.src=ds_TaxResidentDet.src;
		
		ds_TaxResidentDet.XMLDocument.replaceChild(oTaxDtlsPassed,ds_TaxResidentDet.XMLDocument.documentElement);
		
		G_sModeOpenned=VBTrim(ds_TaxResidentDet.XMLDocument.documentElement.getAttribute('Mode'));
		
		var sHeading;
		
		if (G_sModeOpenned=='Edit')
		{
			sHeading='Edit Tax Residence Details';	
			document.all.cboReason.value="<-- Please Select -->";
			document.all.cboReason.disabled=true;
		}
					
		if (G_sModeOpenned=='Create')
			sHeading='New Tax Residence Details';
				
		document.all.spnHead1.innerText =sHeading;
		ds_TaxResidentDet.XMLDocument.documentElement.removeAttribute("Mode");
				
		InitilizeAppBRS(ds_TaxResidentDet.XMLDocument.documentElement);
		
		InitializeReason();
		InitializeExplanation();
		addDefaultValue();	
		setDefaultValue();
		var tin=ds_TaxResidentDet.XMLDocument.documentElement.selectSingleNode("CountryTIN").text;		
		var reason=ds_TaxResidentDet.XMLDocument.documentElement.selectSingleNode("NoTinReason").text;		
		if (G_sModeOpenned=='Edit')
		{
			if (tin.length == 0)
			{		
				document.all.cboReason.disabled=false;
			}
			else
			{				
				document.all.cboReason.selectedIndex=-1;
				document.all.cboReason.disabled=true;			
			} 
			if (reason == "Z")
			{			
				document.all.inExplanation.disabled=false;
			}
			else
			{			
				document.all.inExplanation.disabled=true;
			}
		}
	}
	catch(e)
	{
		displayError(e,"InitializeTaxResidentPopup");
	}	
}



//==============================================================
//	Name:		SaveTaxDetails
//	Purpose:	Handles the click event of the save button
//				
//	Parameters:	
//				
//	Returns:	
//==============================================================
function SaveTaxDetails()
{
	try
	{
		
		//SetEmpStatus();
		if (document.all.cboTaxResidenttType.value=='<-- Please Select -->' && 
			document.all.cboReason.value=='<-- Please Select -->' && 
			document.all.inpTINno.value=="" && document.all.inExplanation.value=="")
		{
			document.all.cboTaxResidenttType.focus();
		}
		else
		{
			if (document.all.cboTaxResidenttType.value == '<-- Please Select -->')
			{			
				document.all.cboTaxResidenttType.selectedIndex=-1;
			}		
			if (document.all.cboReason.value == '<-- Please Select -->')
			{			
				document.all.cboReason.selectedIndex=-1;
			}		
		
			
			ds_TaxResidentDet.XMLDocument.documentElement.setAttribute("TaxCountry",getListText(cboTaxResidenttType));
			
			ds_TaxResidentDet.XMLDocument.documentElement.setAttribute("TINNo",document.all.inpTINno.value);		
			
			ds_TaxResidentDet.XMLDocument.documentElement.setAttribute("Reason",getListText(cboReason));
			
			ds_TaxResidentDet.XMLDocument.documentElement.setAttribute("Explanation",document.all.inExplanation.value);		
			
			var btest=EvaluateAppBRS(ds_TaxResidentDet.XMLDocument.documentElement);
				
			if(btest==true)
			{	
				
				window.returnValue = ds_TaxResidentDet.XMLDocument.documentElement.cloneNode(true);
				window.close();
			}
			else
				VBMsgBox('Please enter valid tax resident details.',G_iVB_WARNING,G_sAPPLICATION_TITLE);
		}
	}
	catch (e)
	{
		displayError(e, "SaveTaxDetails")
	}
}


//==============================================================
//	Name:		InitializeReason
//	Purpose:	Disables/Enables Reason
//	Parameters:	Blank / Non Blank
//==============================================================
function InitializeReason()
{
	var bSelect;
	bSelect= document.getElementById("inpTINno").value;	
	
	try
	{
		if (bSelect=="") 
		{				
			document.all.cboReason.selectedIndex=0;
			document.all.inExplanation.value ="";
			DisableElement(document.all.cboReason,(1));
			DisableElement(document.all.inExplanation,(0));			
		}
		else if (bSelect!="")
		{			
			document.all.cboReason.selectedIndex=-1;
			document.all.inExplanation.value ="";
			DisableElement(document.all.cboReason,(0));	
			DisableElement(document.all.inExplanation,(0));
		}
	}
	catch(e)
	{
		displayError(e,"InitializeReason");
	}
}

//==============================================================
//	Name:		InitializeReason
//	Purpose:	Disables/Enables Reason
//	Parameters:	Blank / Non Blank
//==============================================================
function enableTinNo()
{
	var bSelect;
	bSelect= document.getElementById("cboReason").selectedIndex;	
	
	try
	{
		if (bSelect>0) 
		{				
			document.all.inpTINno.value="";			
			DisableElement(document.all.inpTINno,(0));				
		}
		else 
		{						
			DisableElement(document.all.inpTINno,(1));	
		}
	}
	catch(e)
	{
		displayError(e,"enableTinNo");
	}
}
//==============================================================
//	Name:		InitializeCountryofResidance
//	Purpose:	Disables/Enables Country 
//	Parameters:	Yes / No
//==============================================================
function InitializeCountry()
{
	try
	{			
		if (document.getElementById("cboTaxResidenttType").length == 1)
		{
			populateList("A_TS_COUNTRY_CODES_NEW",  document.all.cboTaxResidenttType,null, 'CODE', 'NAME', false,true);
		}
		
	}
	catch(e)
	{
		displayError(e,"InitializeCountry");
	}
}

//==============================================================
//	Name:		CheckBlankTINNoforReason
//	Purpose:	Disables/Enables and resets/defaults Tin No control. 
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
/* function CheckBlankTINNoforReason(bSelect)
{
	try
	{
		var ND = (bSelect)? ds_cust.recordset.fields("CustomerTIN").value:document.all.inpCustTin.value;
		DisableElement(document.all.inpCustTin,(ND!=""));
	}
	catch(e)
	{
		displayError(e,"CheckBlankTINNoforReason");
	}
}*/ 

//==============================================================
//	Name:		InitializeExplanation
//	Purpose:	Disables/Enables Explanation
//	Parameters:	Blank / Non Blank = "TIN unobtainable"
//==============================================================
function InitializeExplanation()
{
	var bSelect2= document.getElementById("cboReason").value;
	
	try
	{		
		if (bSelect2=="Z")
		{		
			DisableElement(document.all.inExplanation,(1));	
		}
		else if (bSelect2!="Z")
		{
			document.all.inExplanation.value ="";
			DisableElement(document.all.inExplanation,(0));				
		}
	}
	catch(e)
	{
		displayError(e,"InitializeExplanation");
	}
}
function enable_reason()
{
	var bSelect2= document.getElementById("inpTINno").value;	
	InitializeReason();
}
//=============================================================
// Name: limitText
// Purpose: To limit the characters upto 200 in explanation 
//=============================================================
function limitText(limitField, limitNum)
{
	if (limitField.value.length > limitNum)
	{
		limitField.value = limitField.value.substring(0, limitNum);
	}
}
//=============================================================
//Name: To add default Please Select text in the country list
//=============================================================
function addDefaultValue()
{
	var x = document.getElementById("cboTaxResidenttType");	
	x.options[0]=new Option('<-- Please Select -->','<-- Please Select -->',true,true);
	var option = x.options[0];
	document.getElementById("cboTaxResidenttType").value = "<-- Please Select -->";
	var y = document.getElementById("cboReason");	
	y.options[0]=new Option('<-- Please Select -->','<-- Please Select -->',false,false);
	var defaultoption = y.options[0];
	document.getElementById("cboReason").value = "<-- Please Select -->";	
}

function setDefaultValue()
{	
	var a = document.getElementById("cboTaxResidenttType");
	a.options[0].selected = true;
	document.getElementById("cboTaxResidenttType").value ="<-- Please Select -->"; 
	var v = document.getElementById("cboReason");
	v.options[0].selected = true;
	document.getElementById("cboReason").value ="<-- Please Select -->";	
}
//==============================================================
//	Name:		HandleTaxCountrySelection
//	Purpose:	Handles the Screen changes for various tax country details
//				status values.
//	Parameters:	
//				
//	Returns:	
//==============================================================
function HandleTaxCountrySelection()
{
	try
	{
		var sTaxCountrySel=getListText(cboTaxResidenttType);
		var sReason=getListText(cboReason);		
		ds_TaxResidentDet.XMLDocument.documentElement.selectSingleNode("cboCountry").text=sTaxCountrySel;
		ds_TaxResidentDet.XMLDocument.documentElement.selectSingleNode("NoTinReason").text=sReason;
		
		InitilizeAppBRS(ds_TaxResidentDet.XMLDocument.documentElement);	
	}
	catch (e)
	{
		displayError(e, "HandleTaxCountrySelection")
	}
}

