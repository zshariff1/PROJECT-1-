// <SCRIPT/>
//==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Eugene Elutine, Tim Heide
//	Workfile:  
//	ModTtime: 2003/03/04
//  File: BranchSelector.js	
//============================================================

// Branch selector window java scripts
var G_selectedRow = 0;


//==============================================================
//	Name:		searchBranches
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Searches ref data for branches matching quiery 
//				and adds them to the search results DSO
//==============================================================
function searchBranches()
{
	try
	{
		document.all.spnNoRec.innerText = "";
		var s=document.all.inpNomBranchName.value;
	  
	  //WR1970 - To remove the double quotes entered in if any - Start
		s = s.replace('"','');
	  //WR1970 - To remove the double quotes entered in if any - Start	
		
		s=s.toUpperCase();
		//search ref data for branches and return xml for table
	  //WR1970 - The Branch search CONTAINS the search criteria entered instead of STARTING with that. - Start
		//var oSR = getRDRows("A_TSR_BRANCH",'starts-with(@P_BR_NAME,"' + s + '")'); 
		var oSR = getRDRows("A_TSR_BRANCH",'contains(@P_BR_NAME,"' + s + '")');
	  //WR1970 - The Branch search CONTAINS the search criteria entered instead of STARTING with that. - End
		
		clearSearchResults();
		var oBR=ds_SearchResults.XMLDocument.documentElement.selectSingleNode("//A_TSR_BRANCH");
		
		document.all.spnNoRec.innerText = (oSR.length==0)? "No records found.":((oSR.length==1)? "1 record found:":oSR.length + " records found:");
		
		for (i=0; i<oSR.length; i++)
				oBR.appendChild(oSR(i).cloneNode(true));
	} 
	catch(e)
	{
		displayError(e,"searchBranches");
	}
}

//==============================================================
//	Name:		searchIfEnter
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Calls search branches if enter is pressed
//==============================================================
function searchIfEnter()
{
	if (event.keyCode==13) searchBranches();
}

//==============================================================
//	Name:		selectBranch
//	Parameters:	RecNo - (numeric) record number of selected branch
//	Return:		Nil	
//	Purpose:	Sets the 'G_selectedRow' variable with the selected branches recno
//==============================================================
function selectBranch(RecNo)
{
	G_selectedRow = RecNo;
}

//==============================================================
//	Name:		closeIfEnter
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Close the window if enter on HTML element
//==============================================================
function closeIfEnter()
{
	if (event.keyCode==13 && G_selectedRow>0) closeWindow(true);
}

//==============================================================
//	Name:		closeWindow
//	Parameters:	bOk - (boolean) Flag indicating if OK was pressed
//	Return:		String - Window return value. Selected branch code.	
//	Purpose:	Closes the window and returns the selected branch
//==============================================================
function closeWindow(bOk)
{	
	try
	{
		var sBSB = null;
	
		if (bOk && G_selectedRow>0)
		{
			var oBR=ds_SearchResults.XMLDocument.documentElement.selectSingleNode("//A_TSR_BRANCH");
			sBSB = oBR.childNodes(G_selectedRow-1).getAttribute("PCD_USER_KEY");
		}
	
		window.returnValue=sBSB; 
		window.close();
	} 
	catch(e)
	{
		displayError(e,"closeWindow");
	}
}

//==============================================================
//	Name:		initBranchSearchScr
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Initialises the Branch search screen.
//==============================================================
function initBranchSearchScr()
{
	try
	{	
		ds_SearchResults.XMLDocument.async = false;
		ds_SearchResults.XMLDocument.setProperty("SelectionLanguage","XPath");
		clearSearchResults()
		initRefData();
	} 
	catch(e)
	{
		displayError(e,"initBranchSearchScr");
	}
	
}

//==============================================================
//	Name:		clearSearchResults
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Clear the search results
//==============================================================
function clearSearchResults()
{
	try
	{
		G_selectedRow = 0;
		ds_SearchResults.src=ds_SearchResults.src
		var oBR=ds_SearchResults.XMLDocument.documentElement.selectSingleNode("//A_TSR_BRANCH");
		var oCleanBR=oBR.cloneNode(false);
		oBR.parentNode.replaceChild(oCleanBR, oBR);
	} 
	catch(e)
	{
		displayError(e,"clearSearchResults");
	}
}