// <SCRIPT/>
//==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Tim Heide
//	Workfile:  
//	ModTtime: 2003/09/24
//  File: OccupationSelector.js	
//============================================================

// Occupation selector window java scripts
var G_selectedRow = 0;
var G_sNECriteria = "";

//==============================================================
//	Name:		searchOccupations
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Searches ref data for occupations matching quiery 
//				and adds them to the search results DSO
//==============================================================
function searchOccupations()
{
	try
	{
		document.all.spnNoRec.innerText = "";
		var s=document.all.inpOccupationName.value;
		s=VBReplace(s,'"','');
		s=s.toUpperCase();
		//search ref data for occupations and return xml for table
		var oSR = getRDRows("A_TS_CIS_OCCUPATIONS",'starts-with(@CODE_DESC,"' + s + '")' + G_sNECriteria);
		clearSearchResults();
		var oBR=ds_SearchResults.XMLDocument.documentElement.selectSingleNode("//A_TS_CIS_OCCUPATIONS");
		
		document.all.spnNoRec.innerText = (oSR.length==0)? "No records found.":((oSR.length==1)? "1 record found:":oSR.length + " records found:");
		
		for (i=0; i<oSR.length; i++)
				oBR.appendChild(oSR(i).cloneNode(true));
	} 
	catch(e)
	{
		displayError(e,"searchOccupations");
	}
}

//==============================================================
//	Name:		searchIfEnter
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Calls search branches if enter is pressed
//==============================================================
function searchIfEnter()
{
	if (event.keyCode==13) searchOccupations();
}

//==============================================================
//	Name:		selectOccupation
//	Parameters:	RecNo - (numeric) record number of selected occupation
//	Return:		Nil	
//	Purpose:	Sets the 'G_selectedRow' variable with the selected occupation recno
//==============================================================
function selectOccupation(RecNo)
{
	G_selectedRow = RecNo;
}

//==============================================================
//	Name:		closeIfEnter
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Close the window if enter on HTML element
//==============================================================
function closeIfEnter()
{
	if (event.keyCode==13 && G_selectedRow>0) closeWindow(true);
}

//==============================================================
//	Name:		closeWindow
//	Parameters:	bOk - (boolean) Flag indicating if OK was pressed
//	Return:		String - Window return value. Selected occupation code.	
//	Purpose:	Closes the window and returns the selected occupation
//==============================================================
function closeWindow(bOk)
{	
	try
	{
		var sOCC = null;
	
		if (bOk && G_selectedRow>0)
		{
			var oOCC=ds_SearchResults.XMLDocument.documentElement.selectSingleNode("//A_TS_CIS_OCCUPATIONS");
			sOCC = oOCC.childNodes(G_selectedRow-1).getAttribute("OCCUPATION_CODE");
		}
	
		window.returnValue=sOCC; 
		window.close();
	} 
	catch(e)
	{
		displayError(e,"closeWindow");
	}
}

//==============================================================
//	Name:		initBranchSearchScr
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Initialises the Branch search screen.
//==============================================================
function initOccupationSearchScr()
{
	try
	{	
		ds_SearchResults.XMLDocument.async = false;
		ds_SearchResults.XMLDocument.setProperty("SelectionLanguage","XPath");
		clearSearchResults()
		initRefData();
		UCaseNode("A_TS_CIS_OCCUPATIONS", "CODE_DESC");
		
		//Set up search criteria for 'not employed' occupations
		var bNotEmployed = window.dialogArguments;
		setupSearchCriteria(bNotEmployed);
	} 
	catch(e)
	{
		displayError(e,"initOccupationSearchScr");
	}
	
}


//==============================================================
//	Name:		clearSearchResults
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Clear the search results
//==============================================================
function clearSearchResults()
{
	try
	{
		G_selectedRow = 0;
		ds_SearchResults.src=ds_SearchResults.src
		var oOCC=ds_SearchResults.XMLDocument.documentElement.selectSingleNode("//A_TS_CIS_OCCUPATIONS");
		var oCleanOCC=oOCC.cloneNode(false);
		oOCC.parentNode.replaceChild(oCleanOCC, oOCC);
	} 
	catch(e)
	{
		displayError(e,"clearSearchResults");
	}
}
//==============================================================
//	Name:		setupSearchCriteria
//	Parameters:	p_bNotEmployed - Not employed flag	
//	Return:		Nil	
//	Purpose:	Creates search criteria for not employed employment type
//==============================================================
function setupSearchCriteria(p_bNotEmployed)
{
	try
	{
		if (p_bNotEmployed)
		{
			var rNECodes = getRDRows("A_TS_NON_EMPLMT_OCCD",null);
			if (rNECodes)
			{
				for (var i=0; i < rNECodes.length; i++)
				{
					if (G_sNECriteria) G_sNECriteria = G_sNECriteria + ' or ';
					G_sNECriteria = G_sNECriteria + '@OCCUPATION_CODE="' + rNECodes.item(i).getAttribute("OCCUPATION_CODE") + '"'
				}
				if (G_sNECriteria) G_sNECriteria = " and (" + G_sNECriteria + ")";
			}
		}
	} 
	catch(e)
	{
		displayError(e,"setupSearchCriteria");
	}
}