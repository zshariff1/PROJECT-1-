//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		E.Elutin
//	Workfile:	SPWizard.js
//	ModTtime:	14/03/2003
//============================================================-->
//<SCRIPT>

//Global variables
var G_bSPWizInitilised=false;	//Flag indicationg that SPWizard stub has been initilised

//=====================================================================
//	Function Name:	InitSPWizardDlg
//	Purpose:		Controls screen apperence on the load.
//					Initilises screen controls.
//=====================================================================
function InitSPWizardDlg()
{
	initXMLObject(xsl_SPWizSave);
	initRefData();
	for (var i=0; i < inpItemDtls.length; i++)
		 SetMaxLength(inpItemDtls(i));

	G_bDEBUG_MODE = (ds_SPWiz.XMLDocument.documentElement.getAttribute("mode")=="debug");
	
	document.all.divLoading.style.display='none';
	document.all.divSPWizard.style.display='block';
	//WR1970 - Removed the Set focus to the Date of statement field.
}

//=====================================================================
//	Function Name:	InitSPWizardStub
//	Purpose:		Initilises SP wizard stub XML. 
//					Initilise XSL sets the proper SP items code descriptions
//					and calculates maximum details field length.
//=====================================================================
function InitSPWizardStub()
{
	if (G_bSPWizInitilised) return;
	G_bSPWizInitilised = true;
	initXMLObject(ds_SPWiz);
	initXMLObject(xsl_SPWizInit);
	initXMLObject(xml_refData);
	var oSPWdoc = ds_SPWiz.XMLDocument;

	oSPWdoc.documentElement.appendChild(xml_refData.XMLDocument.documentElement.cloneNode(true));
	oSPWdoc.documentElement.transformNodeToObject(xsl_SPWizInit.XMLDocument, oSPWdoc);
}

//=====================================================================
//	Function Name:	SetMaxLength
//	Purpose:		Sets the maximum length of the Details input box
//					based on the value in the SP wizard stub.
//	Parameters:		inpDtls - (HTML element) Details input box
//=====================================================================
function SetMaxLength(inpDtls)
{
	inpDtls.maxLength = inpDtls.value;
	inpDtls.value='';
	if (inpDtls.maxLength < 10) DisableElement(inpDtls);
}

//=====================================================================
//	Function Name:	CalculateNetRent
//	Purpose:		Calculates and sets value of the Net income for 
//					rent income type  
//	Parameters:		oinpGrossRent - (HTML element) Gross Rent input box
//					where change has been made
//=====================================================================
function CalculateNetRent(oinpGrossRent)
{
	var nNetRent = GetIntVal(oinpGrossRent.value * 0.75);
	if (document.all.inpRentGross.length>0)
		document.all.inpRentNet(oinpGrossRent.recordNumber-1).value = nNetRent;
	else
		document.all.inpRentNet.value = nNetRent;
}


//=====================================================================
//	Function Name:	CloseSPWizard
//	Purpose:		Prepares SP details to save. 
//					Closes SPWizard window 
//	Parameters:		bSave - (boolean) flag indicating that the entered 
//					SP details will be saved
//=====================================================================
function CloseSPWizard(bSave)
{
	try
	{
		var oReturn = null;
		if (bSave)
		{
			var oSPWiz = ds_SPWiz.XMLDocument.documentElement;
			if (document.all.divSPWizard.style.display == 'block' && (!pass_SPWizardRule1(oSPWiz) || !pass_SPWizardRule2(oSPWiz)))
			{
				document.all.divSPWizard.style.display = 'none';
				if (!pass_SPWizardRule1(oSPWiz))
					document.all.divWarning.style.display = 'block';
				if (!pass_SPWizardRule2(oSPWiz))
					document.all.divWarning2.style.display = 'block';
				if (!pass_SPWizardRule1(oSPWiz) && !pass_SPWizardRule2(oSPWiz))
				{
					document.all.divWarning.style.height = '100';
					document.all.divWarning2.style.height = '343';
				}
				return;
			}
			else	
			{
				var oSPWdoc = ds_SPWiz.XMLDocument;
				oSPWdoc.documentElement.appendChild(xml_refData.XMLDocument.documentElement.cloneNode(true));
				oSPWdoc.documentElement.transformNodeToObject(xsl_SPWizSave.XMLDocument, oSPWdoc);
					

				var oSPW = ds_SPWiz.XMLDocument.documentElement;
				var aItems = Array ("Asset", "Liability", "Income", "Expense");
				var bResult = true;
				var oItems;
				for (var i=0; i<aItems.length; i++)
				{
					oItems = oSPW.selectNodes('//' + aItems[i]);
					for (var itm=0; itm<oItems.length; itm++)
					{
						bResult = bResult && EvaluateAppBRS(oItems(itm));
					}
				}
					
				if (!bResult) 
				{
					VBMsgBox("Error in creation of statement of position", G_iVB_CRITICAL_ERROR, G_sERROR_TITLE);	
					return;
				}

				oReturn = ds_SPWiz.XMLDocument.documentElement.cloneNode(true);
			}
		}
		else
		{
			if (document.all.divWarning.style.display == 'block' || document.all.divWarning2.style.display == 'block')
			{
				document.all.divWarning.style.display = 'none';
				document.all.divWarning.style.height = '443';
				document.all.divWarning2.style.display = 'none';
				document.all.divWarning2.style.height = '443';
				document.all.divSPWizard.style.display = 'block';
				return;
			}
		}
		
		window.returnValue=oReturn; 
		window.close();
	}
	catch (e)
	{
		displayError(e,'closeSPWizard');	
	}
}


//==============================================================================
//	Function Name:	pass_SPWizardRule1
//	Parameters:		oSPW - (XML Node) SPW Node
//	Return:			Boolean - true if no inputs in for the specified Expense Types
//	Description:	Validate: To show Warning Message when there are inputs 
//					for the specified Expense Types
//==============================================================================
function pass_SPWizardRule1(oSPW)
{
	try
	{
		var bRule = true;
		var sType;
		var sAmt;
		//WR1970 - Removed the validation required for Credit Commitments
		var oOthrComm = oSPW.selectSingleNode('//OtherCommitments');
		for (var itm=0; itm<oOthrComm.childNodes.length; itm++)
		{
			sType = oOthrComm.childNodes(itm).selectSingleNode('ExpenseType').text;
			sAmt = oOthrComm.childNodes(itm).selectSingleNode('DeclaredAmount').text;
			if	(sType != '016' && sAmt > 0)
				bRule = false;
		}

		return bRule;
	}
	catch (e)
	{
		displayError(e,'pass_SPWizardRule1');
	}
}


//==============================================================================
//	Function Name:	pass_SPWizardRule2
//	Parameters:		oSPW - (XML Node) SPW Node
//	Return:			Boolean - true if ANZ CC detail is numeric and 16-chalacter
//	Description:	Validate: To show Warning Message when there are inputs 
//					for ANZ CC detail and CC detail is not valid
//==============================================================================
function pass_SPWizardRule2(oSPW)
{
	try
	{
		var bRule = true;
		var sType;
		var sDesc;
		var sLmt;
		var sAmt;
		
		var oCredit = oSPW.selectSingleNode('//CreditCardsOverdrafts');
		for (var itm=0; itm<oCredit.childNodes.length; itm++)
		{
			sType = oCredit.childNodes(itm).selectSingleNode('LiabilityType').text;
			sDesc = oCredit.childNodes(itm).selectSingleNode('LiabilityDescription').text;
			sLmt = oCredit.childNodes(itm).selectSingleNode('Limit').text;
			sAmt = oCredit.childNodes(itm).selectSingleNode('AmountOwing').text;
			if	(sType == '003' && (sLmt > 0 || sAmt > 0) && (!VBIsNumeric(sDesc) || sDesc.length != 16))
				bRule = false;
		}

		return bRule;
	}
	catch (e)
	{
		displayError(e,'pass_SPWizardRule2');
	}
}

//==============================================================
//	Function Name:	checkWiz_ANZCCNumber
//	Parameters:		-
//	Return:			-
//	Description:	Remove all none-number characters from the Liability Description (Account Number) field 
//==============================================================
function checkWiz_ANZCCNumber(el)
{
	try
	{
			el.value = replaceAll(el.value,/\D/g,"");
	}
	catch (e)
	{
		displayError(e,"checkWiz_ANZCCNumber");
	}
}


//==============================================================
//	Function Name:	fnEnblDsblMtlyExp
//	Parameters:		-RecNo - Record number of the clicked LiabToClr checkbox ,trID - if of the tr in which the check box is present
//	Return:			-
//	Description:	set the value of the monthly expenses text box and enable / disable the same depending on the value of LiabToClr check box.
//==============================================================
function fnEnblDsblMtlyExp(RecNo,trID)
{
	if(trID.all.inpLiabToClr(RecNo-1).checked == true)
	{
		trID.all.text1(RecNo-1).value = 0;
		trID.all.text1(RecNo-1).disabled = true;
	}
	else
	{
		trID.all.text1(RecNo-1).disabled = false;
	}
}