//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.0  $
//	$Author:   maheedhv  $
//	$Workfile:   SPIncome.js  $
//	$Modtime:   Aug 01 2005 14:20:44  $	
//============================================================-->
//<SCRIPT>

//====================================================================
//	Function Name:	initIncomeDtlsDlg
//	Parameters:		nil
//					But the record passed from the main screen as window.dialogArguments
//					when popup window opens.
//	Return:			nil
//	Description:	Initialise the Income pop-up window for Add/Edit.
//====================================================================
function initIncomeDtlsDlg()
{
	try
	{
		G_bSaveIsAllowed = true;
		initRefData();
		initXMLObject(ds_spIncome);
		initXMLObject(xml_ClickHelp)
		initXMLObject(xml_AppBRS);

		var oIncome = window.dialogArguments;
		
		document.all.divCaption.innerText = (oIncome.childNodes(0).text)? 'Edit Income Details':'New Income';
	
		ds_spIncome.src=ds_spIncome.src;
		ds_spIncome.XMLDocument.appendChild(oIncome);
		var sCriteria = '@TYPE_CAT="O"';  // Added the new selection criteria.
		
		populateList('A_TS_INCOME_TYPES', document.all.tblIncomeDtls.all('cboIncomeType'), sCriteria, 'TYPE_CODE', 'CODE_DESC');	
		
		check_IncomeType(true); // CFDS-672
		InitilizeAppBRS(ds_spIncome.XMLDocument.documentElement);	
		
		
		// Added for Validation in Pop - Up of Income
		if((oIncome.childNodes(0).text))
		{
			var oIncomes = ds_spIncome.XMLDocument.documentElement;
			var lcl_income_type = oIncomes.selectSingleNode('IncomeType').text;
			if(lcl_income_type == "004")
			{
				var bResultIncome = EvaluateAppBRS(oIncomes);
			}
			
		}
		// Added for Validation in Pop - Up of Income
	}
	catch (e)
	{
		displayError(e,'initIncomeDtlsDlg');		
	}
}

//============================================================================
//	Function Name:	check_IncomeType
//	$Author:   Divya Mohan Kumar for CFDS - 672  $
//	Parameters:		bInit - whether used in initIncomeDtlsDlg or other functions
//	Return:			
//	Description:	Get Income Description depending on Income Type
//============================================================================
function check_IncomeType(bInit)
{
	try
	{	
		var sType = (bInit)? ds_spIncome.recordset.fields('IncomeType').value:document.all.tblIncomeDtls.all('cboIncomeType').value;
		//Start : Card 672
		if(sType=='004')
		{
			document.all.trIncomeGovtBenefit.style.display = "block";
			document.getElementById("trIncomeGovtBenefit").className="tblHilite3";
			document.getElementById("trIncomeNetMthly").className="tblHilite2";
			populateList("A_TS_INCOME_GOVTBENEFIT_TYPE", document.all.cboGovtBenefitType, null , 'GOVT_CODE', 'CODE_DESC', false); 
		}
		else
		{
			//Clear the fields
			document.getElementById("trIncomeNetMthly").className="tblHilite3";
			ds_spIncome.XMLDocument.documentElement.selectSingleNode("IncomeGovtBenefitType").text="";
			document.all.trIncomeGovtBenefit.style.display = "none";
		}
		//End : Card 672
	}
	catch (e)
	{
		displayError(e,'check_IncomeType');
	}
}




function removeOptions(selectbox)
{
	var i;
    for(i = selectbox.options.length - 1 ; i >= 0 ; i--)
    {
		if((selectbox(i).text == "Bonus") || (selectbox(i).text == "Commission"))
			selectbox.remove(i);
    }
}

//====================================================================
//	Function Name:	CheckEmpType
//	Parameters:		nil
//	Return:			Income record back to main screen
//	Description:	When click on [save] in the popup window.
//====================================================================

function CheckEmpType()
{
	try
	{
		//alert("CheckEmpType");
		var oMDocEl = xml_master.XMLDocument.documentElement;
		if(oMDocEl.selectNodes("//StatementsOfPosition/StatementOfPosition").length > 0)
		{
			var oSPCusts = oMDocEl.selectNodes("StatementsOfPosition/StatementOfPosition");
			if(oSPCusts.length > 0){
				//alert("SOP Count==> " + oSPCusts.length);
				var intCount;
				for(intCount=0;intCount<=oSPCusts.length;intCount++)
				{			
					var oC = oSPCusts.nextNode;
					var bRelated=(oC.getAttribute('Related')=='-1');
					//alert(bRelated);
					//IncomeFormat(oC, oSDocEl, bRelated);
				}
			}
			
		}
	}
	catch (e)
	{
		displayError(e,'CheckEmpType');		
	}
}


//====================================================================
//	Function Name:	saveIncomeDtls
//	Parameters:		nil
//	Return:			Income record back to main screen
//	Description:	When click on [save] in the popup window.
//====================================================================
function saveIncomeDtls()
{
	try
	{
		var oIncome = ds_spIncome.XMLDocument.documentElement;
	
		//copy type description
		oIncome.setAttribute('TypeDescription',getListText(document.all.cboIncomeType));
		//CFDS-672
		oIncome.setAttribute('IncomeGovtBenefitTypeDescription',getListText(document.all.cboGovtBenefitType));
		//format the amount
		var sAmount = document.all.tblIncomeDtls.all('inpNetMonthlyIncome').value;
		oIncome.setAttribute('fmtAmount', VBFormatCurrency(sAmount,0));
	
		var bResult = EvaluateAppBRS(oIncome);

		if (G_bSaveIsAllowed) 
		{
			if (bResult)	
			{
				window.returnValue = ds_spIncome.XMLDocument.documentElement.cloneNode(true);
				window.close();
			}
			else
				VBMsgBox('Please enter valid income details.',G_iVB_WARNING,G_sAPPLICATION_TITLE);
		}
		else
		{
			promptSaveProhibited('Income');
			window.close();
		}
		
	}
	catch (e)
	{
		displayError(e,'saveIncomeDtls');	
	}
}

