//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		Nagendiran.s
//	Workfile:	PortfolioDtls.js
//	ModTtime:	10/12/2008
//==============================================================
//	Name:		InitializePfPopup
//	Purpose:	Disables/Enables, hides/shows and resets/defaults
//				customer employment controls.
//	Parameters:	
//				
//==============================================================
function InitializePfPopup()
{
	try
	{
		var oPfDtlsPassed;
		var iSubProdCountPassed;
		
			
		oPfDtlsPassed = window.dialogArguments;
					
		initRefData();
		initXMLObject(xml_ClickHelp);
		initXMLObject(ds_PfDtlsPopup);
		initXMLObject(xml_AppBRS);
		
		iSubProdCountPassed=oPfDtlsPassed.getAttribute("SubProdCount")
		
		var temp;
		if (oPfDtlsPassed.selectSingleNode("Portfolio"))
				temp=oPfDtlsPassed.selectSingleNode("Portfolio");
		
		ds_PfDtlsPopup.src=ds_PfDtlsPopup.src;
		
		populateList("A_TS_PURPOSE_CATEGORIES", document.all.lbPurpCat,"@ALLOW_PF_DET='1'", 'CATEGORY_CODE', 'CODE_DESC', true, true);
		
		
		PopulateNominee(oPfDtlsPassed);
		if (temp.selectSingleNode("PfPurposeCategory"))
		{
			ds_PfDtlsPopup.XMLDocument.replaceChild(temp,ds_PfDtlsPopup.XMLDocument.documentElement);
			var sNominee =  ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfNominatedBorrower").text;
			var iPurpCat =  ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfPurposeCategory").text;
			var iPurpPurp =  ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfPurpose").text;			
			ds_PfDtlsPopup.XMLDocument.documentElement.setAttribute("SubProdCount",iSubProdCountPassed)
			if (ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfNoEndDate").text == "1" ) 
			{
				ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfLimitEndDate").text = "";
				DisableElement(document.all.inpODLimitEndDate, false); 
			}
			else
				DisableElement(document.all.inpODLimitEndDate, true); 
			
			populateList("A_TS_PURP_CODE_DESC" , document.all("lbPurpCode"), "@PURPOSE_CATEGORY='" + iPurpCat  + "' and @ALLOW_PF_DET='1'",'PURPOSE_CODE', 'CODE_DESC');
			ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfPurpose").text =iPurpPurp;
			cboNominee.value =ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfNominatedBorrower").text;
			}
		else
		{
			//ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfNoEndDate").text ="-1";
			ds_PfDtlsPopup.recordset.fields("PfNoEndDate").value = -1;
			//document.all.chkNoEndDate.value=-1;
			document.all.inpODLimitEndDate.text = "";
			DisableElement(document.all.inpODLimitEndDate, false); 
		}	
		document.all.spnHead.innerText ="Portfolio Details";
		InitilizeAppBRS(ds_PfDtlsPopup.XMLDocument.documentElement);
		
		
		var sCurrPackageTier =  ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfPackageTier").text;
		
		if (sCurrPackageTier=="")
		{
			ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfPackageTier").text="005";
			document.all.lbPackTier.value="005";
		}
		
		document.all.lbPurpCat.focus();
		
		
	}
	catch(e)
	{
		displayError(e,"InitializePfPopup");
	}	
}

//===============================================================================
//	Name:		PopulateNominee
//	Purpose:	populating the customers, 
//	Parameters:	none
//===============================================================================
function PopulateNominee(oApp)
{
	try
	{
		var df=cboNominee.dataFld;
		var ds=cboNominee.dataSrc;
		
		cboNominee.dataFld="";
		cboNominee.dataSrc="";
	
		// clear list
		for (i = cboNominee.options.length-1; i>=0; i--)
			cboNominee.options.remove(i);
		
		var oCusts=oApp.selectNodes("//Customers/Customer[CustomerType!='GTR']");
		
		var opt = document.createElement("OPTION");
	
		cboNominee.options.add (opt);
		opt.value = "Nominate All";
		opt.innerText = "Nominate All";
		opt.selected=true
		var sName = "";
		var sID;
		for (var i=0; i < oCusts.length; i++)
		{
			sID = oCusts(i).selectSingleNode("CustomerID").text;
			sName = oCusts(i).selectSingleNode("CustomerName").text;
			if(sName.length != 0)
			{
				var opt = document.createElement("OPTION");
				cboNominee.options.add (opt);
				opt.value = sID;
				opt.innerText = sName;
			}
		}
	}
	catch(e)
	{
		displayError(e, 'PopulateNominee');
	}
}

//==============================================================
//	Name:		SaveDetails
//	Purpose:	Handles the click event of the save button
//				
//	Parameters:	
//				
//	Returns:	
//==============================================================
function SaveDetails()
{
	try
	{
		ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfNominatedBorrower").text = cboNominee.value;
		if (document.all("chkEndDate").checked !="0") 
			ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfNoEndDate").text = 1;
		else
			ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfNoEndDate").text = 0;
			
		ds_PfDtlsPopup.XMLDocument.documentElement.setAttribute("PfSummaryDescription",ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfDescriptor").text);
		categorytext= getListText(document.all.lbPurpCat) + ': ' +  getListText(document.all.lbPurpCode) ;
		ds_PfDtlsPopup.XMLDocument.documentElement.setAttribute("PfSummaryDetails",categorytext);
		
		var PfAmtFormatted;
		
		if (ds_PfDtlsPopup.XMLDocument.documentElement.getAttribute("PortfolioAmount"))
			PfAmtFormatted=ds_PfDtlsPopup.XMLDocument.documentElement.getAttribute("PortfolioAmount");
		else
			PfAmtFormatted="0";
		
		PfAmtFormatted=VBFormatCurrency(PfAmtFormatted,0);
		
		ds_PfDtlsPopup.XMLDocument.documentElement.setAttribute("PortfolioAmountFormatted",PfAmtFormatted);
	
		var btest=EvaluateAppBRS(ds_PfDtlsPopup.XMLDocument.documentElement);
		if(btest)
		{	
			window.returnValue = ds_PfDtlsPopup.XMLDocument.documentElement.cloneNode(true);
			window.close();
		}
		else
			VBMsgBox('Please enter valid portfolio details.',G_iVB_WARNING,G_sAPPLICATION_TITLE);
	}
	catch (e)
	{
		displayError(e, "SaveDetails")
	}
}

//==============================================================
//	Name:		RefreshPortPurpList
//	Purpose:	Handles the purpose combo box
//				
//	Parameters:	
//				
//	Returns:	
//==============================================================
function RefreshPortPurpList(oPurpNode)
{
	try
	{
	    ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfPurpose").text = "";
	    
	    var iPurpCat =  (oPurpNode)? getXMLField (oPurpNode, "Category", null, true) : document.all.lbPurpCat.value;      	     	
		populateList("A_TS_PURP_CODE_DESC" , document.all("lbPurpCode"), "@PURPOSE_CATEGORY='" + iPurpCat  + "' and @ALLOW_PF_DET='1'",'PURPOSE_CODE', 'CODE_DESC');
		document.all("lbPurpCode").selectedIndex = -1;
	}
	catch(e)
	{
		displayError(e,"RefreshPurpList");
	}
}

function disableLimitEndDate()
{
	try
	{
		if (document.all("chkEndDate").checked !="0")
		{
			ds_PfDtlsPopup.XMLDocument.documentElement.selectSingleNode("PfLimitEndDate").text = "";
			DisableElement(document.all.inpODLimitEndDate, false); 
		}
		else
			DisableElement(document.all.inpODLimitEndDate, true); 
	}
	catch(e)
	{
		displayError(e,"disableLimitEndDate");
	}
}

//Handles the values for package and PackageTier
function  HandlePackageAndTierOnPackageChg()
{
	try
	{
	    var iTier,sPackage;
	    
	    document.getElementById("lbDisPack").disabled=false;
	    document.getElementById("lbPackTier").disabled=false;
	    
	    iTier=document.getElementById("lbPackTier").value;
	    sPackage = document.getElementById("lbDisPack").value;
	    
	    if(sPackage == "Breakfree")
	    {
			document.getElementById("lbPackTier").value="012";
	    }
	}
	catch(e)
	{
		displayError(e,"HandlePackageAndTierOnPackageChg");
	}
}

//Handles the values for package and PackageTier
function  HandlePackageAndTierOnTierChg()
{
	try
	{
	    var iTier,sPackage;
	    
	    document.getElementById("lbDisPack").disabled=false;
	    document.getElementById("lbPackTier").disabled=false;
	    
	    iTier=document.getElementById("lbPackTier").value;
	    sPackage = document.getElementById("lbDisPack").value;
	    
	    if(iTier == "005")
	    {
			document.getElementById("lbDisPack").value="";
			document.getElementById("lbDisPack").disabled=true;
	    }
	}
	catch(e)
	{
		displayError(e,"HandlePackageAndTierOnTierChg");
	}
}