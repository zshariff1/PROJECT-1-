//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		E.Elutin
//	Workfile:	application.js
//	ModTtime:	04/05/2012
//============================================================-->
//<SCRIPT>
//==============================================================
//	Name:		initApp
//	Purpose:	initilising framework,
//				XML DSO objects, screens and reference data
//History:
//Date			Modified By		Comments
//02-05-2011	Suresh			WR4301-01 - RL 1.5 - eMOS
//14-04-2012    NS              Rel 12.3 NCCP2, CR129 and MCP Changes
//28/04/2018    Wipro      Rel 18.1 Tax Residence CRS Requirements
//30/05/2018    Wipro      Rel 18.3 Mortgage Interview Guide link to be disabled
//==============================================================
function initApp()
{
	try
	{	
		document.all.dsBody.style.display="block";
		resizeScreenHld();
	
		//initialise File Access DOM
		G_oXML.async=false;
	
		//initilize DSO objects	
		var oDSGroup = document.all.DSGroup.childNodes;
		for (var i =0; i < oDSGroup.length; i++)
			initXMLObject(oDSGroup(i))

		G_bDEBUG_MODE = (xml_master.XMLDocument.documentElement.getAttribute("mode")=="debug");
		G_sCurrentVersion = xml_VersionCtrl.XMLDocument.documentElement.getAttribute('currentVersion');
		
		//Configure the the editor
		configureEditor();
		SetWindowTitle();
		
		var spanScreens = document.all.divScreenHld.childNodes;
		for (var i=0; i < spanScreens.length; i++)
		{
			if (spanScreens(i).id)
			{
				G_oScreens[spanScreens(i).screen] = new Object; 
				G_oScreens[spanScreens(i).screen].Tag=spanScreens(i).id;
				G_oScreens[spanScreens(i).screen].Source=document.all(spanScreens(i).id + "_src");
				G_oScreens[spanScreens(i).screen].Loaded=false;
				G_oScreens[spanScreens(i).screen].ListsPopulated=false;
			}
		}

		initRefData();
		openAppFromCommandLine(ANZOnlineApplications.commandLine);
		
		
	}
	catch(e)
	{
		displayError(e,"initApp");
	}
}

//==============================================================
//	Name:		configureEditor
//	Purpose:	Configures the editor according to the
//				eMOSConfig.xml file
//==============================================================
function configureEditor()
{
	try
	{	
		var xmlConfig = xml_Config.XMLDocument.documentElement;
		var xmlClick = xml_ClickHelp.XMLDocument.documentElement;
		
		//Set the editor title
		G_sAppWindowTitle = xmlConfig.selectSingleNode("windowTitle").text;
		
		//Get the configuration type of the editor
		//ie 'O' for Originator or 'F' for Mortgage Solutions configuration
		G_sConfigType = xmlConfig.selectSingleNode("configType").text;
	
	//WR1970 - LHN - Added to display the link to the Originator site log in page depending on whether Franchise or Originator - Start
		if(G_sConfigType == "O") // For eMOS Originator
		{
			document.all.aOrgSiteLogIn.style.display = "block";
		}
		else if(G_sConfigType == "F") // For eMOS Franchise
		{
			document.all.aMortSlnsLogIn.style.display = "block";
		}
	//WR1970 - LHN - Added to display the link to the Originator site log in page depending on whether Franchise or Originator - End
		
		//Update the Clickhelp
		var clickWC = "$$APPNAME$$";
		var sReplaceText = xmlConfig.selectSingleNode("appName").text;
		//replace the wildcard in the click help nodes
		var nodeList = xmlClick.selectNodes("HlpMsg[@config='1']");
		for (var i=0;i<nodeList.length;i++)
		{
			nodeList.item(i).text = VBReplace(nodeList.item(i).text,clickWC,sReplaceText);
		}
		
	//WR1970 - Setting footer Copy right text year value.
		var sYr=VBGetYear();
		document.getElementById("spnCopyRightYr").innerHTML=sYr;
		
	
	}
	catch(e)
	{
		displayError(e,"configureEditor");
	}
}

//==============================================================
//	Name:		NewApplication
//	Purpose:	Creates new loan application
//==============================================================
function NewApplication()
{
	try
	{
		saveCurrentScreen();
		//WR1970 - Added to incorporate cancel button click in cust screen warning
		if(G_bStayInCustScreen)
		{
			G_bStayInCustScreen=false;
			//return;	/*Commented "return" statement to fix issue - Defect# 9483[Open file over existing]*/
		}
		//WR1970 - Added to incorporate cancel button click in security screen warning
		if(G_bStayInSecScreen)
		{
			G_bStayInSecScreen=false;
			return;
		}
		//WR1970 - Initializing the values for the global variables		
		G_LoDocValue=0;
		G_ReasonForInterestOnly = "";
		G_OtherReasonForInterestOnly = "";
		G_Sub_Prd_Typ=1;
		
		// Added for Clearing Values for Tax Resident - Starts
		G_ACHBrkFreeCard = "";
		G_Product_Type = "";
		G_breakfree_Type = "";
		// Added for Clearing Values for Tax Resident - Ends
		
		// re-load from file!
		var arFileDetail= new Array(2); //Array for holding file details
	
		arFileDetail = getSaveFilePath(G_sApplicationFilePath);
			
		if (arFileDetail[0] == "" || arFileDetail[1] == "")
			return;
	
		G_sApplicationFilePath=arFileDetail[0];
		G_sApplicationTitle = arFileDetail[1]; 
		SetWindowTitle();
		if (!G_sApplicationTitle || G_sApplicationTitle == "")
		{
			G_sApplicationTitle = null;
			return;
		}
		G_bSaveIsAllowed = true;
		document.all.xml_master.src = document.all.xml_master.src;
		var oDocEl=xml_master.XMLDocument.documentElement;
		oDocEl.setAttribute ("appTitle", G_sApplicationTitle);
		oDocEl.setAttribute ("appPath", G_sApplicationFilePath);
		oDocEl.setAttribute ("eMOSVersion", G_sCurrentVersion);
		oDocEl.setAttribute ("configType", G_sConfigType);
		//WR1970 - Setting the values for the newly added attributes
		//oDocEl.setAttribute ("DiscountPack",G_sDiscPackValue);
		oDocEl.setAttribute ("LoDocApp",G_LoDocValue);
		oDocEl.setAttribute ("ReasonForIntOnly",G_ReasonForInterestOnly);
		oDocEl.setAttribute ("OtherReasonForIntOnly",G_OtherReasonForInterestOnly);
		oDocEl.selectSingleNode("//Customers").removeChild(oDocEl.selectSingleNode("//Customer"));
		oDocEl.selectSingleNode("//Securities").removeChild(oDocEl.selectSingleNode("//Security"));
		oDocEl.selectSingleNode("//Purposes").removeChild(oDocEl.selectSingleNode("//Purpose"));
		oDocEl.selectSingleNode("//StatementsOfPosition").removeChild(oDocEl.selectSingleNode("//StatementOfPosition"));
		InitilizeAppBRS(oDocEl);
		EvaluateAppBRS(oDocEl);
			
		FlushToDisk();
		G_pScreenSaveFunction=null;
		showApplication();
		
	}
	catch(e)
	{
		displayError(e,"NewApplication");
	}
}

//==============================================================
//	Name:		openApplication
//	Purpose:	Opens existing loan application
//==============================================================
function openApplication()
{
	try
	{
		saveCurrentScreen();
		G_SelectedCustomer = 0;
		G_Sub_Prd_Typ==4;
		//WR1970 - Added to incorporate cancel button click in cust screen warning
		if(G_bStayInCustScreen)
		{
			G_bStayInCustScreen=false;
			//return;	/*Commented "return" statement to fix issue - Defect# 9483[Open file over existing]*/
		}
		//WR1970 - Added to incorporate cancel button click in security screen warning
		if(G_bStayInSecScreen)
		{
			G_bStayInSecScreen=false;
			return;
		}
		
		var arFileDetail= new Array(2);
	
		arFileDetail = getOpenFilePath(G_sApplicationFilePath);

		if (arFileDetail[0] == "" || arFileDetail[1] == "")
			return;

		G_bSaveIsAllowed = true;
		G_sApplicationFilePath=arFileDetail[0];
		G_sApplicationTitle = arFileDetail[1]; 
	
		if (G_sApplicationFilePath && G_sApplicationFilePath != "")
		{
			G_LastOpenFile = G_sApplicationFilePath;
			if (loadApplicationXML (G_sApplicationFilePath))
			{
				SetWindowTitle();
				G_pScreenSaveFunction=null;
				addFileRefDetails();
				showApplication();
			} 
			else
			{
				resetApp();
			}
		}
		}
	catch(e)
	{
		displayError(e,"openApplication");
	}
}

//==============================================================
//	Name:		openAppFromCommandLine
//	Purpose:	Opens existing loan application from the 
//				file passed in the command line
//	Parameters:	psCommandLine - (string) command line parameters
//==============================================================
function openAppFromCommandLine(psCommandLine)
{
	try
	{
		var sCmdLine = new String(psCommandLine);
		var arCmdLineDetail= new Array();
		var arFileName = new Array();
		var sFilePath;

		//split the command line to get the file path
		//check for quotes for file path with spaces
		if (sCmdLine.substr(0,1) == '"')
		{
			sFilePath = VBtrim(sCmdLine.substr(sCmdLine.indexOf('"',1) + 1));
		}
		else
		{
			arCmdLineDetail = sCmdLine.split(" ");
			sFilePath = arCmdLineDetail[1];
		}
		
		if (sFilePath == "") return;
		G_bSaveIsAllowed = true;
					
		//Set the file path
		G_sApplicationFilePath=sFilePath;
	
		if (G_sApplicationFilePath && G_sApplicationFilePath != "")
		{
			G_LastOpenFile = G_sApplicationFilePath;
			if (loadApplicationXML (G_sApplicationFilePath,true))
			{
				G_sApplicationTitle = xml_master.XMLDocument.documentElement.getAttribute("appTitle");
				SetWindowTitle();
				G_pScreenSaveFunction=null;
				addFileRefDetails();
				showApplication();
			} 
			else 
			{
				resetApp();
			}
		}
	}
	catch (e)
	{
		displayError(e, "openAppFromCommandLine")
	}
}

//==============================================================
//	Name:		loadApplicationXML
//	Purpose:	Loads loan application from the file 
//				and sets aplication file attributes
//	Parameters:	sFileName	- (string) file path 
//				bNoSetTitle	- (boolean) should be set to true 
//							  if file has been opened from the 
//							  command line due to command line 
//							  returns file name in the 8.3 format
//	Returns:	boolean - true if application has been loaded 
//	`					  successfully
//==============================================================
function loadApplicationXML (sFileName, bNoSetTitle)
{
	try
	{
		loadDSOFromFile (sFileName,xml_temp);

		ds_cust.src=ds_cust.src;
		//check version 
		var sAppVersion = xml_temp.XMLDocument.documentElement.getAttribute('eMOSVersion');
		var bUpgraded = false;
		if (sAppVersion != G_sCurrentVersion) {
			if (!UpgradeAppFile(sAppVersion, xml_temp)) return false;
			bUpgraded = true;
		}
		
		//load app into master dso
		resetDSO(xml_master);
		var oMDocEl=xml_master.XMLDocument.documentElement;		
		xml_master.XMLDocument.replaceChild(xml_temp.XMLDocument.documentElement.cloneNode(true),oMDocEl);
		resetDSO(xml_temp);
		
		oMDocEl=xml_master.XMLDocument.documentElement;
		
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		
		//19.5.1 Defect Fixed Jira Card 513 - Starts
		var oSPsCnt = xml_master.XMLDocument.documentElement.selectNodes('StatementsOfPosition/StatementOfPosition');
		if(oSPsCnt.length > 0) 
		{
			var oSPs = xml_master.XMLDocument.documentElement.selectSingleNode('StatementsOfPosition');
			var noSPs = oSPs.getElementsByTagName("AssetLinkedPropAddr");
			var noSPs1 = oSPs.getElementsByTagName("AssetDescription");					  	
			var noSPs2 = oSPs.getElementsByTagName("AssetType");
			var iRCount;
			if (noSPs.length>0){
				iRCount=0;
				for (var i = 0; i < noSPs2.length; i++) {
					if (noSPs2[i].text =="003"){
						for(var j=i+1;j < noSPs2.length ;j++){
							if((noSPs[j].text != "") && (noSPs[i].text != ""))
							{
								if (noSPs2[j].text =="003" && noSPs[j].text ==noSPs[i].text){
									noSPs[j].text="0";
									noSPs1[j].text="";
									iRCount = iRCount + 1;
								}
							}
							else
							{
								if (noSPs2[j].text =="003") {
									noSPs1[j].text = "";
								}
							}
						}
					}
				}	
			}
		}
		
		//19.5.1 Defect Fixed Jira Card 513 - Ends
		
		
		if (!bNoSetTitle) oMDocEl.setAttribute ("appTitle", G_sApplicationTitle);
		oMDocEl.setAttribute ("appPath", G_sApplicationFilePath);
		oMDocEl.setAttribute ("configType", G_sConfigType);
	
	//WR1970 - Adding a new attribute "maxStatementOfPositionID" to the application if missing - Start
		if(oMDocEl.getAttribute("maxStatementOfPositionID") == null) {
			if(oMDocEl.selectNodes("//StatementsOfPosition/StatementOfPosition").length > 0) {
				var smaxSPID = oMDocEl.selectSingleNode("//StatementsOfPosition/StatementOfPosition[last()]/StatementOfPositionID").text;
			}
			else {
				var smaxSPID = 0;
			}
			oMDocEl.setAttribute ("maxStatementOfPositionID", smaxSPID);
		}
	//WR1970 - Adding a new attribute "maxStatementOfPositionID" to the application if missing - End
	
		//WR1970 - Setting the value of the first Product's Loan Package and Lo Doc
		var oPurpsNode = oMDocEl.selectNodes("Purposes/Purpose");
		
		if(oPurpsNode.length>0) {
			var oProdNode = oMDocEl.selectNodes("Purposes/Purpose/Products/Product");
			if(oProdNode.length>0) {
				G_LoDocValue = oProdNode.item(0).selectSingleNode("LoDocApplication").text;
				if (oProdNode.item(0).selectSingleNode("SubProductCode").text == "RC") {
					G_Sub_Prd_Typ=5;
					G_Product_Type=oProdNode.item(0).selectSingleNode("SubProductCode").text;
				}
				else
				{
					G_Product_Type = "";
				}
			}
			else {				
				G_LoDocValue=oMDocEl.getAttributeNode("LoDocApp").value;
			}
			var oProdLoanNode = oMDocEl.selectNodes("Purposes/Purpose/Products/Product/LoanDetails");

			if (oProdLoanNode.length > 0)
			{
				for(var inode=0; inode<oProdLoanNode.length; inode++)
				{
					if ((oProdLoanNode.item(inode).selectSingleNode("ReasonForInterestOnly")==null))
					{
							oProdLoanNode.item(inode).appendChild (oProdLoanNode.item(inode).ownerDocument.createElement ("ReasonForInterestOnly"));
							oProdLoanNode.item(inode).appendChild (oProdLoanNode.item(inode).ownerDocument.createElement ("OtherReasonForInterestOnly"));
					}	
				}
				for(var i=0; i<oProdLoanNode.length; i++)
				{
					if (oProdLoanNode.item(i).childNodes.length >  0)
					{
						if (oProdLoanNode.item(i).selectSingleNode("ReasonForInterestOnly").text != "") {
							G_ReasonForInterestOnly = oProdLoanNode.item(i).selectSingleNode("ReasonForInterestOnly").text;
						}
						if (oProdLoanNode.item(i).selectSingleNode("OtherReasonForInterestOnly").text != "") {
							G_OtherReasonForInterestOnly = oProdLoanNode.item(i).selectSingleNode("OtherReasonForInterestOnly").text;
						}
						if ((G_ReasonForInterestOnly != "") || (G_OtherReasonForInterestOnly != "")) break;
					}
				}

			}
		}
		else {
			G_LoDocValue=0;
			G_ReasonForInterestOnly = "";
			G_OtherReasonForInterestOnly = "";
			G_Product_Type = "";
		}
		
		// Remove of Duplicate Nodes from Packages XML Node
		RemovePackDupNode();
		
		
		//New Code Begin Tax Resident added on 28/02/2018 for tax resident crs changes	
		var oPackNode1 = oMDocEl.getElementsByTagName("Packages")[0];
		if  (oPackNode1.childNodes.length > 0) 
		{	
			var oPakNode = oMDocEl.selectNodes("Packages");
			if (oPakNode.item(0).selectSingleNode("BreakFreeType").text == "New Credit Card")
			{
				G_Sub_Prd_Typ=5;
				G_breakfree_Type=oPakNode.item(0).selectSingleNode("BreakFreeType").text;
				if((oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID") != null)){
					if(oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text != "") {
						var oACH = oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text;
						sXpath="//Customers/Customer[CustomerID='" + oACH + "']/CustomerID";
						if(oMDocEl.selectSingleNode(sXpath) != null) {
							G_ACHBrkFreeCard = oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text;
						}
						else {
							if(oACH != "0")
							{
								G_ACHBrkFreeCard = "";
								oPakNode.item(0).selectSingleNode("AdditionalCardHolderCustID").text ="";
							}
						}
						
					}
				}	
				G_havebreakfree = oPakNode.item(0).selectSingleNode("HaveBreakFreePackage").text
			}
			else
			{
				G_ACHBrkFreeCard = "";
				G_breakfree_Type = "";
			}
		}
		else
		{
			G_ACHBrkFreeCard = "";
			G_breakfree_Type = "";
		}
		
		//New Code Ended 
		//WR1970 - Calling the function for updating purpose and product details in Loan Detail
		UpdatePurposeProduct();
		
		//WR1970 - Calling the function for updating customer type description
		UpdateCustTypeDesc();
		
		
		
		// CFDS - 442 - Calling the function for updating the TaxResidentAustralia in Customer - Starts
		if ((G_Product_Type == "") && (G_breakfree_Type == "")){ 
			UpdateCustTaxResident(false,G_ACHBrkFreeCard);
		}
		else if((G_breakfree_Type != ""))
		{
			UpdateCustTaxResident(true,G_ACHBrkFreeCard);
		}
		// CFDS - 442 - Calling the function for updating the TaxResidentAustralia in Customer - Ends

		
		//need to stop loading if evaluate fails!!!
		if (!ableToEvaluate(oMDocEl))
		{
			// error warning stop loading file.
			VBMsgBox("The file you have attempted to load is not compliant with ANZ Online Applications", G_iVB_CRITICAL_ERROR, G_sAPPLICATION_TITLE);
			return false;
		}
		if (bUpgraded) FlushToDisk();
		
		//WR1970 - New function to set the maximum customer ID and Security ID
		G_bStayInCustScreen=false;
		G_bStayInSecScreen=false;
		SetMaxCustID();
		SetMaxPurpID();
		SetMaxSecID();
		
		return true;
	}
	catch (e)
	{
		VBMsgBox("The file you have attempted to load is not compliant with ANZ Online Applications", G_iVB_CRITICAL_ERROR, G_sAPPLICATION_TITLE);
		//displayError(e, "loadApplicationXML")
	}
}

//==============================================================
//	Name:		showApplication
//	Purpose:	Shows Home screen and hides welcome splash screen
//==============================================================
function showApplication()
{
	try
	{
		if (document.all.tblScreenHld.style.display=="none")
		{
			document.all.tblWelcomeSplash.style.display="none";
			document.all.tblScreenHld.style.display="block";
		}
		G_bStayInCustScreen=false;
		G_bStayInSecScreen=false;

		// RL 1.5 - eMOS - 02-05-2011	Suresh
		//RL 18.3 for disable Mortgage interview guide link from left panel and show branch as default page
		ShowScreen ("ScrMortgageInterviewGuide", document.all.mnuItem(0),MortgageInterviewGuideScreenShow);
		ShowScreen ("ScrApplication", document.all.mnuItem(0),HomeScreenShow);
		
	}
	catch (e)
	{
		displayError(e, "showApplication")
	}
}

//==============================================================
//	Name:		QuitApp
//	Purpose:	Saves loan application into file when exit from programm.
//	Parameters: bUnload - (boolean) should be true when window control 
//							button used	to close application.
//==============================================================
function QuitApp(bUnload)
{
	try
	{
		saveCurrentScreen();
		ShowContactWarn();
		//WR1970 - Added to incorporate cancel button click in cust screen warning
		if(G_bStayInCustScreen)
		{
			G_bStayInCustScreen=false;
			return;
		}
		
		//WR1970 - Added to incorporate cancel button click in security screen warning
		if(G_bStayInSecScreen)
		{
			G_bStayInSecScreen=false;
			return;
		}
		
		if (bUnload) return;
		if (VBMsgBox("Are you sure you want to quit?", 52,"ANZ Online Applications")==6) window.close(); 
	}
	catch(e)
	{
		displayError(e,"QuitApp");
	}
}

//==============================================================
//	Name:		resetApp
//	Purpose:	Resets master DSO, hides current screen and 
//				displays welcome splach screen.
//				Used when atempt to load non eMOS file. 
//==============================================================
function resetApp()
{
	try
	{
		resetDSO(document.all.xml_master);
		if (G_sCurScr && document.all(G_sCurScr)) document.all(G_sCurScr).style.display = 'none';			
		document.all.tblScreenHld.style.display="none";
		document.all.tblWelcomeSplash.style.display="";
		G_sApplicationTitle="";
		SetWindowTitle();
	}
	catch (e)
	{
		displayError(e, "resetApp");
	}
}

//==============================================================
//	Name:		ShowScreen
//	Purpose:	Shows selected screen, manages menu item's appearence
//				Loads screens on demand
//	Parameters:	sScr		- (string) ID of the screen to show
//				mnuItem		- (HTML element) selected menu item
//				ScreenInitFn - (pointer) pointer to the specific 
//								show screen function
//==============================================================
function ShowScreen (sScr, mnuItem, ScreenInitFn)
{
	try
	{
		if (G_bShowingScreen) return;
	
		saveCurrentScreen(true);

		//WR1970 - Added to incorporate cancel button click in cust screen warning
		if(G_bStayInCustScreen)
		{
			G_bStayInCustScreen=false;
			return;
		}
		//WR1970 - Added to incorporate cancel button click in security screen warning
		if(G_bStayInSecScreen)
		{
			G_bStayInSecScreen=false;
			return;
		}
		
		G_bShowingScreen = true
		
		
	
		//load screen if it's not loaded
		if (!G_oScreens[sScr].Loaded) 
		{
			document.all(G_oScreens[sScr].Tag).innerHTML = G_oScreens[sScr].Source.XMLDocument.xml;
			G_oScreens[sScr].Loaded=true;
		}
		
		if (G_sCurScr) document.all(G_sCurScr).style.display = 'none';
		G_sCurScr = sScr;
		if (G_sCurScr) 
		{ 
			ScrollScreenUp();
			if (document.all(sScr)) document.all(sScr).style.display = 'block';
			//set selected menu color
			var mnuCount=document.all.mnuItem.length;
			for (var i=0; i<mnuCount; i++)	
				document.all.mnuItem(i).style.color="#FFFFFF";
			mnuItem.style.color="yellow";
			if (ScreenInitFn) ScreenInitFn();
		}
	
		G_bShowingScreen = false;
	}
	catch(e)
	{
		displayError(e,"ShowScreen");
	}
}

//==============================================================
//	Name:		saveCurrentScreen
//	Purpose:	Executes current save function using the global pointer
//	Parameters:	bNoReselect	- (boolean) flag to pass to the current save 
//							 function. If the save function reserves 
//							this parameter then no item reselection 
//							will happen.
//==============================================================
function saveCurrentScreen(bNoReselect)
{
	try
	{
		if (G_pScreenSaveFunction)
		{
			G_pScreenSaveFunction(bNoReselect);
			ScrollScreenUp();
		}
	}
	catch(e)
	{
		displayError(e,"saveCurrentScreen");
	}
}

//==============================================================
//	Name:		ScrollScreenUp
//	Purpose:	Scrolls up screen holder DIV element.
//==============================================================
function ScrollScreenUp()
{
	try
	{
		var divScreenHolder = document.all.divScreenHld;
		for (var i=0; i<5; i++)
			divScreenHolder.doScroll("up");
	}
	catch (e)
	{
		displayError(e, "ScrollScreenUp")
	}
	
}

//==============================================================
//	Name:		SetAppStatus
//	Purpose:	Sets the text of the application ready status 
//				based on the last validation result
//==============================================================
function SetAppStatus()
{
	try
	{
		var bAppValid = (xml_master.XMLDocument.documentElement.getAttribute("valid_entity_Application")=="1")
		document.all.spnAppStatus.innerHTML= (bAppValid)? "Ready to Submit":"Not Ready to Submit";
	}
	catch(e)
	{
		displayError(e,"SetAppStatus");
	}
}

//==============================================================
//	Name:		ShowHideLegend
//	Purpose:	Shows/Hides validation graphical symbols legend
//==============================================================
function ShowHideLegend()
{
	try
	{	
		G_bLegend = !G_bLegend;
		document.all.aShowLegend.innerHTML=(G_bLegend)? "Hide Legend":"Show Legend";
		document.all.aShowLegend.title=(G_bLegend)? "Hide Legend":"Show Legend";  
		document.all.tblLegend.style.visibility=(G_bLegend)? "":"hidden";
	}
	catch(e)
	{
		displayError(e,"ShowHideLegend");
	}
}

//==============================================================
//	Name:		AddUpdateAddress
//	Purpose:	Shows common add/update address dialog window to
//				add new or edit existing address record.
//	Parameters:	AdrId - (numeric) ID of the selected address (for edit)
//				bSecurityAdr - (boolean) should be set to true for adding 
//								or editing security address
//	Returns:	XML Node - updated or new address item
//==============================================================
function AddUpdateAddress(AdrId, bSecurityAdr)
{
	try
	{
		var oEdtAdr;
		var oAddrs = xml_master.XMLDocument.documentElement.selectSingleNode("//Addresses");
	
		//WR1970 - Changed the height of the address window if it is opened from securities screen
		
		var sBoxHeight = (bSecurityAdr)?  "dialogHeight:320px;":"dialogHeight:332px;"
		if (!AdrId) 
		{ 
			oEdtAdr = ds_address.XMLDocument.documentElement.cloneNode(true);
			//WR1970 - Added New default value
			oEdtAdr.selectSingleNode("AddressType").text="Standard Street Address";
		}
		else
		{
			var oReplAdr = oAddrs.selectSingleNode("Address[AddressID="+AdrId+"]");
			if(oReplAdr != null)
				oEdtAdr = oReplAdr.cloneNode(true);
		}
		oEdtAdr.setAttribute("SecurityAddress") = (bSecurityAdr)? "-1":"0";
	
		oEdtAdr=window.showModalDialog("AddressDtls.htm", oEdtAdr,sBoxHeight + "dialogWidth:650px;help:No;resizable:No;status:No;scroll:No;");
		if (oEdtAdr==null) return null;
	
		if (AdrId)
		{
			oAddrs.replaceChild(oEdtAdr,oReplAdr);
			if (bSecurityAdr) 
			{
				//copy address details to the security
				var oSecs=xml_master.XMLDocument.documentElement.selectNodes('Securities/Security[AddressID=' + AdrId +']');
				for (var i=0; i<oSecs.length; i++){
					oSecs(i).setAttribute('AddressDtls',oEdtAdr.getAttribute('AddressDetails'));}
					var SecUpdAdr = oEdtAdr.getAttribute('AddressDetails');
					if(SecUpdAdr != "")
						UpdateAssetAddr(SecUpdAdr,AdrId);
						UpdateLiabilityAddr(SecUpdAdr,AdrId);
			}
		}
		else
		{
			//WR1970 - New Fuction call added.
			SetMaxAddrID()
			
			oEdtAdr.firstChild.text = allocateNewID("maxAddressID");
			oAddrs.appendChild(oEdtAdr);
		}
		FlushToDisk();
	
		return oEdtAdr;
	}
	catch (e)
	{
		displayError(e, "AddUpdateAddress")
	}
}

//==============================================================
//	Name:		openPrintDialog
//	Purpose:	Shows print preview dilog box for the document printing
//	Parameters:	sTitle - (string) window title (does not works in 
//						  the current IE version)
//				sXSLTrasformFile - (string) path to the printing 
//						  document XSL file
//==============================================================
function openPrintDialog(sTitle, sXSLTrasformFile)
{
	try
	{
		var oDoc=xml_master.XMLDocument.documentElement.cloneNode(true);
		var sDialogWidth;
		var sRenderingType;
		
		sRenderingType=sTitle;
		
		//WR1970 - For setting the width of the dialog window depending upon the report selected
		if(sXSLTrasformFile == "../xsl/SupportDocKit.xsl")
			sDialogWidth="850px";
		else if (sRenderingType == "PDFDocument")
			sDialogWidth="900px";
		else
			sDialogWidth="650px";
		
		oDoc.setAttribute("PrintTitle",sTitle);
		oDoc.setAttribute("XSLTransformFile",sXSLTrasformFile);
		
		if (sRenderingType == "PDFDocument")
		{
			//Commented for the fix of Fortify Scan - PdfPreview in not in use as we removed MortgageInterviewGuide screen
			//window.showModalDialog("PdfPreview.htm",sXSLTrasformFile, "dialogHeight:900px;dialogWidth:1500px;help:No;resizable:Yes;status:No;scroll:No;");
		}
		else 
			window.showModalDialog("PrintPreview.htm", oDoc, "dialogHeight:470px;dialogWidth:" + sDialogWidth + ";help:No;resizable:No;status:No;scroll:No;");
		
	}
	catch(e)
	{
		displayError(e,"openPrintDialog");
	}
}



//==============================================================
//	Name:		addFileRefDetails
//	Purpose:	Gather the customers and loan amounts of the 
//				application. 
//==============================================================
function addFileRefDetails()
{
	try
	{
		var oDocEl=xml_master.XMLDocument.documentElement;
		oDocEl.setAttribute ("appCustomers", collateCustomers());
		oDocEl.setAttribute ("appAmounts", VBFormatCurrency(collateAmounts(), 0));
	}
	catch(e)
	{
		displayError(e,"addFileRefDetails");
	}
}

//==============================================================
//	Name:		collateCustomers
//	Purpose:	collates customer's names 
//				for the application file reference info
//	Returns:	string - all customer's name separated by comma
//==============================================================
function collateCustomers()
{
	///search the xml_master file for customer names
	try
	{
		var sCombNames="";
		var oDocEl=xml_master.XMLDocument.documentElement;
		var oNodeList = oDocEl.selectNodes("Customers/Customer/CustomerName");
		if  (oNodeList.length > 0) 
		{
			for (i=0; i<oNodeList.length; i++)
			{
				if (sCombNames.length > 0) sCombNames = sCombNames + ", " ;
				sCombNames = sCombNames + oNodeList.item(i).text;
			}
		}
		return sCombNames;
	}
	catch(e)
	{
		displayError(e,"collateCustomers");
	}
}

//==============================================================
//	Name:		collateAmounts
//	Purpose:	collates purpose's total amounts  
//				for the application file reference info
//	Returns:	numeric - sum of the all purpose's total amounts
//==============================================================
function collateAmounts()
{
	try
	{
		var dAppAmounts = 0;
		var oDocEl=xml_master.XMLDocument.documentElement;
		if (oDocEl.getAttribute("PortfolioApp")==0)
		{
			var oNodeList = oDocEl.selectNodes("Purposes/Purpose");
			if  (oNodeList.length > 0)
			{
				for (i=0; i<oNodeList.length; i++)
					dAppAmounts = dAppAmounts + Number(oNodeList.item(i).getAttributeNode("TotalAmount").value);
			}
		}
		else
		{
			var oNodeList = oDocEl.selectSingleNode("Portfolio");
			dAppAmounts=oNodeList.getAttributeNode("PortfolioAmount").value;

		}

		return dAppAmounts;
	}
	catch (e)
	{
		displayError(e,"collateAmounts");
	}
}

//==============================================================
//	Name:		showEmosHelp
//	Purpose:	Load eMOS CHM with context 
//	Parameters:	none
//==============================================================
function showEmosHelp()
{

	var sHelpScreen;

	// resolve context for help identifier
	switch (G_sCurScr.toLowerCase())
	{
		case 'scrapplication':
			sHelpScreen = "branch/branch.html";	
			break;
		case 'scrcustdetails':
			sHelpScreen = "customers/customers.html";	
			break;
		case 'scrsecdetails':
			sHelpScreen = "securities/securities.html";	
			break;
		case 'scrsolicitor':
			sHelpScreen = "solicitor/solicitor.html";	
			break;
		case 'scrpurpprod':
			sHelpScreen = "loan_details/loan_details.html";	
			break;
		case 'scrstatement':
			sHelpScreen = "statements_of_positions/statements_of_positions.html";	
			break;
		case 'scrfees':
			sHelpScreen = "Approval_Fee_Discounts/Approval_Fee_Discounts.html";	
			break;
		case 'scrinterview':
			sHelpScreen = "Interview_Checklist/interview_checklist.html";	
			break;
		case 'scrdocuments':
			sHelpScreen = "documents/documents.html";	
			break;
	//WR1970 - Added to show the Summary / Comment help page - Start
		case 'scrsummary':
			sHelpScreen = "Summary_Comments/summary_comments.html";	
			break;

//WR1970 - Added to show the Summary / Comment help page - End         case 'ScrPackages':
            sHelpScreen = "Packages/Packages.html";
            break;	
		default:
			sHelpScreen = "";		
	}
	
	// open the help window
	if (sHelpScreen.length>0)
		window.showHelp("../includes/emos.chm::/"+sHelpScreen);
	else
		window.showHelp("../includes/emos.chm");
}

//==============================================================
//	Name:		showInfo
//	Purpose:	Shows Information about application eg. Version etc.
//	Parameters:	none
//==============================================================
function showInfo()
{
	try
	{
		popup('Version: ' + G_sCurrentVersion);
	}
	catch (e)
	{
		displayError(e,"collateAmounts");
	}	
}


function UpgradeAppFile(sOldAppVersion, oDSO)
{
	try
	{

                            //store the orignal xml
                            var sOriginalxml = new ActiveXObject("MSXML2.DOMDocument");
                            sOriginalxml.loadXML(xml_temp.XMLDocument.xml);
                            
		//check if file is versioned
		var sPrmpt = '';
		if (!sOldAppVersion)
		{
			sPrmpt = 'The file you have chosen was not created by ' + G_sAPPLICATION_TITLE + 
					'.  Please check that you have chosen the correct file.' +
					'\n\r\n\rThe file cannot be opened.';
			VBMsgBox(sPrmpt,G_iVB_CRITICAL_ERROR, G_sAPPLICATION_TITLE);
			return false;
		}
		//check whether upgrade is available
		var oVC = xml_VersionCtrl.XMLDocument.documentElement;
                            
		var oUpgradeXSL = oVC.selectSingleNode('//Upgrade[@from="'+sOldAppVersion+'"]');
		if (!oUpgradeXSL)
		{
			sPrmpt= 'This version of ' + G_sAPPLICATION_TITLE + ' - version ' + G_sCurrentVersion + 
					 ', cannot upgrade the file you have chosen.\n\r\n\r' +
					 'The file was created with ' + G_sAPPLICATION_TITLE + ' - version ' + sOldAppVersion + 
					 ', for which there is no upgrade.  Please check that you have chosen the correct file.' +
					 '\n\r\n\rThe file cannot be opened.';		 
			
			VBMsgBox(sPrmpt,G_iVB_CRITICAL_ERROR, G_sAPPLICATION_TITLE);
			return false;
		}

		var bUpgWithBackup = window.showModalDialog('upgradeprompt.htm',Array(G_sCurrentVersion,sOldAppVersion),'dialogHeight:130px;dialogWidth:700px;help:No;resizable:No;status:No;scroll:No;');
		if (bUpgWithBackup == null) return false;
			
		//save backup 
		if (bUpgWithBackup)
		{
			if (!SaveBackup(xml_temp.XMLDocument.xml)) return false;
		}
		
		var sNextVersion='';
		var sUpMsgIds = '';
		var sUpMsgId = '';
		
		while (oUpgradeXSL)
		{  
			sNextVersion = oUpgradeXSL.getAttribute('to');
			sUpMsgId = oUpgradeXSL.getAttribute('upgradeMsgId');
			if ((sUpMsgId) && (sUpMsgIds.indexOf('|' + sUpMsgId + '|')<0))  
			{
				sUpMsgIds = sUpMsgIds + '|' + sUpMsgId + '|'
			}
			var oUpgrXSL=oUpgradeXSL.childNodes(0);
			
			if (oUpgrXSL)
				xml_temp.XMLDocument.documentElement.transformNodeToObject(oUpgrXSL, xml_temp.XMLDocument);
			              oUpgradeXSL = oVC.selectSingleNode('//Upgrade[@from="'+sNextVersion+'"]');
		}
		xml_temp.XMLDocument.documentElement.setAttribute('eMOSVersion',sNextVersion);

		//format successfull upgrade message if any.
		if (sUpMsgIds)
		{	
			var sUpgrPrompt = 'The file has been successfully upgraded to the current version of ' +
								G_sAPPLICATION_TITLE + ' - version ' + G_sCurrentVersion;
			
			sUpMsgIds = sUpMsgIds.substring(1,sUpMsgIds.length-1);

			var aMsgIds = sUpMsgIds.split('||');
			var oUpgrMsg;
                                       
			//for (var iM=0; iM < aMsgIds.length; iM++)
			for (var iM=aMsgIds.length-1; iM >=0; iM--)
			{  
                                                        //check whether message style sheet is available
				oUpgradeXSL = oVC.selectSingleNode('//UpgradeMessages/Message[@id=' + aMsgIds[iM] + ']');
                                                       
                                                        if(oUpgradeXSL)
                                                        {
					var oUpgrXSL=oUpgradeXSL.childNodes(0);
					oUpgrMsg =  sOriginalxml.transformNode(oUpgrXSL);
                                         
                                                                      if (oUpgrMsg) sUpgrPrompt = sUpgrPrompt +  '\n\r' + oUpgrMsg;
                                                                     
				}
			}
			VBMsgBox(sUpgrPrompt,G_iVB_INFO, G_sAPPLICATION_TITLE);
		}
				
		return true;
	}
	catch (e)
	{
		displayError(e,"UpgradeAppFile");
	}	
}

function SetWindowTitle()
{
	if (G_sApplicationTitle)
		window.document.title= G_sAppWindowTitle + G_sCurrentVersion + " [" + G_sApplicationTitle +"]";
	else
		window.document.title= G_sAppWindowTitle + G_sCurrentVersion
}

//WR1970 - New Function Added
//==============================================================
//	Name:		SetMaxAddrID
//	Purpose:	Sets the Maximum Adress ID.
//	Parameters:	none
//==============================================================
function SetMaxAddrID()
{
	try
	{
		var oAppDSO=xml_master.XMLDocument.documentElement
		var oAddressesNode=oAppDSO.selectSingleNode("Addresses");
		var iAddrCountAct=oAddressesNode.childNodes.length;
		iAddrCountAct=GetIntVal(iAddrCountAct);
		var iMaxID=0
		if (iAddrCountAct>0)
		{
			for(var iIndex=0;iIndex<iAddrCountAct;iIndex++)
			{
				if (iMaxID<GetIntVal(oAddressesNode.childNodes(iIndex).selectSingleNode("AddressID").text))
					iMaxID=GetIntVal(oAddressesNode.childNodes(iIndex).selectSingleNode("AddressID").text);
			}
			
		}
		oAppDSO.setAttribute("maxAddressID",iMaxID);
	}
	catch (e)
	{
		displayError(e,"SetMaxAddrID");
	}
}

//==============================================================
//	Name:		SetMaxCustID
//	Purpose:	Sets the Maximum Adress ID.
//	Parameters:	none
//==============================================================
function SetMaxCustID()
{
	try
	{
		var oAppDSO=xml_master.XMLDocument.documentElement
		var oCustomersNode=oAppDSO.selectSingleNode("Customers");
		var iCustCountAct=oCustomersNode.childNodes.length;
		iCustCountAct=GetIntVal(iCustCountAct);
		var iMaxID=0
		if (iCustCountAct>0)
		{
			for(var iIndex=0;iIndex<iCustCountAct;iIndex++)
			{
				if (iMaxID<GetIntVal(oCustomersNode.childNodes(iIndex).selectSingleNode("CustomerID").text))
					iMaxID=GetIntVal(oCustomersNode.childNodes(iIndex).selectSingleNode("CustomerID").text);
			}
			
		}
		oAppDSO.setAttribute("maxCustomerID",iMaxID);
	}
	catch(e)
	{
		displayError(e,"SetMaxCustID");
	}
}

//==============================================================
//	Name:		SetMaxPurpID
//	Purpose:	Sets the Maximum Purpose ID.
//	Parameters:	none
//==============================================================
function SetMaxPurpID()
{
	try
	{
		var oAppDSO=xml_master.XMLDocument.documentElement
		var oPurpsNode=oAppDSO.selectSingleNode("Purposes");
		var iPurpCountAct=oPurpsNode.childNodes.length;
		iPurpCountAct=GetIntVal(iPurpCountAct);
		var iMaxID=0;
		var iMaxProdID=0;
		var iCurProdID=0;
		var iCurPurpID=0;
				
		if (iPurpCountAct>0)
		{
			for(var iIndex=0;iIndex<iPurpCountAct;iIndex++)
			{
				if (iMaxID<GetIntVal(oPurpsNode.childNodes(iIndex).selectSingleNode("PurposeID").text))
					iMaxID=GetIntVal(oPurpsNode.childNodes(iIndex).selectSingleNode("PurposeID").text);
					
				iCurPurpID = GetIntVal(oPurpsNode.childNodes(iIndex).selectSingleNode("PurposeID").text);
				iCurProdID = SetMaxProdID(iCurPurpID);
				
				if(iMaxProdID<iCurProdID)
					iMaxProdID = iCurProdID
				
			}
			
		}
		oAppDSO.setAttribute("maxPurposeID",iMaxID);
		oAppDSO.setAttribute("maxProductID",iMaxProdID);
	}
	catch(e)
	{
		displayError(e,"SetMaxPurpID");
	}
}

//==============================================================
//	Name:		SetMaxProdID
//	Purpose:	Sets the Maximum Product ID.
//	Parameters:	none
//==============================================================
function SetMaxProdID(iPurpId)
{
	try
	{
		
		var oAppDSO=xml_master.XMLDocument.documentElement;
		var iMaxID=0;
		
		if(iPurpId>0)
		{
			
			var oProdsNode=oAppDSO.selectSingleNode("Purposes/Purpose[PurposeID=" + iPurpId + "]/Products");
			var iProdCountAct=oProdsNode.childNodes.length;
			iProdCountAct=GetIntVal(iProdCountAct);
			if (iProdCountAct>0)
			{
				for(var iIndex=0;iIndex<iProdCountAct;iIndex++)
				{
					if (iMaxID<GetIntVal(oProdsNode.childNodes(iIndex).selectSingleNode("ProductID").text))
						iMaxID=GetIntVal(oProdsNode.childNodes(iIndex).selectSingleNode("ProductID").text);
				}	
			}		
		}
		
		return(iMaxID);
			
	}
	catch(e)
	{
		displayError(e,"SetMaxProdID");
	}
}

//==============================================================
//	Name:		SetMaxSecID
//	Purpose:	Sets the Maximum Security ID.
//	Parameters:	none
//==============================================================
function SetMaxSecID()
{
	try
	{
		var oAppDSO=xml_master.XMLDocument.documentElement
		var oSecNode=oAppDSO.selectSingleNode("Securities");
		var iSecCountAct=oSecNode.childNodes.length;
		iSecCountAct=GetIntVal(iSecCountAct);
		var iMaxID=0
		if (iSecCountAct>0)
		{
			for(var iIndex=0;iIndex<iSecCountAct;iIndex++)
			{
				if (iMaxID<GetIntVal(oSecNode.childNodes(iIndex).selectSingleNode("SecurityID").text))
					iMaxID=GetIntVal(oSecNode.childNodes(iIndex).selectSingleNode("SecurityID").text);
			}
			
		}
		oAppDSO.setAttribute("maxSecurityID",iMaxID);
		
	}
	catch(e)
	{
		displayError(e,"SetMaxSecID");
	}
}

//==============================================================
//            Name:             UpdateAssetAddr
//            Purpose:          Update the Address in Asset of SOP
//            Parameters:       Text Value Name
//==============================================================
function UpdateAssetAddr(AddrUpd,AdrId)
{
	try
	{
		var valid_address_asst;
		//copy address details to the SOP - Asset Starts
				var oSPsCnt = xml_master.XMLDocument.documentElement.selectNodes('StatementsOfPosition/StatementOfPosition');
				var oTotPropAsset = "Assets/Asset[AssetType='003']";
				if(oSPsCnt.length > 0) {
					for(var iTotSop=0; iTotSop<=oSPsCnt.length-1; iTotSop++) {
						var oTotAsCnt = oSPsCnt(iTotSop).selectNodes(oTotPropAsset);
						if(oTotAsCnt.length > 0) {
							for(var iTotAssetCount=0; iTotAssetCount<=oTotAsCnt.length-1; iTotAssetCount++) {
								var nNodeSelectAsst = oTotAsCnt(iTotAssetCount);
								if(nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr") != null) {
									var AstAddrID = nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr").text;
									if((AstAddrID != "" ) && (AstAddrID == AdrId)){
										if(AddrUpd != "")
										{
											nNodeSelectAsst.setAttribute('AssetLinkedPropAddrDescription',AddrUpd);
											nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr").text = AdrId;
											nNodeSelectAsst.selectSingleNode("AssetDescription").text = AddrUpd;
										}
										else
										{
											nNodeSelectAsst.setAttribute('AssetLinkedPropAddrDescription',AddrUpd);
											nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr").text = "";
											nNodeSelectAsst.selectSingleNode("AssetDescription").text = AddrUpd;
										}
										
									}
									else{
										if(AstAddrID == "")
										{
											nNodeSelectAsst.selectSingleNode("AssetDescription").text = "";
											nNodeSelectAsst.setAttribute('AssetLinkedPropAddrDescription',"");
										}
										valid_address_asst = true;
									}
								}
							}
						}
					}
				}
				//copy address details to the SOP - Asset Ends
	}
	catch(e)
	{
		displayError(e, 'UpdateAssetAddr');
	}
}

//==============================================================
//     Name:             Street Type Validation for Customer and Security Addresses
//     Purpose:          Validates the Street Type in Customer and Security Screen
//     Parameters:       Address Id of Addresses
//==============================================================

function ValidateStreetTypeAddr(AddrID)
{
	try
	{
		var valid_StreetType;
		var oMDocEl = xml_master.XMLDocument.documentElement;
		// Start for VALID STREET TYPE
		if(AddrID != "")
		{
			var oTotAdd = "Addresses/Address[AddressID="+ AddrID +"]";
			var oTotAddrCnt = oMDocEl.selectNodes(oTotAdd);
			if(oTotAddrCnt.length > 0)
			{
				var sAddrType=oTotAddrCnt(0).selectSingleNode("AddressType").text;
				var oStreetType=oTotAddrCnt(0).selectSingleNode("StreetType");
				if (sAddrType=="Non Standard Address") {
					valid_StreetType = true;
				}
				if (sAddrType=="Standard Street Address") {
					if (oStreetType.text!="")
						valid_StreetType = true;
					else
						valid_StreetType = false;
				}
			}
			return valid_StreetType;
		}
		// END for VALID STREET TYPE
	}
	catch(e)
	{
		displayError(e, 'ValidateStreetTypeAddr');
	}
}

//==============================================================
//    Name:             DeleteCustomerSecurityAddress
//    Purpose:          Delete the Customer and Security Address
//    Parameters:       Address Id of Addresses
//==============================================================

function DeleteCustomerSecurityAddress(cust_recNo,sec_recNo,oCustSecXML,frmscreen)
{
	try
	{
	
		var sCusPrompt = "";
		var base_xml_addr = oCustSecXML;
		var sLA, oLnkResCustAddrs;
		var oDocEl=xml_master.XMLDocument.documentElement;
		var AdrId,CustId,SecID;
		var oSecs;
		
		if(frmscreen=="C"){
			// Customer
			//var oCustAddrs=ds_cust.XMLDocument.documentElement.selectSingleNode("CustomerAddresses");
			var oCustAddrs = oCustSecXML.selectSingleNode("CustomerAddresses");
			AdrId = oCustAddrs.childNodes(cust_recNo-1).selectSingleNode("AddressID").text;
			CustId=ds_cust.XMLDocument.documentElement.selectSingleNode("CustomerID").text;
			sLA = "//Customer[CustomerID!="+CustId+" and CustomerAddresses/CustomerAddress[AddressID="+AdrId+" and (Type='CR' or Type='PR') ]]/CustomerName"
			oLnkResCustAddrs = oDocEl.selectNodes(sLA);
			
			//find if any non-TBA security is linked to this address - Customer
			oSecs = oDocEl.selectNodes("//Security[SecurityDetailsTBA!=-1 and AddressID="+AdrId+"]");
		}
		else {
			// Security
			//var oSecAddrs= oSec.selectSingleNode("SecurityAddresses");
			var oSecAddrs= oCustSecXML.selectSingleNode("SecurityAddresses");
			AdrId = oSecAddrs.childNodes(sec_recNo-1).selectSingleNode("AddressID").text;
			SecID=oCustSecXML.selectSingleNode("SecurityID").text;
			sLA = "//Customer[CustomerAddresses/CustomerAddress[AddressID="+AdrId+" and (Type='CR' or Type='PR')]]/CustomerName"
			oLnkResCustAddrs = oDocEl.selectNodes(sLA);
			
			//find if any non-TBA security is linked to this address - Security
			oSecs = oDocEl.selectNodes("//Security[SecurityID!="+SecID+" and SecurityDetailsTBA!=-1 and AddressID="+AdrId+"]");
		}
		
		//find if any customer has link to this address as residential
		if (oLnkResCustAddrs.length)
		{
			var sNames = "    " + oLnkResCustAddrs(0).text + "\r\n";
			for (var i=1; i<oLnkResCustAddrs.length; i++)
				sNames = sNames + "    " + oLnkResCustAddrs(i).text + "\r\n";
			sCusPrompt="Warning: Deleting this address may make the following customers invalid:\r\n"+sNames;
		}
	
		var sSecPrompt = (oSecs.length>0)? "Warning: Deleting this address will make securities invalid.":"";
	
		var sPrompt = (sCusPrompt!="" && sSecPrompt!="")? sCusPrompt + "\r\n" + sSecPrompt:sCusPrompt+sSecPrompt;
	
		if (!ConfirmDelete(sPrompt)) return;
		
		if(frmscreen=="C"){
			//remove address from current dso - Customer
			oCustAddrs.removeChild(oCustAddrs.childNodes(cust_recNo-1));
		}
		else{
			//remove address from current dso - Security
			oSecAddrs.removeChild(oSecAddrs.childNodes(sec_recNo-1));
			//Remove address ID from ds_security if deleting linked address
			if (AdrId == oCustSecXML.selectSingleNode("AddressID").text)
				oCustSecXML.selectSingleNode("AddressID").text="";
		}
		
		//remove security addresses
		var oSecAddrs = oDocEl.selectNodes("//SecurityAddress[AddressID="+AdrId+"]");
		if(oSecAddrs.length > 0)
		{
			for (var i=oSecAddrs.length-1; i>=0; i--){
				if(oSecAddrs(i) != null)
					oSecAddrs(i).parentNode.removeChild(oSecAddrs(i));
			}
		}
		
		
		//remove customer addresses which is deleted from Security Screen
		if(oDocEl.getElementsByTagName("CustomerAddress").length > 0){
			var oAddrList=oDocEl.selectNodes("//CustomerAddress[AddressID="+AdrId+"]");
				if(oAddrList.length > 0 ){
					for (var i=0; i<oAddrList.length; i++){
						if(oAddrList(i) !=  null){
							oAddrList(i).parentNode.removeChild(oAddrList(i));
						}
					}
				}
		}
			
		//Remove address ID from all other securities
		//remove links to securities - get all securities including TBA
		var oAllSecs=oDocEl.selectNodes("//Security[AddressID="+AdrId+"]");
		if(oAllSecs.length > 0) {
			for(var i=0;i<oAllSecs.length;i++){
				oAllSecs(i).selectSingleNode("AddressID").text="";
				oAllSecs(i).setAttribute("AddressDtls","");
			}
		}
		
		// remove asset addresses
			UpdateAssetAddr("",AdrId);
		// remove liability addresses
			UpdateLiabilityAddr("",AdrId);
		
		//remove address
		var oAddr = xml_master.XMLDocument.documentElement.selectSingleNode("//Addresses/Address[AddressID="+AdrId+"]");
		if(oAddr != null)
			oAddr.parentNode.removeChild(oAddr);
		
		
		if(frmscreen=="C"){
			//make sure that the customer will be saved
			G_bCustomerDirty=true;
		}
		else {
			//SaveSecurity
			G_bSecurityDirty=true;
			G_bCustomerDirty= true;
		}
		
		
		//requires validation of the all customers 
		//due to residential address has been deleted
		if (sCusPrompt) EvaluateAppBRS(oDocEl.selectSingleNode("//Customers"));
		//requires validation of the all securities 
		//due to security address has been deleted
		if (oSecs.length>0) EvaluateAppBRS(oDocEl.selectSingleNode("//Securities"));
		//requires validation of application due to customer and/or security have been changed
		
		//requires validation of the all sops 
		//due to customer address has been deleted
		var oSPsCnt = oDocEl.selectNodes('StatementsOfPosition/StatementOfPosition');
		if (oSPsCnt.length>0) EvaluateAppBRS(oDocEl.selectSingleNode("//StatementsOfPosition"));
		
		//requires validation of application due to customer and/or security have been changed
		if (sCusPrompt || oSecs.length>0) EvaluateAppBRS(oDocEl,true);
	
		FlushToDisk();
	}
	catch(e)
	{
		displayError(e, 'DeleteCustomerSecurityAddress');
	}
}


//==============================================================
//	Name:		Validate_PhNumbers_OnLoad
//	Purpose:	Validates all home phone number preferred
//	Parameters:	poCust - (XML node) single customer XML element
//	Return:		boolean - true, if the home phone number preferred is valid,
//							otherwise - false
//==============================================================
function Validate_PhNumbers_OnLoad(txtNode)
{
	try
	{
		if(txtNode != null) {
			if(txtNode.text != "") {
				txtNode.text = (txtNode.text).replace(/\D+/g, "");
				var regexval = /^[0-9]+$/;
				var nValue=(regexval.test(txtNode.text));
				if((nValue==true)) {
					var nTextVal = ((txtNode.text).replace(/\s/g, ""));
					if(nTextVal != "") {
						if(nTextVal.length > 10){
							nTextVal = "0" +  nTextVal.substring(nTextVal.length - 9, nTextVal.length); 
						}
						else
						{
							nTextVal = nTextVal;
						}
						if(nTextVal.length==10) {
							txtNode.text =  nTextVal;
							return ((txtNode.text) && (true));
						}
						else{
							return ((txtNode.text) && (false));		
						}
					}
				}
				else 
				{
					txtNode.text = (txtNode.text).replace(/\D+/g, "");
					return ((txtNode.text) && (false));		
				}
			}
			else 
			{
				return (true);		
			}
		}
	}
    catch(e)
    {
       displayError(e,"Validate_PhNumbers_OnLoad");
    }
}


//==============================================================
//     Name:             UpdateSameAssetAddr
//     Purpose:          Clears the Address in Asset if multiple Asset contains same Address of SOP
//     Parameters:       Text Value Name
//==============================================================
function UpdateSameAssetAddr()
{
	try
	{
		var valid_address_asst;
		var oSPsCnt = xml_master.XMLDocument.documentElement.selectNodes('StatementsOfPosition/StatementOfPosition');
		var oTotPropAsset = "Assets/Asset[AssetType='003']";
		if(oSPsCnt.length > 0) {
			for(var iTotSop=0; iTotSop < oSPsCnt.length; iTotSop++) {
				var oTotAsCnt = oSPsCnt(iTotSop).selectNodes(oTotPropAsset);
				if(oTotAsCnt.length > 1) {
					for(var iTotAssetCount=0; iTotAssetCount < oTotAsCnt.length; iTotAssetCount++) {
						var I_nNodeSelectAsst = oTotAsCnt(iTotAssetCount);
						if(I_nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr") != null) {
							var I_AstAddrID = I_nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr").text;
							for(jAstCnt=iTotAssetCount+1; jAstCnt < oTotAsCnt.length; jAstCnt++)
							{
								var J_nNodeSelectAsst = oTotAsCnt(jAstCnt);
								if(J_nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr") != null) {
									var J_AstAddrID = J_nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr").text;
									if(J_AstAddrID != "")
									{
										if ((I_AstAddrID == J_AstAddrID))
										{
											J_nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr").text = "";
											J_nNodeSelectAsst.selectSingleNode("AssetDescription").text = "";
											J_nNodeSelectAsst.setAttribute('AssetLinkedPropAddrDescription',"");
										}
									}
									
								}
							}
						}
					}
				}
			}
		}
		//copy address details to the SOP - Asset Ends
	}
	catch(e)
	{
		displayError(e, 'UpdateSameAssetAddr');
	}
}



//==============================================================
//            Name:             UpdateLiabilityAddr - Not Necessary (No validation excepted in Liability)
//            Purpose:          Update the Address in Asset of SOP
//            Parameters:       Text Value Name
//==============================================================
function UpdateLiabilityAddr(AddrUpd,AdrId)
{
	try
	{
		var valid_address_asst;
		
		//copy address details to the SOP - Liability Starts
				var oSPsCnt = xml_master.XMLDocument.documentElement.selectNodes('StatementsOfPosition/StatementOfPosition');
				var oTotPropLiabMort = "Liabilities/Liability[LiabilityType='001']";
				var oTotPropLiabOFI = "Liabilities/Liability[LiabilityType='005']";
				if(oSPsCnt.length > 0) {
					for(var iTotSop=0; iTotSop<=oSPsCnt.length-1; iTotSop++) {
						var oTotLiabMortCnt = oSPsCnt(iTotSop).selectNodes(oTotPropLiabMort);
						var oTotLiabOFICnt = oSPsCnt(iTotSop).selectNodes(oTotPropLiabOFI);
						
						// Added for updating the address of ANZ Mortgage in Liability 
						if(oTotLiabMortCnt.length > 0)
						{
							for(var iTotLiabilCount=0; iTotLiabilCount<=oTotLiabMortCnt.length-1; iTotLiabilCount++) {
								var nNodeSelectAsst = oTotLiabMortCnt(iTotLiabilCount);
								if(nNodeSelectAsst.selectSingleNode("LinkedPropertyAsset") != null) {
									var LiabilAddrID = nNodeSelectAsst.selectSingleNode("LinkedPropertyAsset").text;
									if((LiabilAddrID != "" ) && (LiabilAddrID == AdrId)){
										if(AddrUpd != "")
										{
											nNodeSelectAsst.setAttribute('LinkedPropertyAssetDescription',AddrUpd);
											nNodeSelectAsst.selectSingleNode("LinkedPropertyAsset").text = AdrId;
										}
										else
										{
											nNodeSelectAsst.setAttribute('LinkedPropertyAssetDescription',AddrUpd);
											nNodeSelectAsst.selectSingleNode("LinkedPropertyAsset").text = "";
										}
										
									}
									else{
										if(LiabilAddrID == "")
										{
											nNodeSelectAsst.setAttribute('LinkedPropertyAssetDescription',"");
										}
										valid_address_asst = true;
									}
								}
							}
						}
						// Added for updating the address of OFI in Liability 
						if(oTotLiabOFICnt.length > 0)
						{
							for(var iTotLiabilCount=0; iTotLiabilCount<=oTotLiabOFICnt.length-1; iTotLiabilCount++) {
							var nNodeSelectAsst = oTotLiabOFICnt(iTotLiabilCount);
								if(nNodeSelectAsst.selectSingleNode("LinkedPropertyAsset") != null) {
									var LiabilAddrID = nNodeSelectAsst.selectSingleNode("LinkedPropertyAsset").text;
									if((LiabilAddrID != "" ) && (LiabilAddrID == AdrId)){
										if(AddrUpd != "") {
											nNodeSelectAsst.setAttribute('LinkedPropertyAssetDescription',AddrUpd);
											nNodeSelectAsst.selectSingleNode("LinkedPropertyAsset").text = AdrId;
										}
										else {
											nNodeSelectAsst.setAttribute('LinkedPropertyAssetDescription',AddrUpd);
											nNodeSelectAsst.selectSingleNode("LinkedPropertyAsset").text = "";
										}
									}
									else{
										if(LiabilAddrID == ""){
											nNodeSelectAsst.setAttribute('LinkedPropertyAssetDescription',"");
										}
										valid_address_asst = true;
									}
								}
							}
						}
					}
				}
				//copy address details to the SOP - Asset Ends
	}
	catch(e)
	{
		displayError(e, 'UpdateLiabilityAddr');
	}
}

//==============================================================
//            Name:             RemovePackDupNode - 
//            Purpose:          Removes Duplicate Nodes in packages
//            Parameters:       
//==============================================================
function RemovePackDupNode()
{
	try
	{
		var oMDocEl=xml_master.XMLDocument.documentElement;		
		//New Code Begin Tax Resident added on 28/02/2018 for tax resident crs changes	
		var oPackNode1 = oMDocEl.selectSingleNode("Packages");
		if  (oPackNode1.hasChildNodes) 
		{
			var oPakNode = oMDocEl.selectNodes("Packages");
			if(oPakNode.length > 0)
			{
				for(var i=0;i<oPakNode.length;i++)
				{
					var oPCH_Dup = oPakNode(i).getElementsByTagName("PrimaryCardHolder");
					var oPCHName_Dup = oPakNode(i).getElementsByTagName("PrimaryCardHolderName");
					var oACH_Dup = oPakNode(i).getElementsByTagName("AdditionalCardHolderCustID");
					var oACHName_Dup = oPakNode(i).getElementsByTagName("AdditionalCardHolder");
					
					// Remove Duplicate PrimaryCardHolderName from Packages 
						if(oPCHName_Dup != null) 
						{
							if(oPCHName_Dup.length > 1)
							{
								for(var iAd=1;iAd<oPCHName_Dup.length;iAd++)
								{
									oPakNode(i).removeChild(oPCHName_Dup(iAd));
								}
							}
						}
						// Remove Duplicate AdditionalCardHolderCustID from Packages 
						if(oACH_Dup != null) 
						{
							if(oACH_Dup.length > 1)
							{
								for(var iAd=1;iAd<oACH_Dup.length;iAd++)
								{
									oPakNode(i).removeChild(oACH_Dup(iAd));
								}
							}
						}
						
						//Remove Value from PrimaryCardHolderName if PrimaryCardHolder is null
						if(oPCH_Dup != null) 
						{
							if(VBTrim(oPCH_Dup(i).text) == "")
							{
								if(oPakNode(i).selectSingleNode("PrimaryCardHolderName") != null)
								{
									if(oPakNode(i).selectSingleNode("PrimaryCardHolderName").text != "")
									{
										oPakNode(i).selectSingleNode("PrimaryCardHolderName").text = "";
									}
										
								}
							}
						}
						
						// Remove Duplicate AdditionalCardHolderName from Packages 
						if(oACHName_Dup != null) 
						{
							if(oACHName_Dup.length > 1)
							{
								for(var iAd=1;iAd<oACHName_Dup.length;iAd++)
								{
									oPakNode(i).removeChild(oACHName_Dup(iAd));
								}
							}
						}
						
				}
			}
		}
		//New Code Ended 
	}
	catch(e)
	{
		displayError(e,'RemovePackDupNode')
	}
}

//=============================================================================================
//	Name:		UpdateCustTaxResident
//	Parameters:	Nil
//	Return:		Nil
//	Purpose:	Updating Customer Type Description.
//=============================================================================================
function UpdateCustTaxResident(bFlag,b_RefACHBrkFreeCard)
{
	try
	{
	
		//Updating Tax Resident for Customer's
			
		var oDocEl=xml_master.XMLDocument.documentElement;
		var oCust = oDocEl.selectNodes("Customers/Customer");
		
		if  (oCust.length > 0)
		{
			for(var i=0; i<oCust.length; i++)
			{
				var bSelectCustType = oCust.item(i).selectSingleNode("CustomerType").text;
				var bSelectCustId = oCust.item(i).selectSingleNode("CustomerID").text;
				//alert("TEST==> " + bSelectCustId + " == " + b_RefACHBrkFreeCard);
				if((bSelectCustType == "GTR") && (bFlag))
				{
					if((bSelectCustId != b_RefACHBrkFreeCard) || (b_RefACHBrkFreeCard == ""))
					{
						// Clearing of TaxResidentAustralia Node from Customer 
						if((oCust.item(i).selectSingleNode("TaxResidentAustralia") != null) && (oCust.item(i).selectSingleNode("TaxResidentAustralia").text != ""))
						{
							oCust.item(i).selectSingleNode("TaxResidentAustralia").text = "";
						}
						// Removing of TaxResident Details from Customer Node 
						if((oCust.item(i).selectSingleNode("TaxResidents/TaxResidentDetails") != null) && (oCust.item(i).selectSingleNode("TaxResidents/TaxResidentDetails").hasChildNodes))
						{
							var oNewCust = oCust.item(i);
							var remTaxResidentCh=oNewCust.selectSingleNode("TaxResidents")
							remTaxResidentCh.removeChild(remTaxResidentCh.selectSingleNode("TaxResidentDetails"));
						}
					}
				}
				else if(!bFlag)
				{
					// Clearing of TaxResidentAustralia Node from Customer 
					if((oCust.item(i).selectSingleNode("TaxResidentAustralia") != null) && (oCust.item(i).selectSingleNode("TaxResidentAustralia").text != ""))
					{
						oCust.item(i).selectSingleNode("TaxResidentAustralia").text = "";
					}
					// Removing of TaxResident Details from Customer Node 
					if((oCust.item(i).selectSingleNode("TaxResidents/TaxResidentDetails") != null) && (oCust.item(i).selectSingleNode("TaxResidents/TaxResidentDetails").hasChildNodes))
					{
						var oNewCust = oCust.item(i);
						var remTaxResidentCh=oNewCust.selectSingleNode("TaxResidents")
						remTaxResidentCh.removeChild(remTaxResidentCh.selectSingleNode("TaxResidentDetails"));
					}
				}
			}
		}	
		FlushToDisk();
	}
	catch (e)
	{
		displayError(e,"UpdateCustTaxResident");	
	}
}
