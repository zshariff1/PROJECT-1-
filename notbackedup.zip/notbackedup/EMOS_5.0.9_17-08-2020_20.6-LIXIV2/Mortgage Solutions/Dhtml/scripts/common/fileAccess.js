//<!--==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Tim Heide
//	Workfile:  
//	ModTtime: 2003/03/04
//  File: fileAccess.js	
//============================================================-->
//<SCRIPT>

//==============================================================
//	Function Name:	getOpenFilePath
//	Parameters:		sInitDir - (String) Initial file path to open common dialog
//	Return:			Array - File name and path
//	Description:	Shows the common dialog box in Open mode to allow user to select file
//					Returns an array of file details for selected file to open
//==============================================================
function getOpenFilePath(sInitDir)
{
	try
	{
		//set up the common dialog box
		if (sInitDir.length > 0) 
			objComDlg.InitDir = sInitDir;
			
		objComDlg.Filename = "";
		objComDlg.Flags = gc_FileMustExist;
		objComDlg.Filter = "ANZ Online Application (*.mos)|*.mos";
		objComDlg.DialogTitle  = "Open Application";
		objComDlg.ShowOpen();
		
		//return an array of selected file details
		return Array(objComDlg.Filename, objComDlg.FileTitle);
	}
	catch(e)
	{
		displayError(e,"getOpenFilePath");
	}
}

//==============================================================
//	Function Name:	getSaveFilePath
//	Parameters:		sInitDir - (String)Initial file path to open common dialog
//	Return:			Array - File name and path
//	Description:	Shows the common dialog box in Save mode to allow user to create a new file
//					Returns an array of file details for selected file to open
//==============================================================
function getSaveFilePath(sInitDir)
{
	try
	{	
		//set up the common dialog box
		if (sInitDir.length > 0) 
			objComDlg.InitDir = sInitDir;
			
		objComDlg.Filename = "";
		objComDlg.Flags = gc_OverwritePrompt;
		objComDlg.Filter = "ANZ Online Application (*.mos)|*.mos";
		objComDlg.DialogTitle  = "New Application";
		objComDlg.ShowSave();

		return Array(objComDlg.Filename, objComDlg.FileTitle);
	}
	catch(e)
	{
		displayError(e,"getSaveFilePath");
	}
}

//==============================================================
//	Function Name:	FlushToDisk
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Saves the master DSO using the current file path to disk
//==============================================================
function FlushToDisk()
{	
	try
	{
		if (G_bSaveIsAllowed)
		{
			// save to file
			G_oXML.loadXML(xml_master.XMLDocument.xml);
			G_oXML.save (G_sApplicationFilePath);
		}
		else
		{
			promptSaveProhibited('Application');
		}
	}
	catch (e)
	{
		displayError(e,"FlushToDisk");
	}
}

//==============================================================
//	Function Name:	SaveBackup
//	Parameters:		sXMLString (String) - XML string to save as backup
//	Return:			Boolean - true if saved successfully, otherwise - false
//	Description:	Saves the backup copy of the file current file 
//					path to disk
//==============================================================
function SaveBackup(sXMLString)
{	
	try
	{
		// save backup
		G_oXML.loadXML(sXMLString);
		var sBackupPath = G_sApplicationFilePath;
		sBackupPath = sBackupPath.substring(0, sBackupPath.length - 4) + '.bak';
		G_oXML.save (sBackupPath);
		
		return true;		
	}
	catch (e)
	{
		displayError(e,"SaveBackup");
	}
}

//==============================================================
//	Function Name:	loadDSOFromFile
//	Parameters:		sFilePath - (String) File path to load file from
//					oDSO - DSO to load it into
//	Return:			Nil
//	Description:	Loads a file into the given DSO
//==============================================================
function loadDSOFromFile(sFilePath,oDSO)
{	
	try
	{
		//load file into DOM
		G_oXML.load(sFilePath);
						
		resetDSO(oDSO);
		oDSO.XMLDocument.loadXML(G_oXML.xml);
		//var oDocEl=oDSO.XMLDocument.documentElement;
	
		//oDSO.XMLDocument.replaceChild(G_oXML.documentElement.cloneNode(true),oDocEl);
	}
	catch(e)
	{
		displayError(e,"loadDSOFromFile");
	}
}



