//<!--==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Tim Heide, Eugene Elutine
//	Workfile:  
//	ModTtime: 2003/03/04
//  File: common.js	
//============================================================-->
//	Revision: 2
//	Author: Arshad
//	Workfile:  
//	ModTtime: 2005/04/04
//  File: common.js	
//==============================================================-->
//	Revision: 3
//	Author: NS
//	Workfile:  
//	ModTtime: 2012/05/04
//  File: common.js	
//============================================================-->
//<SCRIPT>

//==============================================================
//	Function Name:	DebugDumpXML
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Opens a window to view debug htm.
//					For debugging DSOs and files
//==============================================================
function DebugDumpXML()
{	
	try
	{
		if (G_bDEBUG_MODE)
			window.showModalDialog("../debugDSO.htm", document, "dialogHeight:600px; dialogWidth:850px");
	}
	catch(e)
	{
		displayError(e,"DebugDumpXML");
	}
}

//==============================================================
//	Function Name:	resetDSO
//	Parameters:		oDSO - DSO to reset
//	Return:			Nil	
//	Description:	Resets a DSO to its original source.
//==============================================================
function resetDSO(oDSO)
{
	try
	{
		oDSO.src=oDSO.src;
	}
	catch (e)
	{
		displayError(e,"resetDSO");
	}
}

//==============================================================
//	Function Name:	getXMLField
//	Parameters:		dsOrNode - XML Element (DSO or Node)
//					fieldName - Name of field to get
//					sXP - Xpath
//					bFromXMLNode - Boolean flag indicating if selecting from DSO or Node
//	Return:			String - Node text or null if it doesn't exist
//	Description:	Returns the text for a given field from a supplied DSO or Node
//==============================================================
function getXMLField (dsOrNode, fieldName, sXP, bFromXMLNode, bAttr)
{
	try
	{
		sXP = (sXP)?  (sXP + "/" + fieldName) : fieldName;
		var oNode =  (bFromXMLNode)? dsOrNode.selectSingleNode (sXP) : dsOrNode.XMLDocument.documentElement.selectSingleNode (sXP);
	
		// assume if node's empty it has a NULL value.
		return  (oNode)?  ((oNode.text == "")? null : oNode.text) : null;
	}
	catch (e)
	{
		displayError(e,"getXMLField");
	}
	
}

//==============================================================
//	Function Name:	setXMLField
//	Parameters:		dsOrNode - (XML Element) (DSO or Node)
//					fieldName - (String) Name of field to set
//					vValue - (variant) Value to be set to field
//					bAttr - (boolean) Flag for attribute
//					bIXMLNode - (Boolean) flag indicating if selecting from DSO or Node
//					sXP - (String) XPath
//	Return:			Nil
//	Description:	Sets an XML elements value in a given DSO or Node. 
//					It can set an attribute or a node.
//==============================================================
function setXMLField (dsOrNode, fieldName, vValue, bAttr, bIXMLNode, sXP)
{
	try
	{
		var oParNode;
		if (sXP)
			oParNode =  (!bIXMLNode)? dsOrNode.XMLDocument.documentElement.selectSingleNode (sXP) : dsOrNode.selectSingleNode (sXP) ;
		else
			oParNode =  (!bIXMLNode)? dsOrNode.XMLDocument.documentElement : dsOrNode ;
			
		if (!oParNode)
			raiseError ("Parent Node for field '" + fieldName + "' not found by XP='" + sXP + "'");

		if (bAttr)
		{
			oParNode.setAttribute (fieldName, vValue.toString())
		}
		else
		{
			var oNode = oParNode.selectSingleNode (fieldName);
			if (!oNode) oNode = oParNode.appendChild (oParNode.ownerDocument.createElement (fieldName));
				oNode.text =  vValue.toString();
		}
	}
	catch (e)
	{
		displayError(e,"setXMLField");
	}
}

//==============================================================
//	Function Name:	raiseError
//	Parameters:		sMessage - (String) Error message
//					sNumber - (String) Error Number
//					sName - (String) Error Name
//	Return:			Nil
//	Description		Throws a custom error
//==============================================================
function raiseError (sMessage, sNumber, sName)
{
	G_bSaveIsAllowed = false;
	e = new Error();
	e.message = sMessage;
	e.name = sName;
	throw (e);
}

//==============================================================
//	Function Name:	displayError
//	Parameters:		e - Error Object
//					sFuncName - (String) Source function name
//	Return:			Nil
//	Description:	Formats and displays an error using a VBMessage box
//==============================================================
function displayError(e,sFuncName)
{
	G_bSaveIsAllowed = false;
	VBMsgBox(getErrorMsg(e,sFuncName), G_iVB_CRITICAL_ERROR, G_sERROR_TITLE);	
}

//==============================================================
//	Function Name:	throwError
//	Parameters:		e - Error object
//					sSourceFunc - (String) Source to append to error
//	Return:			Nil
//	Description:	Takes an error and a message and throws it		
//==============================================================
function throwError(e,sSourceFunc)
{
	G_bSaveIsAllowed = false;
	var err = new Error();
	err.number = e.number;
	err.description = e.description;
	err.name = e.name;

	//concat the source
	err.message = concatSourceForError(e.message,sSourceFunc);
	throw (err);
}

//==============================================================
//	Function Name:	concatSourceForError
//	Parameters:		sCurrMsg - (string) current error source
//					sSourceFunc - (String) Source to append to error
//	Return:			String - New error source
//	Description:	Concatinates the error source		
//==============================================================
function concatSourceForError(sCurrMsg, sSourceFunc)
{
	var sCurr = new String(sCurrMsg);
	var sWildCard = new String("$emos$");
	var sRetVal = sWildCard + "[" + sSourceFunc + "]";
	var iIndexOfSource = sCurr.indexOf(sWildCard);
		
	if  (iIndexOfSource != -1) sRetVal = sRetVal + ">>" + sCurr.substr(iIndexOfSource + sWildCard.length);
		
	return sRetVal;
}

//==============================================================
//	Function Name:	getErrorMsg
//	Parameters:		e - Error Object
//					sFuncName - (String) Source Function Name
//	Return:			Formatted String containing error details
//	Description:	Formats a string with details or an error object
//					for display
//==============================================================
function getErrorMsg(e, sFuncName)
{
	var sSrc = new String(e.message);
	var sWildCard = new String("$emos$");
	var sSource = "[" + sFuncName + "]";
	
	if (sSrc.indexOf(sWildCard) != -1)sSource = sSource + ">>" + sSrc.substr(sWildCard.length);
	
	return "Error#:\t\t" + e.number + 
		"\r\nName:\t\t" + e.name + 
		"\r\nSource:\t\t" + sSource +
		"\r\nDescription:\t" + e.description;
		
}

//==============================================================
//	Function Name:	ClearRowSelectors
//	Parameters:		tblCA - (pointer) Table
//					oRowSelector - Option button collection
//					RecNo - (numeric) Radio button to selects record number
//	Return:			Nil
//	Description:	Handles a bug in IE where more then one
//					option buttons can be selected in a collection
//					of option buttons. This function un-checks all the 
//					option buttons and selects the 1 for the given record number. 
//==============================================================
function ClearRowSelectors(tblCA, oRowSelector, RecNo)
{
	//this function should be called on the readystatechange event for
	//for the top level selection table if the screen with that 
	//table has been loaded on demand. For screens initilised from 
	//start it's not required.
	try 
	{
		if ((tblCA.readyState!="complete")||(RecNo==0)||(!oRowSelector)) return;
		if (oRowSelector.length>0)
		{
			//clear not selected radio buttons and select required
			for (var i=0; i<oRowSelector.length; i++)
				oRowSelector(i).checked = (i==(RecNo-1))? true:false;	
		}	
	}
	catch (e) 
	{ 
		displayError(e,"ClearRowSelectors");
	}	
}


//==============================================================
//	Function Name:	SetRowSelectors
//	Parameters:		oRowSelector - (HTML radio button collection) 
//									row selectors
//					RecNo - (numeric) record number to be selected 
//	Description:	Selects required radio button
//==============================================================
function SetRowSelectors(oRowSelector, RecNo)
{
	try 
	{
		if (oRowSelector.length> 0)
		{
			for (var i=0; i<oRowSelector.length; i++) 
			{
				if((oRowSelector(i) != undefined) || (oRowSelector(i) != null)) // Added to avoid CustRowSelect Script Error - 19.7 Release
					oRowSelector(i).checked = (i==(RecNo-1))? true:false;	
			}
		}
		else
		{
			if((oRowSelector != undefined) || (oRowSelector != null)) // Added to avoid CustRowSelect Script Error - 19.7 Release
				oRowSelector.checked = (RecNo>0)? true:false;
		}
			
	}
	catch (e) 
	{ 
		//ignore error: assinchronous event
	}	
}

//==============================================================
//	Function Name:	allocateNewID
//	Parameters:		sIdName - (String) Name of ID
//	Return:			Integer - ID
//	Description:	Returns the next available ID for a given ID name
//==============================================================
function allocateNewID(sIdName)
{
	try
	{
		var oDocEl=xml_master.XMLDocument.documentElement;
		var IdVal = GetIntVal(oDocEl.getAttribute(sIdName));
		IdVal++;
		// update ID		
		oDocEl.setAttribute (sIdName, IdVal);
		return IdVal;
	}
	catch (e) 
	{ 
		displayError(e,"allocateNewID");
	}	
}

//==============================================================
//	Function Name:	InitAppBRSImages
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Initialise application image globals
//==============================================================
function InitAppBRSImages()
{
	try
	{
		//initilize Application BRS
		var oAppBR= xml_AppBRS.XMLDocument.documentElement;
		G_imgValidTab = oAppBR.getAttribute("imgValidTab");
		G_imgErrorTab = oAppBR.getAttribute("imgErrorTab");
		G_imgValidEntity= oAppBR.getAttribute("imgValidEntity");
		G_imgInvalidEntity= oAppBR.getAttribute("imgInvalidEntity");
		G_imgError= oAppBR.getAttribute("imgError");
		G_imgValid= oAppBR.getAttribute("imgValid");
		G_imgEmpty = oAppBR.getAttribute("imgEmpty");
	}
	catch(e)
	{
		displayError(e,"InitAppBRSImages");
	}
}	

//==============================================================
//	Function Name:	InitilizeAppBRS
//	Parameters:		oStartNode - Node to Evaluate
//	Return:			Nil
//	Description:	Sets up the validation for a given node but
//					does not add validation errors to the node	
//==============================================================
function InitilizeAppBRS(oStartNode)
{
	EvaluateAppBRS(oStartNode,false,true);
}

//==============================================================
//	Function Name:	EvaluateAppBRS
//	Parameters:		oStartNode - XML Root Node
//					bThisItemOnly - (boolean) Flag indicating if child nodes should be validated
//					bInitilize - (boolean) Flag indicating if node is only to be initialized and not validated
//					bSimpleEntityChilds - (boolean) 
//	Return:			boolean - Valid or not flag
//	Description:	Validation engine
//==============================================================
function EvaluateAppBRS(oStartNode, bThisItemOnly, bInitilize, bSimpleEntityChilds)
{
	try
	{
		if (!oStartNode) return;
		if (G_imgEmpty=="") InitAppBRSImages();
		
		var bInEval = false;
		var valid = true;
		var res = true;
		
		//get node from BizRules
		var BR_xpath = "//" + oStartNode.nodeName;
		var oBR = xml_AppBRS.XMLDocument.documentElement.selectSingleNode(BR_xpath).cloneNode(true);
		if (!oBR) return;
		var bSimpleEntity = (oBR.getAttribute("simpleEntity"))? true:false;
		if ((oBR.getAttribute("entity")||bSimpleEntity)&&(!bSimpleEntityChilds))
		{
			//current node is entity level (eg. Application, Customers, etc.)
			if (!bThisItemOnly)
			{
				//for each relevant to BR child node evaluate BR for data child node
				var oEntityBRChilds = oBR.childNodes;
		
		
		
				if (bSimpleEntity)
						EvaluateAppBRS(oStartNode,false,bInitilize,true);
				else
				{					
					for (var i=0; i<oBR.childNodes.length; i++)
					{
						var oDataChilds=oStartNode.selectNodes(oBR.childNodes(i).nodeName);
						//Rel 18.1 new code ended
						for (var n=0; n<oDataChilds.length; n++) 
						{
							if (oBR.childNodes(i).nodeName=="Customer")
							{
								G_Cust_ID=oDataChilds(n).selectSingleNode("CustomerID").text;
								G_Customer_Type=oDataChilds(n).selectSingleNode("CustomerType").text;				
							}
							EvaluateAppBRS(oDataChilds(n),false,bInitilize);
						}
						//new code ended
						
					}
				}
			}
			//set entity validation results on parent node if it's not a document  
			var bRoot=oStartNode.parentNode.nodeType==9
			var oResNode = (bRoot)? oStartNode:oStartNode.parentNode;
			
			//for initilising simple entities do not set results on the simple entity node
			if (bSimpleEntity && bInitilize && (oResNode.nodeName==oStartNode.nodeName)) return true;
			
			//entity level special validation if any
			var custom = oBR.getAttribute("custom");		
			var params = oBR.getAttribute("params");
			if (params==null) params="";		
			valid = true && ((custom && !bInitilize)? eval(custom + "(oStartNode"+params+");"):true);
			var emptyEntityValid = oBR.getAttribute("emptyEntityValid");
			//set entity special validation rule result
			if (custom) oResNode.setAttribute(custom, (valid)? G_imgValid:G_imgError);
			//check if any error in entity
			//var has_entity_empty_valid =true;
			var entity_valid =false;
			if (bSimpleEntity)
			{
				entity_valid = (GetIntVal(oStartNode.getAttribute("valid")) && valid)||bInitilize
			}	
			else
			{
				var sChkErrPath="//*[attribute::*[starts-with(name(.),'valid') and name(.)!='valid_entity_"+oStartNode.nodeName+"']='0']";
				sChkErrPath = (bRoot)? sChkErrPath:"." + sChkErrPath;
				entity_valid = (oStartNode.selectSingleNode(sChkErrPath)==null && valid)||bInitilize
			}
			
			//set entity level result
			var sValEntityAttr="valid_entity_" + oStartNode.nodeName;
			//chech if the entity is empty 
			var bEntityIsEmpty = (oStartNode.childNodes.length==0);
			if (bEntityIsEmpty && !emptyEntityValid) 
			{
				entity_valid = false;
				oResNode.setAttribute(sValEntityAttr, "0");
			}
			else
			{
				oResNode.setAttribute(sValEntityAttr, (entity_valid && !bInitilize)? "1":"0");
			}
			//if entity is empty set empty image 
			if (!bEntityIsEmpty && !bInitilize) 
				oResNode.setAttribute("valid_" + oStartNode.nodeName, (entity_valid)? G_imgValidEntity:G_imgInvalidEntity);		
			else
				oResNode.setAttribute("valid_" + oStartNode.nodeName, (bRoot)? G_imgInvalidEntity:G_imgEmpty);			
			
			//exit validation for entity
			return entity_valid;
		}
		//entity item level validation (eg. Customer, Product, etc.)
		var tab = new Object

		for (var i=0; i<oBR.childNodes.length; i++)
		{
			var brFld = oBR.childNodes(i);
			var fldpath = brFld.getAttribute("path");		
			var chkFld = oStartNode.selectSingleNode((fldpath)? fldpath:brFld.nodeName);
			if (chkFld && (brFld.getAttribute("entity") || brFld.getAttribute("complexfield"))) 
			{
				//read and initilize relevant tab result
				var tabName = brFld.getAttribute("tab");		
				if ((tabName!="")&&(tab[tabName]==null)) tab[tabName]= G_imgValidTab;
				//evaluate entity or complex field BRS and exit
				valid = EvaluateAppBRS(chkFld,false,bInitilize)||bInitilize;
				res = res && valid;
				if ((!valid)&&(tabName!="")) tab[tabName] = G_imgErrorTab;
				//oStartNode.setAttribute("valid_" + brFld.nodeName, (valid)? G_imgValid:G_imgError);
				//continue;
			}
			else
			{
				//get required validation rules
				var mandator = brFld.getAttribute("mandatory");		
				var custom = brFld.getAttribute("custom");		
				var params = brFld.getAttribute("params");		
				if (params==null) params=""; 
				//read and initilize relevant tab result
				var tabName = brFld.getAttribute("tab");
	
						
	
				if ((tabName!="")&&(tab[tabName]==null)) tab[tabName]= G_imgValidTab;
				//validate
				valid = (mandator=="1" && chkFld && !bInitilize)? CheckMandatoryFld(chkFld):true;
				valid = valid && ((custom && !bInitilize)? eval(custom + "(oStartNode"+params+");"):true);
				//mark tab where error
				if ((!valid)&&(tabName!="")) tab[tabName] = G_imgErrorTab;
				//keep result for entity item level		
				res = res && valid;
				//set field level result
				oStartNode.setAttribute("valid_" + brFld.nodeName, (valid)? G_imgValid:G_imgError);
			}
		}
		//set tab level result
		for (key in tab)
			if (key!="null") oStartNode.setAttribute(key, tab[key]);
		//set entity item level  result		
		oStartNode.setAttribute("valid",(res)? "1":"0");		
		oStartNode.setAttribute("validimg", (res)? G_imgEmpty:G_imgError);
	
		return res;
	}
	catch(e)
	{
		displayError(e,"EvaluateAppBRS");
	}
}

//==============================================================
//	Function Name:	CheckMandatoryFld
//	Parameters:		oFld - Html field
//	Return:			Boolean - flag indicating if node has a value
//	Description:	Returns true if a given field has a value
//==============================================================
function CheckMandatoryFld(oFld)
{
	try
	{
		var valid = !(oFld.text=="");
		return valid;
	}
	catch (e) 
	{ 
		displayError(e,"CheckMandatoryFld");
	}
}

//==============================================================
//	Function Name:	findParent
//	Parameters:		el - HTML element
//					sParentKey - (String) Parent elements name
//					bFindById - (Boolean) Flag indicating if parent should be found by name or ID
//	Return:			HTML Element - Parent element
//	Description:	Finds the parent element for a given HTML element
//==============================================================
function findParent (el, sParentKey, bFindById)
{
	try
	{
		var parEl = el.parentElement;
		sParentKey =  sParentKey.toLowerCase();
	
		if (bFindById)
		{
			while (parEl && parEl.id.toLowerCase() != sParentKey) 
				parEl = parEl.parentElement;
		}
		else
		{
			while (parEl && parEl.tagName.toLowerCase() != sParentKey) 
				parEl = parEl.parentElement;
		}
	
		return parEl;
	}
	catch (e) 
	{ 
		displayError(e,"findParent");
	}
}

//==============================================================
//	Function Name:	GetFloatVal
//	Parameters:		num - (Numeric) Number to get float value from
//	Return:			Number - float value
//	Description:	Parses a given number to a float if it is a number
//==============================================================
function GetFloatVal(num)
{
	try
	{
		return (isNaN(parseFloat(num)))? 0 : parseFloat(num);
	}
	catch (e) 
	{ 
		displayError(e,"GetFloatVal");
	}
}

//==============================================================
//	Function Name:	GetIntVal
//	Parameters:		num - (Numeric) Number to get integer value from
//	Return:			Number - integer value
//	Description:	Parses a given number to a integer if it is a number
//==============================================================
function GetIntVal(num)
{
	try
	{
		return (isNaN(parseInt(num,10)))? 0:parseInt(num,10);
	}
	catch (e) 
	{ 
		displayError(e,"GetIntVal");
	}
}

//==============================================================
//	Function Name:	DisableElement
//	Parameters:		el - HTML Element
//					bEnable	- (Boolean) Enable/ Disable flag
//	Return:			Nil
//	Description:	Disables or enables a given HTML element such as a text box
//==============================================================
function DisableElement(el, bEnable)
{
	try
	{
		if (!el) return;
		if (el.disabled==(!bEnable)) return;
	
		if (!el.oldClass) el.oldClass = el.className;
	
		var oParentTR = findParent(el, "tr");
		el.className=(bEnable)? el.oldClass:el.oldClass+oParentTR.className;
		el.disabled=(!bEnable);
	}
	catch (e) 
	{ 
		displayError(e,"DisableElement");
	}
	
}

//==============================================================
//	Function Name:	getListText
//	Parameters:		lbEl - List box
//	Return:			String - List boxs text value
//	Description:	returns selected text from a given list box
//==============================================================
function getListText(lbEl)
{
	try
	{
		return (lbEl.selectedIndex>-1)? lbEl.options(lbEl.selectedIndex).text : "";
	}
	catch (e) 
	{ 
		displayError(e,"getListText");
	}
}

//==============================================================
//	Function Name:	popup
//	Parameters:		sMsgKey - (String) Click Help key
//					oSrcEl - Source element
//					sBgColor - Background color
//	Return:			Nil
//	Description:	Shows a popup box containing given text or
//					text froma click help file
//==============================================================
//WR1970 - LHN - Function signature changed to accept the background color parameter
//function popup(sMsgKey, oSrcEl)
function popup(sMsgKey, oSrcEl, sBgColor)
{	
	try 
	{
		oSrcEl = (oSrcEl)? oSrcEl:event.srcElement;
		if (!oSrcEl) return;
		//check source element is image and it's not empty 
		if (oSrcEl.tagName=='IMG')
		{
			var sImg = new String(oSrcEl.src);
			var sNameOfEmpty = new String(G_imgEmpty);
			sNameOfEmpty = sNameOfEmpty.substr(2);
			if (sImg=='' || sImg.indexOf(sNameOfEmpty)>0) return;
		}
		var sMsgText = "";
		//lookup click help file
		var oMsg=xml_ClickHelp.XMLDocument.documentElement.selectSingleNode('//HlpMsg[@id="' + sMsgKey + '"]');
		sMsgText = (oMsg)? oMsg.text:sMsgKey;
		if (!sMsgText) return;
		
	//WR1970 - LHN - Added if condition for not adding the extra <table>,..etc tags for those which have the <table> already in the click help text - Start
		if((sMsgText.toUpperCase()).indexOf("<TABLE") != -1)
		{
			var sInnerHTML = sMsgText;
		}
		else
		{
			var sInnerHTML='<table><tr><td><div style="font:normal normal normal 8pt Arial" align="justify">' + sMsgText+ '</div></td></tr></table>';
		}
	//WR1970 - LHN - Added if condition for not adding the extra table,..etc tags for those which have the table already in the click help text - End
	
		//display dummy popup to find aout required height
		var oPopBody = G_oPopup.document.body;
		
	//WR1970 - LHN - To apply blue background color for the Show Legend and Online Application Exclusion click helps and lightyellow for all others - Start
		//oPopBody.style.backgroundColor = "lightyellow";
		if(sBgColor != null)
		{
			oPopBody.style.backgroundColor = sBgColor;
		}
		else
		{
			oPopBody.style.backgroundColor = "lightyellow";
		}
	//WR1970 - LHN - To apply blue background color for the Show Legend and Online Application Exclusion click helps and lightyellow for all others - End
		
		oPopBody.style.border = "solid black 1px";
		oPopBody.innerHTML = sInnerHTML;
		var realWidth = 300;
		G_oPopup.show(0, 0, realWidth, 0);
		var realHeight = oPopBody.scrollHeight;
		G_oPopup.hide();

		if (realHeight<=25) 
		{
			realWidth = sMsgText.length * ((sMsgText.length<=15)? 8:6);
			if (realWidth<50) realWidth = 50; 
		}
		
		// display popup
		oPopBody.innerHTML = sInnerHTML;
		oSrcEl = (oSrcEl)? oSrcEl:event.srcElement;
		G_oPopup.show(oSrcEl.width, oSrcEl.height, realWidth, realHeight, oSrcEl);
	}
	catch(e)
	{
		displayError(e,"popup");
	}
}

//==============================================================
//	Function Name:	ShowRefPopup
//	Parameters:		sAttribute - (String)Attribute name
//					sEl - Source Element
//	Return:			nil
//	Description:	Shows a popup box containg reference details
//==============================================================
function ShowRefPopup(sAttribute, sEl)
{
	try
	{
		var oTd=document.all(sEl);
		var sMsg=xml_master.XMLDocument.documentElement.getAttribute(sAttribute);
		popup(sMsg,oTd);
	}
	catch (e) 
	{ 
		displayError(e,"ShowRefPopup");
	}
}

//==============================================================
//	Function Name:	ConfirmDelete
//	Parameters:		sSpecialPrompt - (String) String containing special prompt
//	Return:			Vb yes/no message box
//	Description:	Shows a Vb yes/no message box asking to confirma delete
//==============================================================
function ConfirmDelete(sSpecialPrompt)
{
	try
	{
		var sPrompt = "Are you sure you want to delete this record?"
		if (sSpecialPrompt) sPrompt = sSpecialPrompt +"\n\n" + sPrompt;
		return (VBMsgBox(sPrompt, 52,"Confirm Delete")==6);
	}
	catch (e) 
	{ 
		displayError(e,"ShowRefPopup");
	}
}

//==============================================================
//	Function Name:	printScreen
//	Parameters:		Nil	
//	Return:			Nil
//	Description:	Prints the screen as it is currently seen
//==============================================================
function printScreen()
{
	try
	{
		var H = document.all.divScreenHld.style.height;
		document.all.divScreenHld.style.height='';
		window.print();
		document.all.divScreenHld.style.height=H;
	}
	catch (e) 
	{ 
		displayError(e,"printScreen");
	}
}


//==============================================================
//	Function Name:	ReformatDate
//	Parameters:		el - HTML element that contains a date
//	Return:			Nil
//	Description:	Reformats a date to long form
//==============================================================
function ReformatDate(el)
{
	try
	{
		el.value = VBFormatToLongDate(el.value);
	}
	catch (e) 
	{ 
		displayError(e,"ReformatDate");
	}
}

//==============================================================
//	Function Name:	TruncateToMaxLen
//	Parameters:		el - HTML Element containing text to truncate
//					MaxLen - Max length of field
//	Return:			Nil
//	Description:	Truncates the text in a given element to the
//					given max length
//==============================================================
function TruncateToMaxLen(el, MaxLen)
{
	try
	{
		var sVal = el.value;
		if (sVal.length>MaxLen) 
		{
			el.value=sVal.substr(0,MaxLen);
			VBMsgBox('Maximum number of characters has been reached. Your input has been reduced to fit.' ,G_iVB_WARNING, G_sAPPLICATION_TITLE);	
		}
	}
	catch (e) 
	{ 
		displayError(e,"TruncateToMaxLen");
	}
}

//==============================================================
//	Function Name:	SetFocusOnElement
//	Parameters:		sElement - HTML element to have focus set
//	Return:			Nil
//	Description:	Attempts to set focus repeatedly on a given element
//==============================================================
function SetFocusOnElement(sElement)
{
	StopFocusSet();
	try
	{
		var sSetFocus="FocusSet('document.all."+ sElement +"');";
		G_focusTimerID = window.setInterval(sSetFocus, 100); 
	}
	catch (e)
	{
		//Ignore errors
	}
}

//==============================================================
//	Function Name:	FocusSet
//	Parameters:		sElement - HTML element to have focus set 
//	Return:			Nil
//	Description:	Sets focus on the given HTML element
//==============================================================
function FocusSet(sElement)
{
	try
	{
		eval(sElement + ".focus();");
	}
	catch (e) 
	{ 
		//ignore error just reset timer
		StopFocusSet();
	}
}

//==============================================================
//	Function Name:	StopFocusSet
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Clears timer that calls FocusSet
//==============================================================
function StopFocusSet()
{
	try
	{
		if (G_focusTimerID!=0) window.clearInterval(G_focusTimerID);
	}
	catch (e)
	{
		//Ignore errors
	}	
}	

//==============================================================
//	Function Name:	ableToEvaluate
//	Parameters:		oDocEl - Document element of DSO
//	Return:			Boolean - Flag indicating if validation was successful
//	Description:	Checks if a file is able to validated. This effectivly
//					shows if a file is eMOS compliant or not. Returns a boolean
//					indicating if validation could be done rather then
//					if doc is valid
//==============================================================
function ableToEvaluate(oDocEl)
{
	var bRetVal=false;
	try
	{
		if (G_bSaveIsAllowed) EvaluateAppBRS(oDocEl);
		bRetVal=G_bSaveIsAllowed;	//will be 'true' if no error happend
	} 
	catch (e)
	{
		bRetVal=false;
	}
	return bRetVal;
} 

//==============================================================
//	Function Name:	initXMLObject
//	Parameters:		oXML = XML Dom object to be initialised
//	Return:			Nil
//	Description:	Sets up an XML Dom object to be synchronous
//					and have Xpath as its selection language
//==============================================================
function initXMLObject(oXML)
{
	try
	{
		if (!oXML.id) return;
		oXML.XMLDocument.async = false;
		oXML.XMLDocument.setProperty("SelectionLanguage","XPath");
	}
	catch (e) 
	{ 
		displayError(e,"initXMLObject");
	}
}

//==============================================================
//	Function Name:	resizeScreenHld
//	Parameters:		Nil
//	Return:			Nil
//	Description:	Resize screen handlers in the HTA
//==============================================================
function resizeScreenHld()
{
	try
	{
		var h=document.body.clientHeight;
		document.all.imgMenuBG.height = (h-538 > 0)? h-538:0;
		if (h-538 > 0) document.all.divScreenHld.style.height=h-84;
		if (h-84 > 0) document.all.tblWelcomeSplash.style.height=h-84;
	}
	catch (e) 
	{ 
		displayError(e,"resizeScreenHld");
	}
}

//==============================================================
//	Name:		DisplayTable
//	Purpose:	Shows the summary tables for initial screen load.
//				Used to avoid tables blinking 
//	Parameters:	oTbl - (HTML TABLE element) summary table element
//==============================================================
function DisplayTable(oTbl)
{
	try
	{
		if (oTbl.readyState=="complete" && oTbl.style.display!='block') 
			oTbl.style.display = 'block';
	}
	catch(e)
	{
		displayError(e,"DisplayTable");
	}	
}

//==============================================================
//	Name:		promptSaveProhibited
//	Purpose:	Formats and shows save prohibition message prompt.
//	Parameters:	sDetails - (string) name of details screen
//==============================================================
function promptSaveProhibited(sDetails)
{
	try
	{
		var sMsg;
		var sNL = '\r\n';
		var s2NL = sNL+sNL;
	
		if (sDetails=='Application')
		{
			sMsg = 'The save operation cannot be performed because an error has occurred previously.' + s2NL +
					'Please try to:' + sNL +
					'   -  Open the current application file, or' + sNL +
					'   -  Quit, re-start ANZ Online Applications and re-open the current application file' + sNL +
					'Both actions should return you to the last successful save of the current application file.';
		}
		else
		{
			sMsg = 'The save operation cannot be performed because an error has occurred within the ' + sDetails + ' Details screen.' + s2NL +
					'Please try to:' + sNL +
					'   -  Add or Edit the ' + sDetails + ' again, or' + sNL +
					'   -  Quit, re-start ANZ Online Applications and re-open the current application file' 
		}
	
		sMsg = sMsg + s2NL + 'If errors continue please call ANZ State Originator Services for your state.'
	
		VBMsgBox(sMsg , G_iVB_CRITICAL_ERROR, G_sERROR_TITLE);	
	}
	catch(e)
	{
		displayError(e,"promptSaveProhibited");
	}	
}


//==============================================================================
//	Function Name:	replaceAll
//	Parameters:		sSearchTxt - Text to be searched
//					rRegularExp - Regular Expression to find
//					sReplaceTxt - Text to be replaced
//	Return:			New text after replaced 
//	Description:	Find all characters in the search text matched the regular expression and replace with the replace text
//==============================================================================
function replaceAll(sSearchTxt, rRegularExp, sReplaceTxt)
{
	try
	{
		var sText = new String(sSearchTxt);
		return sText.replace(rRegularExp, sReplaceTxt);  
	}
	catch (e)
	{
		displayError(e,'replaceAll');
	}	
}

//==============================================================================
//	Function Name:	ShowContactWarn
//	Parameters:		
//	Return:			 
//	Description:	Shows the contact phone warn if contact phone number is blank
//==============================================================================
function ShowContactWarn()
{
	try
	{
		var bValidData=true;
		G_bStayInCustScreen=false;

		if (xml_master)
		{
			var oDocEl=xml_master.XMLDocument.documentElement;
			var oCustsNode=oDocEl.selectSingleNode("Customers");
			var iCustCount=oCustsNode.childNodes.length;
			var bReturnFrmFn
			if(iCustCount>0)
			{			
				for(var iIndex=0;iIndex<iCustCount;iIndex++)
				{
					var oCustNode=oCustsNode.childNodes(iIndex);
						
					if(oCustNode.selectSingleNode("CustomerID"))
					{
						bReturnFrmFn=checkContactNos(oCustNode);
						bValidData=bValidData && bReturnFrmFn;
					}
				}
			}
		}
		G_bStayInCustScreen=!bValidData
	}
	catch (e)
	{
		displayError(e,'ShowContactWarn');
	}
}


//==============================================================
//	Name:		LinkCustomers
//	Purpose:	Link the customer relation with Product 
//==============================================================
function LinkCutomerToProduct(oProductNode)
{
	try
	{
		
		var oCustsNode;								
		oCustsNode=xml_master.XMLDocument.documentElement.selectSingleNode("Customers"); 			          
		oCustsNode.transformNodeToObject(xsl_RelatedCustRefresh.XMLDocument, xml_temp.XMLDocument);
		
		ds_RelCusts.src=ds_RelCusts.src;
		
		ds_RelCusts.XMLDocument.replaceChild(xml_temp.XMLDocument.documentElement.cloneNode(true),ds_RelCusts.XMLDocument.documentElement)

		oProductNode.replaceChild(xml_temp.XMLDocument.documentElement.cloneNode(true),oProductNode.selectSingleNode("RelatedCustomers"));	

		FlushToDisk();

	}
	catch(e)
	{
		displayError(e,"LinkCutomerToProduct");
	}
}

//=======================================================================
//	Function Name:	SetLVRValue
//	Parameters:		nil
//	Return:			nil
//	Description:	Sets the LVR value to the application.
//======================================================================= 
function SetLVRValue() 
{
    try 
	{
        var iLVR;

        var oPurposeNode, oSecuritiesNode, oPurpose, oSecurity, oPFNode;
        var iTotalAmtSought, iExistingLoan, iTotSecurity;
        var sSecType;
        var iCustStatedValue, iSecValue;

        iTotalAmtSought = 0;
        iExistingLoan = 0;
        iTotSecurity = 0;

        oPurposeNode = xml_master.XMLDocument.documentElement.selectSingleNode('Purposes');

        oPFNode = xml_master.XMLDocument.documentElement.selectSingleNode('Portfolio')

        //Loop through the purposes to get the purpose amount
        if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '0') {
            for (var iIndex = 0; iIndex < oPurposeNode.childNodes.length; iIndex++) {
                oPurpose = oPurposeNode.childNodes(iIndex);
                iTotalAmtSought = iTotalAmtSought + parseInt(oPurpose.getAttribute("TotalAmount"));
            }
        }
        else
            iTotalAmtSought = parseInt(oPFNode.getAttribute('PortfolioAmount'));

        oSecuritiesNode = xml_master.XMLDocument.documentElement.selectSingleNode('Securities');

        //Loop through the securities to get the security value and the existing loan amounts.
        for (var iIndex = 0; iIndex < oSecuritiesNode.childNodes.length; iIndex++) {
            oSecurity = oSecuritiesNode.childNodes(iIndex);


            iExistingLoan = iExistingLoan + parseInt(oSecurity.selectSingleNode("ExistingLoanAmount").text);
            sSecType = oSecurity.selectSingleNode("SecurityType").text;
            if (sSecType == 'B') {
                iCustStatedValue = parseInt(oSecurity.selectSingleNode("CustomerStatedValue").text);
                iSecValue = parseInt(oSecurity.selectSingleNode("SecurityValue").text);
                if (iSecValue == 0)
                    iTotSecurity = iTotSecurity + iCustStatedValue;
                else
                    iTotSecurity = iTotSecurity + iSecValue;
            }
            else
                iTotSecurity = iTotSecurity + parseInt(oSecurity.selectSingleNode("SecurityValue").text);
        }

        //Calculate the LVR value
        iLVR = ((iTotalAmtSought + iExistingLoan) / iTotSecurity) * 100;
        iLVR = Number(iLVR);

        if (iTotSecurity == 0) {
            iLVR = "0.00";
        }
        else {
            if (isNaN(iLVR))
                iLVR = "0.00";
            else {
                //Round to two decimal points
                iLVR = VBRound(iLVR, 2);
            }
        }
        //Display
        xml_master.XMLDocument.documentElement.setAttribute('APPLVR', iLVR);
    }
    catch (e) 
    {
        displayError(e, "SetLVRValue");
    }
}
