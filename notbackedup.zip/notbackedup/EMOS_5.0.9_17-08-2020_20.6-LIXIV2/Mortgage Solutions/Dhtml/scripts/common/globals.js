//<!--==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Tim Heide
//	Workfile:  
//	ModTtime: 2003/03/04
//  File: common.js	
//============================================================-->
//<SCRIPT>
//Common File Global Variables
//Application
var G_sApplicationTitle;		// current application title
var G_sApplicationFilePath="";	// current application file path
var G_sCurScr="";				// current screen name 
var G_bShowingScreen= false;	// flag set to true during screen show process
var G_bLegend=false;			// flag set to true if legend is displayed
var G_oScreens = new Object;	// screens collection
var G_sCurrentVersion			// current version of the software
var G_sConfigType				// Current configuration of the editor. 'O' for Originator or 'F' for Mortgage Solutions
var G_Sub_Prd_Typ=0;            // to get the equity manager or new credit card with breakfree package. new tax residence req
var G_Product_Type="";			// to get the product type
var G_breakfree_Type="";        // to get the breakfree type value
var G_havebreakfree="";         // to get the customer have existing breakfree package yes/no
var G_taxcompanyname=[];        // to get the tax company names
var G_Cust_ID=""; // to get the customer ID customer selected in the screen to display tax resident australia yes/ no
var G_Customer_Type=""; //to get the type of the customer
var G_Tax="";                    //to get the tax resident yes/no
//Common
var G_bSaveIsAllowed = false;
var G_pScreenSaveFunction=null;
var G_bDEBUG_MODE=false;
var G_sAPPLICATION_TITLE = "ANZ Online Applications"
var G_sAppWindowTitle; 
var G_sERROR_TITLE="ANZ Online Applications Error";
var G_iVB_WARNING=48;
var G_iVB_CRITICAL_ERROR=16;
var G_iVB_INFO=64;
var G_oPopup = window.createPopup();
var G_focusTimerID = 0;

//validation 
var G_imgValidTab;
var G_imgErrorTab;
var G_imgValidEntity;
var	G_imgInvalidEntity;
var G_imgError;
var	G_imgValid;
var G_imgEmpty="";

//file access
var G_oXML = new ActiveXObject("MSXML2.DOMDocument");
var gc_FileMustExist = 4096;
var gc_OverwritePrompt = 2;

//Reference Data 
var G_COMPANY = "10";					// global company variable
var oxmlRefData = null;					// XML DOM of the ref data cache
var G_oCompanyOptions = new Object;		// company options

var G_sDiscPackDesc;		//selected Discount Package Description
var G_sDiscPackValue;		//selected Discount Package value
var G_LoDocValue;			//LodDocApplication value
var G_ReasonForInterestOnly; 			//These variables are added as part of Release 15.7 in APRA change
var G_OtherReasonForInterestOnly; 

//WR1970 - For setting default values for Property Tenure and Property Zoning

//Security
var G_sPropTenureDefault = "F";			//global Property Tenure Default
var G_sPropZoningDefault = "R";			//global Property Zoning Default


//WR1970 - For Stoping moving between screens after pressing cancel from customer screen
var G_bStayInCustScreen=false;

//WR1970 - For Stoping moving between screens after pressing cancel from security screen
var G_bStayInSecScreen=false;

//WR1970 - For setting the values for Loan Package and Lo Doc
var G_sDiscPackDesc="";		//selected Discount Package Description
var G_sDiscPackValue="";	//selected Discount Package value
var G_LoDocValue=0;			//LodDocApplication value
var G_BrkFreeCardLt=0;		//Break free credit card limit
var G_BrkFreeCardOpt="";	//Break free credit card option
var G_ACHBrkFreeCard = ""; // Added for Secondary Card Holder Tax Resident

var SOPMasterXML = ""; // Added for SOP Asset and Security Address Field Validation
