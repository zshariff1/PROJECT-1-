//============================================================================
//	Function Name:	ValLimitAmount
//	Parameters:		oProdLoan - <DepositDetails> node under <Product> node
//	Return:			Validation boolean
//	Description:	Validate Product-DDA's LimitAmount
//============================================================================
function ValPfLimitAmount(oPort)
{
	try
	{
		if (!oPort.hasChildNodes) return true;
		var valid = false;
		var nLimitAmt = GetIntVal(oPort.getAttribute("PortfolioAmount"));
		var minAmt = 0;
		var maxAmt = 999999999;
		valid = ((nLimitAmt > minAmt) && (nLimitAmt <= maxAmt));
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValPfLimitAmount');
	}
}

//============================================================================
//	Function Name:	ValPfLimitEndDate
//	Parameters:		oPort - Portfolio Details Node
//	Return:			Validation boolean
//	Description:	Validate portfolio limit end date for a valid business day
//	Modified: Holiday check code is added to fix the IE9 issue
//============================================================================
function ValPfLimitEndDate(oPort)
{
	var bValid;
	try
	{
		if (!oPort.hasChildNodes) return true;
		if (oPort.selectSingleNode("PfNoEndDate").text != 0) return true;		
//		return VBValidPFLimitEndDate(oPort.selectSingleNode("PfLimitEndDate").text);
		bValid = VBValidPFLimitEndDate(oPort.selectSingleNode("PfLimitEndDate").text);
			if (bValid == true)
			{
				if (getSingleRDRow("A_TSR_HOLIDAYS","@H_DAY='" + oPort.selectSingleNode("PfLimitEndDate").text + "'") == null)
				{
					bValid = true;
				}
				else
				{
					bValid = false;
				}
			}
	return bValid;
	}
	catch (e)
	{
		displayError(e,'ValPfLimitEndDate');
	}

}

//============================================================================
//	Function Name:	ValPfLimitEndDate
//	Parameters:		oPort - Portfolio Details Node
//	Return:			Validation boolean
//	Description:	Validate portfolio Package Tier
//============================================================================
function ValPfPackageTier(oPort)
{
	try
	{
		var valid=true;
		if (!oPort.hasChildNodes) return valid;
		if (oPort.getAttribute("SubProdCount")!=null)
		{
			var iSubProdCount=oPort.getAttribute("SubProdCount")
			var iPackageTier=(oPort.selectSingleNode("PfPackageTier").text=="005")? 5:12
			if(iPackageTier<iSubProdCount)
				valid=false;
		}
		
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValPfPackageTier');
	}
	

}




