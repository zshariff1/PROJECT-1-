//<script>
//==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Tim Heide
//	Workfile:  
//	ModTtime: 2003/03/04
//  File: ValSecurity.js	
//============================================================

//==============================================================
//	Function Name:	ValAccNumber
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag
//	Purpose:		Validate the account number
//==============================================================
function ValAccNumber(oSec)
{
	try
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "B") return true;
		var sAccNum = oSec.selectSingleNode("AccountNumber").text;
		var oSecType = getSingleRDRow ("A_TS_SEC_TYPES", "@TYPE_CODE='" + sSecTypeCode + "'");
		var sDepProd = VBTrim(oSecType.getAttribute("DEPOSIT_PRODUCT"));
		var bDepProd = (sDepProd.length!=0);
		
		return (bDepProd)? (sAccNum!=""):true;
	
	}
	catch (e)
	{
		displayError(e,"ValAccNumber");
	}
	
}

//==============================================================
//	Function Name:	ValPropBasedSecFld
//	Parameters:		oSec - (XML Node) Security node
//					sNodeName - (string) name of property based field
//					sCompOpt - (string) company option field name
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that this property based field has a value
//==============================================================
function ValPropBasedSecFld(oSec,sNodeName,sCompOpt) {
	
	try 
	{
		var Valid;
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "B") return true;
		var bCompOptOK = (sCompOpt.length>0)? (eval("G_oCompanyOptions."+sCompOpt)!="N"):true; 
		var sNodeText = oSec.selectSingleNode(sNodeName).text;
		var bPropBased = (oSec.getAttribute("PropBased")!="0");
		Valid = (bPropBased)? (sNodeText!=""):true;
		var sSecTypeZone = oSec.selectSingleNode("PropertyZoning").text;
		var sSecTypeType = oSec.selectSingleNode("PropertyType").text;
		if (sNodeName == 'PropertyType')
		{
		if(sSecTypeZone == 'R' && ((sSecTypeType == 'ConvertedCommercialProperty') || (sSecTypeType == 'ConvertedMotelUnits') || (sSecTypeType == 'ConvertedIndustrialProperty') ))
		{
			Valid = false;
		}
		if(sSecTypeZone == 'C' && ((sSecTypeType == 'VacantLand') || (sSecTypeType == 'RetirementVillage')))
		{
			Valid = false;
		}
		}
		return Valid;
	}
	catch (e)
	{
		displayError(e,"ValPropBasedSecFld");
	}
}

//==============================================================
//	Function Name:	ValSecDesc1
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag			
//	Purpose:		Validate that security description 1 has a value
//==============================================================
function ValSecDesc1(oSec) 
{
	try
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		
		//WR1970 - Mandatory only when Security Type = Registered Mortgage
		if(sSecTypeCode != "B") return true;
		
		var sSecDesc1 = oSec.selectSingleNode("SecurityDescription1").text; 
		var bPropBased = (oSec.getAttribute("PropBased")!="0");
		var bShareMort = isSharedMortgage(sSecTypeCode);
		
		return (!bPropBased || bShareMort)? (sSecDesc1!=""):true;
	}
	catch (e)
	{
		displayError(e,"ValSecDesc1");
	}
}

//==============================================================
//	Function Name:	ValSecNature
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that Sec nature has a value if security type = "O"
//==============================================================
function ValSecNature(oSec) {
	try 
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "B") return true;
		var sSecNature = oSec.selectSingleNode("NatureOfSecurity").text;
		
		return (sSecTypeCode=="O")? (sSecNature!=""):true;
	}
	catch (e)
	{
		displayError(e,"ValSecNature");
	}
}

//==============================================================





//==============================================================
//	Function Name:	ValSecFMV
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag		
//	Purpose:		validate that FMV is correct
//==============================================================
function ValSecFMV(oSec) {
	try 
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		var oSecType = getSingleRDRow ("A_TS_SEC_TYPES", "@TYPE_CODE='" + sSecTypeCode + "'");
	
		var bProbBased = (oSec.getAttribute("PropBased")!="0");
		if (oSecType!=null)
		{
			var bSecFMVApplicable = (oSecType.getAttribute("FMV_APPLICABLE")!="0");
		}
		var bPropPurch = (oSec.selectSingleNode("PropertyPurchase").text!="0");
		var iFMV = GetIntVal(oSec.selectSingleNode("SecurityValue").text);
	
		var bRet=true;
	
		if (bSecFMVApplicable)
		{
			if (bProbBased)
			{
				if (bPropPurch)
					bRet = (iFMV>0);
			}
			else
			{
				bRet= (sSecTypeCode=="O")? true:(iFMV>0);
			}
			
		}
		
		return bRet;
	}
	catch (e)
	{
		displayError(e,"ValSecFMV");
	}	
}

//==============================================================
//	Function Name:	ValSecCSV
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag		
//	Purpose:		validate that CSV is correct
//==============================================================
function ValSecCSV(oSec) {
	try 
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "B") return true;
		var bCompOptOK = (G_oCompanyOptions.SEC_CUS_STAT_VAL!="N");
		var bPropPurch = (oSec.selectSingleNode("PropertyPurchase").text!="0");
		var bProbBased = (oSec.getAttribute("PropBased")!="0");
		var iCSV = GetIntVal(oSec.selectSingleNode("CustomerStatedValue").text);
		//alert(!bPropPurch + "  ===> " + bProbBased);
		return (bCompOptOK && bProbBased)? (iCSV>0):true;
		//return (bCompOptOK && bProbBased && !bPropPurch)? (iCSV>0):true;
	}
	catch (e)
	{
		displayError(e,"ValSecCSV");
	}
}

//==============================================================
//	Function Name:	ValSecTLV
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag			
//	Purpose:		validate that TLV is correct
//==============================================================
function ValSecTLV(oSec) {
	try 
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "B") return true;
		var bPropPurch = (oSec.selectSingleNode("PropertyPurchase").text!="0");
		var iTLV = GetIntVal(oSec.selectSingleNode("TransferOfLandValue").text);
		
		return (bPropPurch)? (iTLV>0):true;
	}
	catch (e)
	{
		displayError(e,"ValSecTLV");
	}
}

//==============================================================
//	Function Name:	ValSecContractOfSaleDate
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that the date is valid
//==============================================================
function ValSecContractOfSaleDate(oSec) {
	try 
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "B") return true;
		var bProbBased = (oSec.getAttribute("PropBased")!="0");
		var sCoSDate = oSec.selectSingleNode("ContractOfSaleDate").text;
		
		return (bProbBased && (sCoSDate!=""))? VBValidNonFutureDate(sCoSDate):true;
	}
	catch (e)
	{
		displayError(e,"ValSecContractOfSaleDate");
	}
}

//==============================================================
//	Function Name:	ValSecFirstMortgageValue
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag		
//	Purpose:		validate first mortgagevalue is correct and applicable	
//==============================================================
function ValSecFirstMortgageValue(oSec) {
	try 
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		var oSecType = getSingleRDRow ("A_TS_SEC_TYPES", "@TYPE_CODE='" + sSecTypeCode + "'");
		if (oSecType!=null)
		{
			var bFirstMortVal = (oSecType.getAttribute("M1V_APPLICABLE")!="0");
		}	
		var i1stMV = GetIntVal(oSec.selectSingleNode("FirstMortgageValue").text);
		//WR1970 - Mandatory only if security type = Registered Mortgage
		if(sSecTypeCode != "B") return true;
		
		return (bFirstMortVal)? (i1stMV>0):true;
	}
	catch (e)
	{
		displayError(e,"ValSecFirstMortgageValue");
	}
}

//==============================================================
//	Function Name:	ValSecFirstMortgagee
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate the a first mortgagee is present for sec type 'Sec Reg Mort'
//==============================================================
function ValSecFirstMortgagee(oSec) {
	try 
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "B") return true;
		var bReq = (oSec.selectSingleNode("SecurityType").text=="C");
		var s1stMort = oSec.selectSingleNode("FirstMortgagee").text;
		
		return (bReq)? (s1stMort!=""):true;
	}
	catch (e)
	{
		displayError(e,"ValSecFirstMortgagee");
	}
}

//==============================================================
//	Function Name:	ValSecOtherFirstMortgagee
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that other first mort is present if applicable
//==============================================================
function ValSecOtherFirstMortgagee(oSec) {
	try 
	{
		var bReq = (oSec.selectSingleNode("SecurityType").text=="C");
		var b1stMortOther = (oSec.selectSingleNode("FirstMortgagee").text=="05");
		var s1stMortOther = oSec.selectSingleNode("OtherFirstMortgagee").text;
		
		return (bReq && b1stMortOther)? (s1stMortOther!=""):true;
	}
	catch (e)
	{
		displayError(e,"ValSecFirstMortgagee");
	}
}

//==============================================================
//	Function Name:	ValSecGuarAmt
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag		
//	Purpose:		validate first guarantee amount is correct and applicable
//==============================================================
function ValSecGuarAmt(oSec) {
	try 
	{
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		var oSecType = getSingleRDRow ("A_TS_SEC_TYPES", "@TYPE_CODE='" + sSecTypeCode + "'");
		if (oSecType!=null)
		{
			var bGuarAmtApp = (oSecType.getAttribute("GAMT_APPLICABLE")!="0");
		}
		var bGuarUnlimited = (oSec.selectSingleNode("GuaranteeUnlimited").text=="-1");
		var iGuarAmt = GetIntVal(oSec.selectSingleNode("GuaranteeAmount").text);
		
		return (bGuarAmtApp && !bGuarUnlimited)? (iGuarAmt>0):true;
	}
	catch (e)
	{
		displayError(e,"ValSecGuarAmt");
	}
}

//==============================================================
//	Function Name:	ValSecAddrID
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Vali flag		
//	Purpose:		Validate security address ID
//==============================================================
function ValSecAddrID(oSec) {
	try 
	{	
		//WR1970
		//If Security Type selected is not Registerd Mortgage then return true as address
		//is disabled
		var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "B") return true;
		
		//If security details TBA is true then return true as address is optional
		var bSecTBA = (oSec.selectSingleNode("SecurityDetailsTBA").text=="-1");		
		if (bSecTBA) return true;
		
		var bProbBased = (oSec.getAttribute("PropBased")!="0");
		var bSharedMort = isSharedMortgage(sSecTypeCode);
		var bReq = (bProbBased && !bSharedMort);
		var valid_SameSecMapAddr = ValMapSecAddress(oSec); // Validates Securities with Same Addresses
		var sAddrID = oSec.selectSingleNode("AddressID").text;
		
		var validAdr = true;
		// Start for VALID STREET TYPE
		if(sAddrID != "")
		{
			var valid_StreetType = ValidateStreetTypeAddr(sAddrID); // Validates Street Type in Securities
			if(valid_StreetType)
			{
				var isMap_SecAst = ValSecAstMap_Addr(sAddrID); // Validates Securities with Asset Addresses
				validAdr = isMap_SecAst;
			}
			else
			{
				validAdr = false;
			}	
		}
		else {
			validAdr = false;
			
		}
		return validAdr;
		// Ends for VALID STREET TYPE
		
	}
	catch (e)
	{
		displayError(e,"ValSecAddrID");
	}
}


function ValSecAstMap_Addr(sAddrID)
{
	try
	{
		var isDup_Ast = true;
		var oMDocEl=xml_master.XMLDocument.documentElement;
		if(oMDocEl.selectNodes("//StatementsOfPosition/StatementOfPosition").length > 0)
		{
			var oSOPCnt = oMDocEl.selectNodes("StatementsOfPosition/StatementOfPosition");
			if(oSOPCnt.length > 0){
				for(var jsop=0; jsop < oSOPCnt.length; jsop++){
					var oAssetsAddrCnt = oSOPCnt(jsop).selectNodes("Assets/Asset[AssetType='003']");
					if(oAssetsAddrCnt.length > 0){
						for(var j=0; j < oAssetsAddrCnt.length; j++){	
							var AssetAddrID = oAssetsAddrCnt(j).selectSingleNode("AssetLinkedPropAddr").text;
							if(AssetAddrID == sAddrID) {
								isDup_Ast = false;
								break;
							}
						}
						if(isDup_Ast==false)
						{
							break;
						}
					}
				}
			}
		}
		return isDup_Ast;
	}
	catch (e)
	{
		displayError(e,"ValSecAstMap_Addr");
	}
}



//WR1970 - Added new functions for validating Securit Given By and Securities Combination
//==============================================================
//	Function Name:	ValSecGivenBy
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid flag		
//	Purpose:		Validate security given by
//==============================================================
function ValSecGivenBy(oSec)
{
	try
	{
		
		var oSecGivenBy=oSec.selectNodes('SecuritiesGivenBy/SecurityGivenBy[@Linked="-1" and CustomerID!=""]');
		if(oSecGivenBy.length > 0) return true;
	}
	catch(e)
	{
		displayError(e, "ValSecGivenBy");
	}
}

//==============================================================
//	Function Name:	ValSecuritiesCombination
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid flag		
//	Purpose:		Validate security type guidelines
//==============================================================
function ValSecuritiesCombination(oSec)
{
	try
	{
	
		//validates combination of the customers types
		var iRegMortCount = 0;	
		var valid=true;	
	
		var oSecList = xml_master.XMLDocument.selectNodes("//Securities/Security");
	
		for (i=0; i<oSecList.length; i++)
		{
			var oSec=oSecList(i);
			var sSecType = oSec.selectSingleNode("SecurityType").text;
			if (sSecType.length>0)
			{
				if(sSecType == "B") iRegMortCount++;
				
				//var oSecGivenBy = oSec.selectNodes('SecuritiesGivenBy/SecurityGivenBy[@Linked="-1"]');
				//if(oSecGivenBy.length > 0) iSecGivenByCount++;
			}
			 else
			 {
				allvalid = false;
				break;
			 }
		} 
		if (oSecList.length)
		{
			valid = valid && (iRegMortCount>0);			
		}
		
		return valid;
	}
	catch(e)
	{
		displayError(e, "ValSecuritiesCombination");
	}
}

//==============================================================
//	Function Name:	ValSecAddInfo - Rental Income
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid flag		
//	Purpose:		Validate Rental Income 
// Card - 260 Starts -->
//==============================================================
function ValSecAddInfoRental(oSec){
	try{
			var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
			if((sSecTypeCode.length > 0) && (sSecTypeCode != "B"))  return true;
			if((oSec.selectSingleNode("SecRentalIncome") != null))
				var sSecRentalIncome = oSec.selectSingleNode("SecRentalIncome").text;
					if((sSecRentalIncome != '') && (sSecRentalIncome != undefined))
						return (sSecTypeCode && sSecRentalIncome);
	}
	catch(e)
	{displayError(e, "ValSecAddInfoRental");}
}

//==============================================================
//	Function Name:	ValSecAddInfo - Floor Area Land 
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid Flag			
//	Purpose:		validate that Floor Area Land  is correct
//==============================================================
function ValSecAddInfoFloor(oSec) {
	try {
		
			var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
			if((sSecTypeCode.length > 0) && (sSecTypeCode != "B"))  return true;
			if((oSec.selectSingleNode("SecFloorAreaLand") != null) && (oSec.selectSingleNode("SecFloorAreaLand") != undefined))
				var sSecFloorAreaLand = oSec.selectSingleNode("SecFloorAreaLand").text;
					if((sSecFloorAreaLand != '') && (sSecFloorAreaLand != undefined))
						return sSecTypeCode && sSecFloorAreaLand;
		}
	catch (e)
	{	displayError(e,"ValSecAddInfoFloor"); }
}

// Card - 260 Ends -->
//==============================================================
//	Function Name:	        ValSecInvestmentExpense
//	Parameters:		oSec - (XML Node) Security node
//	Return:			Boolean - Valid flag		
//	Purpose:		Validate Investment Expense 
//Card - 784 Start
//=============================================================
function ValSecInvestmentExpense(oSec){
	try{
			var valid = true;
			var sSecProUse = oSec.selectSingleNode("PropertyUse").text;
			var sSecProZone = oSec.selectSingleNode("PropertyZoning").text;
			if (sSecProZone=='F')
			{
				sSecProZone=='R'
			}
			
			
			if ((sSecProUse=='I')  && (sSecProZone=='R'))
			{
				var sNodeText = oSec.selectSingleNode("SecInvestmentExpense").text;
				
				valid = (sNodeText!="" && sNodeText>=0)? true : false;
				
			}
			
			
			return valid;
	}
	catch(e)
	{displayError(e, "ValSecInvestmentExpense");}
}
//Card 784 Ends

//==============================================================
//	Function Name:	ValCityStatePCProperty
//	Parameters:		oSec- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the City,State & PinCode
//==============================================================
function ValCityStatePCProperty(oAddr)
{
  try
  
	{
  
		var valid = false;
		
		if (!oAddr) return valid;
		var bCheckedTBA = (oAddr.selectSingleNode("SecurityDetailsTBA").text==0);
		if(bCheckedTBA) 
			return true;
		else
		{ 
			//must be valid combination
			var sCity = oAddr.selectSingleNode("SecurityTBASubUrb").text.toUpperCase();
			var sState = oAddr.selectSingleNode("SecurityTBAState").text;
			var sPC = oAddr.selectSingleNode("SecurityTBAPostCode").text;
			valid = !(sCity=="") && !(sState=="") && !(sPC=="")
			if(valid)
			{
				// ensure that no invalid ' string combinations appear in the search string
				sCity = sCity.replace(/"/g, '');
				sState = sState.replace(/"/g, '');
				var sCheck='@P="' + sPC + '" and @C="' + sCity + '" and @S="' + sState +'"';
				valid = (getSingleRDRow("A_E_TSR_PC", sCheck)!=null);
			}
		}
			
		return valid;	
	}
	catch (e)
	{
		displayError(e,"ValCityStatePCProperty");
	}
}



//==============================================================
//	Function Name:	ValCity
//	Parameters:		oSec- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the city
//==============================================================
function ValCity(oSec)
{
	try
	{
		return ValSecFld(oSec,"SecurityTBASubUrb","@C");
	}
	catch (e)
	{
		displayError(e,"ValCity");
	}
}

//==============================================================
//	Function Name:	ValState
//	Parameters:		oSec- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the state
//==============================================================
function ValState(oSec)
{
	try
	{
		return ValSecFld(oSec,"SecurityTBAState","@S");
	}
	catch (e)
	{
		displayError(e,"ValState");
	}
}

//==============================================================
//	Function Name:	ValPostcode
//	Parameters:		oSec- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the postcode
//==============================================================
function ValPostcode(oSec)
{
	try
	{
		return ValSecFld(oSec,"SecurityTBAPostCode","@P");
	}
	catch (e)
	{
		displayError(e,"ValPostcode");
	}
}

//==============================================================
//	Function Name:	ValSecFld
//	Parameters:		oSec - (XML Node) Address node
//					sFldName - (string) DSO field name
//					sAttr - (string) Ref data attribute name
//	Return:			Boolean - Valid flag
//	Description:	Validates given address fields
//==============================================================
function ValSecFld(oSec,sFldName,sAttr)
{
	
	try
	{
		var valid = false;
		
		if (!oSec) return valid;
		var bCheckedTBA = (oSec.selectSingleNode("SecurityDetailsTBA").text==0);
		if(bCheckedTBA) 
			return true;
		else
		{ 
		var bFldName = (oSec.selectSingleNode(sFldName).text=="");
		valid = !(bFldName)
		
		if(valid)
		 {
			//must be not empty and valid
			var sVal = oSec.selectSingleNode(sFldName).text.toUpperCase();
			if(!(sVal=="") && !(sVal==-"1")) 
			{
				//valid = true;
				//check ref data
			
				// ensure that no invalid ' string combinations appear in the search string
				sVal = sVal.replace(/"/g, '');
				valid = valid && (getSingleRDRow("A_E_TSR_PC", sAttr + '="' + sVal + '"')!=null)
			}
			else valid = false;
		 }				
	}
		return valid;		
	}
	catch (e)
	{
		displayError(e,"ValSecFld");
	}
}

//==============================================================
//	Function Name:	ValTypeofGaurantee
//	Parameters:		oGType - (XML Node) Sec Type node
//					sNodeName - (string) name of property based field
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that this Sec Guarantee type field has a value
//==============================================================
function ValTypeofGaurantee(oGType, node) {
	
	try 
	{
		var valid = false;
		var sSecTypeCode = oGType.selectSingleNode("SecurityType").text;
		if(sSecTypeCode != "D") 
			valid = true;
		else
		{
			var sNodeText = oGType.selectSingleNode(node).text;
			
			valid = (sNodeText!="")? true : false;
						
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,"ValTypeofGaurantee");
	}
}


//==============================================================
//	Function Name:	ValMapSecAddress _ Multiple Securities with Same Address
//	Parameters:		
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that this Sec Address which should be Unique
//==============================================================
function ValMapSecAddress(oSec)
{
	try
	{
		// Started for Validating Same Address in Multiple Security of Reg Mortgage  - Starts
		
		var oMDocEl=xml_master.XMLDocument.documentElement;
		var oSecRMAddrList = oMDocEl.selectNodes('Securities/Security[SecurityType = "B"]'); //AddressID
		if(oSecRMAddrList.length > 1)
		{
			// Chekc the Security Type , IF it is (D,A) return
			var sSecTypeCode = oSec.selectSingleNode("SecurityType").text;
			if(sSecTypeCode != "B") {return;}
			else{
				var Sec_TBA_AdrID = oSec.selectSingleNode("SecurityDetailsTBA").text;
				// If Security Type is TBA and When Address should be cleared
				if(Sec_TBA_AdrID == "-1")
				{
					oSec.selectSingleNode("AddressID").text = "";
					oSec.setAttribute('AddressDtls',"");
				}
				var Sec_J_AdrID = oSec.selectSingleNode("AddressID").text;
				var Sec_J_SecID = oSec.selectSingleNode("SecurityID").text;
				for (i=0; i<oSecRMAddrList.length; i++)
				{
					var Sec_I_AdrID = oSecRMAddrList(i).selectSingleNode("AddressID").text;
					var Sec_I_SecID = oSecRMAddrList(i).selectSingleNode("SecurityID").text;
					// Check Security Id Matched or Not
					if(Sec_I_SecID != Sec_J_SecID)
					{
						if((VBTrim(Sec_J_AdrID) != "") && (VBTrim(Sec_I_AdrID) != ""))
						{
							// Check Address is Matched or Not
							if ((Sec_J_AdrID == Sec_I_AdrID))
							{
								oSec.selectSingleNode("AddressID").text = "";
								oSec.setAttribute('AddressDtls',"");
							}
						}
					}
				}
			}			
		}
		return;
		// Ended for Validating Same Address in Multiple Security of Reg Mortgage  - Ends
	}
	catch (e)
	{
		displayError(e,"ValMapSecAddress");
	}
}

