//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		E.Elutin
//	Workfile:	validations.js
//	ModTtime:	04/03/2003
//============================================================-->
//<SCRIPT>

//==============================================================
//	Name:		VE_IntegerOnly
//	Purpose:	Prohibits enetering non digits
//==============================================================
function VE_IntegerOnly()
{
	try
	{
		var KeyCode=window.event.keyCode;
		if (KeyCode<48||KeyCode>57) window.event.keyCode=0;
	}
	catch(e)
	{
		displayError(e,"VE_IntegerOnly");
	}
}

//==============================================================

//==============================================================
//	Name:		VE_Date
//	Purpose:	Prohibits enetering any symbol other than 
//				digits or slash (/) symbol
//==============================================================
function VE_Date()
{
	try
	{
		if (window.event.keyCode<47||window.event.keyCode>57) window.event.keyCode=0;
	}
	catch(e)
	{
		displayError(e,"VE_Date");
	}
}

//==============================================================
//	Name:		ValidateInteger
//	Purpose:	Validates that the numeric value shoud be beetween
//				required minimum and maximum, sets the valid value 
//				back to the input box.
//	Parameters:	nMin - (numeric) required minimum
//				nMax - (numeric) required maximum
//==============================================================
function ValidateInteger(nMin, nMax)
{
	try
	{
		var bRet=true;
		var oInpBox=window.event.srcElement
		var nValue=GetIntVal(oInpBox.value);
		if (nValue<nMin) 
		{	
			nValue = nMin; 
			bRet=false;
		}
		if (nValue>nMax) 
		{	
			nValue = nMax;
			bRet=false;
		}
		oInpBox.value = nValue;
	}
	catch(e)
	{
		displayError(e,"ValidateInteger");
	}
}

//==============================================================
//	Name:		VE_NoSpaces
//	Purpose:	Prohibits enetering space symbol
//	Parameters:	none
//==============================================================
function VE_NoSpaces()
{
	try
	{
		if (window.event.keyCode==32) window.event.keyCode=0;
	}
	catch(e)
	{
		displayError(e,"VE_NoSpaces");
	}
}

//==============================================================
//	Name:		VE_NoDecimalPoints
//	Purpose:	Prohibits enetering decial point (.) symbol
//	Parameters:	none
//==============================================================
function VE_NoDecimalPoints()
{
	try
	{
		if (window.event.keyCode==46) window.event.keyCode=0;
	}
	catch(e)
	{
		displayError(e,"VE_NoDecimalPoints");
	}
}

//==============================================================
//	Name:		RemoveSpaces
//	Purpose:	Removes spaces from the entered  value, 
//				sets the valid value back to the input box.
//==============================================================
function RemoveSpaces()
{
	try
	{
		var ver = Number(ScriptEngineMajorVersion() + "." + ScriptEngineMinorVersion())
		if (ver >= 5.5)
		{
       		var oInpBox=window.event.srcElement;
			var sValue=String(oInpBox.value);
			var re = / /g;
			oInpBox.value = sValue.replace(re, '');
		}
	}
	catch(e)
	{
		displayError(e,"RemoveSpaces");
	}
}

//==============================================================
//	Name:		RemoveDecimals
//	Purpose:	Removes decimal points from the entered  value, 
//				sets the valid value back to the input box.
//==============================================================
function RemoveDecimals()
{
	try
	{
		var oInpBox=window.event.srcElement;
		var sValue=String(oInpBox.value);
		oInpBox.value = VBReplace(sValue,".","");
	}
	catch(e)
	{
		displayError(e,"RemoveDecimals");
	}
}


//==============================================================
//	Name:		ReplaceDblSpaces
//	Purpose:	Replace double spaces from the entered  value with single space, 
//				sets the valid value back to the input box.
//==============================================================
function ReplaceDblSpaces()
{
	try
	{
		var ver = Number(ScriptEngineMajorVersion() + "." + ScriptEngineMinorVersion())
		if (ver >= 5.5)
		{
       		var oInpBox=window.event.srcElement;
			var sValue=String(oInpBox.value);
			var re = /  */g;
			oInpBox.value = sValue.replace(re, ' ');
		}
	}
	catch(e)
	{
		displayError(e,"ReplaceDblSpaces");
	}
}

//==============================================================
//	Name:		TrimSpaces
//	Purpose:	Trims white space characters from the start and 
//				end of strings
//==============================================================
function TrimSpaces()
{
	try
	{

       	var oInpBox=window.event.srcElement;
		var sValue=String(oInpBox.value);
		oInpBox.value = VBTrim(sValue);

	}
	catch(e)
	{
		displayError(e,"TrimSpaces");
	}
}

//==============================================================
//	Name:		VE_IntegerDecimalOnly
//	Purpose:	Prohibits enetering non digits
//==============================================================
function VE_IntegerDecimalOnly()
{
	try
	{
		var KeyCode=window.event.keyCode;
		if (KeyCode != 46 && KeyCode > 31 && (KeyCode<48||KeyCode>57)) window.event.keyCode=0.00;
	}
	catch(e)
	{
		displayError(e,"VE_IntegerDecimalOnly");
	}
}

//==============================================================
//	Name:		ValidateIntegerDecimal
//	Purpose:	Validates that the value should be numeric and
//				accept decimals. 2 digits after decimal. sets the value
//				back to the input box.
//	Parameters:	nMin - (numeric) required minimum
//				nMax - (numeric) required maximum
//==============================================================
function ValidateIntegerDecimal()
{
	try
	{
		var oInpBox=window.event.srcElement
		oInpBox.value = (isNaN(oInpBox.value)) ? oInpBox.value : (+oInpBox.value).toFixed(2);
		//Converted to float & Round to two decimal points
		oInpBox.value = (isNaN(oInpBox.value) || oInpBox.value.indexOf(".")<0) ? "0.00" : parseFloat(oInpBox.value).toFixed(2);
	}
	catch(e)
	{
		displayError(e,"ValidateIntegerDecimal");
	}
}

//==============================================================
// Name:                  ValidateRemoveZeroInt
// Purpose:              Prohibits entering only Numbers not Zero's
//==============================================================
function ValidateRemoveZeroInt(nMin, nMax)
{
	try
	{
		var oInpBox=window.event.srcElement;
		var nValue=(/^-?\d*$/.test(oInpBox.value));
		if(nValue==true)
			oInpBox.value = oInpBox.value;
		else 
			oInpBox.value = "";		
	}
	catch(e)
	{
		displayError(e,"ValidateRemoveZeroInteger");
	}
}


//==============================================================
// Name:       ValidateInt
// Purpose:    Prohibits entering only Numbers 
//==============================================================
function ValidateInt()
{
	try
	{
		var oInpBox=window.event.srcElement;
		var nValue=(/^\d*$/.test(oInpBox.value));
		if(nValue==true)
			oInpBox.value = oInpBox.value;
		else 
			oInpBox.value = "";		
	}
	catch(e)
	{
		displayError(e,"ValidateRemoveZeroInteger");
	}
}
