//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//	Revision:	1.0
//	Author:		Arshad K
//	Workfile:	valsolicitor.js
//	ModTtime:	10/12/2018
//============================================================-->
var cityValid, stateValid, pcValid, combValid, addrValid = false;

//Start : Card 389
//=====================================================================
//	Function Name:	ValSolicitor
//	Parameters:		nil
//	Return:			Validation boolean
//	Description:	Validate solicitor.
//=====================================================================
function ValSolicitor()
{
	try
	{
		var allValid = true;
		var oSolicitor = xml_master.XMLDocument.documentElement.selectSingleNode("Solicitor");
		if(oSolicitor.hasChildNodes && oSolicitor.text)
		{
			var sSolNm = (oSolicitor)? oSolicitor.selectSingleNode("SolicitorName").text:'';
			var sCompNm = (oSolicitor)? oSolicitor.selectSingleNode("CompanyName").text:'';
			allValid = (sSolNm.length>0) || (sCompNm.length>0) || (!oSolicitor);
			if(allValid)
			{
				allValid = (cityValid) && (stateValid) && (pcValid) && (combValid) && (addrValid);
			}
			
		}
		return allValid;
	}
	catch (e)
	{
		displayError(e,'ValSolicitor');
	}
}


//==============================================================
//	Function Name:	ValCity
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the city
//==============================================================
function ValSolCity(oAddr)
{
	try
	{
		cityValid = Sol_ValAddressFld(oAddr,"City","@C");
		return cityValid;
	}
	catch (e)
	{
		displayError(e,"ValCity");
	}
}

//==============================================================
//	Function Name:	ValState
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the state
//==============================================================
function ValSolState(oAddr)
{
	try
	{
		stateValid = Sol_ValAddressFld(oAddr,"State","@S");
		return stateValid;
	}
	catch (e)
	{
		displayError(e,"ValState");
	}
}

//==============================================================
//	Function Name:	ValPostcode
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the postcode
//==============================================================
function ValSolPostcode(oAddr)
{
	try
	{
		pcValid = Sol_ValAddressFld(oAddr,"Postcode","@P");
		return pcValid;
	}
	catch (e)
	{
		displayError(e,"ValPostcode");
	}
}

//==============================================================
//	Function Name:	ValSolAddress
//	Parameters:		oSolicitor- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the address
//==============================================================
function ValSolAddress(oSolicitor)
{              
	try
	{
		var ad_valid = false;
		if (!oSolicitor) return ad_valid;
		if(oSolicitor.hasChildNodes)
		{
			var bPrevEmp = ((oSolicitor.selectSingleNode("SolicitorName").text!="") || (oSolicitor.selectSingleNode("CompanyName").text!="")) ? true:false;
			if ((oSolicitor)&&(!bPrevEmp)) ad_valid = true;
			else
				{
					var sSolAddress = oSolicitor.selectSingleNode("AddressLine1").text;
					var txtPhNo = Validate_PhNumbers_OnLoad(oSolicitor.selectSingleNode("PhoneNumber"));
					var txtFax = Validate_PhNumbers_OnLoad(oSolicitor.selectSingleNode("FaxNumber"));
					ad_valid = sSolAddress;
				}
		}                                              
		addrValid = ad_valid;
		return addrValid;                             
	}
	catch (e)
	{
		displayError(e,"ValSolAddress");
	}
}


//==============================================================
//	Function Name:	Sol_ValAddressFld
//	Parameters:		oAddr - (XML Node) Address node
//					sFldName - (string) DSO field name
//					sAttr - (string) Ref data attribute name
//	Return:			Boolean - Valid flag
//	Description:	Validates given address fields
//==============================================================
function Sol_ValAddressFld(oSolicitor,sFldName,sAttr)
{
	var valid = false;
		
	try
	{
		if (!oSolicitor) return valid;
		if(oSolicitor.hasChildNodes)
		{
			var bIsvaild = ((oSolicitor.selectSingleNode("SolicitorName").text!="") || (oSolicitor.selectSingleNode("CompanyName").text!=""))? true:false;
			if ((oSolicitor)&&(!bIsvaild)) valid = true;
			else
				{
					//must be not empty and valid
					var sVal = oSolicitor.selectSingleNode(sFldName).text.toUpperCase();
					valid = !(sVal=="");
					if(valid)
					{	
						// ensure that no invalid ' string combinations appear in the search string
						sVal = sVal.replace(/"/g, '');
						valid = valid && (getSingleRDRow("A_E_TSR_PC", sAttr + '="' + sVal + '"')!=null)
					}
				}
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,"Sol_ValAddressFld");
	}
}

//==============================================================
//	Function Name:	ValSolCityStatePC
//	Parameters:		oAddrDtls - (XML Node) Address node
//	Return:			Boolean - Valiod flag
//	Description:	Validates city state and post code combo
//==============================================================
function ValSolCityStatePC(oSolicitor)
{	
	try
	{
		var valid = false;
		if (!oSolicitor) return valid;
		if(oSolicitor.hasChildNodes)
		{
		var bPrevEmp = ((oSolicitor.selectSingleNode("SolicitorName").text!="") || (oSolicitor.selectSingleNode("CompanyName").text!="")) ? true:false;
			if ((oSolicitor)&&(!bPrevEmp)) valid = true;
			else
				{
					//must be valid combination
					var sCity = oSolicitor.selectSingleNode("City").text.toUpperCase();
					var sState = oSolicitor.selectSingleNode("State").text;
					var sPC = oSolicitor.selectSingleNode("Postcode").text;
					
					// ensure that no invalid ' string combinations appear in the search string
					sCity = sCity.replace(/"/g, '');
					sState = sState.replace(/"/g, '');
					var sCheck='@P="' + sPC + '" and @C="' + sCity + '" and @S="' + sState +'"';
					valid = (getSingleRDRow("A_E_TSR_PC", sCheck)!=null);
				}
		}		
		combValid = valid;
		return combValid;		
	}
	catch (e)
	{
		displayError(e,"ValSolCityStatePC");
	}
}
//End : Card 389



//==============================================================
//	Name:		ValDataOnLoad
//	Purpose:	Validates customer home phone number preferred
//	Parameters:	poCust - (XML node) single customer XML element
//	Return:		boolean - true, if the home phone number preferred is valid,
//							otherwise - false
//==============================================================
function ValDataOnLoad(txtNode)
{
	try
	{
		if(txtNode != null) {
			if(txtNode.text != "") {
				txtNode.text = (txtNode.text).replace(/\D+/g, "");
				var regexval = /^[0-9]+$/;
				var nValue=(regexval.test(txtNode.text));
				if((nValue==true)) {
					var nTextVal = ((txtNode.text).replace(/\s/g, ""));
					if(nTextVal != "") {
						if(nTextVal.length > 10){
							nTextVal = "0" +  nTextVal.substring(nTextVal.length - 9, nTextVal.length); 
						}
						else
						{
							nTextVal = nTextVal;
						}
						if(nTextVal.length==10) {
							txtNode.text =  nTextVal;
							return ((txtNode.text) && (true));
						}
						else{
							return ((txtNode.text) && (false));		
						}
					}
				}
				else 
				{
					txtNode.text = (txtNode.text).replace(/\D+/g, "");
					return ((txtNode.text) && (false));		
				}
			}
			else 
			{
				return (true);		
			}
		}
	}
    catch(e)
    {
       displayError(e,"ValDataOnLoad");
    }
}
