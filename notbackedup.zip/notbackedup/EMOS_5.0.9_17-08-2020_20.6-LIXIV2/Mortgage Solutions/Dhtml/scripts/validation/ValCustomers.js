//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		E.Elutin
//	Workfile:	ValCustomer.js
//	ModTtime:	04/03/2003
//============================================================-->
//<SCRIPT>

//==============================================================
//	Name:		ValCustomersTypeCombination
//	Purpose:	Validates customers type combination
//	Return:		boolean - true, if the combintaion is valid,
//							otherwise - false
//==============================================================
function ValCustomersTypeCombination()
{
	try
	{
		//validates combination of the customers types
		var iPrimaryOwners = 0;	
		var iDirectOwners = 0;
		var allvalid=true;
		
		//WR1970 - Added to handle Guarantor
		var iGuarantors=0;
	
		var oCustList = xml_master.XMLDocument.selectNodes("//Customers/Customer");
	
		var iAlowMltDirect =true;
	
		for (i=0; i<oCustList.length; i++)
		{
			var oCust=oCustList(i);
			var sCustType = oCust.selectSingleNode("CustomerType").text;
			if (sCustType.length>0)
			{
				//get rules for customer type
				var oR = getRDRowObject('A_TS_CUS_REL_CONTROL','@CATEGORY="ACCU" and @RELATIONSHIP_CODE="' + sCustType + '" and @PRODUCT_CODE="MOS"');
				if (oR.PRIMARY_OWNER_YN) iPrimaryOwners++;
				if (oR.DIRECT_OWNER_YN) iDirectOwners++;
				
				//WR1970 - Added for increment the Guarentors count (The if condition may change)
				if (oR.RELATIONSHIP_CODE=='GTR') iGuarantors++;
								
				iAlowMltDirect = iAlowMltDirect && oR.MULTIPLE_DIRECT_ALLOW_YN;
			 }
			 else
			 {
				allvalid = false;
				break;
			 }
		} 
		
		if (oCustList.length)
		{
			allvalid = allvalid && !((iAlowMltDirect)&&(iDirectOwners==1));
			allvalid = allvalid && !((!iAlowMltDirect)&&(iDirectOwners>1));
			allvalid = allvalid && (iPrimaryOwners==1);
			allvalid = allvalid && (iDirectOwners<=8);
			
			//Added to incorporate Guarentor WR-1970
			allvalid = allvalid && (iGuarantors<=4);
		}
		return allvalid;
	}
	catch(e)
	{
		displayError(e,"ValCustomersTypeCombination");
	}
}

//==============================================================
//	Name:		ValDriverLicState
//	Purpose:	Validates customer driver license state
//	Parameters:	poCust - (XML node) single customer XML element
//	Return:		boolean - true, if the driver license state is valid,
//							otherwise - false
//==============================================================
function ValDriverLicState(poCust)
{
	try
	{
		var sLic = poCust.selectSingleNode("DriversLicenseNumber").text
		var sState = poCust.selectSingleNode("DriversLicenseState").text
		return (sLic!="")? (sState!=""):(sState=="");
	}
	catch(e)
	{
		displayError(e,"ValDriverLicState");
	}
}

//==============================================================
//	Name:		ValAgeOfDependents
//	Purpose:	Validates customer age of dependents field value
//	Parameters:	oCust - (XML node) single customer XML element
//	Return:		boolean - true, if value is valid,
//							otherwise - false
//==============================================================
function ValAgeOfDependents(oCust)
{
	try
	{
		var NumOf = GetIntVal(oCust.selectSingleNode("NumberOfDependents").text)
		var Age = oCust.selectSingleNode("AgeOfDependents").text
		return (NumOf>0)? (Age.length>0):(Age.length==0);
	}
	catch(e)
	{
		displayError(e,"ValAgeOfDependents");
	}
}

//==============================================================
//	Name:		ValDateOfBirth
//	Purpose:	Validates customer date of birth
//	Parameters:	oCust - (XML node) single customer XML element
//	Return:		boolean - true, if date of birth is valid,
//							otherwise - false
//==============================================================
function ValDateOfBirth(oCust)
{
	try
	{
		return VBValidateAge18(oCust.selectSingleNode("DateOfBirth").text);
	}
	catch(e)
	{
		displayError(e,"ValDateOfBirth");
	}
}

//==============================================================
//	Name:		ValCustomerAddresses
//	Purpose:	Validates customer addresses state
//	Parameters:	oAddr - (XML node) customer addresses XML element
//	Return:		boolean - true, if customer addresses are valid,
//							otherwise - false
//==============================================================
function ValCustomerAddresses(oAddr)
{
	try
	{
		var cntCR=0;
		var cntCM=0;
		var cntPR=0;
		var oLnkAddrs=oAddr.selectNodes("CustomerAddress[@Linked=-1]");
		var AdrCnt=oLnkAddrs.length
		
		if (AdrCnt==0) return;
		
		var cntAddrMonth=0;
		var cntAddrYear=0;
		var cntPrevAddrYear = 0;
		var cntPrevAddrMonth = 0;
		var valid_StreetType;
		
		for (var i=0; i<AdrCnt; i++)
		{
			var AdrUsg = oLnkAddrs(i).selectSingleNode("Type").text;
			var CustAdrId = oLnkAddrs(i).selectSingleNode("AddressID").text;
			if (AdrUsg=="CR") {
				cntCR++;
				var AdrY = oLnkAddrs(i).selectSingleNode("YearsAtAddress").text;
				var AdrM = oLnkAddrs(i).selectSingleNode("MonthsAtAddress").text;
				cntAddrYear += Number(AdrY) * 12;
				cntAddrMonth += Number(AdrM);
			}
			if (AdrUsg=="CM") {
				cntCM++;
				var AdrCMY = oLnkAddrs(i).selectSingleNode("YearsAtAddress").text;
			}
			if (AdrUsg=="PR") {
				cntPR++;
				var AdrPRY = oLnkAddrs(i).selectSingleNode("YearsAtAddress").text;
				var AdrPRM = oLnkAddrs(i).selectSingleNode("MonthsAtAddress").text;
				cntPrevAddrYear += Number(AdrPRY) * 12;
				cntPrevAddrMonth += Number(AdrPRM);
			}
			
			// Start for VALID STREET TYPE
				if(CustAdrId != "")
					valid_StreetType = ValidateStreetTypeAddr(CustAdrId);
			// END for VALID STREET TYPE
		}
		
		//Converting Year(s) into Months and validating by Months of 3 Years.
		var totalAddrTime = Number(cntAddrYear) + Number(cntAddrMonth);
		var totalPrevAddrTime = Number(cntPrevAddrYear) + Number(cntPrevAddrMonth);
		
		if(totalAddrTime < 36) {
			if(totalPrevAddrTime > 0) {
				if(valid_StreetType)
					return (cntCR==1)&&(cntCM<=1)&&((AdrY>=3)||(cntPR>0));
				else
					return false;
			}
			else {
				return false;
			}
		}
		else {
			if(valid_StreetType)
				return (cntCR==1)&&(cntCM<=1)&&((AdrY>=3)||(cntPR>0));
			else
				return false;
		}
		
	}
	catch(e)
	{
		displayError(e,"ValCustomerAddresses");
	}

}

//==============================================================
//	Name:		ValCustMonthAddr
//	Purpose:	Validates months at address
//	Parameters:	oAddr - (XML node) single customer address XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if net income is valid,
//							otherwise - false
//==============================================================
function ValCustMonthAddr(oAddr)
{
	try
	{
		var mm = GetIntVal(oAddr.selectSingleNode("MonthsAtAddress").text);
		return (mm<12);
	}
	catch(e)
	{
		displayError(e,"ValCustMonthAddr");
	}
}

//WR1970 - The validation function for employment details are moved to a different file.

//WR1970-New function added for validating driving licence.
//==============================================================
//	Name:		ValDrivLic
//	Purpose:	Validates the driving licence for 4 char length
//	Parameters:	oCust - (XML node) customer Node
//				
//	Return:		boolean - true, if net value is valid,
//							otherwise - false
//==============================================================
function ValDrivLic(oCust)
{
	try
	{
		
		//get the value in the node
		var sLicNo=oCust.selectSingleNode("DriversLicenseNumber").text;
		if (sLicNo.length<4 && sLicNo.length!=0)
		{
			return(false);
		}
		
		if(sLicNo.length>=4)
		{
			var str = oCust.selectSingleNode("DriversLicenseNumber").text;
			
			var TrdChar = isNaN(str.substr(2, 2));
			
			return(TrdChar)? false:true;
			
		}
		else
		{
			return(true);
			
		}
	}
	catch(e)
	{
		displayError(e,"ValDrivLic");
	}
}

//==============================================================
//	Name:		ValEmpTypeCombination
//	Parameters:	OEmpRecs - Employment records node
//	Purpose:	validates combination of the customers Employment types
//	Return:		boolean - true, if the combintaion is valid,
//							otherwise - false
//==============================================================
function ValEmpTypeCombination(OEmpRecs)
{
	try
	{
		//WR1970_CMR002 Removed the code for CMR002 Changes
		var allvalid=false;
		var nUpEmpDet = ValEmpCityStatePC(OEmpRecs.selectSingleNode("EmploymentDetails"));
		if(nUpEmpDet)
		{
		var oCurPrimEmp = OEmpRecs.selectNodes("EmploymentDetails[PrimaryEmployment=-1]");
		var bPrimEmpCount=true
		
		if (oCurPrimEmp.length!=1)
			bPrimEmpCount=false;
		
		var bPrevNotMandatory=true;
		if (bPrimEmpCount)
		{
			var oCurEmp= OEmpRecs.selectSingleNode("EmploymentDetails[PrimaryEmployment=-1]");
			var iCurEmpTime = Number(oCurEmp.selectSingleNode("YearsInEmployment").text);
			// Card : 257
				if (iCurEmpTime<2)
			{
				var oPrevEmp = OEmpRecs.selectNodes("EmploymentDetails[PreviousEmployment=-1]");
				if (oPrevEmp.length<1)
					bPrevNotMandatory= false;
				// Card : 257 - Added Else for summing up logic
				else
				{
					var cntMonth=0;
					var cntYear=0;
					for (var i=0; i<oPrevEmp.length; i++)
					{
						cntYear += Number(oPrevEmp(i).selectSingleNode("YearsInEmployment").text);
						cntMonth += Number(oPrevEmp(i).selectSingleNode("MonthsInEmployment").text);
					}					
					var iCurEmpYear = Number(oCurEmp.selectSingleNode("YearsInEmployment").text);
					var iCurEmpMonth = Number(oCurEmp.selectSingleNode("MonthsInEmployment").text);
					//Converting Year(s) into Months and validating by Months of 3 Years.
					var totalEmpTime = (iCurEmpYear*12) + (iCurEmpMonth) + (cntYear*12) + (cntMonth);
						/*if(totalEmpTime < 36)
							bPrevNotMandatory= false;*/
				}
			}
		}
		var oCusPrevEmp = OEmpRecs.selectNodes("EmploymentDetails[PreviousEmployment=-1]");
		var bMaxPrevNotReached=true;
		if (oCusPrevEmp.length>5)
			bMaxPrevNotReached=false;

		var oCusSecEmp = OEmpRecs.selectNodes("EmploymentDetails[PreviousEmployment=0 and PrimaryEmployment=0]");
		var bMaxCurSecNotReached=true;
		if (oCusSecEmp.length>5)
			bMaxCurSecNotReached = false;
		
		allvalid = ((bMaxCurSecNotReached) && (bMaxPrevNotReached)) && ((bPrevNotMandatory) && (bPrimEmpCount));
			return allvalid;
		}
		else
		{
			allvalid = nUpEmpDet;
			return allvalid;
		}
		
	}
	catch(e)
	{
		displayError(e,"ValEmpTypeCombination");
	}
}
//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//==============================================================
//	Name:		ValTaxResidentsCombination
//	Parameters:	OEmpRecs - Employment records node
//	Purpose:	validates combination of the customers Employment types
//	Return:		boolean - true, if the combintaion is valid,
//							otherwise - false
//==============================================================
function ValTaxResidentsCombination(OTaxRecs)
{
	try
	{		
		var allvalid=false;
		var oCurTaxRes;		
		oCurTaxRes = OTaxRecs.selectSingleNode("//Customers/Customer");		
		if (G_Cust_ID.length==0) {
			oCurTaxRes = OTaxRecs.selectSingleNode("//Customers/Customer");
		}
		else {			
			oCurTaxRes = G_Tax; //OTaxRecs.selectSingleNode("//Customers/Customer[CustomerID=" + G_Cust_ID + "]");			
		}		
		var iCurTax= G_Tax;  //oCurTaxRes.selectSingleNode("TaxResidentAustralia").text;		
		var iCustType= G_Customer_Type;//  oCurTaxRes.selectSingleNode("CustomerType").text;
		
		if ((iCustType != "GTR") && (G_Sub_Prd_Typ == 3) || (G_Sub_Prd_Typ == 5) || (G_Sub_Prd_Typ == 2)) {	
			if (iCurTax.length==1) {
				allvalid=true;					
			}
			else {
				if (G_Product_Type == "RC" || G_breakfree_Type == "New Credit Card")
					allvalid=false;					
				else
					allvalid=true;				
			}					
		}
		else {
			allvalid=true; 		
		}
		return allvalid;		
	}
	catch(e)
	{
		displayError(e,"ValTaxResidentsCombination");
	}
}
//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes

//==============================================================
//	Name:		ValEmailAddress
//	Purpose:	Validates customer Email Address
//	Parameters:	poCust - (XML node) single customer XML element
//	Return:		boolean - true, if the email is valid,
//							otherwise - false
//	Date	: 28-11-2017 R 18.01
//==============================================================

function ValEmailAddress(poCust) 
{
	try
	{
		var sEmailAdd = poCust.selectSingleNode("EmailAddress").text
		if (sEmailAdd.length > 0)
		{
			var regex = /^[a-zA-Z0-9._+-]{2,}@[a-zA-Z0-9.-]{2,}\.[a-zA-Z]{2,}$/;
			return regex.test(sEmailAdd);					
		}
		else
		{
			return(true);
		}
	}
	catch(e)
	{
		displayError(e,"ValEmailAddress");
	}
}

//Start : Card 253 - New function added for validating VisaSubClass.
//==============================================================
//	Name:		ValVisaSubclass
//	Purpose:	Enables the VisaSubClass for TemporaryResident
//			and Validates the value to Integer of max 3
//	Parameters:	oCust - (XML node) customer Node
//				
//	Return:		boolean - true, if net value is valid,
//							otherwise - false
//==============================================================
function ValVisaSubclass(oCust)
{
	try
	{
		//get the value in the node
		var sRStatus = oCust.selectSingleNode("ResidentStatus").text;
		var sVisaNo=oCust.selectSingleNode("VisaSubclass").text;
		return (sRStatus == "TemporaryResident")? (sVisaNo.length>0 && +sVisaNo === parseInt(sVisaNo,10)):(sVisaNo.length==0);
	}
	catch(e)
	{
		displayError(e,"ValVisaSubclass");
	}
}
//End : Card 253


//Start : Card 377
//==============================================================
//	Name:		ValMitigants
//	Purpose:	Enables the ValMitigants for SigFinancecircumstances
//			and Validates the value to Integer of max 3
//	Parameters:	oCust - (XML node) customer Node
//				
//	Return:		boolean - true, if net value is valid,
//							otherwise - false
//==============================================================
function ValMitigants(oCust)
{
 var valid = true;
	try
	{
		if(document.getElementById('chksigfinanceCircum') != null)
		{
			 var sSFinance = document.getElementById('chksigfinanceCircum').checked;
			 var sMitigants = document.getElementById('cboCustomerMitigants').value;
			 if(sSFinance == true)
			  {
				if (sMitigants == undefined || sMitigants == "")
				  valid = false;
			  }
			   
		}
	}	
	catch(e)
	{
		displayError(e,"ValMitigants");
	}
	
	return valid;
}


//==============================================================
//	Name:		ValNatureOfChange
//	Purpose:	Enables the ValNatureOfChange for SigFinancecircumstances
//			and Validates the value to Integer of max 3
//	Parameters:	oCust - (XML node) customer Node
//				
//	Return:		boolean - true, if net value is valid,
//							otherwise - false
//==============================================================
function ValNatureOfChange(oCust)
{
	var valid = true;
	try
	{
		if(document.getElementById('chksigfinanceCircum') != null)
		{
			var sSFinance = document.getElementById('chksigfinanceCircum').checked;
			var sNatureOfChange = document.getElementById('cboCustNatureOfChange').value;
			if(sSFinance == true)
			  {
				if (sNatureOfChange == undefined || sNatureOfChange == "")
				  valid = false;
			  }                                                   
		}
	}              
	catch(e)
	{
		displayError(e,"ValNatureOfChange");
	}
	
	return valid;
}

//==============================================================
//	Name:		ValOtherNatureOfChange
//	Purpose:	Enables the ValOtherNatureOfChange for SigFinancecircumstances
//			and Validates the value to Integer of max 3
//	Parameters:	oCust - (XML node) customer Node
//				
//	Return:		boolean - true, if net value is valid,
//							otherwise - false
//==============================================================

function ValOtherNatureOfChange(oCust)
{
	var valid = true;
	try
	{
		if(document.getElementById('chksigfinanceCircum') != null)
		{
			var sSFinance = document.getElementById('chksigfinanceCircum').checked;
			var sNatureOfChange = document.getElementById('cboCustNatureOfChange').value;
			var sOtherNatureChange = document.getElementById('txtNatureOfChange').value;
			if(sSFinance == true)
			  {
				if (sNatureOfChange == undefined || sNatureOfChange == "NatureOther")
				{
					if(sOtherNatureChange == undefined || sOtherNatureChange == ""){
						valid = false;
					}
				}
			  }                                                   
		}
	}              
	catch(e)
	{
		displayError(e,"ValOtherNatureOfChange");
	}
	
	return valid;
}

//==============================================================
//	Name:		ValOtherMitigants
//	Purpose:	Enables the ValOtherMitigants for SigFinancecircumstances
//			and Validates the value to Integer of max 3
//	Parameters:	oCust - (XML node) customer Node
//				
//	Return:		boolean - true, if net value is valid,
//							otherwise - false
//==============================================================

function ValOtherMitigants(oCust)
{
	var valid = true;
	try
	{
		if(document.getElementById('chksigfinanceCircum') != null)
		{
			var sSFinance = document.getElementById('chksigfinanceCircum').checked;
			var sNatureOfChange = document.getElementById('cboCustomerMitigants').value;
			var sOtherNatureChange = document.getElementById('txtMitigantChange').value;
			if(sSFinance == true)
			  {
				if (sNatureOfChange == undefined || sNatureOfChange == "Other")
				{
					if(sOtherNatureChange == undefined || sOtherNatureChange == ""){
						valid = false;
					}
				}
			  }                                                   
		}
	}              
	catch(e)
	{
		displayError(e,"ValOtherMitigants");
	}
	
	return valid;
}


//End : Card 377

//==============================================================
//	Name:		ValPreferredContact
//	Purpose:	Validates customer home phone number preferred
//	Parameters:	poCust - (XML node) single customer XML element
//	Return:		boolean - true, if the home phone number preferred is valid,
//							otherwise - false
//==============================================================
function ValPreferredContact(poCust)
{
	var valid = true;
	try
	{
		var txtHome = Validate_PhNumbers_OnLoad(poCust.selectSingleNode("HomePhoneNumber"));
		var txtWork = Validate_PhNumbers_OnLoad(poCust.selectSingleNode("BusinessPhoneNumber"));
		var txtMobile = Validate_PhNumbers_OnLoad(poCust.selectSingleNode("MobilePhoneNumber"));
		var txtFax = Validate_PhNumbers_OnLoad(poCust.selectSingleNode("FaxNumber"));
		if((txtHome) && (txtWork) && (txtMobile))
		{
			var txtHome_len = VBTrim(poCust.selectSingleNode("HomePhoneNumber").text).length;
			var txtWork_len = VBTrim(poCust.selectSingleNode("BusinessPhoneNumber").text).length;
			var txtMobile_len = VBTrim(poCust.selectSingleNode("MobilePhoneNumber").text).length;
			
			if(txtHome_len == 0)
				poCust.selectSingleNode("HomePhonePreferred").text = "";
			
			if(txtWork_len == 0)
				poCust.selectSingleNode("BusinessPhonePreferred").text = "";
			
			if(txtMobile_len == 0)
				poCust.selectSingleNode("MobilePhonePreferred").text = "";
			
			var chkHomePhone = poCust.selectSingleNode("HomePhonePreferred").text;
			var chkWorkPhone = poCust.selectSingleNode("BusinessPhonePreferred").text;
			var chkMobile = poCust.selectSingleNode("MobilePhonePreferred").text;
			
			if(chkHomePhone =="-1" || chkWorkPhone =="-1" || chkMobile =="-1")
				valid = true;					   
			else
				valid = false;
		}
		else
		{
			var txtHome_len = VBTrim(poCust.selectSingleNode("HomePhoneNumber").text).length;
			var txtWork_len = VBTrim(poCust.selectSingleNode("BusinessPhoneNumber").text).length;
			var txtMobile_len = VBTrim(poCust.selectSingleNode("MobilePhoneNumber").text).length;
			
			if(txtHome_len == 0)
				poCust.selectSingleNode("HomePhonePreferred").text = "";
			
			if(txtWork_len == 0)
				poCust.selectSingleNode("BusinessPhonePreferred").text = "";
			
			if(txtMobile_len == 0)
				poCust.selectSingleNode("MobilePhonePreferred").text = "";
			
			valid = false;
		}
		return valid;	
	}
    catch(e)
    {
       displayError(e,"ValPreferredContact");
    }
}



//==============================================================
//	Name:		ValTaxResidentsEnableNew
//	Parameters:	oCurTaxRes - Tax records node
//	Purpose:	validates combination of the customers Tax Resident types
//	Return:		boolean - true, if the combintaion is valid,
//							otherwise - false
//==============================================================

function ValTaxResidentsEnableNew(oCurTaxRes)
{
	try
	{		
		var allvalid;
		var iCustType= oCurTaxRes.selectSingleNode("CustomerType").text;
		var iCurTax = oCurTaxRes.selectSingleNode("TaxResidentAustralia").text;		
		
		if ((G_Sub_Prd_Typ == 3) || (G_Sub_Prd_Typ == 5) || (G_Sub_Prd_Typ == 2))
		{	
			if ((G_Product_Type == "RC") || (G_breakfree_Type == "New Credit Card")) {
				//G_ACHBrkFreeCard we will get Customer ID of Additional Card Holder in Packages Screen.
				if(G_ACHBrkFreeCard != "") {
					var iCustId = oCurTaxRes.selectSingleNode("CustomerID").text;
					if(iCustId == G_ACHBrkFreeCard) 
					{
						if(iCurTax != "")
							allvalid = true;
						else 
							allvalid = false;
					}
					else 
					{
						if(iCustType == "GTR"){
							allvalid = true;
						}
						else {
							if(iCurTax != "")
								allvalid = true;
							else 
								allvalid = false;
						}
					}
				}
				else 
				{
					if(iCustType == "GTR"){
						allvalid = true;
					}
					else {
						if(iCurTax != "")
							allvalid = true;
						else 
							allvalid = false;
					}
				}
			}
			else {
				allvalid=true;				
			}
		}
		else 
		{
			allvalid=true;				
		}
		return allvalid;		
	}
	catch(e)
	{
		displayError(e,"ValTaxResidentsEnableNew");
	}
}



//==============================================================
//	Name:		ValTaxResidentsEnable
//	Parameters:	oCurTaxRes - Tax records node
//	Purpose:	validates combination of the customers Tax Resident types
//	Return:		boolean - true, if the combintaion is valid,
//							otherwise - false
//==============================================================

function ValTaxResidentsEnable(oCurTaxRes)
{
	try
	{		
		var allvalid;
		var iCustType= oCurTaxRes.selectSingleNode("CustomerType").text;
		var iCurTax = oCurTaxRes.selectSingleNode("TaxResidentAustralia").text;		
		
		if ((G_Sub_Prd_Typ == 3) || (G_Sub_Prd_Typ == 5) || (G_Sub_Prd_Typ == 2))
		{	
			if ((G_Product_Type == "RC") || (G_breakfree_Type == "New Credit Card")) {
				//G_ACHBrkFreeCard we will get Customer ID of Additional Card Holder in Packages Screen.
				if(G_ACHBrkFreeCard != "") {
					var iCustId = oCurTaxRes.selectSingleNode("CustomerID").text;
					if(iCustId == G_ACHBrkFreeCard) 
					{
						if(iCurTax != ""){
							if(iCurTax == "Y")
								allvalid = true;
							else if(iCurTax == "N")
								allvalid  = ValTaxResidentsEnableOptionNo(oCurTaxRes);
						}
						else {
							allvalid = false;
						}
					}
					else {
						if(iCustType == "GTR"){
							allvalid = true;
						}
						else {
							if(iCurTax != ""){
								if(iCurTax == "Y")
									allvalid = true;
								else if(iCurTax == "N"){
									allvalid  = ValTaxResidentsEnableOptionNo(oCurTaxRes);
								}
							}
							else {
								allvalid = false;
							}
						}
					}
				}
				else 
				{
					if(iCustType == "GTR"){
						allvalid = true;
					}
					else {
						if(iCurTax != "") {
							if(iCurTax == "Y")
								allvalid = true;
							else if(iCurTax == "N"){
								allvalid  = ValTaxResidentsEnableOptionNo(oCurTaxRes);
							}
						}
						else {
							allvalid = false;
						}
					}
				}
			}
			else {
				allvalid=true;				
			}
		}
		else 
		{
			allvalid=true;				
		}
		return allvalid;		
	}
	catch(e)
	{
		displayError(e,"ValTaxResidentsEnable");
	}
}


//==============================================================
//	Name:		ValTaxResidentsEnableOptionNo
//	Parameters:	oCurTaxRes - Tax records node
//	Purpose:	validates combination of the customers Tax Resident types
//	Return:		boolean - true, if the combintaion is valid,
//							otherwise - false
//==============================================================

function ValTaxResidentsEnableOptionNo(oCurTaxRes)
{
	try
	{		
		var allvalid = true;
		var oTaxResDetails = oCurTaxRes.selectSingleNode("TaxResidents");		
		if ((oTaxResDetails.hasChildNodes) && (oTaxResDetails.childNodes.length > 0))
			allvalid = true;	
		else
			allvalid = false;
		
		return allvalid;		
	}
	catch(e)
	{
		displayError(e,"ValTaxResidentsEnableOptionNo");
	}
}
