/* //<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//	Revision:	1.0
//	Author:		Arshad K
//	Workfile:	valEmpDtls.js
//	ModTtime:	19/04/2005
//============================================================-->


//==============================================================
//	Name:		CheckSomeEmpDtlsRequired
//	Purpose:	Common function to check if the specific employment 
//				details are required
//	Parameters:	oEmpDtls - (XML node) single employment dtls XML element
//				sFldToChk - (string) employment details field name
//				bNumber - (boolean) flag to indicate that the value 
//							is numeric
//				bReqForPrev - (boolean) flag indicating that the value 
//							is mandatory for previous empl. when all 
//							other requirements met
//							employment record, should be 0 or -1
//	Return:		boolean - true, if the combintaion is valid,
//							otherwise - false
//==============================================================
function CheckSomeEmpDtlsRequired(oEmpDtls,sFldToChk, bNumber, bReqForPrev)
{
	try
	{
		var bPrevEmp = (oEmpDtls.selectSingleNode("PreviousEmployment").text=='-1')? true:false;
		var sEmpType = oEmpDtls.selectSingleNode("EmploymentType").text;
		var sOccCd = oEmpDtls.selectSingleNode("OccupationCode").text;
		var bNonEmpOcc = getSingleRDRow("A_TS_NON_EMPLMT_OCCD",'@OCCUPATION_CODE="'+ sOccCd + '"');
		var sFldVal = oEmpDtls.selectSingleNode(sFldToChk).text;
		
		if (bReqForPrev) bPrevEmp = false;

		if (!bNumber)
			return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? (sFldVal!=""):true;
		else
			return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? (sFldVal>0):true;
	}
	catch(e)
	{
		displayError(e,"CheckSomeEmpDtlsRequired");
	}
}

//==============================================================
//	Name:		ValEmpEmployerType
//	Purpose:	Validates customer employer type state
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if employer type is valid,
//							otherwise - false
//==============================================================
function ValEmpEmployerType(oEmpDtls)
{
	try
	{
		return CheckSomeEmpDtlsRequired(oEmpDtls,"EmployerType");
	}
	catch(e)
	{
		displayError(e,"ValEmpEmployerType");
	}
}

//==============================================================
//	Name:		ValEmpEmployerName
//	Purpose:	Validates customer employer name
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if employer name is valid,
//							otherwise - false
//==============================================================
function ValEmpEmployerName(oEmpDtls)
{	
	try
	{
		return CheckSomeEmpDtlsRequired(oEmpDtls,"EmployerName",false,-1);
	}
	catch(e)
	{
		displayError(e,"ValEmpEmployerName");
	}
}

//==============================================================
//	Name:		ValEmpEmployerAdr1
//	Purpose:	Validates employer first address line
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if the employer first address line 
//							is valid, otherwise - false
//==============================================================
function ValEmpEmployerAdr1(oEmpDtls)
{
	try
	{
		return CheckSomeEmpDtlsRequired(oEmpDtls,"EmployerAddress1");
	}
	catch(e)
	{
		displayError(e,"ValEmpEmployerAdr1");
	}
}

//==============================================================
//	Name:		ValEmpGrossIncome
//	Purpose:	Validates customer gross income
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if gross income is valid,
//							otherwise - false
//==============================================================
function ValEmpGrossIncome(oEmpDtls)
{
	try
	{
		return CheckSomeEmpDtlsRequired(oEmpDtls,"GrossMonthlyIncome",true);
	}
	catch(e)
	{
		displayError(e,"ValEmpGrossIncome");
	}
}

//==============================================================
//	Name:		ValEmpMonths
//	Purpose:	Validates months at employment
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if net income is valid,
//							otherwise - false
//==============================================================
function ValEmpMonths(oEmpDtls)
{
	try
	{
		var mm = GetIntVal(oEmpDtls.selectSingleNode("MonthsInEmployment").text);
		return (mm<12);
	}
	catch(e)
	{
		displayError(e,"ValEmpMonths");
	}
}

//==============================================================
//	Name:		ValEmpNetIncome
//	Purpose:	Validates customer net income
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if net income is valid,
//							otherwise - false
//==============================================================
function ValEmpNetIncome(oEmpDtls)
{
	try
	{
		var nNet = GetIntVal(oEmpDtls.selectSingleNode("NetMonthlyIncome").text);
		var nGross = GetIntVal(oEmpDtls.selectSingleNode("GrossMonthlyIncome").text);
		return (CheckSomeEmpDtlsRequired(oEmpDtls,"NetMonthlyIncome",true)&&(nNet<=nGross));
	}
	catch(e)
	{
		displayError(e,"ValEmpNetIncome");
	}
}

//==============================================================
//	Name:		ValEmpOccCode
//	Purpose:	Validates customer occupation code
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if occupation code is valid,
//							otherwise - false
//==============================================================
function ValEmpOccCode(oEmpDtls)
{
	try
	{
		var bPrevEmp = (oEmpDtls.selectSingleNode("PreviousEmployment").text=="-1")? true:false;
		if ((!oEmpDtls)&&(bPrevEmp)) return true;	//N/A for previous
		var sEmpType = oEmpDtls.selectSingleNode("EmploymentType").text;
		var sOccCd = oEmpDtls.selectSingleNode("OccupationCode").text;
		var sOccGrp = oEmpDtls.selectSingleNode("OccupationGroup").text;
	
		return (sOccCd!="");
	}
	catch(e)
	{
		displayError(e,"ValEmpOccCode");
	}
}

 */
 

 