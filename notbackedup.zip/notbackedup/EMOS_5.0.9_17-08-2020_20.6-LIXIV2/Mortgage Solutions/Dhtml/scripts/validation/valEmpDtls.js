//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//	Revision:	1.0
//	Author:		Arshad K
//	Workfile:	valEmpDtls.js
//	ModTtime:	19/04/2005
//============================================================-->


//==============================================================
//	Name:		CheckSomeEmpDtlsRequired
//	Purpose:	Common function to check if the specific employment 
//				details are required
//	Parameters:	oEmpDtls - (XML node) single employment dtls XML element
//				sFldToChk - (string) employment details field name
//				bNumber - (boolean) flag to indicate that the value 
//							is numeric
//				bReqForPrev - (boolean) flag indicating that the value 
//							is mandatory for previous empl. when all 
//							other requirements met
//							employment record, should be 0 or -1
//	Return:		boolean - true, if the combintaion is valid,
//							otherwise - false
//==============================================================
function CheckSomeEmpDtlsRequired(oEmpDtls,sFldToChk, bNumber, bReqForPrev)
{
	try
	{
		var bPrevEmp = (oEmpDtls.selectSingleNode("PreviousEmployment").text=='-1')? true:false;
		var sEmpType = oEmpDtls.selectSingleNode("EmploymentType").text;
		var sOccCd = oEmpDtls.selectSingleNode("OccupationCode").text;
		var bNonEmpOcc = getSingleRDRow("A_TS_NON_EMPLMT_OCCD",'@OCCUPATION_CODE="'+ sOccCd + '"');
		var sFldVal = oEmpDtls.selectSingleNode(sFldToChk).text;
		
		if (bReqForPrev) bPrevEmp = false;

		/*if (!bNumber)
			return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? (sFldVal!=""):true;
		else
			return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? (sFldVal>0):true;*/
			
		if (!bNumber)
		{
			if(sFldToChk == "EmployerPhoneNumber")
			{
				var txtMobile = Validate_PhNumbers_OnLoad(oEmpDtls.selectSingleNode("EmployerPhoneNumber"));
				if(txtMobile)
				{
					return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? ((sFldVal!="")&&(sFldVal.length == 10)&&(txtMobile)):true;
				}
				else{
					return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? ((txtMobile)):true;
				}
			}
			else
			{
				return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? (sFldVal!=""):true;
			}
		}
		else
		{
			if(sFldToChk == "EmployerPhoneNumber")
			{
				var txtMobile = Validate_PhNumbers_OnLoad(oEmpDtls.selectSingleNode("EmployerPhoneNumber"));
				if(txtMobile)
				{
					return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? ((sFldVal!="")&&(sFldVal.length == 10)&&(txtMobile)):true;
				}
				else{
					return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? ((txtMobile)):true;
				}
			}
			else
			{
				return ((!bPrevEmp)&&(sEmpType!="NE")&&(!bNonEmpOcc))? (sFldVal>0):true;
			}
		}
	}
	catch(e)
	{
		displayError(e,"CheckSomeEmpDtlsRequired");
	}
}

//==============================================================
//	Name:		ValEmpPhNumb
//	Purpose:	Validates employer Phone Number 
//	Parameters:	oEmpDtls - (XML node) single EmpDtls XML element
//	Return:		boolean - true, if the employer first address line 
//							is valid, otherwise - false
//==============================================================
function ValEmpPhNumb(txtNode)
{
	try 
	{
		if(txtNode != null) {
			if(txtNode.text != "") {
				txtNode.text = (txtNode.text).replace(/\D+/g, "");
				var regexval = /^[0-9]+$/;
				var nValue=(regexval.test(txtNode.text));
				if((nValue==true)) {
					var nTextVal = ((txtNode.text).replace(/\s/g, ""));
					if(nTextVal != "") {
						if(nTextVal.length > 10){
							nTextVal = "0" +  nTextVal.substring(nTextVal.length - 9, nTextVal.length); 
						}
						else
						{
							nTextVal = nTextVal;
						}
						if(nTextVal.length==10) {
							txtNode.text =  nTextVal;
							return ((txtNode.text) && (true));
						}
						else{
							return ((txtNode.text) && (false));		
						}
					}
				}
				else 
				{
					txtNode.text = (txtNode.text).replace(/\D+/g, "");
					return ((txtNode.text) && (false));		
				}
			}
			else 
			{
				return (true);		
			}
		}
	}
	catch(e)
	{
		displayError(e,"ValEmpPhNumb");
	}
}
//End : Card 388

//==============================================================
//	Name:		ValEmpEmployerType
//	Purpose:	Validates customer employer type state
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if employer type is valid,
//							otherwise - false
//==============================================================
function ValEmpEmployerType(oEmpDtls)
{
	try
	{
		return CheckSomeEmpDtlsRequired(oEmpDtls,"EmployerType");
	}
	catch(e)
	{
		displayError(e,"ValEmpEmployerType");
	}
}

//==============================================================
//	Name:		ValEmpEmployerName
//	Purpose:	Validates customer employer name
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if employer name is valid,
//							otherwise - false
//==============================================================
function ValEmpEmployerName(oEmpDtls)
{	
	try
	{
		return CheckSomeEmpDtlsRequired(oEmpDtls,"EmployerName",false,-1);
	}
	catch(e)
	{
		displayError(e,"ValEmpEmployerName");
	}
}

//==============================================================
//	Name:		ValEmpEmployerAdr1
//	Purpose:	Validates employer first address line
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if the employer first address line 
//							is valid, otherwise - false
//==============================================================
function ValEmpEmployerAdr1(oEmpDtls)
{
	try
	{
		return CheckSomeEmpDtlsRequired(oEmpDtls,"EmployerAddress1");
	}
	catch(e)
	{
		displayError(e,"ValEmpEmployerAdr1");
	}
}

//Start : Card 388
//==============================================================
//	Name:		ValEmpPhoneNumber
//	Purpose:	Validates employer first address line
//	Parameters:	oEmpDtls - (XML node) single EmpDtls XML element
//	Return:		boolean - true, if the employer first address line 
//							is valid, otherwise - false
//==============================================================
function ValEmpPhoneNumber(oEmpDtls)
{
	try
	{
		var bValid = CheckSomeEmpDtlsRequired(oEmpDtls,"EmployerPhoneNumber",false,-1);
		var txtEmpFax = Validate_PhNumbers_OnLoad(oEmpDtls.selectSingleNode("EmployerFaxNumber"));
		return bValid;
	}
	catch(e)
	{
		displayError(e,"ValEmpPhoneNumber");
	}
}
//End : Card 388

//==============================================================
//	Name:		ValEmpGrossIncome
//	Purpose:	Validates customer gross income
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if gross income is valid,
//							otherwise - false
//==============================================================
function ValEmpGrossIncome(oEmpDtls)
{
	try
	{
		return CheckSomeEmpDtlsRequired(oEmpDtls,"GrossMonthlyIncome",true);
	}
	catch(e)
	{
		displayError(e,"ValEmpGrossIncome");
	}
}

//==============================================================
//	Name:		ValEmpMonths
//	Purpose:	Validates months at employment
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if net income is valid,
//							otherwise - false
//==============================================================
function ValEmpMonths(oEmpDtls)
{
	try
	{
		var mm = GetIntVal(oEmpDtls.selectSingleNode("MonthsInEmployment").text);
		return (mm<12);
	}
	catch(e)
	{
		displayError(e,"ValEmpMonths");
	}
}

//==============================================================
//	Name:		ValEmpNetIncome
//	Purpose:	Validates customer net income
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if net income is valid,
//							otherwise - false
//==============================================================
function ValEmpNetIncome(oEmpDtls)
{
	try
	{
		var nNet = GetIntVal(oEmpDtls.selectSingleNode("NetMonthlyIncome").text);
		var nGross = GetIntVal(oEmpDtls.selectSingleNode("GrossMonthlyIncome").text);
		return (CheckSomeEmpDtlsRequired(oEmpDtls,"NetMonthlyIncome",true)&&(nNet<=nGross));
	}
	catch(e)
	{
		displayError(e,"ValEmpNetIncome");
	}
}

//==============================================================
//	Name:		ValEmpOccCode
//	Purpose:	Validates customer occupation code
//	Parameters:	oCust - (XML node) single customer XML element
//				bPrevEmp - (boolean) flag indicating previous 
//							employment record, should be 0 or -1
//	Return:		boolean - true, if occupation code is valid,
//							otherwise - false
//==============================================================
function ValEmpOccCode(oEmpDtls)
{
	try
	{
		var bPrevEmp = (oEmpDtls.selectSingleNode("PreviousEmployment").text=="-1")? true:false;
		if ((!oEmpDtls)&&(bPrevEmp)) return true;	//N/A for previous
		var sEmpType = oEmpDtls.selectSingleNode("EmploymentType").text;
		var sOccCd = oEmpDtls.selectSingleNode("OccupationCode").text;
		var sOccGrp = oEmpDtls.selectSingleNode("OccupationGroup").text;
	
		return (sOccCd!="");
	}
	catch(e)
	{
		displayError(e,"ValEmpOccCode");
	}
}

//Start : Card 388
//==============================================================
//	Function Name:	ValEmpCountry
//	Parameters:		oAddr - (XML Node) Address node
//	Return:			Boolean - Valiod flag
//	Description:	Validates the country
//==============================================================
function ValEmpCountry(oAddr)
{
	try
	{
		var valid = false;
		if (!oAddr) return valid;
		var bOversea = (oAddr.selectSingleNode("EmployerOverseasAddress").text=="-1");
		var sVal = oAddr.selectSingleNode("EmployerCountry").text;
		valid = (bOversea && !(sVal==""))||(sVal=="" && !bOversea);
		
		return valid;
	}
	catch (e)
	{
		displayError(e,"ValEmpCountry");
	}
	
}

//==============================================================
//	Function Name:	ValEmpCity
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the city
//==============================================================
function ValEmpCity(oEmpAddr)
{
	try
	{
		return ValAddressFld(oEmpAddr,"EmployerCity","@C");
	}
	catch (e)
	{
		displayError(e,"ValEmpCity");
	}
}

//==============================================================
//	Function Name:	ValEmpState
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the state
//==============================================================
function ValEmpState(oEmpAddr)
{
	try
	{
		return ValAddressFld(oEmpAddr,"EmployerState","@S");
	}
	catch (e)
	{
		displayError(e,"ValEmpState");
	}
}

//==============================================================
//	Function Name:	ValEmpPostcode
//	Parameters:		oAddr- (XML Node) Address Node
//	Return:			Boolean - Valid Flag
//	Description:	Validates the postcode
//==============================================================
function ValEmpPostcode(oEmpAddr)
{
	try
	{
		return ValAddressFld(oEmpAddr,"EmployerPostcode","@P");
	}
	catch (e)
	{
		displayError(e,"ValEmpPostcode");
	}
}

//==============================================================
//	Function Name:	ValAddressFld
//	Parameters:		oAddr - (XML Node) Address node
//					sFldName - (string) DSO field name
//					sAttr - (string) Ref data attribute name
//	Return:			Boolean - Valid flag
//	Description:	Validates given address fields
//==============================================================
function ValAddressFld(oEmpAddrDtls,sFldName,sAttr)
{
	var valid = false;
		
	try
	{
		
		if (!oEmpAddrDtls) return valid;
		var bPrevEmp = (oEmpAddrDtls.selectSingleNode("EmploymentStatusDesc").text=="Current - Unemployed")? true:false;
		var bPrevEmpType = (oEmpAddrDtls.selectSingleNode("EmploymentType").text=="NE")? true:false;
		if ((oEmpAddrDtls)&&(bPrevEmpType)) {
			valid = true;
		}	
		else if ((oEmpAddrDtls)&&(bPrevEmp)) {
			valid = true;	
		}
		else
		{
			//must be not empty and valid
			valid = CheckSomeEmpDtlsRequired(oEmpAddrDtls,sFldName,false,-1);
			var bOversea = (oEmpAddrDtls.selectSingleNode("EmployerOverseasAddress").text=="-1");
			if(valid && !bOversea)
			{
				var sVal = oEmpAddrDtls.selectSingleNode(sFldName).text.toUpperCase();
				// ensure that no invalid ' string combinations appear in the search string
				sVal = sVal.replace(/"/g, '');
				valid = valid && (getSingleRDRow("A_E_TSR_PC", sAttr + '="' + sVal + '"')!=null)
			}
		}	
		return valid;		
	}
	catch (e)
	{
		displayError(e,"ValAddressFld");
	}
}

//==============================================================
//	Function Name:	ValEmpCityStatePC
//	Parameters:		oEmpAddrDtls - (XML Node) Address node
//	Return:			Boolean - Valiod flag
//	Description:	Validates city state and post code combo
//==============================================================
function ValEmpCityStatePC(oEmpAddrDtls)
{	
	try
	{
		var valid = false;
		if (!oEmpAddrDtls) return valid;
		
		var bPrevEmp = (oEmpAddrDtls.selectSingleNode("EmploymentStatusDesc").text=="Current - Unemployed")? true:false;
		var bPrevEmpType = (oEmpAddrDtls.selectSingleNode("EmploymentType").text=="NE")? true:false;
		if ((oEmpAddrDtls)&&(bPrevEmpType)) {
			valid = true;
		}	
		else if ((oEmpAddrDtls)&&(bPrevEmp)) {
			valid = true;	
		}
		else
		{
			var bOversea = (oEmpAddrDtls.selectSingleNode("EmployerOverseasAddress").text=="-1");
			if(bOversea) valid = true;
			else
			{
				//must be valid combination
				var sCity = oEmpAddrDtls.selectSingleNode("EmployerCity").text.toUpperCase();
				var sState = oEmpAddrDtls.selectSingleNode("EmployerState").text;
				var sPC = oEmpAddrDtls.selectSingleNode("EmployerPostcode").text;
				
				// ensure that no invalid ' string combinations appear in the search string
				sCity = sCity.replace(/"/g, '');
				sState = sState.replace(/"/g, '');
				var sCheck='@P="' + sPC + '" and @C="' + sCity + '" and @S="' + sState +'"';
				valid = (getSingleRDRow("A_E_TSR_PC", sCheck)!=null);
			}
		}	
		return valid;		
	}
	catch (e)
	{
		displayError(e,"ValEmpCityStatePC");
	}
}
//End : Card 388