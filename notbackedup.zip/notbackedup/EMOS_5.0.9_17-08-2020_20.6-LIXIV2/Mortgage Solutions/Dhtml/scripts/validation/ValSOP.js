//<script>
//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.1  $
//	$Author:   sivanann  $
//	$Workfile:   valsop.js  $
//	$Modtime:   Jul 25 2011 22:00:08  $	
//============================================================-->


//============================================================================
//	Function Name:	ValDescription
//	Parameters:		oSOPItem - eg. <Asset> or <Liability> node
//					sDescNodeNm - Decription node name eg. AssetDescription
//					sTypeNodeNm - Node name used for check in validation
//					sChkVal - Value to check
//	Return:			Validation boolean
//	Description:	Validate whether the description field is required
//					for the entry.
//============================================================================
function ValDescription(oSOPItem, sDescNodeNm, sTypeNodeNm, sChkVal)
{
	try
	{
		var sType=oSOPItem.selectSingleNode(sTypeNodeNm).text;
		var sDesc=oSOPItem.selectSingleNode(sDescNodeNm).text;
		var valid = ((sType==sChkVal) && (sDesc)) || (sType!=sChkVal);
		if((((sTypeNodeNm == 'AssetType') && (sDescNodeNm == 'AssetDescription') && (sType == "001")) || ((sTypeNodeNm == 'LiabilityType') && (sDescNodeNm == 'LiabilityDescription') && ((sType == "001") || (sType == "002") || (sType == "003")))))
		{
			var iAcctNum = ((oSOPItem.selectSingleNode(sDescNodeNm).text == "") || (isNaN(oSOPItem.selectSingleNode(sDescNodeNm).text))) ? "" : parseInt(oSOPItem.selectSingleNode(sDescNodeNm).text);
			valid = ((iAcctNum > 0) && (oSOPItem.selectSingleNode(sDescNodeNm).text.length <= 9) && (oSOPItem.selectSingleNode(sDescNodeNm).text.length >= 7)) ? true : false;
			
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValDescription');
	}
}


//============================================================================
//	Function Name:	ValSPDate
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate SPDate
//============================================================================
function ValSPDate(oSOP)
{
	try
	{
		if(oSOP.selectSingleNode('SPDate') != null)
			return VBValSPDate(oSOP.selectSingleNode('SPDate').text);
		
	}
	catch (e)
	{
		displayError(e,'ValSPDate');
	}
}


//============================================================================
//	Function Name:	ValSPCustomers
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate SPCustomers
//============================================================================
function ValSPCustomers(oSOP)
{
	try
	{
		var oSPCust=oSOP.selectSingleNode('SPCustomers/SPCustomer[@Related="-1"]');
		return (oSPCust);
	}
	catch (e)
	{
		displayError(e,'ValSPCustomers');
	}
}


//============================================================================
//	Function Name:	ValExpenses
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate Expenses - Total Living Expenses (016) must exist and greater than 0.
//============================================================================
function ValExpenses(oSOP)
{
	try
	{
		var valid = false;		
		var oLivExp = "Expenses/Expense[ExpenseType='020' or ExpenseType='040' or ExpenseType='041' or ExpenseType='042' or ExpenseType='024' or ExpenseType='043' or ExpenseType='044' or ExpenseType='045' or ExpenseType='046' or ExpenseType='047' or ExpenseType='034' or ExpenseType='035']/DeclaredAmount";
		valid = CalcTotalofExpense(oSOP,oLivExp);
		if(valid)
		{
			valid = ValRelatedSPRentBoard(oSOP);
		}
		return valid;						
	}
	catch (e)
	{
		displayError(e,'ValExpenses');
	}
}

//============================================================================
//	Function Name:	CalcTotalofExpense
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean/sum of Total expenses
//	Description:	Calculates the sum of Expenses for the passed ExpType
//============================================================================
function CalcTotalofExpense(oSOP,oSOPExp)
{
	try
	{
		var oTotExp = oSOP.selectNodes(oSOPExp);
		var iTotExpCount = 0;
		for(var index=0; index<=oTotExp.length-1; index++)
		{
			oTotExp.nextNode;
			iTotExpCount += (oTotExp(index))?  GetIntVal(oTotExp(index).text):0; 
		}
		return (isNaN(iTotExpCount))? 0:iTotExpCount;			
	}
	catch (e)
	{
		displayError(e,'CalcTotalofExpense');
	}
}


//============================================================================
//	Function Name:	ValSPDirectOwners
//	Parameters:		nil
//	Return:			Validation boolean
//	Description:	Validate DirectOwners
//============================================================================
function ValSPDirectOwners()
{
	try
	{
		var valid=true;
		var oDocEl=xml_master.XMLDocument.documentElement;

		//if no SOP records return true
		if (!oDocEl.selectSingleNode('StatementsOfPosition/StatementOfPosition')) return valid;
	
		var oCustList=oDocEl.selectNodes('Customers/Customer');
		for (var i=0; i<oCustList.length; i++)
		{
			var sCustID=oCustList(i).selectSingleNode('CustomerID').text
			var sCustType=oCustList(i).selectSingleNode('CustomerType').text;
			if (sCustType.length>0)
			{
				//get the row regarding rules in refdata  
				var oR = getRDRowObject('A_TS_CUS_REL_CONTROL','@CATEGORY="ACCU" and @RELATIONSHIP_CODE="' + sCustType + '" and @PRODUCT_CODE="MOS"');
				if (oR && oR.DIRECT_OWNER_YN) 
				{
					var oSPCust = oDocEl.selectSingleNode('StatementsOfPosition/StatementOfPosition/SPCustomers/SPCustomer[CustomerID='+sCustID+' and @Related="-1"]');
					if (!oSPCust) valid = false; //not found in SPCustomers
				}	
			}
			else
			{	//when no CustomerType input
				valid = true;
			}
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValSPDirectOwners');
	}
}


//============================================================================
//	Function Name:	ValAssetValue
//	$Author:   sivanann  $
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate Assetvalue - Assetvalue must exist and greater than 0.
//============================================================================
function ValAssetValue(oSOP) {
    try {
        var iGuarAmt = GetIntVal(oSOP.selectSingleNode("AssetValue").text);
        return (iGuarAmt > 0);
    }
    catch (e) {
        displayError(e, 'ValAssetValue');
    }
}

//Start : Card 394

//============================================================================
//	Function Name:	ValLiabMthlyExp
//	$Author:   Balaji G  $
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate Monthly Exp for Liability - Monthly Exp must exist and greater than 0.
//============================================================================
function ValLiabMthlyExp(oSOP) {
    try 
	{
		var sType = oSOP.selectSingleNode("LiabilityType").text;
		if((sType == "003")&&((oSOP.selectSingleNode('BreakFreeCardType').text).indexOf("New Credit Card") == -1) && 
			(oSOP.selectSingleNode('BFANZCreditCard').text == "1")) 
		{
				return true;
		}
		else
		{
			//***********************Jira 543 Clearing of monthly expense for Liability --> monthly expense making Mandatory 
				var iLiabAmtOwing = GetIntVal(oSOP.selectSingleNode("AmountOwing").text);
				var iMExp = GetIntVal(oSOP.selectSingleNode("MthlyExp").text);
				if(iLiabAmtOwing > 0) {
					return (iMExp > 0);
				}
				else {
					return (iMExp >= 0);
				}
				
			//***********************Jira 543 End ************************
		}
		
	}
    catch (e) 
	{
        displayError(e, 'ValLiabMthlyExp');
    }
}

//==============================================================
//	Function Name:	ValLiabBankFinInstitution
//	Parameters:		oNode - (XML Node) Asset node
//					oType - (string) Type from Asset or Liab
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that Bank/Fin Ist. has value for OFI Liability type
//==============================================================
function ValBankFinInstitution(oNode, oType) {
	try 
	{
		var valid = true;
		var sTypeCode = oNode.selectSingleNode(oType).text;
		if(oType == "AssetType")
		{
			if((sTypeCode == "002") || (sTypeCode == "009")) 
			{
			
				var sNodeText = oNode.selectSingleNode("AssetBankFinInstitution").text;
				valid = (sNodeText!="")? true : false;
							
			}
		}
		if(oType == "LiabilityType")
		{
			if((sTypeCode == "005") || (sTypeCode == "006") || (sTypeCode == "007")) 
			{
				var sNodeText = oNode.selectSingleNode("LiabBankFinInstitution").text;
				valid = (sNodeText!="")? true : false;
			}
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,"ValLiabBankFinInstitution");
	}
}
//End : Card 394

//Start : Card 365
//==============================================================
//	Function Name:	ValAssetPropDetails
//	Parameters:		oProp - (XML Node) Asset node
//					sNodeName - (string) name of property based field
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that this property type field has a value
//==============================================================
function ValAssetPropDetails(oProp, node) {
	try 
	{
		var valid;
		var sPropTypeCode = oProp.selectSingleNode("AssetType").text;
		if(sPropTypeCode != "003") 
			valid = true;
		else
		{
			var sNodeText = oProp.selectSingleNode(node).text;
			sNodeText = VBTrim(sNodeText);
			if((node == "AssetLinkedPropAddr"))
			{
				if(sNodeText == 0){
					valid = false;
				}
				else{
					var oMDocEl = SOPMasterXML;
					if(oMDocEl != undefined) {
						if(oMDocEl.selectNodes("//Securities/Security").length > 0) {
							var oSecCnt = oMDocEl.selectNodes('Securities/Security[SecurityType = "B"]');
							if(oSecCnt.length == 0){
								oSecCnt = oMDocEl.selectNodes('Security[SecurityType = "B"]');
							}
							if(oSecCnt.length > 0) {
								for(var j=0; j < oSecCnt.length; j++) {	
									var SecAddrID = oSecCnt(j).selectSingleNode("AddressID").text
									if(sNodeText == SecAddrID) {
										valid = false;
										break;
									}
									else {
										valid = true;
									}
								}
							}
							else
							{
								valid = ((sNodeText!="") && (sNodeText !=0))? true : false;
							}
						}
						else
						{
							valid = ((sNodeText!="") && (sNodeText !=0))? true : false;
						}
					}
					else
					{
						valid = ((sNodeText!="") && (sNodeText !=0))? true : false;
					}
				} 
			}
			else
			{
				valid = ((sNodeText!="") && (sNodeText !=0))? true : false;
			}
			var sPropTypeName = oProp.selectSingleNode("AssetPropertyType").text;
			var sPropTypeZone = oProp.selectSingleNode("AssetPropertyZoning").text;
			
			if((sPropTypeZone == 'R') && (node == 'AssetPropertyType' ) && (sPropTypeName == 'ConvertedCommercialProperty' || sPropTypeName == 'ConvertedMotelUnits' || sPropTypeName == 'ConvertedIndustrialProperty'))
			{
				valid=false;
			}
			if((sPropTypeZone == 'C') && (node == 'AssetPropertyType' ) && (sPropTypeName == 'VacantLand' || sPropTypeName == 'RetirementVillage'))
			{
				valid=false;
			}
			
			
			
		}
		
		return valid;
			
	}
	catch (e)
	{
		displayError(e,"ValAssetPropDetails");
	}
}



//==============================================================
//	Function Name:	ValLiabilityPropAddressDetails
//	Parameters:		oSOP - (XML Node) Liability node
//					sNodeName - (string) name of property based field
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that this property type field has a value
//==============================================================
function ValLiabPropRelatedAddrDetails(oSOP, node) {
	
	try 
	{
		var valid = false;
		var sType = oSOP.selectSingleNode("LiabilityType").text;
		
		if((sType == "003")&&((oSOP.selectSingleNode('BreakFreeCardType').text).indexOf("New Credit Card") == -1) && 
			(oSOP.selectSingleNode('BFANZCreditCard').text == "1")) 
		{
				valid = true;
		}
		if((sType != '001') && (sType != '005')){ 
			valid = true;
		}
		else
		{
			var sNodeText = oSOP.selectSingleNode(node).text;
			valid = ((sNodeText!="") && (sNodeText !=0))? true : false;
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,"ValLiabPropRelatedAddrDetails");
	}
}


//============================================================================
//	Function Name:	ValRelatedSPRentBoard
//	Parameters:		nil
//	Return:			Validation boolean
//	Description:	Validate in Expenses, if Related SP has Rent/Board F.Housing
//============================================================================
function ValRelatedSPRentBoard(oSOP)
{
	try
	{	
		var valid=true;
		var oDocEl=xml_master.XMLDocument.documentElement;

		//if no SOP records or SPCustomer return true
		if ((!oDocEl.selectSingleNode('StatementsOfPosition/StatementOfPosition')) || (!oDocEl.selectSingleNode('StatementsOfPosition/StatementOfPosition/SPCustomers/SPCustomer'))) return valid;
		var oSPCustList=oSOP.selectNodes('SPCustomers/SPCustomer[@Related="-1"]');
		for (var i=0; i<oSPCustList.length; i++)
		{	
			var sSPCustID=oSPCustList(i).selectSingleNode('CustomerID').text;
			if (sSPCustID)
			{
				var oCust = oDocEl.selectSingleNode('Customers/Customer[CustomerID='+sSPCustID+']/HousingStatus').text;
				if((oCust == 'B') || (oCust == 'R'))
				{
					var oRentBoardExp = (oCust == 'B') ? "Expenses/Expense[ExpenseType='030']/DeclaredAmount" : (oCust == 'R') ? "Expenses/Expense[ExpenseType='031']/DeclaredAmount" : "";
					if(oRentBoardExp != "")
						valid = CalcTotalofExpense(oSOP,oRentBoardExp);				
				}					
			}
			if(!valid) return valid;
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValRelatedSPRentBoard');
	}
}
//Ends : Card 365

//============================================================================
//	Function Name:	ValAssetSplitup
//	Parameters:		nil
//	Return:			Validation boolean
//	Description:	Validates that the asset split up adds to 100
//============================================================================
function ValAssetSplitup(oSOPItem,Split)
{
	try {

	    var valid = false;
	    var bSplitup;
	    var nTotal=0;

	    bSplitup = oSOPItem.selectSingleNode("JointOwner").text;
	    if (bSplitup == -1) {
			var oCusts = oSOPItem.selectNodes("OwneshipProportion/Customer");
			for (var i = 0; i < oCusts.length; i++) {
                nTotal = nTotal + Number(oCusts[i].text);
		    }
		    if (nTotal != 100) {
		        valid = false;
		    }
		    else {
		        valid = true;
            }
	    }
	    else {
	        valid = true;        
        }

	    return valid;
	}
	catch (e) {
	    displayError(e, 'ValAssetSplitup');
	}
}


//============================================================================
//	Function Name:	ValAssetsUpgrade
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate Assets - Pop Up.
//============================================================================
function ValAssetsUpgrade(oSOP)
{
	try
	{
		var valid;
		var oTotPropAsset = "Assets/Asset";
		var oTotAssetsCnt = oSOP.selectNodes(oTotPropAsset);
		if(oTotAssetsCnt.length > 0){
			for(var iTotAssetCount=0; iTotAssetCount<=oTotAssetsCnt.length-1; iTotAssetCount++)
			{
				var nNodeSelect = oTotAssetsCnt.nextNode;
				var nAssetDesc = ValDescription(nNodeSelect, "AssetDescription", "AssetType", "001");
				var nAssetPropertyType = ValAssetPropDetails(nNodeSelect, "AssetPropertyType");
				var nAssetPropertyUse = ValAssetPropDetails(nNodeSelect, "AssetPropertyUse");
				var nAssetLinkedPropAddr = ValAssetPropDetails(nNodeSelect, "AssetLinkedPropAddr");
				var nAssetBankFinInstitution = ValBankFinInstitution(nNodeSelect,"AssetType");
				var nJointOwner = ValAssetSplitup(nNodeSelect,"JointOwner");
				var nAssetInvestment = ValInvestmentPropertyRunningCost(nNodeSelect,"AssetMonthlyInvestment");
				if((nAssetDesc) && (nAssetPropertyType) && (nAssetPropertyUse) && (nAssetLinkedPropAddr) && (nJointOwner) && (nAssetBankFinInstitution) && (nAssetInvestment)){
					valid = true;
				}
				else{
					valid = false;
					break;
				}
			}
		}
		else {
			valid = true;
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValAssetsUpgrade');
	}
}

//============================================================================
//	Function Name:	ValLiabilitiesUpgrade
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate Liability - Pop Up.
//============================================================================
function ValLiabilitiesUpgrade(oSOP)
{
	try
	{
		var valid;
		var oTotLiability = "Liabilities/Liability";
		var oTotLiabilityCnt = oSOP.selectNodes(oTotLiability);
		if(oTotLiabilityCnt.length > 0)
		{
			for(var iTotLiabilityCount=0; iTotLiabilityCount <= oTotLiabilityCnt.length-1; iTotLiabilityCount++)
			{
				var nNodeSelect = oTotLiabilityCnt.nextNode;
				var nLiabDesc;
				var nLiabBankFinInstitution = ValBankFinInstitution(nNodeSelect,"LiabilityType");
				var nLinkedPropertyAsset = ValLiabPropRelatedAddrDetails(nNodeSelect,"LinkedPropertyAsset");
				var nMthlyExp = ValLiabMthlyExp(nNodeSelect);
				var sType = nNodeSelect.selectSingleNode("LiabilityType").text;
				if((sType == "003")&&((nNodeSelect.selectSingleNode('BreakFreeCardType').text) == "New Credit Card") && 
					(nNodeSelect.selectSingleNode('BFANZCreditCard').text == "1")) 
					{
						nLiabDesc = true;
					}
					else
					{
						nLiabDesc = ValDescription(nNodeSelect, "LiabilityDescription", "LiabilityType", "004");
					}
				if((nLiabDesc) && (nLiabBankFinInstitution) && (nLinkedPropertyAsset) && (nMthlyExp))
				{
					valid = true;
				}
				else 
				{
					valid = false;
					break;	
				}
			}
		}
		else
		{
			valid = true;
		}
		return valid;						
	}
	catch (e)
	{
		displayError(e,'ValLiabilitiesUpgrade');
	}
}


//============================================================================
//	Function Name:	ValIncomeGovtBenefitType
//	$Author:   Divya Mohan Kumar for CFDS - 672  $
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate Govt Benefit Sub Type for Income.
//============================================================================
function ValIncomeGovtBenefitType(oSOP) {
    try 
	{
		var valid = true;
		var sTypeCode = oSOP.selectSingleNode("IncomeType").text;
		if((sTypeCode == "004")) {
			var sNodeText = oSOP.selectSingleNode("IncomeGovtBenefitType").text;
			valid = (sNodeText!="")? true : false;
		}
		return valid;
	}
	catch (e) 
	{
        displayError(e, 'ValIncomeGovtBenefitType');
    }
}


//============================================================================
//	Function Name:	ValIncomeUpgrade
//	$Author:   Divya Mohan Kumar for CFDS - 672  $
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate Govt Benefit Sub Type for Income Type 004 only.
//============================================================================
function ValIncomeUpgrade(oSOP)
{
	try
	{
		var valid = true;
		var oTotIncome = "Incomes/Income[IncomeType='004']";
		var oTotIncomeCnt = oSOP.selectNodes(oTotIncome);
		if(oTotIncomeCnt.length > 0){
			for(var iTotIncomeCount=0; iTotIncomeCount<=oTotIncomeCnt.length-1; iTotIncomeCount++) {
				var nNodeSelect = oTotIncomeCnt.nextNode;
				var nIncomeGovtBenefitType = ValIncomeGovtBenefitType(nNodeSelect);
				if((nIncomeGovtBenefitType)){ valid = true; }
				else {
					valid = false;
					break;
				}
			}
		}
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValIncomeUpgrade');
	}
}
//============================================================================
//	Function Name:	ValAccountNumber
//	$Author:   sivanann  $
//	Parameters:		oSOP - <StatementOfPosition> node
//	Return:			Validation boolean
//	Description:	Validate Assetvalue - Assetvalue must exist and greater than 0.
//============================================================================
function ValAccountNumber(oSOP) {
    try {
        var iGuarAmt = oSOP.selectSingleNode("AssetValue").length;
        return (iGuarAmt < 7);
    }
    catch (e) {
        displayError(e, 'ValAccountNumber');
    }
}
//===========================================================================
//	Function Name:	ExpenseSelected
//	Parameters:		ExpenseTypes
//	Return:			String FullDescription of Expense
//	Description:	LIXIV2 Changes JIRA Card CFDS-783 
//                  
//===========================================================================
function ExpenseSelected(xml_refData)
{
	
    var sExpenseType = document.getElementById("cboExpenseType");
    var sExpenseCode = sExpenseType.options[sExpenseType.selectedIndex].value;
	var sExpenseDesc = sExpenseType.options[sExpenseType.selectedIndex].text;
    
    if(sExpenseCode!="")
	{
		var sCriteria = '@TYPE_CODE='+sExpenseCode+'';
		
		var oRefDataNodes = getExpenseRDRows ("A_TS_EXPENSE_TYPES", sCriteria);
		
		for (var i=0; i < oRefDataNodes.length; i++)
		{
			
			var oRow = oRefDataNodes[i];
			var sVal = oRow.getAttribute("TYPE_CODE");
			var sDesc = oRow.getAttribute("FULL_DESC");
			
			if (sExpenseCode===sVal)
			{
				
				if (sDesc!="")
				{
					
					document.getElementById("Descriptions").innerHTML=sDesc;
					
				}
				else
				{
					
					document.getElementById("Descriptions").style.display = "block";
				}
				
			}
			
		}
			
        
		
	}
    
}
//==============================================================
//	Function Name:	getExpenseRDRows
//	Parameters:		sRefSOPDataDescription - (string) Node name
//					sCriteria - (string) XPath compliant criteria		
//	Return:			Node List	
//	Description:	returns the row nodes for a given table node
//==============================================================
function getExpenseRDRows (sRefDataName, sCriteria)
{
	try
	{
		var oRefNode = findRDExpenseNode(sRefDataName,sCriteria);
		if (!sCriteria)
			return oRefNode.childNodes;
		
		if(sCriteria=="EMPOVR")
			return oRefNode.childNodes;

		return oRefNode.selectNodes ('R[' + sCriteria + ']');
	}
	catch (e)
	{
		displayError(e,"getRDRows");
	}
		
}
//==============================================================
//	Function Name:	findRDExpenseNode
//	Parameters:		sRefSOPName - (string) node name
//	Return:			Node - Selected Ref SOP data node	
//	Description:	Selects a reference data node for the selected Expense Type
//==============================================================
function findRDExpenseNode (sRefDataName,sCriteria)
{
	try
	{
		return oxmlRefData.selectSingleNode ('/' + '*' + '/' + sRefDataName);
	}
	catch (e)
	{
		displayError(e,"findRDExpenseNode");
	}
}

//Start : Card 784

//==============================================================
//	Function Name:	ValInvestmentPropertyRunningCost
//	Parameters:		oNode - (XML Node) Asset node
//					oType - (string) Type from Asset or Liab
//	Return:			Boolean - Valid Flag		
//	Purpose:		Validate that if Asset Type is Property and Property Zone=Residentioal and Property Use=Investment 
//==============================================================
function ValInvestmentPropertyRunningCost(oSOP) 
{
	try 
	{
		var valid = true;
		var sTypeCode = oSOP.selectSingleNode("AssetType").text;
		var sTypeZone = oSOP.selectSingleNode("AssetPropertyZoning").text;
		var sTypeUse = oSOP.selectSingleNode("AssetPropertyUse").text;
			if (sTypeZone=='F')
			{
				sTypeZone='R';
			}
			if((sTypeCode == "003") && (sTypeZone=="R") && (sTypeUse=="I")) 
			{
				
				var sNodeText = oSOP.selectSingleNode("AssetMonthlyInvestment").text;
				valid = (sNodeText!="" && sNodeText>=0)? true : false;
							
			}
			
		
		return valid;
	}
	catch (e)
	{
		displayError(e,"ValInvestmentPropertyRunningCost");
	}
}