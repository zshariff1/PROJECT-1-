//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		Suresh K C
//	Workfile:	ValMortgageInterviewGuide.js
//	ModTtime:	09/05/2011
//============================================================-->
//<SCRIPT>


//==============================================================
//	Name:		ValReasonForRefinance
//	Purpose:	Validates the reason for refinance
//	Return:		boolean - true, if it is valid,
//							otherwise - false
//==============================================================
function ValReasonForRefinance()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');

		var sIsRefinanceLoan = (oMIGDetails.selectSingleNode('IsRefinanceLoan'))? oMIGDetails.selectSingleNode('IsRefinanceLoan').text:'';
		var sReasonForRefinance = (oMIGDetails.selectSingleNode('ReasonForRefinance'))? oMIGDetails.selectSingleNode('ReasonForRefinance').text:'';
		
		return (sIsRefinanceLoan == 1 && sReasonForRefinance.length == 0)? false : true;
	}
	catch(e)
	{
		displayError(e,"ValReasonForRefinance");
	}
}


//==============================================================
//	Name:		ValOtherRefinanceReason
//	Purpose:	Validates reason for refinance if other as reason for refinance
//	Return:		boolean - true, if it as value,
//							otherwise - false
//==============================================================
function ValOtherRefinanceReason()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var sReasonForRefinance = (oMIGDetails.selectSingleNode('ReasonForRefinance'))? oMIGDetails.selectSingleNode('ReasonForRefinance').text:'';
		var sOtherRefinanceReason = (oMIGDetails.selectSingleNode('OtherRefinanceReason'))? oMIGDetails.selectSingleNode('OtherRefinanceReason').text:'';

		return(sReasonForRefinance == 'Other' && sOtherRefinanceReason.length == 0)? false : true;
		
	}
	catch(e)
	{
		displayError(e,"ValOtherRefinanceReason");
	}
}


//==============================================================
//	Name:		ValChangeInFinancialStatus
//	Purpose:	Validates is there any change in the financial status
//	Return:		boolean - true, if it is changed,
//							otherwise - false
//==============================================================
function ValChangeInFinancialStatus()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var sIsChangeInFinancialStatus = (oMIGDetails.selectSingleNode('IsChangeInFinancialStatus'))? oMIGDetails.selectSingleNode('IsChangeInFinancialStatus').text:'';
		var sChangeInFinancialStatus = (oMIGDetails.selectSingleNode('ChangeInFinancialStatus'))? oMIGDetails.selectSingleNode('ChangeInFinancialStatus').text:'';
		
		return (sIsChangeInFinancialStatus == 1 && sChangeInFinancialStatus.length == 0)? false : true;
	}
	catch(e)
	{
		displayError(e,"ValChangeInFinancialStatus");
	}
}

//==============================================================
//	Name:		ValRepaymentPlan
//	Purpose:	Validates the Repayment Plan when there is any reduced income
//	Return:		boolean - true, if it is reduced income,
//							otherwise - false
//==============================================================
function ValRepaymentPlan()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var sIsChangeInFinancialStatus = (oMIGDetails.selectSingleNode('IsChangeInFinancialStatus'))? oMIGDetails.selectSingleNode('IsChangeInFinancialStatus').text:'';
		var sRepaymentPlan = (oMIGDetails.selectSingleNode('RepaymentPlan'))? oMIGDetails.selectSingleNode('RepaymentPlan').text:'';
		
		return (sIsChangeInFinancialStatus == 1 && sRepaymentPlan.length == 0)? false : true;
	}
	catch(e)
	{
		displayError(e,"ValRepaymentPlan");
	}
}

//==============================================================
//	Name:		ValRepaymentPlanText
//	Purpose:	Validates the Repayment Plan text when there is any reduced income
//	Return:		boolean - true, if it is valid,
//							otherwise - false
//==============================================================
function ValRepaymentPlanText()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var sRepaymentPlan = (oMIGDetails.selectSingleNode('RepaymentPlan'))? oMIGDetails.selectSingleNode('RepaymentPlan').text:'';
		var sRepaymentPlanText = (oMIGDetails.selectSingleNode('RepaymentPlanText'))? oMIGDetails.selectSingleNode('RepaymentPlanText').text:'';
		
		return (sRepaymentPlan == 'Other (please specify)' && sRepaymentPlanText.length == 0)? false : true;
	}
	catch(e)
	{
		displayError(e,"ValRepaymentPlanText");
	}
}

/* Commented for PRODUCTIOn ISSUE
//==============================================================
//	Name:		ValReasonForInterestonly
//	Purpose:	Validates the reason for interest only
//	Return:		boolean - true, if it is valid,
//							otherwise - false
//==============================================================

function ValReasonForInterestOnly()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var scboRepaymentPreferences=(oMIGDetails.selectSingleNode('RepaymentPreference'))? oMIGDetails.selectSingleNode('RepaymentPreference').text:'';
		var sReasonForInterestonly = (oMIGDetails.selectSingleNode('ReasonForInterestOnly'))? oMIGDetails.selectSingleNode('ReasonForInterestOnly').text:'';	
		return ((scboRepaymentPreferences == 'Interest Only' || scboRepaymentPreferences == 'Interest in Advance') && (sReasonForInterestonly.length  == 0))? false : true;
	
	}
	catch(e)
	{
		displayError(e,"ValReasonForInterestOnly");
	}
}
//==============================================================
//	Name:		ValOtherReasonIntOnly
//	Purpose:	Validates reason for refinance if other as reason for refinance
//	Return:		boolean - true, if it as value,
//							otherwise - false
//==============================================================
function ValOtherReasonIntOnly()
{
	try
	{		 
		 var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		 var sReasonForInterestonly = (oMIGDetails.selectSingleNode('ReasonForInterestOnly'))? oMIGDetails.selectSingleNode('ReasonForInterestOnly').text:'';
		 var sOtherReasonForInterestonly = (oMIGDetails.selectSingleNode('OtherReasonIntOnly'))? oMIGDetails.selectSingleNode('OtherReasonIntOnly').text:''; 
		 return(sReasonForInterestonly == 'Other (please provide reason in description box)' && sOtherReasonForInterestonly.length == 0)? false : true;		
	
	}
	catch(e)
	{
		displayError(e,"ValOtherReasonIntOnly");
	}
}


*/

//==============================================================
//	Name:		IsAlphaNumeric
//	Purpose:	Validates other as reason is Alphanumeric
//	Return:		boolean - true, if it as value,
//							otherwise - false
//==============================================================
function IsAlphaNumeric(e) 
	{		
		var keyCode = e.keyCode ;           
		var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || (keyCode == 32));           
		return ret;
	}
//==============================================================
//	Name:		ValCustLoanPurposeDecl
//	Purpose:	Validates the customer lending purposes Declarations
//	Return:		boolean - true, if it is valid,
//							otherwise - false
//==============================================================

function ValCustLoanPurposeDecl()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var scboCustLoanPurposeDecl=(oMIGDetails.selectSingleNode('CustLoanPurposeDecl'))? oMIGDetails.selectSingleNode('CustLoanPurposeDecl').text:'';
		return  (scboCustLoanPurposeDecl.length  == 0)? false : true;
		
	}
	catch(e)
	{
		displayError(e,"ValCustLoanPurposeDecl");
	}
}
	
//==============================================================
//	Name:		ValIsCustomerHasOtherIncome
//	Purpose:	Validates the customer's other income confirmation
//	Return:		boolean - true, if it is valid,
//							otherwise - false
//==============================================================
function ValIsCustomerHasOtherIncome()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var scboIsCustomerHasOtherIncome=(oMIGDetails.selectSingleNode('IsCustomerHasOtherIncome'))? oMIGDetails.selectSingleNode('IsCustomerHasOtherIncome').text:'';
		return  (scboIsCustomerHasOtherIncome.length  == 0)? false : true;
		
	}
	catch(e)
	{
		displayError(e,"ValIsCustomerHasOtherIncome");
	}
}
