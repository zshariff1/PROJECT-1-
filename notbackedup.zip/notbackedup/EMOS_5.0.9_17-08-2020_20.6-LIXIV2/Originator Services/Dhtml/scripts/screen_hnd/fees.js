//<script>
//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.0  $
//	$Author:   maheedhv  $
//	$Workfile:   fees.js  $
//	$Modtime:   Aug 01 2005 15:23:24  $	
//============================================================-->

//===========================
// Declare global variables
//===========================
var G_bFeesDirty = false;


//==========================================================================
//	Function Name:	FeesScreenShow
//	Parameters:		nil
//	Return:			nil
//	Descripion:		Initialise the Fees Screen 
//					For new application - Do nothing.
//					For existing application - Replace the stub xml from loaded master xml. 
//==========================================================================
function FeesScreenShow()
{
	try
	{
		G_pScreenSaveFunction = saveFees;

		ds_fees.src = ds_fees.src;
		var oLoadFees = xml_master.XMLDocument.documentElement.selectSingleNode('Fees');
		if (oLoadFees.hasChildNodes)
			ds_fees.XMLDocument.replaceChild(oLoadFees.cloneNode(true),ds_fees.XMLDocument.documentElement);
				
		SetFocusOnElement("inpPeriodicPayments");
	}
	catch (e)
	{
		displayError(e,'FeesScreenShow');	
	}
}


//==========================================================================
//	Function Name:	saveFees
//	Parameters:		nil
//	Return:			nil
//	Descripion:		Save Fees to master xml, validate and FlushToDisk.
//==========================================================================
function saveFees()
{
	try
	{
		if (!G_bFeesDirty) return;
		var oNewFees = ds_fees.XMLDocument.documentElement;
		var oReplFees = xml_master.XMLDocument.documentElement.selectSingleNode('Fees');
		//save fees only if at least one was selected, otherwise remove empty tags
		oReplFees.parentNode.replaceChild(oNewFees.cloneNode((oNewFees.selectSingleNode("//*[.=-1]")? true:false)), oReplFees)
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode('Fees'));
		G_bFeesDirty = false
		FlushToDisk();
	}
	catch (e)
	{
		displayError(e,'saveFees');	
	}
}


//==========================================================================
//	Function Name:	SetFeesDirty
//	Parameters:		nil
//	Return:			nil
//	Descripion:		Set screen dirty.
//==========================================================================
function SetFeesDirty()
{
	G_bFeesDirty = true;
}


//==========================================================================
//	Function Name:	ValFees
//	Parameters:		nil
//	Return:			nil
//	Descripion:		Validate Fees.
//==========================================================================
function ValFees()
{
	return true;
}
