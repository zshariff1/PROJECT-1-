//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.0  $
//	$Author:   maheedhv  $
//	$Workfile:   SPAsset.js  $
//	$Modtime:   Aug 01 2005 14:20:42  $	
//============================================================-->
//<SCRIPT>

//Globals
var G_selectedAdrRec = 0;
var ParentSOP_ID = 0;
var O_AstRecNo = 0;


//====================================================================
//	Function Name:	initAssetDtlsDlg
//	Parameters:		nil
//					But the record passed from the main screen as window.dialogArguments
//					when popup window opens.
//	Return:			nil
//	Description:	Initialise the Asset pop-up window for Add/Edit.
//====================================================================
function initAssetDtlsDlg()
{
	try
	{
		G_bSaveIsAllowed=true;
		initRefData();
		initXMLObject(ds_spAsset);
		initXMLObject(xml_spDescLabels);
		initXMLObject(xml_ClickHelp)
		initXMLObject(xml_AppBRS);
		
//		var oAsset = window.dialogArguments;
//		document.all.divCaption.innerText = (oAsset.childNodes(0).text)? 'Edit Asset Details':'New Asset';
//	
//		ds_spAsset.src=ds_spAsset.src;
//		ds_spAsset.XMLDocument.appendChild(oAsset);

		var oArrPassed = window.dialogArguments;

		var oAddresses = oArrPassed[1].selectSingleNode('Addresses');
		
		var oAddressesForVal = oArrPassed[1].selectSingleNode('Addresses');
		
		ds_SOP.XMLDocument.appendChild(oArrPassed[1].selectSingleNode('Customers'));

		ds_FullApp.XMLDocument.appendChild(oArrPassed[1]);
		
		O_AstRecNo = oArrPassed[2];
		//alert("RECNO==> " + O_AstRecNo);
		
		
		var oAssets = oArrPassed[0];
		
		var idx = GetIntVal(oAssets.getAttribute('RecIndex'));
		document.all.divCaption.innerText = (idx>=0) ? 'Edit Asset Details':'New Asset';
	
		ds_spAsset.src=ds_spAsset.src;
		var oAst = (idx>=0) ? oAssets.childNodes(idx): oAssets.childNodes(0);
		ds_spAsset.XMLDocument.appendChild(oAst.cloneNode(true));
		//var nParentSOP = ds_spAsset.XMLDocument.documentElement.getAttribute('ParentSPID');
		var nParentSOP = oAssets.getAttribute('ParentSPID');
		ParentSOP_ID = nParentSOP;
		BuildSOPCustomerSection(nParentSOP);
		PopulateSOPCustomerSection();
		SplitOwnership();

		//Build sCriteria to populate the list of AssetType combo-box 
		//The list exclude the types that can be added only once and are already in the dso (but not the current record).
		var sCriteria = '@ONE_PER_SOP="0" or (@ONE_PER_SOP="1"';
		var oOnePerSOP, oRslt, sType;
		var sAstType = ds_spAsset.XMLDocument.documentElement.selectSingleNode('AssetType').text;
		if (sAstType)
			oOnePerSOP = getRDRows('A_TS_ASSET_TYPES','@ONE_PER_SOP="1" and @TYPE_CODE!="'+sAstType+'"')
		else
			oOnePerSOP = getRDRows('A_TS_ASSET_TYPES','@ONE_PER_SOP="1"');
		for (var i=0;i<oOnePerSOP.length;i++)
		{
			sType = oOnePerSOP(i).getAttribute('TYPE_CODE')
			oRslt = oAssets.selectSingleNode('Asset[AssetType="'+sType+'"]');
			if (oRslt)
				sCriteria += ' and @TYPE_CODE!=' + sType;
		}
		sCriteria += ')';

		// populate combo-boxes
		populateList('A_TS_ASSET_TYPES', document.all.tblAssetDtls.all('cboAssetType'), sCriteria, 'TYPE_CODE', 'CODE_DESC');
		
		if (oAddresses == null) {
		}
		else {
			ds_PopupAddresses.XMLDocument.replaceChild(oAddresses, ds_PopupAddresses.XMLDocument.documentElement);
		        PopulateLinkedPropertyAddress(ds_PopupAddresses);
		}

		check_AssetType(true);
		InitilizeAppBRS(ds_spAsset.XMLDocument.documentElement);	


		// Added for Validation in Pop - Up of Assets
		var oAstidx = GetIntVal(oAssets.getAttribute('RecIndex'));
		if((oAstidx >= 0))
		{
			var oAsset = ds_spAsset.XMLDocument.documentElement;
			var oSec_Addr = oArrPassed[1].selectSingleNode('Securities');
			SOPMasterXML = oSec_Addr;
			var bResult_Ast = EvaluateAppBRS(oAsset);
		}
		// Added for Validation in Pop - Up of Assets
		document.getElementById("sDesAssetMonthlyInvestment").innerHTML="Includes body corporate fees, strata fees, land tax, property management fees, rates, utilities, repairs and maintenance, electricity, furniture and homewares, home and contents insurance, landlords insurance.";
	}
	catch (e)
	{
		displayError(e,'initAssetDtlsDlg');	
	}
}


//====================================================================
//	Function Name:	saveAssetDtls
//	Parameters:		nil
//	Return:			Asset record back to main screen
//	Description:	When click on [save] in the popup window.
//====================================================================
function saveAssetDtls()
{
	try
	{
		var oAsset = ds_spAsset.XMLDocument.documentElement;
		
		SOPMasterXML = ds_FullApp.XMLDocument.documentElement;

		//set attributes: type description from the value of combo box
		oAsset.setAttribute('TypeDescription',getListText(document.all.cboAssetType));
		oAsset.setAttribute('AssetPropertyTypeDescription',getListText(document.all.cboAssetPropType));
		oAsset.setAttribute('AssetPropertyZoningDescription',getListText(document.all.cboAssetPropZoning));
		oAsset.setAttribute('AssetPropertyUseDescription',getListText(document.all.cboAssetPropUse));
		oAsset.setAttribute('AssetLinkedPropAddrDescription',getListText(document.all.cboAssetLinkedPropAddr));
		
		var sType = oAsset.selectSingleNode("AssetType").text;
		if(sType=='003')
		{
			oAsset.selectSingleNode("AssetDescription").text = getListText(document.all.cboAssetLinkedPropAddr);
		}
		
		// Card - 391 :-
		oAsset.setAttribute('AssetBankFinInstitutionDescription',getListText(document.all.cboBnkLenderName));
		//format the amount
		var sAmount = document.all.tblAssetDtls.all.inpAssetValue.value;
		oAsset.setAttribute('fmtAmount', VBFormatCurrency(sAmount,0));

		if(oAsset.getElementsByTagName("Addresses").length > 0){
			var oRemmovAddrs  = oAsset.selectSingleNode("//Addresses");
			if(oRemmovAddrs!= null){
				oAsset.removeChild(oRemmovAddrs);
			}
		}
        var oOwneshipNode = BuildSOPSplitupNode(ParentSOP_ID);

        var oExistingOwnerProp;
        oExistingOwnerProp = ds_spAsset.XMLDocument.documentElement.selectSingleNode("OwneshipProportion")

        if (oExistingOwnerProp == null) {
            ds_spAsset.XMLDocument.documentElement.appendChild(oOwneshipNode);
        }
        else {
            ds_spAsset.XMLDocument.documentElement.replaceChild(oOwneshipNode, oExistingOwnerProp);
        }
		
		//var bResult_Ast = EvaluateAppBRS(oAsset,true,false,true);
		
		var bResult_Ast = EvaluateAppBRS(oAsset,false);
		//alert("bResult_Ast===>  " + bResult_Ast + G_bSaveIsAllowed);
		
		//19.5.1 Defect Fixed Jira Card 513
		
		if(oAsset.selectSingleNode("AssetType").text == "003")
		{
			var valadrchk = AddressCheck(oAsset);
			if(!valadrchk)
			{
				bResult_Ast = EvaluateAppBRS(oAsset,false);
				return;
			}
		}
		
		//19.5.1 Defect Fixed Jira Card 513
		
		//alert("bResult_Ast===>  " + AddressCheck() + bResult_Ast + G_bSaveIsAllowed);
		if (G_bSaveIsAllowed) 
		{
			if (bResult_Ast)	
			{
			    var OutputXML = new ActiveXObject('Microsoft.XMLDOM');
			    OutputXML.loadXML("<Output/>");

			    //Add new/edited asset record
			    OutputXML.documentElement.appendChild(ds_spAsset.XMLDocument.documentElement.cloneNode(true));

			    //Add new/edited address record
			    OutputXML.documentElement.appendChild(ds_PopupAddresses.XMLDocument.documentElement.cloneNode(true));
			    window.returnValue = OutputXML;
			    window.close();
			}
			else
				VBMsgBox('Please enter valid asset details.',G_iVB_WARNING,G_sAPPLICATION_TITLE);
		}
		else
		{
			promptSaveProhibited('Asset');
			window.close();
		}
		
	}
	catch (e)
	{
		displayError(e,'saveAssetDtls');	
	}
}


//==============================================================================
//	Function Name:	check_AssetType
//	Parameters:		bInit - whether used in initAssetDtlsDlg or other functions
//	Return:			nil 
//	Description:	Get Asset Description depending on Asset Type
//==============================================================================
function check_AssetType(bInit)
{
	try
	{	
		var sType = (bInit)? ds_spAsset.recordset.fields('AssetType').value:document.all.tblAssetDtls.all('cboAssetType').value;
		xml_spDescLabels.src=xml_spDescLabels.src;
		var oLabels = xml_spDescLabels.XMLDocument.documentElement.selectNodes('//SPLabel');
		var oAsset = ds_spAsset.XMLDocument.documentElement;
		for (var i=oLabels.length-1; i>=0 ;i--)
		{
			if ( (oLabels(i).getAttribute('TYPE_CODE')!=sType) ||
				 (oLabels(i).getAttribute('Item')!='Asset') )
				oLabels(i).parentNode.removeChild(oLabels(i));
		}
		
		//disable NumberOfVehicles
		DisableElement(document.all.tblAssetDtls.all('inpNumberOfVehicles'), sType=='004');
		document.all.tblAssetDtls.all.tdNumberOfVehicles.style.color = (sType=='004')? '':'#FFFFFF';
		if (sType=='004')
		{
			if (isNaN(ds_spAsset.recordset.fields('NumberOfVehicles').value) || ds_spAsset.recordset.fields('NumberOfVehicles').value <= 0)
				ds_spAsset.recordset.fields('NumberOfVehicles').value = 1;
		}
		else
		{
			ds_spAsset.recordset.fields('NumberOfVehicles').value = 0;
		}
		
		//Start : Card 395
		//disable AssetMonthlyIncome
		var bEnableMonthlyIncome = ((sType=='001') || (sType=='002') || (sType=='003') || (sType=='007') || (sType=='009'))
		DisableElement(document.all.tblAssetDtls.all('inpAssetMonthlyIncome'), bEnableMonthlyIncome );
		if (bEnableMonthlyIncome)
		{
			if (isNaN(ds_spAsset.recordset.fields('AssetMonthlyIncome').value) || ds_spAsset.recordset.fields('AssetMonthlyIncome').value <= 0)
				ds_spAsset.recordset.fields('AssetMonthlyIncome').value = 0;
		}
		else
		{
			ds_spAsset.recordset.fields('AssetMonthlyIncome').value = 0;
		}
		//End : Card 395
		
		//Card 784 LIXIV2 Changes
			var sType = (bInit)? ds_spAsset.recordset.fields('AssetType').value:document.all.tblAssetDtls.all('cboAssetType').value;
			var sZone = (bInit)? ds_spAsset.recordset.fields('AssetPropertyZoning').value:document.all.tblAssetDtls.all('cboAssetPropZoning').value;
			var sUse = (bInit)? ds_spAsset.recordset.fields('AssetPropertyUse').value:document.all.tblAssetDtls.all('cboAssetPropUse').value;
			if(sZone=='R' || sZone=='F')
			{
				sZone='R';
			}
			var bEnableMonthlyInvest = ((sType=='003') && (sZone=='R') && (sUse=='I'))
			DisableElement(document.all.tblAssetDtls.all('inpAssetMonthlyInvestment'), bEnableMonthlyInvest );
			DisableElement(document.all.tblAssetDtls.all('chkShtStyRentInm'), bEnableMonthlyInvest );
			if (bEnableMonthlyInvest)
			{
				if (isNaN(ds_spAsset.recordset.fields('AssetMonthlyInvestment').value) || ds_spAsset.recordset.fields('AssetMonthlyInvestment').value < 0)
				{
					ds_spAsset.recordset.fields('AssetMonthlyInvestment').value = "0.00";
					ds_spAsset.recordset.fields('AssetShortStay').value = 0;
					document.getElementById("sDesAssetMonthlyInvestment").innerHTML="Includes body corporate fees, strata fees, land tax, property management fees, rates, utilities, repairs and maintenance, electricity, furniture and homewares, home and contents insurance, landlords insurance.";
					
				}
			}
			else
			{
				ds_spAsset.recordset.fields('AssetMonthlyInvestment').value = "0.00";
				ds_spAsset.recordset.fields('AssetShortStay').value = 0;
				document.getElementById("sDesAssetMonthlyInvestment").innerHTML="Includes body corporate fees, strata fees, land tax, property management fees, rates, utilities, repairs and maintenance, electricity, furniture and homewares, home and contents insurance, landlords insurance.";
			}
		//End 784
		var nSplit = ds_spAsset.XMLDocument.documentElement.selectSingleNode('JointOwner').text;
		//Start : Card - 391
		if ((sType=='009') || (sType=='002'))
		{
			document.all.trBankFinInstution.style.display = "block";
			populateList("A_TS_BANK_FIN_INSTITUTION_LENDERNAME", document.all.cboBnkLenderName, null, 'TYPE_CODE', 'CODE_DESC', false);
			if(nSplit == "-1")
				window.dialogHeight = 26.5;
			else
				window.dialogHeight = 21.5;
		}
		else
		{
			document.all.trBankFinInstution.style.display = "none";
			ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetBankFinInstitution").text="";
			if(nSplit == "-1")
				window.dialogHeight = 26.5;
			else
				window.dialogHeight = 19.5;
		}
		
		//Start : Card 365
		DisableElement(document.all.tblAssetDtls.all('inpAssetDescription'), (sType!='003') );
		if(sType=='003')
		{
			document.all.trAssetPropZoning.style.display = "block";
			populateList("A_TS_ASSET_PROP_ZONING_CODES", document.all.cboAssetPropZoning, null , 'ZONING_CODE', 'CODE_DESC', false); 
			if(ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetPropertyZoning").text=="")
				ds_spAsset.recordset.fields("AssetPropertyZoning").value="R";
			document.all.trAssetPropType.style.display = "block";
			RefreshPropZoneList(-1);
			document.all.trAssetPropUse.style.display = "block";			
			populateList("A_TS_ASSET_PROP_USE_CODES", document.all.cboAssetPropUse, null , 'USE_CODE', 'CODE_DESC', false);
			AssetPropUseChange(-1);
			document.all.trAssetPropAddress.style.display = "block";
			
			if(nSplit == "-1")
			{
				window.dialogHeight = 33.0;
			}
			else
			{
				window.dialogHeight = 26.0;
			}
		}
		else
		{
			//Clear the fields
			ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetPropertyType").text="";
			ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetPropertyZoning").text="";
			ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetPropertyUse").text="";
			ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetLinkedPropAddr").text="";
			document.all.trAssetPropType.style.display = "none";
			document.all.trAssetPropZoning.style.display = "none";
			document.all.trAssetPropUse.style.display = "none";
			document.all.trAssetPropAddress.style.display = "none";
			//window.dialogHeight = 15.0;
		}
		//End : Card 365
	}
	catch (e)
	{
		displayError(e,'check_AssetType');
	}
}

//Start : Card 365

//==============================================================
//	Function Name:	RefreshPropZoneList
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security		
//	Return:			Nil	
//	Description:	Handle Property Zone change
//==============================================================
function RefreshPropZoneList(bFromFile)
{
	try 
	{	
		var sAssetPropZone = (bFromFile)? ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetPropertyZoning").text:document.all("cboAssetPropZoning").value;
		
		// reload property type Codes list
		if (sAssetPropZone) {
			populateList("A_TS_ASSET_PROP_TYPE_STATUS", document.all.cboAssetPropType, "@STATUS_CODE='" + sAssetPropZone +"'" , 'TYPE_CODE', 'CODE_DESC', false);
			if(bFromFile == 0)
				ds_spAsset.recordset.fields("AssetPropertyType").value="";
			}
		//ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetPropertyType").text="";
		
		//Card 784 LIXIV2 Changes
			var sType = (bFromFile)? ds_spAsset.recordset.fields('AssetType').value:document.all.tblAssetDtls.all('cboAssetType').value;
			var sZone = (bFromFile)? ds_spAsset.recordset.fields('AssetPropertyZoning').value:document.all.tblAssetDtls.all('cboAssetPropZoning').value;
			var sUse = (bFromFile)? ds_spAsset.recordset.fields('AssetPropertyUse').value:document.all.tblAssetDtls.all('cboAssetPropUse').value;
			if(sZone=='R' || sZone=='F')
			{
				sZone='R';
			}
			var bEnableMonthlyInvest = ((sType=='003') && (sZone=='R') && (sUse=='I'))
			
			DisableElement(document.all.tblAssetDtls.all('inpAssetMonthlyInvestment'), bEnableMonthlyInvest );
			DisableElement(document.all.tblAssetDtls.all('chkShtStyRentInm'), bEnableMonthlyInvest );
			
			if (bEnableMonthlyInvest)
			{
				if (isNaN(ds_spAsset.recordset.fields('AssetMonthlyInvestment').value) || ds_spAsset.recordset.fields('AssetMonthlyInvestment').value < 0)
				{
					ds_spAsset.recordset.fields('AssetMonthlyInvestment').value = "0.00";
					ds_spAsset.recordset.fields('AssetShortStay').value = 0;
					document.getElementById("sDesAssetMonthlyInvestment").innerHTML="Includes body corporate fees, strata fees, land tax, property management fees, rates, utilities, repairs and maintenance, electricity, furniture and homewares, home and contents insurance, landlords insurance.";
				}
			}
			else
			{
				
				ds_spAsset.recordset.fields('AssetMonthlyInvestment').value = '0.00';
				ds_spAsset.recordset.fields('AssetShortStay').value = 0;
				document.getElementById("sDesAssetMonthlyInvestment").innerHTML="Includes body corporate fees, strata fees, land tax, property management fees, rates, utilities, repairs and maintenance, electricity, furniture and homewares, home and contents insurance, landlords insurance.";
			}
		//End 784
	}
	catch (e)
	{
		displayError(e,"RefreshPropZoneList");
	}
}

//==============================================================
//	Function Name:	AssetPropUseChange
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security		
//	Return:			Nil	
//	Description:	Handle Purchase Status change
//==============================================================
function AssetPropUseChange(bFromFile)
{
	try 
	{	
		var sAsstPropUse = (bFromFile)? ds_spAsset.XMLDocument.documentElement.selectSingleNode("AssetPropertyUse").text:document.all("cboAssetPropUse").value;
		
		if (!(sAsstPropUse=="I")) ds_spAsset.recordset.fields("AssetMonthlyIncome").value="0.00";
		DisableElement(document.all.inpAssetMonthlyIncome,(sAsstPropUse=="I"));
		
		    var sType = (bFromFile)? ds_spAsset.recordset.fields('AssetType').value:document.all.tblAssetDtls.all('cboAssetType').value;
			var sZone = (bFromFile)? ds_spAsset.recordset.fields('AssetPropertyZoning').value:document.all.tblAssetDtls.all('cboAssetPropZoning').value;
			var sUse = (bFromFile)? ds_spAsset.recordset.fields('AssetPropertyUse').value:document.all.tblAssetDtls.all('cboAssetPropUse').value;
			if(sZone=='R' || sZone=='F')
			{
				sZone='R';
			}
			var bEnableMonthlyInvest = ((sType=='003') && (sZone=='R') && (sUse=='I'))
			DisableElement(document.all.tblAssetDtls.all('inpAssetMonthlyInvestment'), bEnableMonthlyInvest );
			DisableElement(document.all.chkShtStyRentInm,bEnableMonthlyInvest);
			if (bEnableMonthlyInvest)
			{
				if (isNaN(ds_spAsset.recordset.fields('AssetMonthlyInvestment').value) || ds_spAsset.recordset.fields('AssetMonthlyInvestment').value < 0)
				{
					ds_spAsset.recordset.fields('AssetMonthlyInvestment').value = "0.00";
					ds_spAsset.recordset.fields('AssetShortStay').value = 0;
					document.getElementById("sDesAssetMonthlyInvestment").innerHTML="Includes body corporate fees, strata fees, land tax, property management fees, rates, utilities, repairs and maintenance, electricity, furniture and homewares, home and contents insurance, landlords insurance.";
				}
			}
			else
			{
				ds_spAsset.recordset.fields('AssetMonthlyInvestment').value = "0.00";
				ds_spAsset.recordset.fields('AssetShortStay').value = 0;
				document.getElementById("sDesAssetMonthlyInvestment").innerHTML="Includes body corporate fees, strata fees, land tax, property management fees, rates, utilities, repairs and maintenance, electricity, furniture and homewares, home and contents insurance, landlords insurance.";
			}
	}
	catch (e)
	{
		displayError(e,"AssetPropUseChange");
	}
}

function ValSwitchIntegerDecimal() {
    try 
	{
		var sPropTypeCode = document.all("AssetType").value;
		if(sPropTypeCode != "003") 
		{
			ValidateInteger(0);
		}
		else
		{
			ValidateIntegerDecimal();
		}
    }
    catch (e) 
    {
        displayError(e, 'ValSwitchIntegerDecimal');
    }
}

// Check for Populating Values in DropDown

//Populate the list of addresses in the cboAssetLinkedPropAddr

//==============================================================
//	Name:		PopulateCustSpouseNameCombo
//	Purpose:	Populates the list of addresses cboAssetLinkedPropAddr 
//	Parameters:	Addresses Node in master XML
//==============================================================
function PopulateLinkedPropertyAsset(oAddressesNode)
{
	try
	{
	    var oDOMEl = oAddressesNode.XMLDocument.documentElement;
	    if (oAddressesNode != null) {
	        var oAddrList = oDOMEl.selectNodes('Address');
	        if (oAddrList.length > 0) {

	            document.getElementById("cboAssetLinkedPropAddr").innerHTML = "";
				document.getElementById("inpAssetDescription").value = "";

	            var sAddrIDBlank = 0;
	            var sAddDetBlank = "";
	            var addroptBlank = document.createElement("OPTION");
	            document.getElementById("cboAssetLinkedPropAddr").options.add(addroptBlank);
	            addroptBlank.value = sAddrIDBlank;
	            addroptBlank.innerText = sAddDetBlank;

	            for (var i = 0; i < oAddrList.length; i++) {
	                var sAddrID = oAddrList(i).selectSingleNode('AddressID').text;
	                var sAddDet = oAddrList(i).getAttribute('AddressDetails');
	                var addropt = document.createElement("OPTION");
	                document.getElementById("cboAssetLinkedPropAddr").options.add(addropt);
	                addropt.value = sAddrID;
	                addropt.innerText = sAddDet;
	                if (ds_spAsset.XMLDocument.documentElement.selectSingleNode('AssetLinkedPropAddr').text == sAddrID) {
	                    addropt.selected = true;
	                }
	                else {
	                    document.getElementById("cboAssetLinkedPropAddr").options[0].selected = true;
	                }
	            }
	        }
	    }  
	}
	catch (e)
	{
		displayError(e,'PopulateLinkedPropertyAsset');
	}
}

//==============================================================
//	Name:		GetLinkedPropertyAsset
//	Purpose:	Gets AssetLinkedPropAddrDescription description from the Drop-Down box.
//	Parameters:	Drop-Down Value - related to AssetLinkedPropAddrDescription
//==============================================================
function GetLinkedPropertyAsset()
{
	try
	{
		var oLnkPropAddr = ds_spAsset.XMLDocument.documentElement;
		oLnkPropAddr.setAttribute("AssetLinkedPropAddrDescription",getListText(window.event.srcElement));
		oLnkPropAddr.selectSingleNode("AssetDescription").text=getListText(window.event.srcElement);
	}
	catch(e)
	{
		displayError(e,"GetLinkedPropertyAsset");
	}	
}

function removeOptions(selectbox)
{
    var i;
    for(i = selectbox.options.length - 1 ; i >= 0 ; i--)
    {
        selectbox.remove(i);
    }
}
//Ends : Card 365


//==============================================================
//	Function Name:	PopulateLinkedPropertyAsset
//	Parameters:		oAddressesNode - Node containing all the addresses.
//					
//	Return:			Nil
//	Description:	Populate the combo box "cboAssetLinkedPropAddr" with addresses.
//==============================================================
function PopulateLinkedPropertyAddress(oAddressesNode) 
{
    try 
	{
		var oDOMEl = oAddressesNode.XMLDocument.documentElement;
        if (oAddressesNode != null) {
            var oAddrList = oDOMEl.selectNodes('Address');
            if (oAddrList.length > 0) {

                document.getElementById("cboAssetLinkedPropAddr").innerHTML = "";

                var sAddrIDBlank = 0;
                var sAddDetBlank = "";
                var addroptBlank = document.createElement("OPTION");
                document.getElementById("cboAssetLinkedPropAddr").options.add(addroptBlank);
                addroptBlank.value = sAddrIDBlank;
                addroptBlank.innerText = sAddDetBlank;

                for (var i = 0; i < oAddrList.length; i++) {
                    var sAddrID = oAddrList(i).selectSingleNode('AddressID').text;
                    var sAddDet = oAddrList(i).getAttribute('AddressDetails');
                    var addropt = document.createElement("OPTION");
                    document.getElementById("cboAssetLinkedPropAddr").options.add(addropt);
                    addropt.value = sAddrID;
                    addropt.innerText = sAddDet;
                }
            }
        }
		
    }
    catch (e) 
    {
        displayError(e, 'PopulateLinkedPropertyAddress');
    }
}



//==============================================================
//	Function Name:	AddNewAddress
//	Parameters:		
//					
//	Return:			Nil
//	Description:	Adds a new address to the master XML.
//==============================================================
function AddNewAddress() 
{
    try 
	{
		var oEdtAdr;
		oEdtAdr = window.showModalDialog("PopupAddressDtls.htm", oEdtAdr, "dialogHeight:320px;dialogWidth:650px;help:No;resizable:No;status:No;scroll:No;");
        if (oEdtAdr == null) return null;

        //WR1970 - New Fuction call added.
        var NewAddressID = ds_FullApp.XMLDocument.documentElement.getAttribute("maxAddressID");
        var oAdd_Stub = ds_PopupAddresses.XMLDocument.documentElement;
		var objAdrId = oAdd_Stub.getElementsByTagName("AddressID");
		
		// For Incrementing the Address Id in Addresses Node XML - Starts
		var Ref_AdrId = parseInt(NewAddressID) + 1;
		if(objAdrId != null) 
		{
			if(objAdrId.length > 0)
			{
				for(var iAd=0;iAd<objAdrId.length;iAd++)
				{
					if(objAdrId(iAd).text == Ref_AdrId)
					{
						Ref_AdrId = Ref_AdrId + 1;
					}
				}
			}
		}
		oEdtAdr.firstChild.text = Ref_AdrId;
		// For Incrementing the Address Id in Addresses Node XML - Ends
		
		ds_PopupAddresses.XMLDocument.documentElement.appendChild(oEdtAdr);
        PopulateLinkedPropertyAsset(ds_PopupAddresses);

    }
    catch (e) 
    {
        displayError(e, "AddNewAddress");
    }

}


//==============================================================
//	Function Name:	BuildSOPCustomerSection
//	Parameters:		
//					
//	Return:			Nil
//	Description:	Builds the screen section to capture ownership Splitup.
//==============================================================
function BuildSOPCustomerSection(nSPID) 
{
    try 
	{
		var sHTML;
        var sCustID;
        var nCustName;

        sHTML="<table class='tabDataTable' id='tblSPCustomer' border='0' cellpadding='3' cellspacing='1' width='100%' style='border:2px solid white'>";
		sHTML= sHTML+ "	<thead align='center' class='tblHilite1'>";
		sHTML= sHTML+ "		<th width='50%'>Customer Name</th>";
		sHTML= sHTML+ "		<th width='50%'>Ownership Percentage</th>";
		sHTML = sHTML + "	</thead>";

		var SPCusts = ds_FullApp.XMLDocument.documentElement.selectNodes("//StatementOfPosition[StatementOfPositionID=" + nSPID + "]/SPCustomers/SPCustomer");
		for (var i = 0; i < SPCusts.length; i++) {

		    sCustID=SPCusts[i].selectSingleNode("CustomerID").text;
		    nCustName=SPCusts[i].getAttribute("CustomerName");

		    sHTML = sHTML + "	<tr align='center' class='tblHilite3'>";
		    sHTML = sHTML + "	<td align='Right'><span>" + nCustName + "</span></td>";
		    sHTML = sHTML + "	    <td align='Left'>";
		    sHTML = sHTML + "	    <input maxlength='3' id='PercentageForCust_" + sCustID + "' class='inputMini' onkeypress='VE_IntegerOnly();' onbeforeupdate='ValidateInteger(0);' onblur='ValidateInteger(0);' tabindex='4' type='text' name='PercentageForCust_" + sCustID + "'/>%";
		    sHTML = sHTML + "	    </td>";
		    sHTML = sHTML + "	</tr>";
		}

		sHTML = sHTML + "	</table>";

		document.getElementById("divCustomerList").innerHTML = sHTML;

    }
    catch (e) 
	{
        displayError(e, "BuildSOPCustomerSection");
    }

}


//==============================================================
//	Function Name:	PopulateSOPCustomerSection
//	Parameters:		
//					
//	Return:			Nil
//	Description:	populates the values to the dynamically created ownership split text boxes.
//==============================================================
function PopulateSOPCustomerSection() 
{
    try 
	{
		var oExistingOwnerProp;
        oExistingOwnerProp = ds_spAsset.XMLDocument.documentElement.selectSingleNode("OwneshipProportion");

       

        if (oExistingOwnerProp == null) {
            //Do nothing
        }
        else {
            //Fill text boxes
            var oCusts = ds_spAsset.XMLDocument.documentElement.selectNodes('//OwneshipProportion/Customer');
            for (var i = 0; i < oCusts.length; i++) {
                sElementName = "PercentageForCust_" + oCusts[i].getAttribute("ID");
                oTextBox = document.getElementById(sElementName);
                if (oTextBox != null)
                   oTextBox.value = oCusts[i].text;
                }
            }
    }
    catch (e) 
	{
        displayError(e, "PopulateSOPCustomerSection");
    }
}


//==============================================================
//	Function Name:	BuildSOPSplitupNode
//	Parameters:		
//					
//	Return:			Nil
//	Description:	Builds the node with ownership Splitup values on screen.
//                  This node will be appended to the asset record
//==============================================================
function BuildSOPSplitupNode(nSPID) 
{
    try 
	{
		var oCusts = ds_FullApp.XMLDocument.documentElement.selectNodes("//StatementOfPosition[StatementOfPositionID=" + nSPID + "]/SPCustomers/SPCustomer"); //ds_SOP.XMLDocument.documentElement.selectNodes('Customer');
        var oTextBox;
        var sElementName;
        var nPercentage;
        var nCustID;

        var sXML="<OwneshipProportion>"

        for (var i = 0; i < oCusts.length; i++) {

            nCustID = oCusts[i].selectSingleNode("CustomerID").text;

            sElementName = "PercentageForCust_" + nCustID;
            oTextBox = document.getElementById(sElementName);
            if (oTextBox != null)
                nPercentage = Number(oTextBox.value);
            else
                nPercentage = 0;

            if (nPercentage > 0) {

                sXML = sXML + "<Customer ID='" + nCustID + "'>" + nPercentage + "</Customer>";
                sXML = sXML 
            }
            
        }
        sXML = sXML + "</OwneshipProportion>";


        var OutputXML = new ActiveXObject('Microsoft.XMLDOM');
        OutputXML.loadXML(sXML);
        return OutputXML.selectSingleNode("OwneshipProportion");

    }
    catch (e) 
	{
        displayError(e, "BuildSOPSplitupNode");
    }
}

//==============================================================
//	Function Name:	SplitOwnership
//	Parameters:		
//					
//	Return:			Nil
//	Description:	Show/hide ownership split capture section.
//==============================================================
function SplitOwnership() 
{
    try 
	{
		var nSplit = ds_spAsset.XMLDocument.documentElement.selectSingleNode('JointOwner').text;
        var nBaseWinH;
        var nNewWinH;


        var sType = (ds_spAsset.recordset.fields('AssetType').value!="") ? ds_spAsset.recordset.fields('AssetType').value : document.all.tblAssetDtls.all('cboAssetType').value;


        switch (sType) {
            case '009':
                nBaseWinH = 24.5
                break;
            case '002':
                nBaseWinH = 24.5
                break;
            case '003':
                nBaseWinH = 29.0
                break;
            default:
                nBaseWinH = 22.5
        }

        var bSplitOwnership=false;


        if (nSplit == -1) 
            bSplitOwnership = true;
        else
            bSplitOwnership = document.getElementById("chkEqualOwn").checked;


        if (bSplitOwnership == true) {
            document.getElementById("divCustomerList").style.display = "block";
            window.dialogHeight = nBaseWinH + 7;
        }
        else {
            document.getElementById("divCustomerList").style.display = "none";
            window.dialogHeight = nBaseWinH;

            ClearSplitupFields();
        }
    }
    catch (e) 
	{
        displayError(e, "SplitOwnership");
    }
}



//==============================================================
//	Function Name:	ClearSplitupFields
//	Parameters:		
//					
//	Return:			Nil
//	Description:	Clears the values in the dynamically created ownership split text boxes.
//==============================================================
function ClearSplitupFields() 
{
    try 
	{
        var oExistingOwnerProp;
        oExistingOwnerProp = ds_spAsset.XMLDocument.documentElement.selectSingleNode("OwneshipProportion");

        if (oExistingOwnerProp == null) {
            //Do nothing
        }
        else {
            //Fill text boxes
            var oCusts = ds_spAsset.XMLDocument.documentElement.selectNodes('//OwneshipProportion/Customer');
            for (var i = 0; i < oCusts.length; i++) {
                sElementName = "PercentageForCust_" + oCusts[i].getAttribute("ID");
                oTextBox = document.getElementById(sElementName);
                if (oTextBox != null)
                    oTextBox.value = 0;
            }
        }
    }
    catch (e) 
	{
        displayError(e, "ClearSplitupFields");
    }
}

//==========================================================================
//  Function Name : AddressCheck
//  Paramerter : oAsset
//  Return : boolean
//  Description : Check the Property Asset address and not allow to add same address to multipe properties
// 19.7 Defect Fixed Jira Card 513
//==========================================================================
function AddressCheck(oAsset)
{
	try
	{
		var val_adrchk = true;
		
		// Current Asset XML
		var oAsset = ds_spAsset.XMLDocument.documentElement;
		var jCurAdrsID = oAsset.selectSingleNode("AssetLinkedPropAddr").text;
		
		val_adrchk = ChkSOPIDRecNo(jCurAdrsID);
		if((!val_adrchk))
		{
			var oSPs = ds_FullApp.XMLDocument.documentElement.selectSingleNode('StatementsOfPosition');
			var noMasterAsset = oSPs.getElementsByTagName("Asset");
			val_adrchk = ValEditAstAdrIdMaster(noMasterAsset,jCurAdrsID);
			if(!val_adrchk)
			{
				var e = document.getElementById("cboAssetLinkedPropAddr");
				e.selectedIndex = 0;
				document.getElementById("inpAssetDescription").value="";
				alert("Address already assigned to another asset, please select another address or Add New");
				val_adrchk = false;
			}
		} 
		return val_adrchk;
	}
	catch(e)
	{
		displayError(e, "AddressCheck");
	}
		
}

//==========================================================================
//  Function Name : ChkSOPIDRecNo
//  Paramerter : jCurAdrsID
//  Return : boolean
//  Description : Check the Property Asset address is matched or not with Current Sop Assets
// 19.7 Defect Fixed Jira Card 513
//==========================================================================

function ChkSOPIDRecNo(jCurAdrsID)
{
	try
	{
		var val_adrchk_test = true;
		var oSPsCnt = ds_FullApp.XMLDocument.documentElement.selectNodes('StatementsOfPosition/StatementOfPosition');
		if((ParentSOP_ID > 0)) 
		{
			var oSPs = ds_FullApp.XMLDocument.documentElement.selectSingleNode('StatementsOfPosition');
			var noMasterAsset = oSPs.getElementsByTagName("Asset");
			if(O_AstRecNo > 0)
			{
				for(var iTotSop = 0; iTotSop < oSPsCnt.length; iTotSop++) 
				{
					var LoopSOPID = oSPsCnt(iTotSop).selectSingleNode("StatementOfPositionID").text;
					var noMasterAsset = oSPs.getElementsByTagName("Asset");
					if((LoopSOPID) == (ParentSOP_ID))
					{
						var chk_astcnt = O_AstRecNo - 1;
						var noMasterAsset = oSPsCnt(iTotSop).getElementsByTagName("Asset");
						var I_nNodeSelectAsst = noMasterAsset((chk_astcnt));
						var I_EditAstAddrID = I_nNodeSelectAsst.selectSingleNode("AssetLinkedPropAddr").text;
						if((jCurAdrsID) != (I_EditAstAddrID)) {
							val_adrchk_test = false;
							break;
						}
					}
				}
			}
			else
			{
				val_adrchk_test = ValEditAstAdrIdMaster(noMasterAsset,jCurAdrsID);
			} 
		}
		return val_adrchk_test;
	}
	catch(e)
	{
		display(e,"ChkSOPIDRecNo");
	}
}

//==========================================================================
//  Function Name : ValEditAstAdrIdMaster
//  Paramerter : noMasterAsset, jCurAdrsID
//  Return : boolean
//  Description : Check the Property Asset address is matched or not with All SOP Assets
// 19.7 Defect Fixed Jira Card 513
//==========================================================================

function ValEditAstAdrIdMaster(noMasterAsset,jCurAdrsID)
{
	try
	{
		var val_chkMstrId = true;
		for(var iTotAstCnt = 0 ; iTotAstCnt < noMasterAsset.length; iTotAstCnt++)
		{
			nNodeSelect = noMasterAsset(iTotAstCnt);
			if(nNodeSelect.selectSingleNode("AssetType").text == "003")
			{
				var I_EditAstAddrID = nNodeSelect.selectSingleNode("AssetLinkedPropAddr").text;
				if ((jCurAdrsID) == (I_EditAstAddrID)) //&& (iAdrsID == oAsset.selectSingleNode("AssetLinkedPropAddr").text) 
				{ 
					//alert("ValEditAstAdrIdMaster == EQUAL in ELSE PART==> " + jCurAdrsID + " == " + I_EditAstAddrID);
					val_chkMstrId = false;
					break;
				}
			}
		}
		return val_chkMstrId;
	}
	catch(e)
	{
		displayError(e,"ValEditAstAdrIdMaster")
	}
}


//19.5.1 Defect Fixed Jira Card 513


//==============================================================
//	Function Name:	check_ANZCCNumber
//	Parameters:		-
//	Return:			-
//	Description:	Remove all none-number characters from the Liability Description (Account Number) field 
//==============================================================
function check_ANZCashNumber()
{
	try
	{
		if (document.all.tblAssetDtls.all("cboAssetType").value == "001")
			document.all.tblAssetDtls.all("inpAssetDescription").value = replaceAll(document.all.tblAssetDtls.all("inpAssetDescription").value,/\D/g,"");
	}
	catch (e)
	{
		displayError(e,"check_ANZCashNumber");
	}
}

//Prod Defet 
function AccountNumberMax()
{
		if (document.all.tblAssetDtls.all("cboAssetType").value == "001")
		{
			var input = document.getElementById ("inpAssetDescription");
            input.maxLength = 9;
		}
		else
		{
			document.getElementById("inpAssetDescription").maxLength = 50;
		}
	
}

