//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//**Start Encode**
//
//	$Revision:   1.22  $
//	$Author:   shanmub3  $
//	$Workfile:   prodpurp.js  $
//	$Modtime:   10 Sep 2015 16:35:00  $
//============================================================-->
//<SCRIPT>

//Global Variables
var G_bPurposeDirty = false;	//flag indicating that the purpose details have been changed
var G_bProductDirty = false;	//flag indicating that the product details have been changed

var G_selectedProdRecNo = 0;	//selected product record (row) number
var G_selectedProductId = 0;	//selected product ID
var G_selectedPurpRecNo = 0;	//selected purpose record (row) number
var G_selectedPurposeId = 0;	//selected purpose ID
var G_selectedPackTier1to5  = "005";
var G_selectedPackTier1to12  = "012";
//Tab Related
var G_iCurPrdDtlsTabIdx = 0;	//Current Product Details tab
//customer tab images
var aPrdDtlsTabImgs = Array ("product_details", "Linked_custs");


//==============================================================
//	Name:		PurpProductScreenShow
//	Purpose:	Shows Puspose & products screen.
//				Loads list boxes on the first show.
//==============================================================
function PurpProductScreenShow()
{
	try
	{

		G_pScreenSaveFunction = SavePurpProd;
		var oN = xml_master.XMLDocument.selectNodes("//Purpose");

		if (oN.length!=0)
		{
			G_selectedProdRecNo=0;
			G_selectedProductId=0;
			SelectPurp(1);
			document.all.aSavePurpProd.style.display = "";
		}
		else
		{
			G_selectedPurpRecNo = 0;
			ShowPurpProdSubScreens(false,false);
		}

	//	WR1970
	//	======================================================================
	//	Calling the function for populating the Nominee dropdown menu
		PopulateNominee();
	//	Calling the function for getting the DiscountPackage value of first product
		selectLoanPackValue();
	//	======================================================================

	//	setLoanPackageLtValue();
		ShowAddPurpProdButtons();

		HideshowPfSummary();
	//	EnableControl();
		//	Calling the function to populate the Reason for Interest only dropdown menu
		populateList("A_TS_REASONFORINTERESTONLY", document.all.cboReasonForIntOnly, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);

	}
	catch(e)
	{
		displayError(e,"PurpProductScreenShow");
	}
}

//==============================================================
//	Name:		AddPurpose
//	Purpose:	Adds new purpose record
//==============================================================
function AddPurpose()
{
	try
	{

       	if (G_selectedPurpRecNo>0) SavePurpose(true);
		var oPurposesNode = xml_master.XMLDocument.documentElement.selectSingleNode ('Purposes');

		ds_purp.src=ds_purp.src;
		var oNewPurpNode = ds_purp.XMLDocument.documentElement.cloneNode(true);
		InitilizeAppBRS(oNewPurpNode);

		oNewPurpNode.selectSingleNode("PurposeID").text = allocateNewID ('maxPurposeID');

		oPurposesNode.appendChild (oNewPurpNode);
		var recNo = oPurposesNode.childNodes.length;
		ShowAddPurpProdButtons();

		SelectPurp (recNo);
		G_bPurposeDirty = true;
		//EnableControl();

	}
	catch(e)
	{
		displayError(e,"AddPurpose");
	}
}

//==============================================================
//	Name:		SavePurpose
//	Purpose:	Saves selected purpose.
//	Parameters:	NoReselect - (boolean) should be set to true to
//								stop purpose re-selection.
//==============================================================
function SavePurpose(NoReselect)
{
	try
	{
		if (!G_bPurposeDirty) return;
		var oPurpsNode = xml_master.XMLDocument.selectSingleNode("//Purposes");
		if (oPurpsNode.childNodes.length == 0) return;	// no purposes to save - exit
		// current purpose
		var PurpID = ds_purp.recordset.fields("PurposeID").value;
		var oCurPurpNode = oPurpsNode.selectSingleNode("Purpose[PurposeID=" + PurpID + "]")

		var oUpdPurpRoot = ds_purp.XMLDocument.documentElement.cloneNode(true);
		//do not save products
		var oCurPurpProducts = oCurPurpNode.selectSingleNode("Products");
		oUpdPurpRoot.replaceChild(oCurPurpProducts.cloneNode(true),oUpdPurpRoot.selectSingleNode("Products"));

		var TempRow = getRDRowObject("A_TS_PURPOSE_CATEGORIES","@CATEGORY_CODE='"+oUpdPurpRoot.selectSingleNode("Category").text+"'")
		if (TempRow != null)
		{
		oUpdPurpRoot.setAttribute ("CategoryCodeDescription", TempRow.CODE_DESC);
		}
		TempRow = getRDRowObject("A_TS_PURP_CODE_DESC","@PURPOSE_CODE='"+oUpdPurpRoot.selectSingleNode("LendingPurpose").text+"'")
		if (TempRow != null)
		{
		oUpdPurpRoot.setAttribute ("PurposeCodeDescription", TempRow.CODE_DESC);
		}

		oUpdPurpRoot.setAttribute ("DisplayAmt", VBFormatCurrency(oUpdPurpRoot.getAttribute("TotalAmount"),0));
		// replace purpose node with the screen XDI's contents.
		oPurpsNode.replaceChild (oUpdPurpRoot, oCurPurpNode);
		G_bPurposeDirty = false;
		// re-select purpose
		EvaluateAppBRS(oUpdPurpRoot);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Purposes"));
		EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);
		FlushToDisk();
		
		if(!NoReselect)
		{
			// Added for Production Issue of TaxResident Details - Starts
			var producttype = document.getElementById("lbProductType").value;	
			var breakfree_type=G_breakfree_Type;
			if ((producttype == "RC") || (breakfree_type == "New Credit Card"))
			{
				loadApplicationXML(G_sApplicationFilePath);
			}
			else
			{
				loadApplicationXML(G_sApplicationFilePath);
			}
		// Added for Production Issue of TaxResident Details - Ends
		}
		
		addFileRefDetails();
		if (!NoReselect) SelectPurp(G_selectedPurpRecNo);
	}
	catch(e)
	{
		displayError(e,"SavePurpose");
	}
}

//==============================================================
//	Name:		DeletePurp
//	Purpose:	Deletes purpose.
//	Parameters:	recNo - (numeric) purpose record number
//==============================================================
function DeletePurp(recNo)
{
	try
	{
		if (!ConfirmDelete()) return;

		var oPurpsNode = xml_master.XMLDocument.selectSingleNode ("//Purposes");

		var iCurrentSelected = G_selectedPurpRecNo;
		//find which one to select after deleting
		var iReselect = G_selectedPurpRecNo
		if (iCurrentSelected >= recNo)	iReselect--;

		if (iCurrentSelected!=recNo)
			SavePurpose();
		else
		{
			G_bPurposeDirty=false;
			G_bProductDirty=false;
		}

		// delete rec-th purpose.
		oPurpsNode.removeChild(oPurpsNode.childNodes(recNo-1))

		if (oPurpsNode.childNodes.length>0)
		{
			G_selectedPurpRecNo=iReselect;
			SelectPurp(iReselect);
		}
		else
		{
			//hide purpose details tabs
			ShowPurpProdSubScreens(false,false);
			G_selectedProdRecNo=0;
			G_selectedPurpRecNo=0;
			G_bPurposeDirty = false;
			G_bProductDirty = false;
			/*G_sDiscPackValue = "";
			document.all.lbDiscountPack.value = "";
			EnableControl();*/
		}


		ShowAddPurpProdButtons();

		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Purposes"),true);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Customers"));
		addFileRefDetails();
		FlushToDisk();
		HideshowPfSummary();

	//	************************************************************************
	//	WR1970 - Hiding the visibility of Loan Package section and Loan Document
	//	Nomination section when Purpose is selected
	//	************************************************************************
		document.all.tblLoanDocNomination.style.display = 'none';
		G_Product_Type="";
	}
	catch(e)
	{
		displayError(e,"DeletePurp");
	}
}


//==============================================================
//	Name:		SelectPurp
//	Purpose:	Displays selected purpose details.
//	Parameters:	recNo 	- (numeric) selected purpose record number
//==============================================================
function SelectPurp(recNo)
{
	try
	{
	    document.getElementById("AddPortfolioCmd").style.display="none";
		/*if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
		{
    		document.all.lbDiscountPack.disabled=true;
    		document.all.lbDiscountPack.text=""
		document.all.cboBreakfreeCard.disabled = true;
    		document.all.cboBreakfreeCard.value = "";
    		document.all.BreakFreeCardLt.disabled = true;
    		document.all.BreakFreeCardLt.value = ""
		}
		else
		{
       	         document.all.lbDiscountPack.disabled=false;
  		}*/

  		if (!G_oScreens["ScrPurpProd"].ListsPopulated)
		{
			if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )

				{

				   	//populateList("A_TS_PURPOSE_CATEGORIES", document.all.lbPurpCat, null, 'CATEGORY_CODE', 'CODE_DESC', false, true);
					populateList("A_TS_PURPOSE_CATEGORIES", document.all.lbPurpCat,"@ALLOW_PF_PP='1'", 'CATEGORY_CODE', 'CODE_DESC', false, true);
					/*populateList("A_TS_PACKAGE_CODES", document.all.lbDiscountPack,
								"@PRODUCT_CODE='ILS'", 'PACKAGE_CODE', 'CODE_DESC',true);
					populateList("A_TS_BREAKFREECARD_CODES", document.all.cboBreakfreeCard, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);			*/
					G_oScreens["ScrPurpProd"].ListsPopulated= true;
				}

			else
				{
				   	populateList("A_TS_PURPOSE_CATEGORIES", document.all.lbPurpCat, null, 'CATEGORY_CODE', 'CODE_DESC', false, true);
					/*populateList("A_TS_PACKAGE_CODES", document.all.lbDiscountPack,
								"@PRODUCT_CODE='ILS'", 'PACKAGE_CODE', 'CODE_DESC',true);
					populateList("A_TS_BREAKFREECARD_CODES", document.all.cboBreakfreeCard, null, 'PREFERENCE_CODE', 'CODE_DESC', false, true);			*/
					G_oScreens["ScrPurpProd"].ListsPopulated= true;

				}

  		}


		if (G_selectedProdRecNo>0) SaveProduct(true);
		if (G_selectedPurpRecNo>0) SavePurpose(true);

		//clear product selectors
		SetRowSelectors(document.all.ProdRowSelector,-1);

		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		//if (recNo > oPurps.childNodes.length) recNo = oPurps.childNodes.length;
		if ((!recNo)&&(oPurps.childNodes.length)) recNo = 1;
		if (recNo > oPurps.childNodes.length) recNo = oPurps.childNodes.length;

		G_selectedPurpRecNo = recNo;
		G_selectedProdRecNo = 0;
		if (!recNo) return;

		var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);
		G_selectedPurposeId = GetIntVal(oPurpNode.selectSingleNode("PurposeID").text);
		RefreshPurpList(oPurpNode);

		ds_purp.XMLDocument.loadXML(oPurpNode.xml);
		ds_purp.src=ds_purp.src;
		ds_purp.XMLDocument.replaceChild(oPurpNode.cloneNode(true), ds_purp.XMLDocument.documentElement);

		CheckLendingPurposeCategory(true);

		var numProd = oPurpNode.selectNodes("Products/Product").length

		// prohibit selecting purpose type if purpose has products
		var oPurposeScreen = PurpSubScr.all;
		oPurposeScreen.lbPurpCat.disabled = (numProd > 0);
		oPurposeScreen.lbPurpCode.disabled = (numProd > 0);
		ShowPurpProdSubScreens(true,false);
		document.getElementById("AddPortfolioCmd").style.display="none";

		var sPurpCat=oPurpNode.selectSingleNode("Category").text;
		SetFocusOnElement((sPurpCat!="")? "inpPurpDesc":"lbPurpCat");

     	G_bPurposeDirty = false;

		//set purpose row selector
		SetRowSelectors(document.all.PurpRowSelector,recNo);

	//	************************************************************************
	//	WR1970 - Hiding the visibility of Loan Package section and Loan Document
	//	Nomination section when Purpose is selected
	//	************************************************************************
		document.all.tblLoanDocNomination.style.display = 'none';
		var oDocEl = xml_master.XMLDocument.documentElement;
		var oProdNode = oDocEl.selectNodes("Purposes/Purpose/Products/Product");
		/*var validimg;

		if (oProdNode.length > 0) {
		for (var i = 0; i < oProdNode.length; i++) {
		if (oProdNode.item(i).selectSingleNode("ProductID").text != "") {
		validimg = oProdNode.item(i).getAttribute("valid_BreakFreeCardLimit");
		break;
		}
		}

		}
		else {
		validimg = "../images/blue_asteric.gif";
		}

		document.getElementById("imgValidCL").src = validimg;*/

	}
	catch(e)
	{
		displayError(e,"SelectPurp");
	}
}

//==============================================================
//	Name:		AddProduct
//	Purpose:	Adds new product record
//==============================================================
function AddProduct()
{
	try
	{
		if (G_selectedProdRecNo>0) SaveProduct(true);
		if (G_selectedPurpRecNo>0) SavePurpose(true);

		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		if (oPurps.childNodes.length == 0)
		{
			VBMsgBox('Please add a purpose before you add a product.', G_iVB_WARNING, G_sAPPLICATION_TITLE);
			return;
		}

		var oCurPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);

		if (oCurPurpNode)
		{
			var iPurpCat  =  getXMLField(oCurPurpNode, "Category", null, true);
			var iPurpCode =  getXMLField(oCurPurpNode, "LendingPurpose", null, true);
		}

		if (!oCurPurpNode || !iPurpCat || !iPurpCode || iPurpCat == "" || iPurpCode == "")
		{
			SelectPurp(G_selectedPurpRecNo);
			VBMsgBox('Please select a Purpose Category and Purpose before adding a product.', G_iVB_WARNING, G_sAPPLICATION_TITLE);
			return;
		}

		var oProductsNode = oCurPurpNode.selectSingleNode("Products");
		ds_prod.src=ds_prod.src;

		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') != '1') {

		    //ds_prod.XMLDocument.documentElement.selectSingleNode("BreakFreeCardLimit").text = G_BrkFreeCardLt;
		    //ds_prod.XMLDocument.documentElement.selectSingleNode("BreakFreeCard").text = G_BrkFreeCardOpt;


		    var oDocEl = xml_master.XMLDocument.documentElement;
	        var oProdNode1 = oDocEl.selectNodes("Purposes/Purpose/Products/Product");

		    /*if (oProdNode1.length > 0) {
		        ds_prod.XMLDocument.documentElement.getAttribute("valid_BreakFreeCardLimit").text = oProdNode1.item(0).getAttribute("valid_BreakFreeCardLimit").text;
		    }*/

		    G_bPurposeDirty = true;

		    /*document.all("BreakFreeCardLt").value = G_BrkFreeCardLt;
		    document.all("cboBreakfreeCard").value = G_BrkFreeCardOpt;*/
		}
		//////////////////////////////////////////////////////////////////////////////



		var oNewProdNode = ds_prod.XMLDocument.documentElement.cloneNode(true);
	    InitilizeAppBRS(oNewProdNode);

	  //var oNewCustProdReln = ds_RelCusts.XMLDocument.documentElement.cloneNode(true);
      //oNewProdNode.appendChild (oNewCustProdReln);

        oNewProdNode.selectSingleNode("ProductID").text = allocateNewID ('maxProductID');
		oProductsNode.appendChild (oNewProdNode);

		RefreshProdList(oCurPurpNode);

		ShowAddPurpProdButtons();

		SelectProd (G_selectedPurpRecNo, oProductsNode.childNodes.length);

		G_bProductDirty = true;

		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);
		var oProdNode = oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']');

		LinkCutomerToProduct(oProdNode);
		
		hideDiv('tblReason');

	}
	catch(e)
	{
		displayError(e,"AddProduct");
	}
}


//==============================================================
//	Name:		RowSelectProd
//	Purpose:	Gets selected product and purpose record numbers
//				to perform product selection.
//	Parameters:	el - (HTML radio button element) selected radio button
//==============================================================
function RowSelectProd(el)
{
	try
	{
		// find parent dtblProducts table
		var parentTblEl = findParent (el, "dtblProducts", true);
		SelectProd (parentTblEl.recordNumber , el.recordNumber );

	}
	catch(e)
	{
		displayError(e,"RowSelectProd");
	}
}

//==============================================================
//	Name:		SelectProd
//	Purpose:	Displays selected product details.
//	Parameters:	purpIdx	- (numeric) record number of the parent
//							purpose of the selected product
//				prodIdx - (numeric) record number of the selected
//							product in the purpose
//==============================================================
function SelectProd(purpIdx, prodIdx)
{
	try
	{
		//if (G_bProductDirty)
		//	SaveProdPurp(true);


		if (G_selectedProdRecNo > 0) SaveProduct(true);
		if (G_selectedPurpRecNo > 0) SavePurpose(true);

		//clear product selectors
		SetRowSelectors(document.all.ProdRowSelector,-1);

		var bDifferentPurp = (G_selectedPurpRecNo !=  purpIdx);	// different purpose?

		G_selectedPurpRecNo =  purpIdx;
		G_selectedProdRecNo = prodIdx;

		// load product DS
		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		if (oPurps.childNodes.length == 0)	return;

		var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);

		G_selectedPurposeId = GetIntVal(oPurpNode.selectSingleNode("PurposeID").text);
		//ds_purp.recordset.AbsolutePosition = G_selectedPurpRecNo + 1;
		var oProdNode = oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']');
		G_selectedProductId = GetIntVal(oProdNode.selectSingleNode ("ProductID").text);

		//if (bDifferentPurp)		// if different purpose - reload product list

		RefreshProdList(oPurpNode);

		// re-load Product DS.
		ds_prod.src = ds_prod.src;
		ds_prod.XMLDocument.replaceChild(oProdNode.cloneNode(true),ds_prod.XMLDocument.documentElement);
		ds_prodLoan.src = ds_prodLoan.src;
		ds_prodDeposit.src = ds_prodDeposit.src;
		var oSelProd = ds_prod.XMLDocument.documentElement;
		var oLoanDtls = oSelProd.selectSingleNode("LoanDetails");
		var oDepDtls = oSelProd.selectSingleNode("DepositDetails");
		var sProd="";
		if (oLoanDtls && oLoanDtls.hasChildNodes)
		{
			ds_prodLoan.XMLDocument.replaceChild(oLoanDtls.cloneNode(true),ds_prodLoan.XMLDocument.documentElement);
			sProd="ILS";
		}

		if (oDepDtls && oDepDtls.hasChildNodes)
		{
			ds_prodDeposit.XMLDocument.replaceChild(oDepDtls.cloneNode(true),ds_prodDeposit.XMLDocument.documentElement);
			sProd="DDA";
			hideDiv('tblReason');	
		}


		CheckRegulatedValue(oProdNode);
		CheckProductCode(true);
		ShowPurpProdSubScreens(false,true);
		SwitchProdDetailsTab(0);

		//oProductNode.replaceChild(xml_temp.XMLDocument.documentElement.cloneNode(true),oProductNode.selectSingleNode("RelatedCustomers"));

		var bPortfolioApp=false;
		var bNoPFLimitEndDate = false;
		var PFprimaryAccount = false;
		//New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
		G_Product_Type=oProdNode.selectSingleNode ("SubProductCode").text;
		//New Code Ended
		if (sProd=="")
			SetFocusOnElement("lbProductType")
		else
			SetFocusOnElement((sProd=="ILS")? "inpAmtSought":"inpLimitAmt");


		//set product row selector
		try {
			if (G_selectedPurpRecNo > 0 && G_selectedProdRecNo > 0)
			{
				var oTblProd = dtblPurpose.all ("dtblProducts");
				oTblProd =  (oTblProd.length)? oTblProd(G_selectedPurpRecNo-1) : oTblProd;
				var oRowSel = oTblProd.all("ProdRowSelector");
				if (oRowSel.length>0)
					oRowSel(G_selectedProdRecNo-1).checked = true;
				else
					oRowSel.checked = true;
			}
		}
		catch (e)
		{
			//ignore error: assinchronous event
		}

		//setLoanPackageLtValue();
		selectLoanPackValue();

		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1')
		{
			bPortfolioApp=true;
            if (sProd=='DDA')
            {
				var bPrimAcc;
				bPrimAcc=false;
				bPrimAcc=(oDepDtls.selectSingleNode("PortfolioPrimaryAccount").text=="-1")? true:false;
				//(ds_prodDeposit.XMLDocument.documentElement.selectSingleNode("PortfolioPrimaryAccount").text=="-1")? true:false;
				RefreshPrimaryCusts(bPrimAcc);
			}
		}

		var nCustCount=xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer").length
		//Enable the related customers tab if the app is a portfolio app and customers are added.
		if (bPortfolioApp && nCustCount > 0)
		{
			EnableImg=".gif";
			if (G_iCurPrdDtlsTabIdx==1) EnableImg = "_dn.gif";
		}
		else
		{EnableImg="_faded.gif";}

		document.all.ProdSubScr.all.imgProdDetailsTab(1).src = "../images/tabs/" + aPrdDtlsTabImgs[1] + EnableImg;

		IntOnlyTermChange('OnLoad')
	}
	catch(e)
	{
		displayError(e,"SelectProd");
	}

}

//==============================================================
//	Name:		SetProductRowSelector
//	Purpose:	Selects product selector radio button
//	Parameters:	tblProd	- (HTML TABLE element) product summary
//							table
//==============================================================
function SetProductRowSelector(tblProd)
{
	try
	{
		if (tblProd.readyState!="complete"||G_selectedProdRecNo<=0 || G_selectedPurpRecNo<=0) return;

		if (document.all.dtblProducts.length > 1)
			var oRowSel = document.all.dtblProducts(G_selectedPurpRecNo-1).all.dtblProduct.all("ProdRowSelector");
		else
			var oRowSel = document.all.dtblProducts.all.dtblProduct.all("ProdRowSelector");

		if (oRowSel && oRowSel.length>0)
		{
			//clear selectors
			for (i=0; i<oRowSel.length; i++) oRowSel(i).checked = false;
			oRowSel(G_selectedProdRecNo-1).checked = true;
		}
		else
			if (oRowSel && G_selectedProdRecNo-1==0) oRowSel.checked = true;

	}
	catch(e)
	{
		displayError(e,"SetProductRowSelector");
	}
}

//==============================================================
//	Name:		SaveProduct
//	Purpose:	Saves selected product.
//	Parameters:	NoReselect - (boolean) should be set to true to
//								stop purpose re-selection.
//==============================================================
function SaveProduct(NoReselect)
{
	try
	{
	 	if (!G_bProductDirty) return;

		var sNodeToRemove = null;
		var oNodeToRemove = null;
		var oNodeToReplace = null;
		var oNewDetails = null;

		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		if (oPurps.childNodes.length == 0) return;
		var oCurPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);

		var oCurProductsNode = oCurPurpNode.selectSingleNode("Products");
		if (oCurProductsNode.childNodes.length == 0) return;
		// new node
		var oUpdProdRoot = ds_prod.XMLDocument.documentElement;

		// set code descriptions
		var oPrdTbl= document.all.ScrPurpProd.all.ProdSubScr
		oUpdProdRoot.setAttribute ("ProductCodeDescription", getListText(oPrdTbl.all.lbProductType));
		var sProdType = oUpdProdRoot.selectSingleNode("ProductCode").text;

		switch (sProdType)
		{
			case "ILS":
				oNewDetails = ds_prodLoan.XMLDocument.documentElement
				//calculate terms
				CalculateTerm("LoanTerm", oNewDetails)
				CalculateTerm("FixedRateTerm", oNewDetails)
				CalculateTerm("InterestOnlyTerm", oNewDetails)
				//set product amount attribute
				oUpdProdRoot.setAttribute("ProductAmount", VBFormatCurrency(oNewDetails.selectSingleNode("AmountSought").text,0));
				//set code descriptions
				oNewDetails.setAttribute ("PaymentFrequencyDescription", getListText(oPrdTbl.all.cboPmtFreq));
				oNewDetails.setAttribute ("PaymentMethodDescription", getListText(oPrdTbl.all.cboPmtMethod));

				//set nodes to update
				oNodeToReplace = oUpdProdRoot.selectSingleNode("LoanDetails");
				if (!oNodeToReplace) oNodeToReplace = oUpdProdRoot.selectSingleNode("DepositDetails");
				sNodeToRemove="DepositDetails";
				break;
			case "DDA":
				oNewDetails = ds_prodDeposit.XMLDocument.documentElement
				//set product amount attribute
				oUpdProdRoot.setAttribute("ProductAmount", VBFormatCurrency(oNewDetails.selectSingleNode("LimitAmount").text,0));
				//set code descriptions
				oNewDetails.setAttribute ("NumberOfSignaturesDescription", getListText(oPrdTbl.all.cboNumOfSign));
				oNewDetails.setAttribute ("ATOTypeDescription", getListText(oPrdTbl.all.cboATOType));
				//set nodes to update
				oNodeToReplace = oUpdProdRoot.selectSingleNode("DepositDetails");
				if (!oNodeToReplace) oNodeToReplace = oUpdProdRoot.selectSingleNode("LoanDetails");
				sNodeToRemove = "LoanDetails";
				break;
			default :
		}

		//////////////////////////////////////////////////////////////////////////////
		/*if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') != '1')
		 {
		    ds_prod.XMLDocument.documentElement.selectSingleNode("BreakFreeCardLimit").text = G_BrkFreeCardLt;
		    ds_prod.XMLDocument.documentElement.selectSingleNode("BreakFreeCard").text = G_BrkFreeCardOpt;
		}*/
		//////////////////////////////////////////////////////////////////////////////

		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1')
		{
		   	var NewRelCusts
		    var ExistingRelCusts
			NewRelCusts=ds_RelCusts.XMLDocument.documentElement.cloneNode(true);
			ExistingRelCusts=oUpdProdRoot.selectSingleNode("RelatedCustomers");
			oUpdProdRoot.replaceChild(NewRelCusts,ExistingRelCusts);
		}

		if (oNewDetails) oUpdProdRoot.replaceChild(oNewDetails.cloneNode(true), oNodeToReplace);

		if (sNodeToRemove)
		{
			oNodeToRemove = oUpdProdRoot.selectSingleNode(sNodeToRemove);
			if (oNodeToRemove) oUpdProdRoot.removeChild(oNodeToRemove);
		}

		// replace old product with new one
		if (G_selectedProdRecNo <= "0") return; 
		oCurProductsNode.replaceChild (oUpdProdRoot.cloneNode(true), oCurProductsNode.childNodes (G_selectedProdRecNo-1));
		EvaluateAppBRS(oCurProductsNode.childNodes (G_selectedProdRecNo-1));
		EvaluateAppBRS(oCurPurpNode);
		EvaluateAppBRS(oCurProductsNode,true);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Purposes"),true);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);
		if (!NoReselect) SelectProd(G_selectedPurpRecNo, G_selectedProdRecNo);

		FlushToDisk();
		
		if(!NoReselect)
		{
			// Added for Production Issue of TaxResident Details - Starts
			var producttype;
			if(G_Product_Type != ""){
				producttype = G_Product_Type;
			}
			else{
				producttype = document.getElementById("lbProductType").value;	
			}
			
			var breakfree_type=G_breakfree_Type;
			if ((producttype == "RC") || (breakfree_type == "New Credit Card")){
				loadApplicationXML(G_sApplicationFilePath);
			}
			else {
				loadApplicationXML(G_sApplicationFilePath);
			}
			// Added for Production Issue of TaxResident Details - Ends
		
		}
		
		G_bProductDirty = false;	
		
	}
	catch(e)
	{
		displayError(e,"SaveProduct");
	}
}


//==============================================================
//	Name:		RowDeleteProd
//	Purpose:	Gets product ID of the product to be deleted
//	Parameters:	el - (HTML radio button element) selected radio button
//==============================================================
function RowDeleteProd (el)
{
	try
	{
		var ProductID = el.lastChild.innerText // find product id in span
		DeleteProd (ProductID);

	}
	catch(e)
	{
		displayError(e,"RowDeleteProd");
	}
}

//==============================================================
//	Name:		DeleteProd
//	Purpose:	Deletes product.
//	Parameters:	recNo - (numeric) product ID
//==============================================================
function DeleteProd (ProductId)
{
	try
	{
		if (!ConfirmDelete()) return;

		var oPurpose = xml_master.XMLDocument.selectSingleNode ("//Purpose[Products/Product/ProductID="+ProductId+"]");
		var PurpId=oPurpose.selectSingleNode("PurposeID").text;

		//if the selected product is the last one in list then selectedPrdRecNo
		//needs to be decreased
		//if (G_selectedProdRecNo==oPurpose.selectNodes("Products/Product").length) G_selectedProdRecNo--;
		//if delete selected product reset dirty flag else save it
		if (ds_prod.XMLDocument.documentElement.selectSingleNode("ProductID").text==ProductId)
			G_bProductDirty = false;
		else
			SaveProduct();

		// deleting prodIdx product under purpIdx purpose
		var oDelProduct = xml_master.XMLDocument.selectSingleNode ("//Purpose/Products/Product[ProductID="+ProductId+"]");
		oDelProduct.parentNode.removeChild(oDelProduct);

		ShowAddPurpProdButtons();

		EvaluateAppBRS(oPurpose);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Purposes"),true);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Customers"));

		FlushToDisk();
		//reselect purpose if the product has been deleted from the current purpose
		if (G_selectedPurposeId==PurpId && G_selectedPurpRecNo >=0)
		{
			SelectPurp (G_selectedPurpRecNo);
		}
		G_Product_Type="";
	}
	catch(e)
	{
		displayError(e,"DeleteProd");
	}
}


//==============================================================
//	Name:		RefreshPurpList
//	Purpose:	Re-populates lending purpose list
//	Parameters:	oPurpNode - (XML node) selected purpose node
//==============================================================
function RefreshPurpList(oPurpNode)
{
	try
	{
		// reload purpose Codes list
		var iPurpCat =  (oPurpNode)? getXMLField (oPurpNode, "Category", null, true) : document.all.lbPurpCat.value;

		if (!oPurpNode)
			ds_purp.XMLDocument.documentElement.selectSingleNode ("LendingPurpose").text = "";

		//select related purpose labels
		ds_purpLabels.src=ds_purpLabels.src
		var sReqPurp
		var oPurpLabels=ds_purpLabels.selectNodes("//PurposeLabels");
		var nPLs=oPurpLabels.length-1;
		for (i=nPLs; i>=0; i--)
		{
			var oReqPurp = oPurpLabels(i).selectSingleNode("ForPurposes/PurposeCategory[@CatCode='" + iPurpCat + "']");
			if (!oReqPurp)
				oPurpLabels(i).parentNode.removeChild(oPurpLabels(i));
		}
		//load purpose types"

		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
			{
			    populateList("A_TS_PURP_CODE_DESC" , document.all("lbPurpCode"), "@PURPOSE_CATEGORY='" + iPurpCat +"' and @ALLOW_PF_PP='1'" , 'PURPOSE_CODE', 'CODE_DESC');
			}
		else
			{
			    populateList("A_TS_PURP_CODE_DESC" , document.all("lbPurpCode"), "@PURPOSE_CATEGORY='" + iPurpCat +"'", 'PURPOSE_CODE', 'CODE_DESC');
			}

		document.all("lbPurpCode").selectedIndex = -1;

	}
	catch(e)
	{
		displayError(e,"RefreshPurpList");
	}
}

//==============================================================
//	Name:		RefreshProdList
//	Purpose:	Re-populates product list
//	Parameters:	oPurpNode - (XML node) selected purpose node
//==============================================================
function RefreshProdList(oPurpNode)
{
	try
	{
		var iPurpCat  =  getXMLField (oPurpNode, "Category", null, true);
		var iPurpCode =  getXMLField (oPurpNode, "LendingPurpose", null, true);

		// note: ILS only products are hard-coded for POC purposes.

	if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
	{
		populateList("A_TS_PURP_PROD_CODE_DESC" , document.all("lbProductType"),
					"@PURPOSE_CATEGORY=" + iPurpCat + " and @PURPOSE_CODE=" + iPurpCode + " and @ALLOW_PF_PP='1'", 'SUB_PRODUCT_CODE', 'CODE_DESC');

    }
    else
    {
		populateList("A_TS_PURP_PROD_CODE_DESC" , document.all("lbProductType"),
					"@PURPOSE_CATEGORY=" + iPurpCat + " and @PURPOSE_CODE=" + iPurpCode, 'SUB_PRODUCT_CODE', 'CODE_DESC');
    }



		//LinkCustomers();


	}
	catch(e)
	{
		displayError(e,"RefreshProdList");
	}
}

//==============================================================
//	Name:		CalcPurpAmount
//	Purpose:	Calculates purpose total amount (amount sought)
//==============================================================
function CalcPurpAmount()
{
	try
	{
		var nSubTotal = GetFloatVal(getXMLField(ds_purp, "PurchasePrice1")) + 
						GetFloatVal(getXMLField(ds_purp, "PurchasePrice2")) + 
						GetFloatVal(getXMLField(ds_purp, "AdditionalCosts"))-
						GetFloatVal(getXMLField(ds_purp, "DepositPaid")) - 
						GetFloatVal(getXMLField(ds_purp, "OwnFunds")) - 
						GetFloatVal(getXMLField(ds_purp, "Gifts"));
	
		setXMLField (ds_purp, "TotalAmount", nSubTotal, true);
	}
	catch(e)
	{
		displayError(e,"CalcPurpAmount");
	}
}

//==============================================================
//	Name:		SavePurpProd
//	Purpose:	Wraper around SaveProduct and SavePurpose
//				functions. Provided for auto-save compatibility
//==============================================================
function SavePurpProd()
{
	try
	{
		SaveProduct();
		SavePurpose();
		UpdateLoanPackValue();
	}
	catch(e)
	{
		displayError(e,"SavePurpProd");
	}
}

//==============================================================
//	Name:		CalculateTerm
//	Purpose:	Calculates terms in months
//	Parameters:	TermName - (String) name of the term
//							(eg.LoanTerm, FixedRateTerm, InterestOnlyTerm)
//				oPrdDtls - (XML node) product node
//==============================================================
function CalculateTerm(TermName, oPrdDtls)
{
	try
	{
		var yy = GetIntVal(oPrdDtls.getAttribute(TermName+"YY"));
		var mm = GetIntVal(oPrdDtls.getAttribute(TermName+"MM"));
		oPrdDtls.selectSingleNode(TermName).text = yy*12 + mm;
	}
	catch(e)
	{
		displayError(e,"CalculateTerm");
	}
}

//==============================================================
//	Name:		CheckLendingPurposeCategory
//	Purpose:	Disables/Enables and resets/defaults purpose details controls/fields,
//				which are depependent on selected purpose category.
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckLendingPurposeCategory(bSelect)
{
	try
	{
		//get lending purpose setup
		var sPurpCat = (bSelect)? ds_purp.XMLDocument.documentElement.selectSingleNode("Category").text:document.all.lbPurpCat.value;
		if (sPurpCat.length==0) return;

		//get rules for customer type
		var oR = getRDRowObject('A_TS_PURPOSE_CATEGORIES','@CATEGORY_CODE="' + sPurpCat + '"');

	//==================================================================================
	//WR1970 - Making the enable and disable property of chkPurpRapidRefinance checkbox
	//depending on the value selected from the lbPurpCat drop down menu

		//==================================================================================

		if ((!bSelect)&(!oR.ALLOW_OWNER_BUILDER)) ds_purp.XMLDocument.documentElement.selectSingleNode("OwnerBuilder").text = 0;
		document.all.chkPurpOwnerBuilder.disabled = !(oR.ALLOW_OWNER_BUILDER);

		DisableElement(document.all.PurpAmountPartPlus(1), oR.ALLOW_AMOUNT_2);
		if ((!bSelect)&(!oR.ALLOW_AMOUNT_2)) ds_purp.XMLDocument.documentElement.selectSingleNode("PurchasePrice2").text =0;

		DisableElement(document.all.PurpAmountPartMinus(0), oR.ALLOW_DEPOSIT_PAID);
		if ((!bSelect)&(!oR.ALLOW_DEPOSIT_PAID)) ds_purp.XMLDocument.documentElement.selectSingleNode("DepositPaid").text =0;

		CalcPurpAmount();
	}
	catch(e)
	{
		displayError(e,"CheckLendingPurposeCategory");
	}
}

//==============================================================
//	Name:		CheckProductCode
//	Purpose:	Disables/Enables and resets/defaults product details controls/fields,
//				which are depependent on selected product.
//	Parameters:	bSelect - (boolean) set to true to stop resets/defaults happening.
//==============================================================
function CheckProductCode(bSelect)
{
	try
	{
		//get lending purpose setup
		var sSubPrdCd = (bSelect)? ds_prod.recordset.fields("SubProductCode").value:document.all.lbProductType.value;
		//ds_prod.recordset.fields("DiscountPackage").value = G_sDiscPackValue;

		if (sSubPrdCd.length==0)
		{
			document.all.tblLoanDetails.style.display='none';
			document.all.tblDepositDetails.style.display='none';
			//document.all.lbDiscountPack.selectedIndex = -1;
			return;
		}
		//check loan or deposit
		var oPr=getRDRowObject('A_TS_PURP_PROD_CODE_DESC', '@SUB_PRODUCT_CODE="' + sSubPrdCd + '"');
		var sProdCD=oPr.PRODUCT_CODE;

	    if (!bSelect)
		{
			ds_prod.recordset("ProductCode")=sProdCD;
			//ds_prod.recordset("DiscountPackage")="";
		}

		if (sProdCD=="ILS")
			SelectProductLoan(sSubPrdCd, bSelect);
		else
			SelectProductDeposit(sSubPrdCd, bSelect);

	//========================================================================================
	//	WR1970 - loading product DS and calling the function CheckRegulatedValue
	//========================================================================================
		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		if (oPurps.childNodes.length == 0)	return;

		var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);

		G_selectedPurposeId = GetIntVal(oPurpNode.selectSingleNode("PurposeID").text);
		var oProdNode = oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']');

		CheckRegulatedValue(oProdNode);
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
		{
			document.all.tblLoanDocNomination.style.display = 'none';
			ds_prod.recordset.fields("Regulated").value = 1;
		}

		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1')
		{
 			var dtPFLimitEndDate = (xml_master.XMLDocument.documentElement.selectSingleNode('Portfolio/PfLimitEndDate').text);
 			bPFprimaryAccount = (ds_prodDeposit.XMLDocument.documentElement.selectSingleNode("PortfolioPrimaryAccount").text=="-1")? true:false;

			if (sProdCD=="DDA")
            {
				var row = document.getElementById("PortfolioInd");
				row.style.display = '';

				if (dtPFLimitEndDate!="")
				{
				//There is a limit end date for PF.
				 	if (bPFprimaryAccount)
				 	{
						document.getElementById("chkNoEndDate").checked=false;
						document.all.chkNoEndDate.disabled=true;
						document.all.chkNoEndDate.value=dtPFLimitEndDate;
				 	}

				 	else
				 	{
						document.getElementById("chkNoEndDate").checked=false;
						document.all.chkNoEndDate.disabled=false;
				 	}

				}
				else
				{
				//There is no Limit end date for the PF.
					if (bPFprimaryAccount)
					{
						document.getElementById("chkNoEndDate").checked=true;
						document.all.chkNoEndDate.disabled=true;
						//document.all.inpODLimitEndDate.disabled=true;
					}
					else
					{
						document.all.chkNoEndDate.disabled=false;
						document.all.chkNoEndDate.value=-1;
						document.all.inpODLimitEndDate.disabled=true;
					}
				}
			}
		}
		else
        {
			if (sProdCD=="DDA")
            {
				var row = document.getElementById("PortfolioInd");
				row.style.display = 'none';
            }
        }

	}
	catch(e)
	{
		displayError(e,"CheckProductCode");
	}
}

//==============================================================
//	Name:		GetPurposeAmountLeft
//	Purpose:	Calculates purpose amount left to default
//				product amount sought or limit amount
//	Returns:	numeric - calculated purpose amount left
//==============================================================
function GetPurposeAmountLeft()
{
	try
	{
		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);

		var ExistPrdAmt=0;
		var oILSAmts = oPurpNode.selectNodes("./Products/Product[ProductID!=" + G_selectedProductId + "]/LoanDetails/AmountSought");
		for (i=0; i<oILSAmts.length; i++)
			ExistPrdAmt = ExistPrdAmt + parseFloat(oILSAmts(i).text);
		var oDDAAmts = oPurpNode.selectNodes("./Products/Product[ProductID!=" + G_selectedProductId + "]/DepositDetails/LimitAmount");
		for (i=0; i<oDDAAmts.length; i++)
			ExistPrdAmt = ExistPrdAmt + parseFloat(oDDAAmts(i).text);

		var amtleft = VBRound(parseFloat(oPurpNode.getAttribute("TotalAmount")) - ExistPrdAmt,2) ;

		return (amtleft<0)? 0:amtleft;
	}
	catch(e)
	{
		displayError(e,"GetPurposeAmountLeft");
	}
}

//==============================================================
//	Name:		SelectProductLoan
//	Purpose:	Disables/Enables and resets/defaults loan product
//				details controls/fields, which are depependent on
//				selected loan product.
//	Parameters:	sSubProdCd - (string) selected loan product code
//				bSelect - (boolean) set to true to stop
//				resets/defaults happening.
//==============================================================
function SelectProductLoan(sSubProdCd, bSelect)
{
	try
	{
		//default ILS product amount sought
		if (!bSelect)
		{
			ds_prodLoan.src=ds_prodLoan.src
			InitilizeAppBRS(ds_prodLoan.XMLDocument.documentElement);
			ds_prodLoan.recordset.fields("AmountSought").value = GetPurposeAmountLeft();
		}

		//========To remove the old values selected in the offset details when the product is changed
		if (!bSelect)
		{
			document.all.inpOffset_Y.checked = false;
			document.all.inpOffset_N.checked = false;
			DisableElement(document.getElementById("inpOffsetAccNo"), false);
			ds_prodLoan.recordset.fields('OffsetAccNo').value='';
			ds_prodLoan.recordset.fields('OffsetReqd').value='';
		}

		if (ds_prodLoan.recordset.fields('OffsetReqd')== "0")
		{
			DisableElement(document.getElementById("inpOffsetAccNo"), false);
		}
		//========


		//get rules for loan product type
		var oR_ANZLP = getRDRowObject('A_TSR_ANZLP','@PRODUCT_CD="ILS" and @SUB_PROD_CODE="' + sSubProdCd + '"');
		var oR_LENDP = getRDRowObject('A_TSR_LENDPOLICY','@PRODUCT_CD="ILS" and @SUB_PROD_CD="' + sSubProdCd + '"');

		//regulated
		var sDefReg = oR_ANZLP.DEF_REG_INDC;
		if (sDefReg.length==0)	sDefReg = (oR_ANZLP.RIPL_LAND_PROP.indexOf("Y")>=0)? "N":"Y";
		if (!bSelect) ds_prod.recordset.fields("Regulated").value = (sDefReg=="Y")? -1:0;

		//progressive draw
		document.all.chkProgDraw.disabled = (oR_LENDP.MULT_ADV_LOAN!="Y");
		if ((!bSelect)&(oR_LENDP.MULT_ADV_LOAN!="Y")) ds_prodLoan.recordset.fields("ProgressiveDraw").value=0;
		//revolving credit
		var bRevolv = (oR_LENDP.REVOL_IND=="Y");
		if (!bSelect) ds_prodLoan.XMLDocument.documentElement.setAttribute("RevolvCredit", (bRevolv)? "-1":"0");

		//loan term
		DisableElement(document.all.inpLoanTermYY, (!bRevolv));
		DisableElement(document.all.inpLoanTermMM, (!bRevolv));
		if (!bSelect)
		{
			//var mm = (bRevolv)? 0:oR_LENDP.MAX_INI_RP_TERM;
			//ds_prodLoan.recordset.fields("LoanTerm").value=mm;
			//var yy = Math.floor(mm/12);
			//mm = mm - (yy*12);
			ds_prodLoan.recordset.fields("LoanTerm").value=0;
			ds_prodLoan.recordset.fields("LoanTermYY").value=0;
			ds_prodLoan.recordset.fields("LoanTermMM").value=0;
		}

		//fixed rate term (min-max yet to be coded, current as 1 month to 12 years)
		var bAllowFixTerm = ((oR_ANZLP.RATE_INDC=="M")|(oR_ANZLP.RATE_INDC=="F"));
		DisableElement(document.all.inpFixedTermYY, bAllowFixTerm);
		DisableElement(document.all.inpFixedTermMM, bAllowFixTerm);
		if ((!bSelect)&(!bAllowFixTerm))
		{
			//default FixedRateIndex is used to validate Fixed Rate term
			ds_prodLoan.recordset.fields("FixedRateIndex").value = oR_ANZLP.DEF_FIX_INDEX_CD;
			ds_prodLoan.recordset.fields("FixedRateTermYY").value=0;
			ds_prodLoan.recordset.fields("FixedRateTermMM").value=0;
		}

		//interest only term
		var bAllowIntOnly = ((oR_ANZLP.INT_ONLY_INDC=="Y")|(oR_ANZLP.INT_ONLY_CD_1=="Y")|(oR_ANZLP.INT_ONLY_CD_2=="Y"));
		DisableElement(document.all.inpIntOnlyTermYY, bAllowIntOnly);
		DisableElement(document.all.inpIntOnlyTermMM, bAllowIntOnly);
		if ((!bSelect)&(!bAllowIntOnly))
		{
			ds_prodLoan.recordset.fields("InterestOnlyTermYY").value=0;
			ds_prodLoan.recordset.fields("InterestOnlyTermMM").value=0;
		}

		//fin. LMI fees
		document.all.chkFinLMI.disabled = bRevolv;
		if ((!bSelect)&(bRevolv)) ds_prodLoan.recordset.fields("FinanceMortgageInsurancePremium").value=0;
		//refresh product dependent lists
		populateList("A_TSRR_PMT_FREQ" , document.all("cboPmtFreq"), '@PRODUCT_CD="ILS" and @SUB_PROD_CODE="' + sSubProdCd + '"', 'PMT_FREQ', 'CODE_DESC');
		if (!bSelect)
		{
			//default InterestFrequency is used to validate Fixed Rate term
			ds_prodLoan.recordset.fields("InterestFrequency").value=oR_ANZLP.INT_CHAR_FREQ;
			ds_prodLoan.recordset.fields("PaymentFrequency").value=oR_ANZLP.DEF_PMT_FREQ;
			var sPmtMeth=oR_ANZLP.DEFAULT_BILL_METH;
		}

		CheckTermsForPmtAmount(bSelect, true);
		CheckProgressiveDraw(bSelect, true);

		document.all.tblLoanDetails.style.display='block'
		document.all.tblDepositDetails.style.display='none'
	}
	catch(e)
	{
		displayError(e,"SelectProductLoan");
	}
}

//==============================================================
//	Name:		CheckProgressiveDraw
//	Purpose:	Disables/Enables and resets/defaults amount of
//				this advance control/field, which is depependent
//				on the Progressive Draw product attribute.
//	Parameters:	bSelect - (boolean) set to true to stop
//				resets/defaults happening.
//				bFromDflt - (boolean) flag indicating that the
//				value of Progressive Draw product attribute was
//				defaulted
//==============================================================
function CheckProgressiveDraw(bSelect, bFromDflt)
{
	try
	{
		//progressive drawdown
		var bRevolv = (ds_prodLoan.XMLDocument.documentElement.getAttribute("RevolvCredit")=="-1")
		var bProgDraw = (bSelect || bFromDflt)? (ds_prodLoan.recordset.fields("ProgressiveDraw").value=="-1"):document.all.chkProgDraw.status;
		var bDisAmtTA = ((!bRevolv) && (!bProgDraw))
		//disable/enable and default amount of this advance
		DisableElement(document.all.inpAmtThisAdvance, !bDisAmtTA);
		if (!bSelect)
			ds_prodLoan.recordset.fields("AmountThisAdvance").value = (bDisAmtTA)? ds_prodLoan.recordset.fields("AmountSought").value:0;
	}
	catch(e)
	{
		displayError(e,"CheckProgressiveDraw");
	}
}

//==============================================================
//	Name:		CheckPaymentMethod
//	Purpose:	Disables/Enables and resets/defaults periodical
//				payment account control/field, which is depependent
//				on the Payment Method code.
//	Parameters:	bSelect - (boolean) set to true to stop
//				resets/defaults happening.
//				bFromDflt - (boolean) flag indicating that the
//				value of Payment Method code was
//				defaulted
//==============================================================
function CheckPaymentMethod(bSelect, bFromDflt)
{
	try
	{
		//periodical pmt account
		var sPPMeth = (bSelect || bFromDflt)? ds_prodLoan.recordset.fields("PaymentMethod").value:document.all.cboPmtMethod.value;
		DisableElement(document.all.inpPPAccount, (sPPMeth=="P"));
		if ((!bSelect)&(sPPMeth!="P")) ds_prodLoan.recordset.fields("DirectPaymentAccountNumber").value="";
	}
	catch(e)
	{
		displayError(e,"CheckPaymentMethod");
	}
}

//==============================================================
//	Name:		CheckTermsForPmtAmount
//	Purpose:	Disables/Enables and resets/defaults
//				Customer Requested Payment Amount,
//				Payment Frequency  controls/fields, which are
//				depependent on the loan terms.
//	Parameters:	bSelect - (boolean) set to true to stop
//				resets/defaults happening.
//				bFromDflt - (boolean) flag indicating that the
//				values of loan terms were
//				defaulted
//==============================================================
function CheckTermsForPmtAmount(bSelect, bFromDflt)
{
	try
	{
		var IOT = (bSelect || bFromDflt)? ds_prodLoan.recordset.fields("InterestOnlyTerm").value:GetIntVal(document.all.inpIntOnlyTermYY.value)*12 + GetIntVal(document.all.inpIntOnlyTermMM.value);
		var FRT = (bSelect || bFromDflt)? ds_prodLoan.recordset.fields("FixedRateTerm").value:GetIntVal(document.all.inpFixedTermYY.value)*12 + GetIntVal(document.all.inpFixedTermMM.value);
		var LT =  (bSelect || bFromDflt)? ds_prodLoan.recordset.fields("LoanTerm").value:GetIntVal(document.all.inpLoanTermYY.value)*12 + GetIntVal(document.all.inpLoanTermMM.value);
		var sSubProdCd = (bSelect)? ds_prod.recordset.fields("SubProductCode").value:document.all.lbProductType.value;

		IOT = GetIntVal(IOT);
		FRT = GetIntVal(FRT);
		LT=GetIntVal(LT);
		var bAllowPmtAmt = ((FRT>0)&(FRT<LT)&(IOT==0));
		DisableElement(document.all.inpPmtAmount, bAllowPmtAmt);
		if ((!bSelect)&(!bAllowPmtAmt)) ds_prodLoan.recordset.fields("CustomerRequestedPaymentAmount").value=0;

		//payment frequency
		var bRevolv = (ds_prodLoan.XMLDocument.documentElement.getAttribute("RevolvCredit")=="-1")
		var bAllowPmtFreq = (LT!=IOT) || bRevolv ;
		DisableElement(document.all.cboPmtFreq, bAllowPmtFreq);


		//populate payment method list if not done for selected product or
		//for loan term != interest only full term conditions
		if (!document.all("cboPmtMethod").subprod || (document.all("cboPmtMethod").subprod!=sSubProdCd) || (IOT!=LT && G_oCompanyOptions.DLP_IO_FULL=='N'))
		{
			populateList("A_TSRR_BILLING_METH" , document.all("cboPmtMethod"), '@PRODUCT_CD="ILS" and @SUB_PROD_CODE="' + sSubProdCd + '"', 'BILLING_METHOD', 'CODE_DESC');
			document.all("cboPmtMethod").subprod = sSubProdCd;
		}

		if (IOT==LT && G_oCompanyOptions.DLP_IO_FULL=='N')
		{
			//remove payment method 'P' from the list
			var oPMOptions = document.all.cboPmtMethod.options;
			for (var iPM=oPMOptions.length-1; iPM>=0; iPM--)
			{
				if (oPMOptions(iPM).value == 'P')
				{
					oPMOptions.remove(iPM);
					break;
				}
			}
		}

		if (!bSelect)
		{
			var oR_ANZLP = getRDRowObject('A_TSR_ANZLP','@PRODUCT_CD="ILS" and @SUB_PROD_CODE="' + sSubProdCd + '"');
			if (!bAllowPmtFreq)
				ds_prodLoan.recordset.fields("PaymentFrequency").value="";
			else
			{
				if (ds_prodLoan.recordset.fields("PaymentFrequency").value=="")
					ds_prodLoan.recordset.fields("PaymentFrequency").value = oR_ANZLP.DEF_PMT_FREQ;
			}
			//default payment method
			if (IOT + LT!=0)
			{
				var sDefPmtMeth = (IOT==LT && G_oCompanyOptions.DLP_IO_FULL=='N')? 'O':oR_ANZLP.DEFAULT_BILL_METH;
				if (ds_prodLoan.recordset.fields("PaymentMethod").value == '' || ( ds_prodLoan.recordset.fields("PaymentMethod").value == 'P' && sDefPmtMeth =='O'))
				ds_prodLoan.recordset.fields("PaymentMethod").value = sDefPmtMeth;
			}
		}
		CheckPaymentMethod(bSelect, true);
	}
	catch(e)
	{
		displayError(e,"CheckTermsForPmtAmount");
	}
}

//==============================================================
//	Name:		SetAmtThisAdvance
//	Purpose:	Sets the value of the Amount Of This Advance
//==============================================================
function SetAmtThisAdvance()
{
	try
	{
		//if Amount of this advance field is disabled then
		//it should be equal to amount sought
		if (document.all.inpAmtThisAdvance.disabled)
		{
			var oPL = ds_prodLoan.XMLDocument.documentElement;
			oPL.selectSingleNode("AmountThisAdvance").text = oPL.selectSingleNode("AmountSought").text;
		}
	}
	catch(e)
	{
		displayError(e,"SetAmtThisAdvance");
	}
}

//==============================================================
//	Name:		SelectProductDeposit
//	Purpose:	Disables/Enables and resets/defaults deposit product
//				details controls/fields, which are depependent on
//				selected deposit product.
//	Parameters:	sSubProdCd - (string) selected deposit product code
//				bSelect - (boolean) set to true to stop
//				resets/defaults happening.
//==============================================================
function SelectProductDeposit(sSubProdCd, bSelect)
{
	try
	{
		if (!bSelect)
		{
			var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
			var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);

			//default regulated to No for DDA
		        ds_prod.recordset.fields("Regulated").value = 0;

			//reset to default deposit details
			ds_prodDeposit.src=ds_prodDeposit.src;
			InitilizeAppBRS(ds_prodDeposit.XMLDocument.documentElement);

			//default start date
			var defEstDt=getXMLField (oPurpNode, "EstimatedSettlementDate", null, true);
			ds_prodDeposit.recordset.fields("LimitStartDate").value=(defEstDt)? defEstDt:"";
			//default DDA limit amount
			ds_prodDeposit.recordset.fields("LimitAmount").value = Math.floor(GetPurposeAmountLeft());

			//ATO Type
			DisableElement(document.all.cboATOType, (G_oCompanyOptions.ATO_TYPE=="R"));

		}

		CheckNoEndDate(bSelect);
		document.all.tblDepositDetails.style.display='block'
		document.all.tblLoanDetails.style.display='none'
	}
	catch(e)
	{
		displayError(e,"SelectProductDeposit");
	}
}

//==============================================================
//	Name:		CheckNoEndDate
//	Purpose:	Disables/Enables and resets/defaults Limit End Date
//				control/field, which are depependent on
//				selected deposit product.
//	Parameters:	bSelect - (boolean) set to true to stop
//				resets/defaults happening.
//==============================================================
function CheckNoEndDate(bSelect)
{
	try
	{
		//var bEnable = (ds_prodDeposit.recordset.fields("NoEndDateYN").value==0);
		var bEnable = (document.all.chkNoEndDate.checked==false);
		DisableElement(document.all.inpODLimitEndDate, bEnable);
		if (!bSelect && !bEnable) ds_prodDeposit.recordset.fields("LimitEndDate").value="";
	}
	catch(e)
	{
		displayError(e,"CheckNoEndDate");
	}
}

//==============================================================
//	Name:		ShowPurpProdSubScreens
//	Purpose:	Manages display of the Purpose and Product sub
//				screens
//	Parameters:	bShowPurp - (boolean) flag indicating required
//				status of purpose sub screen (set to true to show
//				screen, false -to hide)
//				bShowProd - (boolean) flag indicating required
//				status of product sub screen (set to true to show
//				screen, false -to hide)
//==============================================================
function ShowPurpProdSubScreens(bShowPurp, bShowProd)
{
	try
	{
		var oPurpStyle=document.all.PurpSubScr.style
		var oProdStyle=document.all.ProdSubScr.style
		var oLoanPackStyle=document.all.LoanPackageDiv.style

		oPurpStyle.display = (bShowPurp)? "block":"none";
		oPurpStyle.visibility = (bShowPurp)? "":"hidden";
		oProdStyle.display = (bShowProd)? "block":"none";
		oProdStyle.visibility = (bShowProd)? "":"hidden";
		oLoanPackStyle.display = (bShowProd || bShowPurp)? "block":"none";
		oLoanPackStyle.visibility = (bShowProd || bShowPurp)? "":"hidden";

		document.all.aSavePurpProd.style.display =  (bShowPurp||bShowProd)? "":"none";
	}
	catch(e)
	{
		displayError(e,"ShowPurpProdSubScreens");
	}
}

//==============================================================
//	Name:		ShowAddPurpProdButtons
//	Purpose:	Hides/Displays add purpose and add product buttons.
//==============================================================
function ShowAddPurpProdButtons()
{
	try
	{
	     var SelectedPakTier;
	     var nPackTier;

	    if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
		{
			var SelectedPakTier= xml_master.XMLDocument.documentElement.selectSingleNode("Portfolio/PfPackageTier").text;
			if (SelectedPakTier==G_selectedPackTier1to5)
				{
					nPackTier=5;
				}
			else
				{
					nPackTier=12;
				}
	    }
	    else
		{
			nPackTier=12;
		}

       	var oMDocEl=xml_master.XMLDocument.documentElement;
		var nPrdCnt=oMDocEl.selectNodes("//Product").length;
		var nPurp=oMDocEl.selectNodes("//Purpose").length;

		var nPurpProdCount=	(nPurp <= nPrdCnt)? nPrdCnt:nPurp;

		//document.all.AddProdCmd.style.display = (nPrdCnt <= nPackTier)? "":"none";
		//Hide the add purpose button if the product/Porpose count is equal to the tier count.
		document.all.AddPurpCmd.style.display = ( nPurpProdCount < nPackTier)? "":"none";
		//Hide the add purpose message if the purpose count is not 0.
		document.all.AddProdNoteDiv.style.display = (nPurp==0)? "":"none";
		//Hide the add Product button if the product count is equal to the tier count.
		document.all.AddProdCmdDiv.style.display = (nPrdCnt<nPackTier)? "":"none";
		//Show the max Product reached message if the product count is greater than or equal to the tier count.
		document.all.MaxProdMsg.style.display = (nPrdCnt>=nPackTier)? "":"none";
	}
	catch(e)
	{
		displayError(e,"ShowAddPurpProdButtons");
	}
}

//==============================================================
//	Name:		SetCustomerDirty
//	Purpose:	Sets product details changed flag
//==============================================================
function SetProductDirty()
{
	G_bProductDirty = true;
}

//==============================================================
//	Name:		SetCustomerDirty
//	Purpose:	Sets purpose details changed flag
//==============================================================

function SetPurposeDirty()
{
	G_bPurposeDirty = true;
}

//WR1970 - Added a new function for updating the Purpose and Purpose Category combination
//that are already saved in the previous version
//===================================================================================
//	Name:		UpdatePurposeProduct
//	Purpose:	Updating the Purpose in the Loan Details section and
//				selecting the default DiscountPackage value for the Products
//				when an old version application is opened in the new version(2.0)
//	Parameters:	none
//===================================================================================
function UpdatePurposeProduct()
{
	try
	{

		//Updating Purpose and purpose Category combinations

		var oDocEl=xml_master.XMLDocument.documentElement;
		var oNodeList = oDocEl.selectNodes("Purposes/Purpose");

		if  (oNodeList.length > 0)
		{

			for (i=0; i<oNodeList.length; i++)
			{

				switch(oNodeList.item(i).getAttributeNode("PurposeCodeDescription").value)
				{

					case "Construction Other-1st Home" :
						oNodeList.item(i).setAttribute("PurposeCodeDescription", "Construction-1st Home");
						break;
					case "Construction Other-Not 1st Home" :
						oNodeList.item(i).setAttribute("PurposeCodeDescription", "Construction-Not 1st Home");
						break;
					case "Purch Estab Home Other-1st Home" :
						oNodeList.item(i).setAttribute("PurposeCodeDescription", "Purch Estab Home-1st Home");
						break;
					case "Purch Estab Home Other-Not 1st Home" :
						oNodeList.item(i).setAttribute("PurposeCodeDescription", "Purch Estab Home-Not 1st Home");
						break;
					case "Purch New Home Other-1st Home" :
						oNodeList.item(i).setAttribute("PurposeCodeDescription", "Purch New Home-1st Home");
						break;
					case "Purch New Home Other-Not 1st Home" :
						oNodeList.item(i).setAttribute("PurposeCodeDescription", "Purch New Home-Not 1st Home");
						break;
					case "Dwellings for Rent/Resale" :
						switch(oNodeList.item(i).getAttributeNode("CategoryCodeDescription").value)
						{
						
							case "Construction of Dwellings" :
								oNodeList.item(i).setAttribute("PurposeCodeDescription", "Construction � Investment Property");
								break;
							case "Home Improvement" :
								oNodeList.item(i).setAttribute("PurposeCodeDescription", "Investment Property - Improvements");
								break;
							case "Purchase Established Dwellings" :
								oNodeList.item(i).setAttribute("PurposeCodeDescription", "Purch Estab � Investment Property");
								break;
							case "Purchase Land" :
								oNodeList.item(i).setAttribute("PurposeCodeDescription", "Investment Land");
								break;
							case "Purchase New Dwelling" :
								oNodeList.item(i).setAttribute("PurposeCodeDescription", "Purch New � Investment Property");
								break;
							case "Re-finance" :
								oNodeList.item(i).setAttribute("PurposeCodeDescription", "Refinance Investment Loan");
								break;
							case "Supplementary" :
								oNodeList.item(i).setAttribute("PurposeCodeDescription", "Investments");
								break;

						}	//inner switch()

						break;

				}	//outer switch

			}	//for loop

		}	//if

		//Updating Loan/Dicount Package for products

		oDocEl=xml_master.XMLDocument.documentElement;
		oNodeList = oDocEl.selectNodes("Purposes/Purpose/Products/Product");

		/*if(oNodeList.length > 0)
		{
			for (i=0; i<oNodeList.length; i++)
			{

				oNodeList.item(i).setAttribute("DiscountPackageDescription", G_sDiscPackDesc);
				oNodeList.item(i).selectSingleNode("DiscountPackage").text = G_sDiscPackValue;

			}	//for loop

		}	//if*/


		FlushToDisk();

	}
	catch (e)
	{
		displayError(e,"UpdatePurposeProduct");
	}
}

//	WR1970 - Added a new function for populating the customers in the cboNominee,
//	if any, is added
//===============================================================================
//	Name:		PopulateNominee
//	Purpose:	populating the customers, if any, is added
//	Parameters:	none
//===============================================================================
function PopulateNominee()
{

	try
	{
		var df=cboNominee.dataFld;
		var ds=cboNominee.dataSrc;

		cboNominee.dataFld="";
		cboNominee.dataSrc="";

		// clear list
		for (i = cboNominee.options.length-1; i>=0; i--)
			cboNominee.options.remove(i);

		var oCusts=xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer")
		var opt = document.createElement("OPTION");

		cboNominee.options.add (opt);
		opt.value = "Nominate All";
		opt.innerText = "Nominate All";
		opt.selected=true
		var sName = "";
		var sID;

		for (var i=0; i < oCusts.length; i++)
		{

			sID = oCusts(i).selectSingleNode("CustomerID").text;
			sName = oCusts(i).selectSingleNode("CustomerName").text;

			if(sName.length != 0)
			{
				opt = document.createElement("OPTION");
				cboNominee.options.add (opt);
				opt.value = sID;
				opt.innerText = sName;
			}
		}

		cboNominee.dataSrc=ds;
		cboNominee.dataFld=df;

	}
	catch(e)
	{
		displayError(e, 'PopulateNominee');
	}

}

//	WR1970 - Added a new function for checking the Regulated value for the
//	selected product
//========================================================================
//	Function Name:	CheckRegulatedValue
//	Parameters:		Product node object
//	Return:			nil
//	Description:	Checking the Regulated value for the selected product
//========================================================================
function CheckRegulatedValue(oProdNode)
{
	try
	{

        document.all.tblLoanDocNomination.style.display = 'none';
		var iRegulated = ds_prod.recordset.fields("Regulated").value;

		if(iRegulated != 0)
		{
			document.all.tblLoanDocNomination.style.display = 'block';
			SelectNominee(oProdNode);
		}
		else
		{
			if(ds_prod.recordset.fields("Regulated").value != 0)
			{
				document.all.tblLoanDocNomination.style.display = 'block';
				ds_prod.recordset.fields("NominatedBorrower").value = "Nominate All";
			}
			else
			{
				document.all.tblLoanDocNomination.style.display = 'none';
			}

		}



	}
	catch (e)
	{
		displayError(e,'CheckRegulatedValue');
	}
}

//	WR1970 - Added a new function for selecting the Nominee if a nominee is selected for
//	a product
//=================================================================================================
//	Function Name	:	SelectNominee
//	Parameters		:	Object of the Product Node
//	Return			:	Nil
//	Description		:	Select the nominee name if any nominee is selected for a particular product
//=================================================================================================
function SelectNominee(oProdNode)
{

	try
	{

		if(oProdNode.selectSingleNode("ProductID").text!="")
		{
			var sNominee = oProdNode.selectSingleNode("NominatedBorrower").text;
			var iSelected = 0;

			if(sNominee != "")
			{
				for(i=0; i<document.all("cboNominee").length; i++)
				{
					if(sNominee == document.all("cboNominee").options[i].value)
					{
						iSelected = i;
					}
				}

				if(iSelected != 0)
				{
					document.all("cboNominee").selectedIndex = iSelected;
				}
				else
				{
					ds_prod.recordset.fields("NominatedBorrower").value = "Nominate All";
				}
			}
			else
			{
				ds_prod.recordset.fields("NominatedBorrower").value = "Nominate All";
			}
		}

	}
	catch (e)
	{
		displayError(e, 'SelectNominee');
	}

}

//	WR1970 - Added a new function when any of the Loan Package value get changes
//==============================================================================================================
//	Function Name	:	LoanPackageValueChange
//	Parameters		:	Nil
//	Return			:	Nil
//	Description		:	Setting the values to the global variables when any of the Loan Package value is changed
//==============================================================================================================
function LoanPackageValueChange()
{
	try
	{
		
		//G_sDiscPackValue=document.all("lbDiscountPack").value;
		//G_sDiscPackDesc=getListText(document.all("lbDiscountPack"));

		if(document.all("chkPurpLoDocApplication").status == true)
			G_LoDocValue = "-1";
		else
			G_LoDocValue = "0";

        UpdateLoanPackValue();

        //EnableControl();

		AddUpdLiability();
		CalculateBFCCTotals();

	}
	catch(e)
	{
		displayError(e, "LoanPackageValueChange");
	}
}



/*
function EnableControl()
{
    try {
        if (G_sDiscPackValue == 'PROF' || G_sDiscPackValue == 'SHRH' || G_sDiscPackValue == '') {
            DisableElement(document.all.lbDiscountPack, true);
            DisableElement(document.all.cboBreakfreeCard, false);
            DisableElement(document.all.BreakFreeCardLt, false);
            G_BrkFreeCardLt = "0";
            G_BrkFreeCardOpt = "";
            document.all.cboBreakfreeCard.value = "";
            document.all.BreakFreeCardLt.value = "0";
            if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1') {
                DisableElement(document.all.lbDiscountPack, false);
            }
        }
        else {
            if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') != '1') {
                DisableElement(document.all.lbDiscountPack, true);
                DisableElement(document.all.cboBreakfreeCard, true);
                DisableElement(document.all.BreakFreeCardLt, true);
                if (G_BrkFreeCardOpt == '') {
                    G_BrkFreeCardOpt = "New Credit Card";
                    document.all.cboBreakfreeCard.value = "New Credit Card";
                }
                else {
                if (G_BrkFreeCardOpt == 'Existing Card - No Change') {
                    DisableElement(document.all.BreakFreeCardLt, false);
                }
            }
          }
        }

     }
	catch(e)
	{
	    displayError(e, "EnableControl");
	}

}
*/

//	WR1970 - Added a new function for updating the Loan Package values
//====================================================================
//	Function Name	:	UpdateLoanPackValue
//	Parameters		:	Nil
//	Return			:	Nil
//	Description		:	Updates the Loan Package values
//====================================================================
function UpdateLoanPackValue()
{
	try
	{
		var oDocEl=xml_master.XMLDocument.documentElement;
		var oPurpNode = oDocEl.selectNodes("Purposes/Purpose");
		var oProdNode = oDocEl.selectNodes("Purposes/Purpose/Products/Product");

		if(oProdNode.length > 0)
		{
			for(var i=0; i<oProdNode.length; i++)
			{
				if(oProdNode.item(i).selectSingleNode("ProductID").text!="")
				{
					//oProdNode.item(i).setAttribute("DiscountPackageDescription", G_sDiscPackDesc);
					//oProdNode.item(i).selectSingleNode("DiscountPackage").text = G_sDiscPackValue;
					oProdNode.item(i).selectSingleNode("LoDocApplication").text = G_LoDocValue;
				}
			}
		}
		else
		{
			if(oPurpNode.length == 0)
			{
				//G_sDiscPackDesc="";
				//G_sDiscPackValue="";
				G_LoDocValue=0;
			}
		}
		
		//oDocEl.setAttribute("DiscountPack", G_sDiscPackValue);
		oDocEl.setAttribute("LoDocApp", G_LoDocValue);
		
		FlushToDisk();
		
	}
	catch(e)
	{
		displayError(e, "UpdateLoanPackValue");
	}
}

//	WR1970 - Added a new function for selecting the values in the dropdown menu and checkbox
//============================================================================
//	Function Name	:	selectLoanPackValue
//	Parameters		:	Nil
//	Return			:	Nil
//	Description		:	Selecting the values in the dropdown menu and checkbox
//============================================================================
function selectLoanPackValue()
{
    try {
        /*if (G_sDiscPackValue != "") {
            for (i = 0; i < document.all("lbDiscountPack").length; i++) {
                if (G_sDiscPackValue == document.all("lbDiscountPack").options[i].value) {
                    document.all("lbDiscountPack").selectedIndex = i;
                    break;
                }
            }
        }
        else {
            document.all("lbDiscountPack").selectedIndex = 0;
        }*/

        if (G_LoDocValue == "-1")
            document.all("chkPurpLoDocApplication").status = true;
        else
            document.all("chkPurpLoDocApplication").status = false;


		if (G_ReasonForInterestOnly != "")
		{
			document.all("cboReasonForIntOnly").value = G_ReasonForInterestOnly;
		}
		if (G_OtherReasonForInterestOnly != "")
		{
			document.all("txtOthRsnforIntOnly").value = G_OtherReasonForInterestOnly;
		}



        /*if (G_BrkFreeCardOpt != "") {
            for (i = 0; i < document.all("cboBreakfreeCard").length; i++) {
                if (G_BrkFreeCardOpt == document.all("cboBreakfreeCard").options[i].value) {
                    document.all("cboBreakfreeCard").selectedIndex = i;
                    break;
                }
            }
        }*/
    }
    catch (e) {
        displayError(e, "selectLoanPackValue");
    }
}


//==============================================================
//	Name:		ShowHideAddPfRecBtn
//	Purpose:	Shows/Hides the Add Portfolio Button
//
//	Parameters:
//==============================================================
function ShowHideAddPfRecBtn()
{
	try
	{
		//var oPfRecs=ds_cust.XMLDocument.documentElement.selectSingleNode("//Portfolio");
		var oPurpsNode = xml_master.XMLDocument.selectSingleNode ("//Purposes");
		var nPfRecs=oPurpsNode.childNodes.length;
		//document.all.AddPortfolioCmd.style.display = (nPfRecs<1)? "":"none";

	}
	catch(e)
	{
		displayError(e,"ShowHideAddPfRecBtn");
	}
}

//==============================================================
//	Name:		HideshowPfSummary
//	Purpose:	Shows/Hides the Portfolio Summary table
//	Parameters:	None
//==============================================================

function HideshowPfSummary()
{
	try
	{
		var showsum = xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp');
		var oPurpsNode = xml_master.XMLDocument.selectSingleNode ("//Purposes");
		var NoOfPurp = oPurpsNode.childNodes.length;

/* Commented for WR4368-Grandfather PTF
		if(showsum == '1')
		{
			document.getElementById("PfSummary").style.display="block";
			document.getElementById("AddPortfolioCmd").style.display="none";
			var row = document.getElementById("PfTextShowHide");
			row.style.display = 'none';
		}
		else
		{
			document.getElementById("PfSummary").style.display="none";
			if (NoOfPurp >=1)
			{
				document.getElementById("AddPortfolioCmd").style.display="none";

			}
			else
			{
				document.getElementById("AddPortfolioCmd").style.display="block";

			}
				var row = document.getElementById("PfTextShowHide");
				row.style.display = 'block';
				row.style.display = '';
		}
added the below lines for WR4368-Grandfather PTF
*/
		document.getElementById("PfSummary").style.display="none";
		document.getElementById("AddPortfolioCmd").style.display="none";
		var row = document.getElementById("PfTextShowHide");
		row.style.display = 'none';
	}
	catch(e)
	{
		displayError(e,"HideshowPfSummary");
	}
}

//==============================================================
//	Name:		DeletePfRecord
//	Purpose:	Deletes the portfolio record and the purpose/product records
//	Parameters:	None
//==============================================================

function DeletePfRecord()
{
	try
	{
		if (VBMsgBox('Warning: All purposes and products will also be deleted. \n\n Are you sure you want to delete this Portfolio Record?', 48+4, "Confirm Delete")==6)
		{
			var oPurpsNode = xml_master.XMLDocument.selectSingleNode ("//Purposes");
			var NoOfPurp = oPurpsNode.childNodes.length;
			var PurpNode;

			var iIndex;

			// delete each purpose.

			for(iIndex=1;iIndex<=NoOfPurp;iIndex++)			{

				oPurpsNode.removeChild(oPurpsNode.childNodes(0));

			}

			var oPfNode = xml_master.XMLDocument.selectSingleNode('//Portfolio');
			var NoOfchildren = oPfNode.childNodes.length;
			oPfNode.setAttribute('PfSummaryDescription','');
			oPfNode.setAttribute('PfSummaryDetails','');
			oPfNode.setAttribute('PortfolioAmount','');

			for(iIndex=1;iIndex<=NoOfchildren;iIndex++)
			{
				oPfNode.removeChild(oPfNode.childNodes(0));
			}
			xml_master.XMLDocument.documentElement.setAttribute('PortfolioApp','0');

			//hide purpose details tabs

			G_selectedProdRecNo=0;
			G_selectedPurpRecNo=0;
			G_bPurposeDirty = true;
			G_bProductDirty = true;

			//Display the Add Portfolio Button
			ShowAddPurpProdButtons();
			EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Purposes"),true);
			EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);

			G_oScreens["ScrPurpProd"].ListsPopulated= false;
			ShowPurpProdSubScreens(false,false);
			HideshowPfSummary();
			//Reset application attributes

			//xml_master.XMLDocument.documentElement.setAttribute('DiscountPack','');
			xml_master.XMLDocument.documentElement.setAttribute('maxPurposeID','0');
			xml_master.XMLDocument.documentElement.setAttribute('maxProductID','0');

			//G_sDiscPackValue = xml_master.XMLDocument.documentElement.getAttribute('DiscountPack');
			//G_sDiscPackDesc="";
			G_LoDocValue=0;

			FlushToDisk()


		}
		else
		return;
	}
	catch(e)
	{
		displayError(e,"DeletePfRecord");
	}

}

//==============================================================
//	Name:		SwitchProdDetailsTab
//	Purpose:	To switch over tab between product and customer relation to that product
//	Parameters:	Selected tabindex
//==============================================================


function SwitchProdDetailsTab(iTabIdx)
{
	try
	{
	    var oTabs = document.all.ScrPurpProd.all.ProductDetailsTab;		// product tabs
		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		var oCurPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);
		var oCurProductsNode = oCurPurpNode.selectSingleNode("Products");
		var oCustsNode;
		var CurRelCusts;

		oProdNode=oCurProductsNode.childNodes (G_selectedProdRecNo-1);
        CurRelCusts=oProdNode.selectSingleNode("RelatedCustomers")

		ds_RelCusts.src=ds_RelCusts.src;

		ds_RelCusts.XMLDocument.replaceChild(CurRelCusts.cloneNode(true),ds_RelCusts.XMLDocument.documentElement);


		//faded
		var currimg=document.all.ScrPurpProd.all.imgProdDetailsTab(iTabIdx).src;
		if (currimg.indexOf("_faded.gif")>=0) return;

		G_iCurPurpProdTab = iTabIdx;

		if (G_iCurPrdDtlsTabIdx != null)
		{
			oTabs(G_iCurPrdDtlsTabIdx).style.display = "none";
			document.all.ScrPurpProd.all.imgProdDetailsTab(G_iCurPrdDtlsTabIdx).src = "../images/tabs/" + aPrdDtlsTabImgs[G_iCurPrdDtlsTabIdx] + ".gif";
		}

		oTabs(iTabIdx).style.display = "block";
		document.all.ScrPurpProd.all.imgProdDetailsTab(iTabIdx).src = "../images/tabs/" + aPrdDtlsTabImgs[iTabIdx] + "_dn.gif";
		G_iCurPrdDtlsTabIdx = iTabIdx;
		window.scrollTo(0,0)


		if (iTabIdx==1)
		{
		    var DepositNodes;
		    var bPFprimaryAccount;
		    var oPurposes;
		    var oSelProd = ds_prod.XMLDocument.documentElement;
		    var oLoanDtls = oSelProd.selectSingleNode("LoanDetails");
		    var oDepDtls = oSelProd.selectSingleNode("DepositDetails");
			var numCust = ds_RelCusts.XMLDocument.documentElement.selectNodes("RelatedCustomer").length

			if (numCust == 0)return;
			bPFprimaryAccount = (ds_prodDeposit.XMLDocument.documentElement.selectSingleNode("PortfolioPrimaryAccount").text=="-1")? true:false;

           	if (bPFprimaryAccount)
			{
				VBMsgBox('The customer relationships of the Primary Account cannot be altered', 64+0, G_sAPPLICATION_TITLE)
				if (numCust == 1)
					//break;
 	    			document.all.cboCustrel.disabled=true


    			if (numCust > 1)
				{
					for (var x = 0; x < numCust; x++)
					document.all.cboCustrel[x].disabled=true;
				}
            }
            else
            {
                for (var x = 0; x < numCust; x++)
			    document.all.cboCustrel[x].disabled=false;
            }
		}

	check_OffsetReqd();
	}
	catch(e)
	{
		displayError(e,"SwitchProdDetailsTab");
	}
}

//==============================================================
//	Name:		AddUpdatePfRecord
//	Purpose:	Updates Portfolio Record Details from the popup
//	Parameters:
//==============================================================
function AddUpdatePfRecord()
{
	try
	{

 		var oPfRecEdit;

		var oMDocEl=xml_master.XMLDocument.documentElement;
		var nPrdCnt=oMDocEl.selectNodes("//Product").length;

		var oPfRec1 = xml_master.XMLDocument.documentElement.cloneNode(true);
		oPfRec1.setAttribute("SubProdCount",nPrdCnt);

		oPfRecEdit=window.showModalDialog("PortfolioDtls.htm", oPfRec1,"dialogHeight:435px;dialogWidth:560px;help:No;resizable:No;status:No;scroll:No;");

		G_bPurposeDirty = true;

		if (oPfRecEdit != null)
		{

			G_oScreens["ScrPurpProd"].ListsPopulated= false;

			xml_master.XMLDocument.documentElement.setAttribute('PortfolioApp','1')
			var oMDocEl=xml_master.XMLDocument.documentElement;
			var oReplPf = oMDocEl.selectSingleNode('Portfolio');
			xml_master.XMLDocument.documentElement.setAttribute('appAmounts',VBFormatCurrency(oPfRecEdit.selectSingleNode("@PortfolioAmount").text, 0));

			//G_sDiscPackValue=GetDiscountPackageValue(oPfRecEdit);

			//xml_master.XMLDocument.documentElement.setAttribute("DiscountPack",G_sDiscPackValue);
			//G_sDiscPackDesc = "";
			//G_BrkFreeCardLt = 0;
			//G_BrkFreeCardOpt = "";

			oMDocEl.replaceChild(oPfRecEdit,oReplPf);
			HideshowPfSummary();
			ShowAddPurpProdButtons();

			var nPurpCount=xml_master.XMLDocument.documentElement.selectNodes("//Purposes/Purpose").length

			if (nPurpCount>0)
			{
				SelectPurp(1);
				EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Purposes"));
			}

		}



		FlushToDisk();



		if (nPrdCnt!=0)
		{
			PurpProductScreenShow();
		}
	}
	catch(e)
	{
		displayError(e,"AddUpdatePfRecord");
	}
}

//==============================================================
//	Name:		RefreshPrimaryCusts
//	Purpose:	(Wrongly named function) It actually enables and
//				disables the controls if the account is primary
//	Parameters:	Primary account flag
//==============================================================

function RefreshPrimaryCusts(bPrimaryAcc)
{
	try
	{

		var bNoPFLimitEndDate = (xml_master.XMLDocument.documentElement.selectSingleNode("Portfolio/PfNoEndDate").text);
		// 0: PF End Date present  1: PF End Date  NOT present
		if (bPrimaryAcc)
		{
		//This is the primary account

			var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
			var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);
			var oProdNode = oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']');

			LinkCutomerToProduct(oProdNode);

		 	var sPFLimitDate = (xml_master.XMLDocument.documentElement.selectSingleNode("Portfolio/PfLimitEndDate").text);

		 	ds_prodDeposit.XMLDocument.documentElement.selectSingleNode("LimitEndDate").text=sPFLimitDate;

 		    if (bNoPFLimitEndDate==1)
			{
			//There is no end date for PF
				ds_prodDeposit.XMLDocument.documentElement.selectSingleNode("NoEndDateYN").text="-1";
				document.getElementById("chkNoEndDate").checked=true;
				document.all.chkNoEndDate.disabled = true;
				document.getElementById("inpODLimitEndDate").text=sPFLimitDate;

				//document.getElementById("inpODLimitEndDate").className="inputSmall";
				//document.getElementById("inpODLimitEndDate").className=document.getElementById("inpODLimitEndDate").className + " tblHilite2"

				DisableElement(document.getElementById("inpODLimitEndDate"),false);

			}

			if (bNoPFLimitEndDate==0)
			{
			//There is an end date for PF
				ds_prodDeposit.XMLDocument.documentElement.selectSingleNode("NoEndDateYN").text="0";
				document.getElementById("inpODLimitEndDate").disabled=false;
				document.getElementById("inpODLimitEndDate").value= sPFLimitDate ; //date of PF Limit End date
				document.getElementById("inpODLimitEndDate").className="inputSmall";
				document.getElementById("chkNoEndDate").checked=false;
				document.all.chkNoEndDate.disabled = true;

				DisableElement(document.getElementById("inpODLimitEndDate"),false);

			}
			     FlushToDisk();
		}
		else
		{
		//This is not the primary account
			if (bNoPFLimitEndDate==1) // date NOT present
			{
			//There is no end date for portfolio
				document.all.chkNoEndDate.disabled = false;
				if (ds_prodDeposit.XMLDocument.documentElement.selectSingleNode("NoEndDateYN").text=="0")
				{
				document.getElementById("inpODLimitEndDate").disabled=false;
				document.getElementById("inpODLimitEndDate").className="inputSmall";
				}
			}

			if (bNoPFLimitEndDate==0) //       date PRESENT
			{
			//There is an end date for portfolio

				ds_prodDeposit.XMLDocument.documentElement.selectSingleNode("NoEndDateYN").text="0";
				document.getElementById("inpODLimitEndDate").disabled=false;
				document.getElementById("chkNoEndDate").checked=false;
				document.all.chkNoEndDate.disabled = true;
				document.getElementById("inpODLimitEndDate").className="inputSmall";
			}
			FlushToDisk();
		}

	}
	catch(e)
	{
		displayError(e,"RefreshPrimaryCusts");
	}
}


//==============================================================
//	Name:		GetDescountPackageValue
//	Purpose:	This function gets the discount package value 
//				based on the selection on the portfolio screen.
//	Parameters:	portfolio details node
//==============================================================

function GetDiscountPackageValue(oPfRec)
{
	try
	{	
		var sPackgeValue="";
		
		var pfPackageTierSelected= oPfRec.selectSingleNode("PfPackageTier").text;
		var pfPackageSelected= oPfRec.selectSingleNode("PfDiscountPackage").text;
	
		if (pfPackageTierSelected=="005")
			if (pfPackageSelected=="Breakfree")
				sPackgeValue="";
			else
				sPackgeValue="";
		else
			if (pfPackageTierSelected=="012")
			{
				if (pfPackageSelected=="Breakfree")
					sPackgeValue="PB12";
				else
					sPackgeValue="PT12";
			}


		return sPackgeValue;
	}
	catch(e)
	{
		displayError(e,"GetDiscountPackageValue");
	}
}




function check_OffsetReqd()
{
	try
	{
		if (ds_prodLoan.recordset.fields('OffsetReqd') == "0" || ds_prodLoan.recordset.fields('OffsetReqd') == "" )
		{
			DisableElement(document.getElementById("inpOffsetAccNo"), false);
			ds_prodLoan.recordset.fields('OffsetAccNo').value='';
		}
		else
		{
			DisableElement(document.getElementById("inpOffsetAccNo"), true);
		}
	}
	catch (e)
	{
		displayError(e,"check_OffsetReqd");
	}
}


/*==============================================================================================================
//	Function Name	:	BrkFreeCrdLtValChange
//	Parameters		:	Nil
//	Return			:	Nil
//	Description		:
//==============================================================================================================
function BrkFreeCrdLtValChange()
{
    try {
        G_BrkFreeCardLt = document.all("BreakFreeCardLt").value;
        G_BrkFreeCardOpt = document.all("cboBreakfreeCard").value;

        var oDocEl = xml_master.XMLDocument.documentElement;
        var oProdNode = oDocEl.selectNodes("Purposes/Purpose/Products/Product");

        if (oProdNode.length > 0) {
            for (var i = 0; i < oProdNode.length; i++) {
               {
                   oProdNode.item(i).selectSingleNode("BreakFreeCardLimit").text = G_BrkFreeCardLt;
                   oProdNode.item(i).selectSingleNode("BreakFreeCard").text = G_BrkFreeCardOpt;

                }
            }
        }
        G_bPurposeDirty = true;
        document.all("BreakFreeCardLt").value = G_BrkFreeCardLt;
        document.all("cboBreakfreeCard").value = G_BrkFreeCardOpt;
        EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("Purposes"), true);

		AddUpdLiability();
        CalculateBFCCTotals();

		FlushToDisk();
    }
    catch (e) {
        displayError(e, "BrkFreeCrdLtValChange");
    }
}

//==============================================================================================================
//	Function Name	:	setLoanPackageLtValue
//	Parameters		:	Nil
//	Return			:	Nil
//	Description		:	Setting the values to the global variables when any of the Loan Package value is changed
//==============================================================================================================
function setLoanPackageLtValue()
{
	try
	{
	    document.all("BreakFreeCardLt").value = G_BrkFreeCardLt;
	    document.all("cboBreakfreeCard").value = G_BrkFreeCardOpt;
	}
	catch(e)
	{
		displayError(e, "setLoanPackageLtValue");
	}
}


function LoanBreakFreeCardChange() {
    try {

        if (((document.all.lbDiscountPack.value == 'PSPX') || (document.all.lbDiscountPack.value == 'PSPW')) ) {
            if ((document.all.cboBreakfreeCard.value == 'New Credit Card') || (document.all.cboBreakfreeCard.value == 'Existing Card - Change to Platinum')) {
                document.all.BreakFreeCardLt.disabled = false;
                document.all.cboBreakfreeCard.disabled = false;
            }
            else {
                if ((document.all.cboBreakfreeCard.value == 'Existing Card - No Change')) {
                    G_BrkFreeCardLt = "0";
                    document.all.BreakFreeCardLt.value = "0";
                    document.all.BreakFreeCardLt.disabled = true;

                }
                else {
                    document.all.cboBreakfreeCard.value = "";
                    document.all.BreakFreeCardLt.value = "0";
                    document.all.cboBreakfreeCard.disabled = false;
                    document.all.BreakFreeCardLt.disabled = false;
                }
            }
        }
        else {
            document.all.cboBreakfreeCard.value = "";
            document.all.BreakFreeCardLt.value = "0";
            document.all.cboBreakfreeCard.disabled = true;
            document.all.BreakFreeCardLt.disabled = true;
        }
		BrkFreeCrdLtValChange();
    }
    catch (e) {
        displayError(e, "LoanBreakFreeCardChange");
    }
}*/


//==============================================================
//	Name:		IntOnlyTermChange
//	Purpose:	Validation onload of the product screen and onchange of the interest only term dropdown box.
//  Parameters: SourceOfChange is either "OnLoad" / "OnChange"
//==============================================================

function IntOnlyTermChange(SourceOfChange)
{
	try
	{
		var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
		var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);
			
			
		if (SourceOfChange == 'OnLoad')
		{
			if (oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']/LoanDetails/InterestOnlyTerm') === null) return;
			var IntOnlyTerm = oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']/LoanDetails/InterestOnlyTerm').text;

			if (IntOnlyTerm > 0)
			{
				showDiv('tblReason');		
			}
			else
			{
				hideDiv('tblReason');	
			}
		}
		else
		{
			if (document.getElementById('inpIntOnlyTermYY').value > 0 || document.getElementById('inpIntOnlyTermMM').value > 0)
			{
				showDiv('tblReason');
				document.all("cboReasonForIntOnly").value = G_ReasonForInterestOnly;
				document.all("txtOthRsnforIntOnly").value = G_OtherReasonForInterestOnly;
			}
			else
			{
				var oDocEl=xml_master.XMLDocument.documentElement;
				var oPrdIntOnlyTerm = oDocEl.selectNodes("//Purposes/Purpose/Products/Product/LoanDetails/InterestOnlyTerm"); 				
				var iCntIntOnlyPrdExists = 0;

				for (var i=0; i<oPrdIntOnlyTerm.length; i++)
				{
					if (GetIntVal(oPrdIntOnlyTerm(i).text) == 0) 
					{
						iCntIntOnlyPrdExists++;
					}
				}	
				
				if (document.getElementById('inpIntOnlyTermYY').value == 0 && document.getElementById('inpIntOnlyTermMM').value == 0) iCntIntOnlyPrdExists++;
				
				if (oPrdIntOnlyTerm.length == iCntIntOnlyPrdExists) 
				{
					ds_prodLoan.XMLDocument.documentElement.selectSingleNode("ReasonForInterestOnly").text="";
					ds_prodLoan.XMLDocument.documentElement.selectSingleNode("OtherReasonForInterestOnly").text="";
				}
		
				hideDiv('tblReason');	
			}
		}
		ReasonForIntOnlyChange(SourceOfChange);
	}
	catch(e)
	{
		displayError(e, "IntOnlyTermChange");
	}
}

//==============================================================
//	Name:		ReasonForIntOnlyChange
//	Purpose:	Validation on load the product screen and on change of the Reason for Interest only dropdown box.
//  Parameters: SourceOfChange is either "OnLoad" / "OnChange"
//==============================================================
function ReasonForIntOnlyChange(SourceOfChange)
{
	try
	{
		if (SourceOfChange == 'OnLoad')
		{
			var oPurps = xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");
			var oPurpNode = oPurps.childNodes(G_selectedPurpRecNo-1);
			var oProdNode = oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']');
			
			if (oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']/LoanDetails/ReasonForInterestOnly') === null) return;
			var RsnForIntOnly = oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']/LoanDetails/ReasonForInterestOnly').text;
			var OtherRsnForIntOnly = oPurpNode.selectSingleNode('Products/Product[' + (G_selectedProdRecNo) + ']/LoanDetails/OtherReasonForInterestOnly').text;

			if (RsnForIntOnly != "")
			{				
				document.all("cboReasonForIntOnly").value = G_ReasonForInterestOnly;
			}
			
			if (OtherRsnForIntOnly != "")
			{
				document.all("txtOthRsnforIntOnly").value = G_OtherReasonForInterestOnly;
			}
			
			if (RsnForIntOnly == 'Other (please provide reason in description box)')
			{
				showDiv('tdOtherRsnLabel');		
				showDiv('tdOtherRsnText');
				hideDiv('tdEmptyFirst');
				hideDiv('tdEmptySecond');
				document.all("txtOthRsnforIntOnly").value = G_OtherReasonForInterestOnly;
			}
			else
			{
				hideDiv('tdOtherRsnLabel');		
				hideDiv('tdOtherRsnText');	
				showDiv('tdEmptyFirst');
				showDiv('tdEmptySecond');
			}
		}
		else
		{
			
			G_ReasonForInterestOnly = document.all("cboReasonForIntOnly").value;
			G_OtherReasonForInterestOnly = document.all("txtOthRsnforIntOnly").value;
			if(document.getElementById('cboReasonForIntOnly').value == 'Other (please provide reason in description box)')
			{
				showDiv('tdOtherRsnLabel');
				showDiv('tdOtherRsnText');
				hideDiv('tdEmptyFirst');
				hideDiv('tdEmptySecond');
			}
			else
			{
				hideDiv('tdOtherRsnLabel');
				hideDiv('tdOtherRsnText');
				showDiv('tdEmptyFirst');
				showDiv('tdEmptySecond');
				document.getElementById('txtOthRsnforIntOnly').value = "";
				G_OtherReasonForInterestOnly = "";
			}
			
		}
		var oDocEl=xml_master.XMLDocument.documentElement;
		var oProdLoanNode = oDocEl.selectNodes('//Purposes/Purpose/Products/Product/LoanDetails');
		if (oProdLoanNode.length > 0)
		{
			for(var i=0; i<oProdLoanNode.length; i++)
			{
				if (oProdLoanNode.item(i).childNodes.length >  0)
				{
					oProdLoanNode.item(i).selectSingleNode("ReasonForInterestOnly").text = G_ReasonForInterestOnly;
					oProdLoanNode.item(i).selectSingleNode("OtherReasonForInterestOnly").text = G_OtherReasonForInterestOnly;
				}
			}

		}
		oDocEl.setAttribute("ReasonForIntOnly", G_ReasonForInterestOnly);
		oDocEl.setAttribute("OtherReasonForIntOnly", G_OtherReasonForInterestOnly);
	}
	catch(e)
	{
		displayError(e, "ReasonForIntOnlyChange");
	}
}


function DDA_Product()
{
	try
	{
		hideDiv('tblReason');
		hideDiv('tdOtherRsnLabel');
		hideDiv('tdOtherRsnText');
		showDiv('tdEmptyFirst');
		showDiv('tdEmptySecond');
	}
	catch(e)
	{
		displayError(e, "DDA_Product");
	}
		
}

//REL 18.1 New Code Begin Tax Resident added on 01/02/2018 for tax resident crs changes
//==============================================================
//	Name:		Enable/Disabled Tax Residence Details tab
//	Purpose:	Disables/Enables Tax Residence Details tab
//	Parameters:	Blank / Non Blank
//==============================================================
function enable_taxresidenttab_loanpage()
{	
	try
	{
	
		var have_breakfree=G_havebreakfree;
		var breakfree_type=G_breakfree_Type;
		var producttype = document.getElementById("lbProductType").value;	
		G_Product_Type = producttype;	
		if (producttype == "RC" || (breakfree_type == "New Credit Card"))
		{			
			DisableElement(document.getElementById("inpAustralia_Y"), true);
			DisableElement(document.getElementById("inpAustralia_N"), true);
			G_Sub_Prd_Typ=2;
			
		}
		else
		{			
			var oCustDocEl = ds_cust.XMLDocument.documentElement;
			//oCustDocEl.selectSingleNode("TaxResidentAustralia").text = "";G_Tax = "";
			DisableElement(document.getElementById("inpAustralia_Y"), false);
			DisableElement(document.getElementById("inpAustralia_N"), false);	
			G_Sub_Prd_Typ=3;			
		}
	}
	catch(e)
	{
		displayError(e,"enable_taxresidenttab_loanpage");
	}
}
//REL 18.1 New Code Ended
