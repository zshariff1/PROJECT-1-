//<SCRIPT>
//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.3  $
//	$Author:   valana  $
//	$Workfile:   SPLiability.js  $
//	$Modtime:   Jan 04 2013 16:30:26  $	
//============================================================-->

//====================================================================
//	Function Name:	initLiabilityDtlsDlg
//	Parameters:		nil
//					But the record passed from the main screen as window.dialogArguments
//					when popup window opens.
//	Return:			nil
//	Description:	Initialise the Liablity pop-up window for Add/Edit.
//====================================================================
function initLiabilityDtlsDlg()
{
	try
	{
		G_bSaveIsAllowed = true;
		initRefData();
		initXMLObject(ds_spLiability);
		initXMLObject(xml_spDescLabels);
		initXMLObject(xml_ClickHelp)
		initXMLObject(xml_AppBRS);
		initXMLObject(ds_PopupAddresses);


		var oArrPassed = window.dialogArguments;

		var oAddresses = oArrPassed[1].selectSingleNode('Addresses');

        	ds_FullApp.XMLDocument.appendChild(oArrPassed[1]);

		//var oLiability = window.dialogArguments;
       		var oLiability = oArrPassed[0];

		document.all.divCaption.innerText = (oLiability.childNodes(0).text)? 'Edit Liability Details':'New Liability';
	
		ds_spLiability.src=ds_spLiability.src;
		ds_spLiability.XMLDocument.appendChild(oLiability);

		if (oAddresses == null) {

		}
		else {
		    ds_PopupAddresses.XMLDocument.replaceChild(oAddresses, ds_PopupAddresses.XMLDocument.documentElement);
		    PopulateLinkedPropertyAsset(ds_PopupAddresses)
		}

		//initRefData();
		populateList('A_TS_LIABILITY_TYPES', document.all.tblLiabilityDtls.all('cboLiabilityType'), null, 'TYPE_CODE', 'CODE_DESC');
		check_LiabilityType(ds_spLiability.recordset.fields('LiabilityType').value);				
		check_TermLoan(ds_spLiability.recordset.fields('TermLoan').value);
		check_LiabilityType_NominatedLoanAccount(ds_spLiability.recordset.fields('LiabilityType').value);

		InitilizeAppBRS(ds_spLiability.XMLDocument.documentElement);	


		// Added for Validation in Pop - Up of Liability
		if((oLiability.childNodes(0).text))
		{
			var oLiability = ds_spLiability.XMLDocument.documentElement;
			var bkfr_cardtype = oLiability.selectSingleNode('BreakFreeCardType').text;
			var bkfrCC_type = oLiability.selectSingleNode('BFANZCreditCard').text;
			if((bkfr_cardtype == "") && (bkfr_cardtype != "New Credit Card"))
			{
				if(bkfrCC_type != "1")
				{
					var bResult = EvaluateAppBRS(oLiability);
				}
			}
			
		}
		// Added for Validation in Pop - Up of Liability
		
	}
	catch (e)
	{
		displayError(e,'initLiabilityDtlsDlg');	
	}
}


//====================================================================
//	Function Name:	saveLiabilityDtls
//	Parameters:		bConfirmSave - flag shows that save is confirmed
//	Return:			Liability record back to main screen
//	Description:	When click on [save] in the popup window.
//====================================================================
function saveLiabilityDtls(bConfirmSave)
{
	try
	{
		var oLiability = ds_spLiability.XMLDocument.documentElement;
	    	var oObjArrParamRet = new Array();
		
		//copy type description
		oLiability.setAttribute('TypeDescription',getListText(document.all.cboLiabilityType));
		// Card - 394 :-
		oLiability.setAttribute('LiabBankFinInstitutionDescription',getListText(document.all.cboBnkLenderName));
		//format the amount
		var sAmount = document.all.tblLiabilityDtls.all('inpAmountOwing').value;
		oLiability.setAttribute('fmtAmount', VBFormatCurrency(sAmount,0));
		
		oLiability.setAttribute('LinkedPropertyAssetDescription',getListText(document.all.cboLinkedPropertyAsset));
		
	//WR1970 - To pass Yes/No for 'LiabilityToContinue' field to MOS depending on 'LiabToClrFrmLn' field value - Start
		if(oLiability.selectSingleNode("LiabToClrFrmLn").text == "0")
		{
			oLiability.selectSingleNode("LiabilityToContinue").text = "-1";
		}
		else if(oLiability.selectSingleNode("LiabToClrFrmLn").text == "-1")
		{
			oLiability.selectSingleNode("LiabilityToContinue").text = "0";
		}
	//WR1970 - To pass Yes/No for 'LiabilityToContinue' field to MOS depending on 'LiabToClrFrmLn' field value - End	

		//Card - 316 Starts
		
		if(oLiability.getElementsByTagName("Addresses").length > 0){
			var oRemmovAddrs  = oLiability.selectSingleNode("//Addresses");
			if(oRemmovAddrs!= null){
				oLiability.removeChild(oRemmovAddrs);
			}
		}
		
		if((oLiability.selectSingleNode('LiabilityType').text == "003")&&(oLiability.selectSingleNode('BFANZCreditCard').text == "1")) 
		{
			oLiability.selectSingleNode("LiabilityDescription").text = "134321411";
		 }
		var bResult = EvaluateAppBRS(oLiability);

		if((oLiability.selectSingleNode('LiabilityType').text == "003")&&(oLiability.selectSingleNode('BFANZCreditCard').text == "1")) 
		{
			oLiability.selectSingleNode("LiabilityDescription").text = "";
		}
		
		if (G_bSaveIsAllowed) 
		{
			if (bResult)	
			{
				//check Liabilty Rules, ie. ANZ Credit Card Number
				var bRulesOk = check_LiabilityRules(oLiability);
				if (bConfirmSave || bRulesOk)
				{
				    oObjArrParamRet[0] = ds_spLiability.XMLDocument.documentElement.cloneNode(true);
				    oObjArrParamRet[1] = ds_FullApp.XMLDocument.documentElement.cloneNode(true);

				    var OutputXML = new ActiveXObject('Microsoft.XMLDOM');
				    OutputXML.loadXML("<Output/>");
				    
                    		    //Add new/edited liability record
                   			OutputXML.documentElement.appendChild(ds_spLiability.XMLDocument.documentElement.cloneNode(true));

                    		    //Add new/edited address record
				    OutputXML.documentElement.appendChild(ds_PopupAddresses.XMLDocument.documentElement.cloneNode(true));
				    //OutputXML.documentElement.appendChild(ds_FullApp.XMLDocument.documentElement.selectSingleNode('Addresses'));

  				    // window.returnValue = oObjArrParamRet; //ds_spLiability.XMLDocument.documentElement.cloneNode(true);

				    //window.returnValue = oObjArrParamRet[0].xml; //ds_spLiability.XMLDocument.documentElement.cloneNode(true);

				    window.returnValue = OutputXML; //ds_spLiability.XMLDocument.documentElement.cloneNode(true);
					window.close();
				}
			}
			else
				VBMsgBox('Please enter valid liability details.',G_iVB_WARNING,G_sAPPLICATION_TITLE);
		}
		else
		{
			promptSaveProhibited('Liability');
			window.close();
		}
		
	}
	catch (e)
	{
		displayError(e,'saveLiabilityDtls');	
	}
}


//==============================================================
//	Function Name:	cancelSaveLiabilityDtls
//	Parameters:		none
//	Description:	cancel saving Liability, returns screen to edit 
//					Liability details
//==============================================================
function cancelSaveLiabilityDtls()
{
	try
	{
		tblLiabilityDtls.style.display="block";
		divWarning.style.display="none";
		if((ds_spLiability.XMLDocument.documentElement.selectSingleNode('BreakFreeCardType').text).indexOf("New Credit Card") == -1)
		{
			inpLiabilityDescription.focus();
		}
	}
	catch (e)
	{
		displayError(e,"cancelSaveLiabilityDtls");
	}
}

//==============================================================
//	Function Name:	check_LiabilityRules
//	Parameters:		oLiability - (XML Node) Liability Node
//	Return:			Boolean - true if the Liability details pass the rules
//	Description:	Validate: ANZ Credit Card Number.
//==============================================================
function check_LiabilityRules(oLiability)
{
	try
	{
		var sType = oLiability.selectSingleNode("LiabilityType").text;
		var sDesc = oLiability.selectSingleNode("LiabilityDescription").text;
		
		// Check if Liability Type is "ANZ Credit Card" 
		//		then check if the Decription is numeric field with lenght equal to 16 characters
		//		otherwise always true. 
		//  If the Breakfree credit Card type is new Card then bRule1 = true
		var bRule1 = true;
		if((sType == "003")&&((oLiability.selectSingleNode('BreakFreeCardType').text).indexOf("New Credit Card") == -1) && 
			(oLiability.selectSingleNode('BFANZCreditCard').text == "1")) 
		{
			bRule1 = true;
		}
		
		else if((sType == "003")&&((oLiability.selectSingleNode('BreakFreeCardType').text).indexOf("New Credit Card") == -1) && (oLiability.selectSingleNode('BFANZCreditCard').text == "0"))
		{
			bRule1 = VBIsNumeric(sDesc)&&(sDesc.length == 16)
		} 
		if (!bRule1)
		{	// If it doesn't pass the rule/s then show the warning.
			check_ANZCCNumber();
			document.all.tblLiabilityDtls.style.display="none";
			document.all.divWarning.style.display="block";
		}	
		return bRule1;
	}
	catch (e)
	{
		displayError(e,"check_LiabilityRules");
	}
}


//==============================================================================
//	Function Name:	check_LiabilityType
//	Parameters:		sType - Type code from the element on the screen
//	Return:			nil 
//	Description:	Get Liabilty Description depending on Asset Type
//==============================================================================
function check_LiabilityType(sType)
{
	try
	{
		xml_spDescLabels.src=xml_spDescLabels.src;
		var oLabels = xml_spDescLabels.XMLDocument.documentElement.selectNodes('//SPLabel');
		var oLiability = ds_spLiability.XMLDocument.documentElement;

		for (var i=oLabels.length-1; i>=0 ;i--)
		{
			if ( (oLabels(i).getAttribute('TYPE_CODE')!=sType) ||
				 (oLabels(i).getAttribute('Item')!='Liability') )
				oLabels(i).parentNode.removeChild(oLabels(i));
		}
		
		//Start : Card - 394
		if ((sType=='005') || (sType=='006') || (sType=='007'))
		{
			document.all.trBankFinInstution.style.display = "block";
			populateList("A_TS_BANK_FIN_INSTITUTION_LENDERNAME", document.all.cboBnkLenderName, null, 'TYPE_CODE', 'CODE_DESC', false);
		}
		else
		{
			document.all.trBankFinInstution.style.display = "none";
			ds_spLiability.XMLDocument.documentElement.selectSingleNode("LiabBankFinInstitution").text="";
		}
		/*Starts : Card - 542
		if(sType=='003')
			document.all.chkJointOwner.disabled = true;
		else 
			document.all.chkJointOwner.disabled = false;
		Ends : Card - 542*/
	}
	catch (e)
	{
		displayError(e,'check_LiabilityType');
	}	
}


//==============================================================
//	Function Name:	check_ANZCCNumber
//	Parameters:		-
//	Return:			-
//	Description:	Remove all none-number characters from the Liability Description (Account Number) field 
//==============================================================
function check_ANZCCNumber()
{
	try
	{
		if (document.all.tblLiabilityDtls.all("cboLiabilityType").value == "003")
			document.all.tblLiabilityDtls.all("inpLiabilityDescription").value = replaceAll(document.all.tblLiabilityDtls.all("inpLiabilityDescription").value,/\D/g,"");
	}
	catch (e)
	{
		displayError(e,"check_ANZCCNumber");
	}
}



//WR4354 - NCCP2 CR024 - Breakfree changes - start
//==============================================================
//	Function Name:	disableFields
//	Parameters:		-
//	Return:			-
//	Description:	Enable / Disable the field depending on Liability screen for Breakfree Credit Card
//					 
//==============================================================
function disableFields() 
{
	try
	{
		if(ds_spLiability.XMLDocument.documentElement.selectSingleNode('BFANZCreditCard').text == '1')
		{
			document.all.chkJointOwner.disabled = true;
			document.all.cboLiabilityType.disabled = true;
			document.all.chkLiabToClrFrmLn.disabled = true;
			document.all.inpLimit.disabled = true;
			document.all.inpMthlyExp.disabled = true;
			 if ((ds_spLiability.XMLDocument.documentElement.selectSingleNode('BreakFreeCardType').text).indexOf("New Credit Card") != -1)
			 {
				document.all.inpAmountOwing.disabled = true;
				document.all.labelBFCC.style.display = "block";
				document.all.labelBFCC.innerText='BREAKFREE PACKAGE CREDIT CARD';
				document.all.labelBFCC.disabled = true;
				document.all.inpLiabilityDescription.style.display = "none";
			 }
			 else if((ds_spLiability.XMLDocument.documentElement.selectSingleNode('BreakFreeCardType').text).indexOf("Existing Card - No") != "-1")
			 {
				document.all.inpLiabilityDescription.disabled = false;
				document.all.inpAmountOwing.disabled = true;
			 }
			 else if((ds_spLiability.XMLDocument.documentElement.selectSingleNode('BreakFreeCardType').text).indexOf("Existing Card - Change") != "-1")
			 {
				document.all.inpLiabilityDescription.disabled = false;
			 }
		}
		else
		{
			/*Starts : Card - 542
			var sType;
			if(ds_spLiability.XMLDocument.documentElement.selectSingleNode('LiabilityType') != null) {
				sType = ds_spLiability.XMLDocument.documentElement.selectSingleNode('LiabilityType').text;
			}
			if((ds_spLiability.XMLDocument.documentElement.selectSingleNode('BFANZCreditCard').text == '0') && (sType=='003')) {
				document.all.chkJointOwner.disabled = true;
			}
			else {
				document.all.chkJointOwner.disabled = false;
			}
			Ends : Card - 542*/
			document.all.chkJointOwner.disabled = false;
			document.all.cboLiabilityType.disabled = false;
			document.all.inpLiabilityDescription.disabled = false;
			document.all.chkLiabToClrFrmLn.disabled = false;
			document.all.inpLimit.disabled = false;
			document.all.inpAmountOwing.disabled = false;
			document.all.inpMthlyExp.disabled = false;
			document.all.labelBFCC.style.display='none';
		}
	}
	catch (e)
	{
		displayError(e,"disableFields");
	}
}
	

//WR4354 - NCCP2 CR024 - Breakfree changes - End
//Card - 316 Starts


function check_LiabilityType_NominatedLoanAccount(sType)
{
	try
	{
		if((sType == '001') || (sType == '005')){
			DisableRemainLoanTerms(true);
			document.all.spnPI.innerText = "P&I ";
		}
		else{
			DisableRemainLoanTerms(false);
			document.all.spnPI.innerText = "";
		}
		/*if(sType == '003')
		{
			document.all.chkJointOwner.disabled = true;
		}*/
	}
	catch (e)
	{
		displayError(e,'check_LiabilityType_NominatedLoanAccount');
	}	
}


function DisableRemainLoanTerms(rflag)
{
	try
	{
		if(rflag == true){
		    	PopulateLinkedPropertyAsset(ds_PopupAddresses);
			HideElement(document.all.chkTermLoan,rflag);
			HideElement(document.all.cboLinkedPropertyAsset,rflag);
			HideElement(document.all.cmdLiabAddAddr,rflag);
			document.getElementById('cmdLiabAddAddr').style.visibility = 'visible';
		}
		else
		{
			HideElement(document.all.chkTermLoan,rflag);ds_spLiability.XMLDocument.documentElement.selectSingleNode("TermLoan").text = 0;
			HideElement(document.all.inpRemainLoanTermMonths,rflag);document.all.inpRemainLoanTermMonths.value = 0;
			HideElement(document.all.cboLinkedPropertyAsset,rflag);document.getElementById("cboLinkedPropertyAsset").innerHTML = "";
			HideElement(document.all.cmdLiabAddAddr,rflag);
			document.getElementById('cmdLiabAddAddr').style.visibility = 'hidden';
			
		}
	}
	catch (e)
	{
		displayError(e,'DisableRemainLoanTerms');
	}
}

function check_TermLoan(rflag)
{
	try
	{
		if(rflag == true)
			HideElement(document.all.inpRemainLoanTermMonths,rflag);			
		else
			HideElement(document.all.inpRemainLoanTermMonths,rflag);document.all.inpRemainLoanTermMonths.value = 0;			
	}
	catch (e)
	{
		displayError(e,'check_TermLoan');
	}	
}


// Check for Populating Values in DropDown

//==============================================================
//	Function Name:	PopulateLinkedPropertyAsset
//	Parameters:		oAddressesNode - Node containing all the addresses.
//					
//	Return:			Nil
//	Description:	Populate the combo box "cboLinkedPropertyAsset" with addresses.
//==============================================================
function PopulateLinkedPropertyAsset(oAddressesNode)
{
	try
	{

	    var oDOMEl = oAddressesNode.XMLDocument.documentElement;
	    if (oAddressesNode != null)
		{
		    var oAddrList = oDOMEl.selectNodes('Address');
			if(oAddrList.length > 0 )
			{

			    document.getElementById("cboLinkedPropertyAsset").innerHTML = "";

			    var sAddrIDBlank = 0;
			    var sAddDetBlank = "";
			    var addroptBlank = document.createElement("OPTION");
			    document.getElementById("cboLinkedPropertyAsset").options.add(addroptBlank);
			    addroptBlank.value = sAddrIDBlank;
			    addroptBlank.innerText = sAddDetBlank;

				for (var i=0; i<oAddrList.length; i++)
				{
					var sAddrID = oAddrList(i).selectSingleNode('AddressID').text;
					var sAddDet = oAddrList(i).getAttribute('AddressDetails');
					var addropt = document.createElement("OPTION");
					document.getElementById("cboLinkedPropertyAsset").options.add(addropt);
					addropt.value = sAddrID;
					addropt.innerText = sAddDet;
					if(ds_spLiability.XMLDocument.documentElement.selectSingleNode('LinkedPropertyAsset').text==sAddrID)
					{
						addropt.selected = true;
					}
					else
					{
						document.getElementById("cboLinkedPropertyAsset").options[0].selected = true;
					}
				}
			}
		}
	}
	catch (e)
	{
		displayError(e,'PopulateLinkedPropertyAsset');
	}
}

//==============================================================
//	Name:		GetLinkedPropertyAsset
//	Purpose:	Gets LinkedPropertyAssetDescription from the drop down box.
//	Parameters:	Drop-Down Value - related to  cboLinkedPropertyAsset
//==============================================================
function GetLinkedPropertyAsset(LnkPropAsset)
{
	try
	{
		var oLnkPropAddr = ds_spLiability.XMLDocument.documentElement;
		oLnkPropAddr.setAttribute("LinkedPropertyAssetDescription",getListText(window.event.srcElement));
	}
	catch(e)
	{
		displayError(e,"GetLinkedPropertyAsset");
	}	
}


//==============================================================
//	Function Name:	HideElement
//	Parameters:		el - HTML Element
//					bEnable	- (Boolean) Enable/ Disable flag
//	Return:			Nil
//	Description:	Disables or enables a given HTML element such as a text box
//==============================================================
function HideElement(el, bEnable)
{
	try
	{
		if (!el) return;
		if (el.disabled==(!bEnable)) return;
	
		if (!el.oldClass) el.oldClass = el.className;
	
		var oParentTR = findParent(el, "tr");
		el.className=(bEnable)? el.oldClass:el.oldClass+oParentTR.className;
		el.disabled=(!bEnable);
	}
	catch (e) 
	{ 
		displayError(e,"HideElement");
	}
	
}


//==============================================================
//	Function Name:	AddNewAddress
//	Parameters:		
//					
//	Return:			Nil
//	Description:	Adds a new address to the master XML.
//==============================================================
function AddNewAddress() {
    try {

        var oEdtAdr;

        oEdtAdr = window.showModalDialog("PopupAddressDtls.htm", oEdtAdr, "dialogHeight:320px;dialogWidth:650px;help:No;resizable:No;status:No;scroll:No;");
        if (oEdtAdr == null) return null;

        //WR1970 - New Fuction call added.
      /*  var NewAddressID = ds_FullApp.XMLDocument.documentElement.getAttribute("maxAddressID");
        //var AddressesNode = ds_FullApp.XMLDocument.documentElement.getElementsByTagName("Application");

        oEdtAdr.firstChild.text = parseInt(NewAddressID) + 1;*/
	
	 var NewAddressID = ds_FullApp.XMLDocument.documentElement.getAttribute("maxAddressID");
        var oAdd_Stub = ds_PopupAddresses.XMLDocument.documentElement;
		var objAdrId = oAdd_Stub.getElementsByTagName("AddressID");
		
		// For Incrementing the Address Id in Addresses Node XML - Starts
		var Ref_AdrId = parseInt(NewAddressID) + 1;
		if(objAdrId != null) 
		{
			if(objAdrId.length > 0)
			{
				for(var iAd=0;iAd<objAdrId.length;iAd++)
				{
					if(objAdrId(iAd).text == Ref_AdrId)
					{
						Ref_AdrId = Ref_AdrId + 1;
					}
				}
			}
		}
		oEdtAdr.firstChild.text = Ref_AdrId;
		// For Incrementing the Address Id in Addresses Node XML - Ends


        ds_PopupAddresses.XMLDocument.documentElement.appendChild(oEdtAdr);
        PopulateLinkedPropertyAsset(ds_PopupAddresses);
        
    }
    catch (e) {
        displayError(e, "AddNewAddress");
    }

}

//Prod Defet 
function AccountNumberMax()
{
		if (document.all.tblLiabilityDtls.all("cboLiabilityType").value == "003")
		{
			var input = document.getElementById ("inpLiabilityDescription");
            input.maxLength = 9;
		}
		else
		{
			document.getElementById("inpAssetDescription").maxLength = 40;
		}
	
}
