//<script>
//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.1  $
//	$Author:   neelgarm  $
//	$Workfile:   interview.js  $
//	$Modtime:   Jan 08 2009 21:24:38  $	
//============================================================-->

//===========================
// Declare global variables
//===========================
var G_bInterviewDirty = false;
var G_multiCust = false;

//==========================================================================
//	Function Name:	InterviewScreenShow
//	Parameters:		nil
//	Return:			nil
//	Descripion:		Initialise the Interview Screen. 
//					For new application - Do nothing.
//					For existing application: 
//					- Populate all other customers that are not recorded in 
//						<IDN> from <Customers> using xslt.   
//					- Replace the stub xml from the result of xslt.
//==========================================================================
function InterviewScreenShow()
{
	try
	{
		G_pScreenSaveFunction = saveInterview;

		ds_interview.src = ds_interview.src;
		var oInt = ds_interview.XMLDocument.documentElement;
		var oLoadIDN = xml_master.XMLDocument.documentElement.selectSingleNode('IDN').cloneNode(true);
		
		//Populate new <InterviewCustomers> using XSLT from master xml to stub xml
		xml_master.XMLDocument.documentElement.transformNodeToObject(xsl_InterviewCustRefresh, xml_temp.XMLDocument);
		var oCustList=xml_temp.XMLDocument.documentElement.cloneNode(true);
		
		//Load existing IDN from master to stub and add new customer list
		if (oLoadIDN.hasChildNodes)
		{
			oLoadIDN.replaceChild(oCustList,oLoadIDN.selectSingleNode('InterviewCustomers'));
			ds_interview.XMLDocument.replaceChild(oLoadIDN,oInt);		
		}
		else
		{
			oInt.replaceChild(oCustList,oInt.selectSingleNode('InterviewCustomers'));
			InitilizeAppBRS(ds_interview.XMLDocument.documentElement);
		}

		// Populate CustomerIDs and Names from xml master to the <CustomerSiginedID> field
		populateSignCustCombo();			
		G_multiCust = multiCustomers();	
		
		// Enable or disable fields
		check_InterpreterRecommended();
		check_BenefitEnquiries();
		check_AdvisedLawyerFinancialCounsellor();
		check_ClearlyUnderstandRisk();
		
		var sCustSgn=ds_interview.XMLDocument.documentElement.selectSingleNode("CustomerSignedID").text;
		SetFocusOnElement((sCustSgn=="")? "cboCustomerSigned":"inpLocationOfInterview");
		//WR1970 - To make the error cross appear when the mandatory fields are not entered.
		//G_bInterviewDirty=false;
		SetInterviewDirty();
		//
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '0' )
		{
			var row = document.getElementById("PortfolioBooklet");
			row.style.display = 'none';
		}
		else
		{
			var row = document.getElementById("PortfolioBooklet");
			row.style.display = '';
		}
	}
	catch (e)
	{
		displayError(e,'InterviewScreenShow');	
	}
}

//Release 19.5 + 19.7
function multiCustomers()
{
	try
	{
		var val_retu_multi = true;
		
		var oAppDocEl = xml_master.XMLDocument.documentElement; 
		var oCOFList = oAppDocEl.selectNodes("//Customers/Customer[CustomerType = 'COF']"); 
		var oSOLList = oAppDocEl.selectNodes("//Customers/Customer[CustomerType = 'SOL']"); 
		var oCOOList = oAppDocEl.selectNodes("//Customers/Customer[CustomerType = 'COO']"); 
		var oInt = oAppDocEl.selectSingleNode("IDN");
		if((oSOLList.length <= 0) && ((oCOFList.length > 0) && (oCOOList.length > 0))) 
		{
				if((oInt.selectSingleNode("ClearlyBenefit") != null))
				{
					if((oInt.selectSingleNode("ClearlyBenefit").text == -1))
					{
						// Enable
						if (document.getElementById("divCOOBenefits")!=undefined)
						document.getElementById("divCOOBenefits").style.display = "block";	
						val_retu_multi =  true;
					}
					else		
					{
						//Disable
						if (document.getElementById("divCOOBenefits")!=undefined)
							document.getElementById("divCOOBenefits").style.display = "none";
						
						ds_interview.recordset.fields('ClearlyUnderstandRisk').value='';		
						ds_interview.recordset.fields('CoBorrowerReason').value='';		
						ds_interview.recordset.fields('InConnection').value='';	
						val_retu_multi =  false;
					}
				}
		}
		else
		{
			//Disable
			if (document.getElementById("divCOOBenefits")!=undefined)
				document.getElementById("divCOOBenefits").style.display = "none";
			
			ds_interview.recordset.fields('ClearlyUnderstandRisk').value='';		
			ds_interview.recordset.fields('CoBorrowerReason').value='';	
			ds_interview.recordset.fields('InConnection').value='';	
			
			val_retu_multi = false;
		}
		
		return val_retu_multi;
	}
	catch (e)
	{
		displayError(e,'multiCustomers');
	}
}

//Release 19.7
function displayCoborrowers()
{
	try
	{
		
		var oAppDocEl = xml_master.XMLDocument.documentElement; 
		var oCOFList = oAppDocEl.selectNodes("//Customers/Customer[CustomerType = 'COF']"); 
		var oSOLList = oAppDocEl.selectNodes("//Customers/Customer[CustomerType = 'SOL']"); 
		var oCOOList = oAppDocEl.selectNodes("//Customers/Customer[CustomerType = 'COO']"); 
		
		if((oSOLList.length <= 0) && ((oCOFList.length > 0) && (oCOOList.length > 0)))
		{
				if(document.getElementById('inpClearlyBenefit_Y').checked == true)
				{
						//Enable
						if (document.getElementById("divCOOBenefits")!=undefined)
							document.getElementById("divCOOBenefits").style.display = "block";	
							return true;			
				}
				else if(document.getElementById('inpClearlyBenefit_N').checked == true)
				{
						//Disable
						if (document.getElementById("divCOOBenefits")!=undefined)
							document.getElementById("divCOOBenefits").style.display = "none";
							return false
				}
		}
		else
		{
			//Disable
			if (document.getElementById("divCOOBenefits")!=undefined)
				document.getElementById("divCOOBenefits").style.display = "none";
			
			ds_interview.recordset.fields('ClearlyUnderstandRisk').value='';		
			ds_interview.recordset.fields('CoBorrowerReason').value='';	
			ds_interview.recordset.fields('InConnection').value='';				
			return false;
		}
			
	}
	catch (e)
	{
		displayError(e,'displayCoborrowers');
	}
}

//=======================================================================
//	Function Name:	populateSignCustCombo
//	Parameters:		nil
//	Return:			nil
//	Description:	Populate the Customer Signed Combobox.
//======================================================================= 
function populateSignCustCombo()
{
	try
	{
		var df=cboCustomerSigned.dataFld;
		var ds=cboCustomerSigned.dataSrc;
		cboCustomerSigned.dataFld="";
		cboCustomerSigned.dataSrc="";
	
		// clear list
		for (i = cboCustomerSigned.options.length-1; i>=0; i--)
			cboCustomerSigned.options.remove(i);
	
		var emptopt = document.createElement("OPTION");
		cboCustomerSigned.options.add (emptopt);
		emptopt.value = "";
		emptopt.innerText = "";
	
		var oCusts=xml_master.XMLDocument.documentElement.selectNodes("//Customers/Customer")	
		for (var i=0; i < oCusts.length; i++)
		{
			var sID = oCusts(i).selectSingleNode("CustomerID").text;
			var sName = oCusts(i).selectSingleNode("CustomerName").text;
			var opt = document.createElement("OPTION");
			cboCustomerSigned.options.add (opt);
			opt.value = sID;
			opt.innerText = sName;
		}
	
		cboCustomerSigned.dataSrc=ds;
		cboCustomerSigned.dataFld=df;
	}
	catch (e)
	{
		displayError(e,'populateSignCustCombo');
	}
}


//=======================================================================
//	Function Name:	check_InterpreterRecommended
//	Parameters:		nil
//	Return:			nil
//	Description:	Enable/Disable field InterpreterRecommended.
//======================================================================= 
function check_InterpreterRecommended()
{
	try
	{
		var bDisabled=!(ds_interview.recordset.fields('ClearlyUnderstandEnglish')=="0");
		document.all.inpInterpreterRecommended_Y.disabled=bDisabled;
		document.all.inpInterpreterRecommended_N.disabled=bDisabled;
		if (bDisabled) ds_interview.recordset.fields('InterpreterRecommended').value='';
		document.all.capInterpreterRecommended.style.color = (bDisabled)? "#FFFFFF":""; 
	}
	catch (e)
	{
		displayError(e,'check_InterpreterRecommended');
	}
}


//=======================================================================
//	Function Name:	check_BenefitEnquiries
//	Parameters:		nil
//	Return:			nil
//	Description:	Enable/Disable field BenefitEnquiries
//======================================================================= 
 function check_BenefitEnquiries()
{
	try
	{		
		//ds_interview.recordset.fields('BenefitEnquiries').value='';			
		
		var bEnable = (ds_interview.recordset.fields('ClearlyBenefit')=="-1")
		DisableElement(document.all.txtBenefitEnquiries, bEnable)
		
		if (!bEnable) ds_interview.recordset.fields('BenefitEnquiries').value='';		
		document.all.capBenefitEnquiries.style.color= (bEnable)? "":"#FFFFFF"; 		
		
	}
	catch (e)
	{
		displayError(e,'check_BenefitEnquiries');
	}			
} 

function check_ClearlyUnderstandRisk()
{
	try
	{
		var bEnable = (ds_interview.recordset.fields('ClearlyUnderstandRisk')=="-1")
		DisableElement(document.all.txtCoBorrowerReason, bEnable)

		if (!bEnable) ds_interview.recordset.fields('CoBorrowerReason').value='';		
		document.all.CapCoBorrowerReason.style.color= (bEnable)? "":"#FFFFFF"; 		
	}
	catch (e)
	{
		displayError(e,'check_ClearlyUnderstandRisk');
	}			
}

//=======================================================================
//	Function Name:	check_AdvisedLawyerFinancialCounsellor
//	Parameters:		nil
//	Return:			nil
//	Description:	Enable/Disable field AdvisedLawyerFinancialCounsellor
//======================================================================= 
function check_AdvisedLawyerFinancialCounsellor()
{
	try
	{
		var bDisabled = !(ds_interview.recordset.fields('DuressOrDisability').value==-1 || 
							ds_interview.recordset.fields('UnsureAboutLoan').value==-1 || 
							ds_interview.recordset.fields('UnableToComprehend').value==-1 || 
							ds_interview.recordset.fields('AnyGuarantors').value==-1)
		document.all.inpAdvisedLawyerFinancialCounsellor_Y.disabled=bDisabled;
		document.all.inpAdvisedLawyerFinancialCounsellor_N.disabled=bDisabled;
		if (bDisabled) ds_interview.recordset.fields('AdvisedLawyerFinancialCounsellor').value='';
		document.all.capAdvisedLawyer.style.color = (bDisabled)? "#FFFFFF":""; 
	}
	catch (e)
	{
		displayError(e,'check_AdvisedLawyerFinancialCounsellor');
	}
}


//=======================================================================
//	Function Name:	saveInterview
//	Parameters:		bNoReselect - whether to perform the initialising functionality 
//	Return:			nil
//	Description:	Save Interview to the disk.
//======================================================================= 
function saveInterview(bNoReselect)
{
	try
	{
		if (!G_bInterviewDirty) return;
		var oNewIDN = ds_interview.XMLDocument.documentElement.cloneNode(true);
		var oSaveIDN = xml_master.XMLDocument.documentElement;
		var oReplIDN = oSaveIDN.selectSingleNode('IDN');

		// Move IDN details from stub xml to master xml
		oSaveIDN.replaceChild(oNewIDN,oReplIDN);
		
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("IDN"));
		EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);
		FlushToDisk();
		G_bInterviewDirty=false;
		if (!bNoReselect) InterviewScreenShow();
	}
	catch (e)
	{
		displayError(e,'saveInterview');	
	}
}


//=======================================================================
//	Function Name:	SetInterviewDirty
//	Parameters:		nil
//	Return:			nil
//	Description:	Set screen dirty.
//======================================================================= 
function SetInterviewDirty()
{
	G_bInterviewDirty=true;
}


//=======================================================================
//	Function Name:	ValDateOfInterview
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field DateOfOnterview.
//======================================================================= 
function ValDateOfInterview(oIDN)
{
	try
	{
		var oFld = oIDN.selectSingleNode("DateOfInterview");
		return (oFld && oFld.text!="")?  VBIsDate(oFld.text):true;
	}
	catch (e)
	{
		displayError(e,'ValDateOfInterview');
	}
}


//=======================================================================
//	Function Name:	ValInterviewCustomers
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field InterviewCustomers.
//======================================================================= 
function ValInterviewCustomers(oIDN)
{
	try
	{
		if (!oIDN) return false;
		return (oIDN.selectSingleNode("InterviewCustomers/Customer[PresentAtInterview=-1]"))? true:false;
	}
	catch (e)
	{
		displayError(e,'ValInterviewCustomers');
	}
}


//=======================================================================
//	Function Name:	ValIDNInterpreter
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field InterpreterRecommended.
//======================================================================= 
function ValIDNInterpreter(oIDN)
{
	try
	{
		var oFld = oIDN.selectSingleNode("ClearlyUnderstandEnglish");
		return (oFld && oFld.text=="0")? 
					CheckMandatoryFld(oIDN.selectSingleNode("InterpreterRecommended")):true;
	}
	catch (e)
	{
		displayError(e,'ValIDNInterpreter');
	}
}


//=======================================================================
//	Function Name:	ValIDNBenefitEnquiries
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field BenefitEnquiries.
//======================================================================= 
/*function ValIDNBenefitEnquiries(oIDN)
{
	try
	{
		var oFld = oIDN.selectSingleNode("ClearlyBenefit");
		return (oFld && oFld.text=="0")? 
						CheckMandatoryFld(oIDN.selectSingleNode("BenefitEnquiries")):true;
	}
	catch (e)
	{
		displayError(e,'ValIDNBenefitEnquiries');
	}
}*/

//=======================================================================
//	Function Name:	ValIDNBenefitEnquiries Rel 19.5
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field BenefitEnquiriesY.
//=======================================================================
/*function ValIDNBenefitEnquiriesY(oIDN)
{
	try
	{
		var oFld = oIDN.selectSingleNode("ClearlyBenefit");
		return (oFld && oFld.text=="-1")? 
						CheckMandatoryFld(oIDN.selectSingleNode("BenefitEnquiriesY")):true;
	}
	catch (e)
	{
		displayError(e,'ValIDNBenefitEnquiriesY');
	}
}*/


//=======================================================================
//	Function Name:	ValIDNCoBorrowerReason Rel 19.5
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field CoBorrowerReason.
//=======================================================================
function ValIDNCoBorrowerReason(oIDN)
{
	try
	{
		var oFld = oIDN.selectSingleNode("ClearlyUnderstandRisk");
		return (oFld && oFld.text=="-1")? 
						CheckMandatoryFld(oIDN.selectSingleNode("CoBorrowerReason")):true;
	}
	catch (e)
	{
		displayError(e,'ValIDNCoBorrowerReason');
	}
}

function ValIDNBenefitEnquiries(oIDN)
{
	try
	{
		var oFld = oIDN.selectSingleNode("ClearlyBenefit");
		return (oFld && oFld.text=="-1")? 
						CheckMandatoryFld(oIDN.selectSingleNode("BenefitEnquiries")):true;
	}
	catch (e)
	{
		displayError(e,'ValIDNBenefitEnquiries');
	}
}

//=======================================================================
//	Function Name:	ValIDNInConnection Rel 19.5 - 19.7	
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field InConnection.
//=======================================================================
function ValIDNInConnection(oIDN)
{
	try
	{
			G_multiCust = multiCustomers();	
			if (!oIDN) return false;		
			if((oIDN.selectSingleNode("InConnection") != null))
			{
				if(G_multiCust)
				{
					if((oIDN.selectSingleNode("ClearlyBenefit").text == "-1"))
					{
						if((oIDN.selectSingleNode("InConnection").text == "-1"))
							return true;
						else
							return false;
					}
					else
					{
						return true;
					}
				}
				else
				{
					return true;
					
				}
				
			}
	}
	catch (e)
	{
		displayError(e,'ValIDNInConnection');
	}
}

//=======================================================================
//	Function Name:	ValIDNInConnectionUI - 19.7 
//	Parameters:		Nil
//	Return:			Validation boolean
//	Description:	Validate field InConnection.
//=======================================================================
function ValIDNInConnectionUI()
{
	try
	{
		if(document.getElementById('InConnection_Y').checked == true)
		{
			ds_interview.recordset.fields('InConnection').value = '-1';			
		}
		else
		{
			ds_interview.recordset.fields('InConnection').value = '0';
		}
	}
	catch (e)
	{
		displayError(e,'ValIDNInConnectionUI');
	}
}

//=======================================================================
//	Function Name:	ValIDNUnreasonable Rel 19.5  - 19.7 - commented completed function
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field Unreasonable.
//=======================================================================
/*function ValIDNUnreasonable(oIDN)
{
	try
	{
		if (!oIDN) return false;
		if((oIDN.selectSingleNode("Unreasonable") != null))
		{
			if(G_multiCust)
			{
				if((oIDN.selectSingleNode("Unreasonable").text == "-1"))
					return true;
				else
					return false;
			}
			else
			{
				//oIDN.selectSingleNode("Unreasonable").text = "";
				return true;
			}
		}	
	}
	catch (e)
	{
		displayError(e,'ValIDNUnreasonable');
	}
}*/


//=======================================================================
//	Function Name:	ValIDNUnreasonableUI - 19.7 - commented complete function
//	Parameters:		Nil
//	Return:			Validation boolean
//	Description:	Validate field Unreasonable.
//=======================================================================
/*function ValIDNUnreasonableUI()
{
	try
	{
		if(document.getElementById('Unreasonable_Y').checked == true)
		{
			ds_interview.recordset.fields('Unreasonable').value = '-1';			
		}
		else
		{
			ds_interview.recordset.fields('Unreasonable').value = '0';
		}
	}
	catch (e)
	{
		displayError(e,'ValIDNUnreasonableUI');
	}
}*/

//=======================================================================
//	Function Name:	ValIDNObligations - commented for 19.7 - complete function
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field Obligations.
//=======================================================================
/*function ValIDNObligations(oIDN)
{
	try
	{
		if (!oIDN) return false;
		if((oIDN.selectSingleNode("Obligations") != null))
		{
			if(G_multiCust)
			{
				if((oIDN.selectSingleNode("Obligations").text == "-1"))
					return true;
				else
					return false;
			}
			else
			{
				//oIDN.selectSingleNode("Obligations").text = "";
				return true;
			}
		}	
	}
	catch (e)
	{
		displayError(e,'ValIDNObligations');
	}
}*/


//=======================================================================
//	Function Name:	ValIDNObligationsUI - 19.7 - commented the complete function
//	Parameters:		Nil
//	Return:			Validation boolean
//	Description:	Validate field Obligations.
//=======================================================================
/*function ValIDNObligationsUI()
{
	try
	{
		if(document.getElementById('Obligations_Y').checked == true)
		{
			ds_interview.recordset.fields('Obligations').value = '-1';			
		}
		else
		{
			ds_interview.recordset.fields('Obligations').value = '0';
		}
	}
	catch (e)
	{
		displayError(e,'ValIDNObligationsUI');
	}
}*/


//=======================================================================
//	Function Name:	ValIDNFinancialAbuse Rel 19.5 - 19.7 - commented complete function
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field FinancialAbuse.
//=======================================================================
/*function ValIDNFinancialAbuse(oIDN)
{
	try
	{
		if (!oIDN) return false;
		if((oIDN.selectSingleNode("FinancialAbuse") != null))
		{
			
			if(G_multiCust)
			{
				if((oIDN.selectSingleNode("FinancialAbuse").text == "-1"))
					return true;
				else
					return false;
			}
			else
			{
				//oIDN.selectSingleNode("FinancialAbuse").text = "";
				return true;
			}
		}	
	}
	catch (e)
	{
		displayError(e,'ValIDNFinancialAbuse');
	}
}*/

//=======================================================================
//	Function Name:	ValIDNFinancialAbuseUI - 19.7 - commented complete function
//	Parameters:		Nil
//	Return:			Validation boolean
//	Description:	Validate field FinancialAbuse.
//=======================================================================
/*function ValIDNFinancialAbuseUI()
{
	try
	{
		if(document.getElementById('FinancialAbuse_Y').checked == true)
		{
			ds_interview.recordset.fields('FinancialAbuse').value = '-1';			
		}
		else
		{
			ds_interview.recordset.fields('FinancialAbuse').value = '0';
		}
	}
	catch (e)
	{
		displayError(e,'ValIDNFinancialAbuseUI');
	}
}*/

function ValIDNClearlyBenefit(oIDN)
{
	try
	{
		if (!oIDN) return false;
		if((oIDN.selectSingleNode("ClearlyBenefit") != null))
		{
			if((oIDN.selectSingleNode("ClearlyBenefit").text == "-1"))
				return true;
			else
				return false;
		}	
	}
	catch (e)
	{
		displayError(e,'ValIDNClearlyBenefit');
	}
}

function ValIDNClearlyUnderstandRisk(oIDN)
{
	try
	{
		G_multiCust = multiCustomers();
		if (!oIDN) return false;
		if((oIDN.selectSingleNode("ClearlyUnderstandRisk") != null))
		{
			if(G_multiCust)
			{
				if((oIDN.selectSingleNode("ClearlyBenefit").text == "-1"))
				{
					if((oIDN.selectSingleNode("ClearlyUnderstandRisk").text == "-1"))
						return true;
					else
						return false;
				}
				else
				{
					return true;
				}
					
			}
			else
			{
				return true;
			}
			
		}	
	}
	catch (e)
	{
		displayError(e,'ValIDNClearlyUnderstandRisk');
	}
}

//=======================================================================
//	Function Name:	ValIDNAdvisedLawer
//	Parameters:		oIDN - <IDN> node
//	Return:			Validation boolean
//	Description:	Validate field AdvisedLawyerFinancialCounsellor.
//======================================================================= 
function ValIDNAdvisedLawer(oIDN)
{
	try
	{
		if (!oIDN.hasChildNodes) return false;
		var bReq =  (oIDN.selectSingleNode("DuressOrDisability").text==-1)||
					(oIDN.selectSingleNode("UnsureAboutLoan").text==-1)||
					(oIDN.selectSingleNode("UnableToComprehend").text==-1)||
					(oIDN.selectSingleNode("AnyGuarantors").text==-1)
			
		return (bReq)?  CheckMandatoryFld(oIDN.selectSingleNode("AdvisedLawyerFinancialCounsellor")):true;
	}
	catch (e)
	{
		displayError(e,'ValIDNAdvisedLawer');
	}
}
