//<SCRIPT>
//==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Tim Heide
//	Workfile:  
//	ModTtime: 2003/03/04
//	Francis   10-08-2011 for WR 4306 - Added Registration field related codes
//  File: Security.js	
//============================================================

//Security Screen JavaScripts
//Globals
var G_SecurityNotLoaded = true;
var G_bSecurityDirty = false;
var G_iCurSecTabIdx = 0;
var aSecTabImgs = Array ("security_offered", "security_address", "security_details", "construction_details");
var G_SelectedSecurity = 0;
var bExstLoanAmt = false;
var G_bSecAddress = false;
//==============================================================
//	Function Name:	SwitchSecurityTab
//	Parameters:		iTabIdx - (numeric) index of tab to switch too
//					sFocusControl - (string) name of control to set focus on
//	Return:			Nil	
//	Description:	Handles the switching of security tabs
//==============================================================
function SwitchSecurityTab(iTabIdx, sFocusControl)
{	
	try 
	{
		var oTabs = document.all.ScrSecDetails.all.SecurityDetailsTab;		// product tabs
	
		var currimg=document.all.ScrSecDetails.all.imgSecurityDtlsTab(iTabIdx).src;
		if (currimg.indexOf("_faded.gif")>=0) return;
		
	//	WR1970
	//	*******************************************************************************
	//	Disabling the Address and Construction Details tabCalling the function 
	//	HideControls(sSecTypeCode) which will hide the controls and setting the focus 
	//	depending on the SecurityType value selected
	
		var sSecTypeCode = ds_security.XMLDocument.documentElement.selectSingleNode("SecurityType").text;
		var sSecStatus = ds_security.XMLDocument.documentElement.selectSingleNode("SecurityStatus").text;
		
		if(iTabIdx == 2)
		{	
			if(sSecTypeCode == "A")
				sFocusControl = "inpSecFMValue";
			else if(sSecTypeCode == "D")
				//WR1970_CMR003 Setting the focus to control
				//WR1970_Defect 125 - Commented the if condition - Start
				//if(sSecStatus == "H")
				//	sFocusControl = "inpSecExistLoanAmt";
				//else
					sFocusControl = "inpSecGuarAmt";
				//WR1970_Defect 125 - Commented the if condition - End
			else
				//WR1970_CMR004
				PropStatusPopulate();
				
		}
		
		if (G_iCurSecTabIdx != null) 	
		{
			oTabs(G_iCurSecTabIdx).style.display = "none";
			document.all.ScrSecDetails.all.imgSecurityDtlsTab(G_iCurSecTabIdx).src = "../images/tabs/" + aSecTabImgs[G_iCurSecTabIdx] + ".gif";
		}
			
		oTabs(iTabIdx).style.display = "block";
		document.all.ScrSecDetails.all.imgSecurityDtlsTab(iTabIdx).src = "../images/tabs/" + aSecTabImgs[iTabIdx] + "_dn.gif";
		G_iCurSecTabIdx = iTabIdx;
		window.scrollTo(0,0);  
		if (sFocusControl && document.all(sFocusControl) && !document.all(sFocusControl).disabled) document.all(sFocusControl).focus();
	}
	catch (e)
	{
		displayError (e,"SwitchSecurityTab");
	}
}

//==============================================================
//	Function Name:	disableUnapplicableAddresses
//	Parameters:		tblSecAddr - (pointer) security address table
//	Return:			Nil
//	Description:	Disable unapplicable addresses checkbox in the security addresses tab
//==============================================================
function disableUnapplicableAddresses(tblSecAddr)
{
	try
	{
		if (tblSecAddr.readyState!="complete") return;
		var oSecAddrs=ds_security.XMLDocument.documentElement.selectSingleNode("SecurityAddresses");
		var oSecAddrLst = oSecAddrs.selectNodes("SecurityAddress");
		var iAtt;

		for (var i=0;i<oSecAddrLst.length;i++)
		{
			iAtt = (oSecAddrLst(i).getAttribute("Applicable")!="0");
			(oSecAddrLst.length > 1)? DisableElement(tblSecAddr.all.chkSecAddrApplicable(i), iAtt):DisableElement(tblSecAddr.all.chkSecAddrApplicable, iAtt);
		}
	}
	catch (e)
	{
		 //ignore error: it's happen bcause of fast selections  
	}
}

//==============================================================
//	Function Name:	SecAddrClick
//	Parameters:		recNo - (numeric) Record number of selected address
//	Return:			Nil	
//	Description:	Handle clicking of a security address so you can only link one at a time
//==============================================================
function SecAddrClick(recNo)
{
	try 
	{
		var oSec = ds_security.XMLDocument.documentElement;
		var oSecAddrs=oSec.selectSingleNode("SecurityAddresses");
		var sAddrID="";
	
	//check the status of the check box
		var bChecked = (document.all.chkSecAddrApplicable.length > 0)? document.all.chkSecAddrApplicable(recNo-1).status:document.all.chkSecAddrApplicable.status;
		if (bChecked)
		{
			//get the selected address id
			sAddrID = oSecAddrs.childNodes(recNo-1).selectSingleNode("AddressID").text;
			
			//remove any existing links
			var oOldLink = oSecAddrs.selectSingleNode("SecurityAddress[AddressID!='" + sAddrID + "' and @Linked='-1']");
			if (oOldLink) oOldLink.setAttribute("Linked",0);
		}
		
		//set the address ID in the security dso
		oSec.selectSingleNode("AddressID").text = sAddrID;
	}
	catch (e)
	{
		displayError(e,"SecAddrClick");
	}
}

//==============================================================
//	Function Name:	SaveSecurity
//	Parameters:		NoReselect - (boolean) Flag stating if the node should be reselected after save
//	Return:			Nil
//	Description:	Saves the current security to the master DSO
//==============================================================
function SaveSecurity(NoReselect)
{
	try
	{
	//If nothing has been changed return without saving
		if (!G_bSecurityDirty) return;
		
	//WR1970 - New validation and popup message if the Existing Loan Amount field is changed to a value other than zero
		var bContinue;
		bContinue=CheckExistingLoanAmt();
		
		G_bStayInSecScreen=false;
		if (!bContinue) 
		{
			G_bStayInSecScreen=true;
			G_GoBackToSec=G_SelectedSecurity;
			return;
		}
	//set ID
		var SecID = ds_security.recordset.fields("SecurityID").value;
		var sSecTypeCode = ds_security.recordset.fields("SecurityType").value;
		var oSec = ds_security.XMLDocument.documentElement;
		
	//remove customers not related to this security 
		var oSecGivenBy = oSec.selectNodes('//SecurityGivenBy');
		for (var c=oSecGivenBy.length-1; c>=0; c--)
		{
			if (oSecGivenBy(c).getAttribute('Linked')!='-1') oSecGivenBy(c).parentNode.removeChild(oSecGivenBy(c));
			if(sSecTypeCode == "D")
				oSecGivenBy(c).setAttribute("SecCustRelationShip", "Guarantee");
			else
				oSecGivenBy(c).setAttribute("SecCustRelationShip", "Proprietor");
		}
				
	//Roll up security attributes 
		updateDescriptions();
		
	//remove security addresses
		var oSecAddrs = oSec.selectSingleNode("SecurityAddresses");
		if (oSecAddrs)
		{
			var oRepSecAddr = oSecAddrs.cloneNode(false);
			oSec.replaceChild(oRepSecAddr,oSecAddrs);
		}
		
	//update construction details
		var bConstructDlsReq = (oSec.getAttribute("ConstructDtlsReq")!="0");
		var oCurConstruct=oSec.selectSingleNode("ConstructionDetails");
		var oConstructNode = ds_construction.XMLDocument.documentElement.cloneNode(bConstructDlsReq);
		oCurConstruct.parentNode.replaceChild(oConstructNode,oCurConstruct);
		
	//WR1970 - Setting the attribute AddressDtls as either ANZ Term Deposit or Guarante if the security type is ANZ Term Deposit or Guarantee
		if((sSecTypeCode != "B") && (sSecTypeCode != "D"))
			oSec.setAttribute("AddressDtls","");
			//oSec.setAttribute("SecurityTypeDescription",getListText(document.all.cboSecType));
			
	//Adding Customers to SecurityGivenBy1 and SecurityGivenBy2
		UpdateSecGivenBy();
		
		//save security to master
		var xPath = "Securities/Security[SecurityID=" + SecID + "]";

		var oReplSec = xml_master.XMLDocument.documentElement.selectSingleNode(xPath);
		var oNewSec=oSec.cloneNode(true);
		
		xml_master.XMLDocument.documentElement.selectSingleNode("Securities").replaceChild(oNewSec,oReplSec);
		G_bSecurityDirty=false;
		
		
		var valid_SameSecMapAddr = ValMapSecAddress(oNewSec); // Validates Securities with Same Addresses
		
		//recalculate SOP totals
		var oSOP=xml_master.XMLDocument.documentElement.selectSingleNode("StatementsOfPosition/StatementOfPosition");
		if (oSOP) CalculateTotals(oSOP);
		
		EvaluateAppBRS(oNewSec);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement.selectSingleNode("//Securities"));
		
		// Added For Re-Validating the SOP's - Starts
		var oDocEl=xml_master.XMLDocument.documentElement;
		var oSPsCnt = oDocEl.selectNodes('StatementsOfPosition/StatementOfPosition');
		if (oSPsCnt.length>0) EvaluateAppBRS(oDocEl.selectSingleNode("//StatementsOfPosition"));
		
		// Added For Re-Validating the SOP's - Ends
		
		EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);
		
		FlushToDisk();
		if (!NoReselect) 
		{
			//SelectSecurity(G_SelectedSecurity);
			SelectSecurity(G_SelectedSecurity,false,true,"S");
		}
		
	}
	catch (e)
	{
		displayError(e,"SaveSecurity");
	}
}

//==============================================================
//	Function Name:	InitSecurityScreen
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Initialise security the screen	
//==============================================================
function InitSecurityScreen()
{
	try
	{
		G_SelectedSecurity=0;
		document.all.tblSecurityDtlsTab.style.display = 'none';
	}
	catch (e)
	{
		displayError(e,"InitSecurityScreen");
	}
}

//==============================================================
//	Function Name:	DeleteSecurity
//	Parameters:		recNo - (Numeric) Record number of security to delete
//	Return:			Nil	
//	Description:	Deletes a chosen security and reselects another
//==============================================================
function DeleteSecurity(recNo)
{
	try
	{
		if (!ConfirmDelete()) return;
		
		var oSecs = xml_master.XMLDocument.documentElement.selectSingleNode("Securities");
		var iCurrentSelected = G_SelectedSecurity;
		
		//find which one to select after deleting
		var iReselect = iCurrentSelected;
		if (iCurrentSelected > recNo) iReselect = iReselect - 1;
		var bFirstTab=false;
		
		if(iCurrentSelected!=recNo)
		{
			SaveSecurity();
			
			//WR1970 - Added to incorporate cancel button click in security screen warning
			if(G_bStayInSecScreen)
			{
				G_bStayInSecScreen=false;
				return;
			}
		}
		else
		{
			bFirstTab=true;
			G_bSecurityDirty=false;
		}
	
		oSecs.removeChild(oSecs.childNodes(recNo-1));
	
		ShowAddSecurityButton();
	
		if (oSecs.childNodes.length) {
			SelectSecurity(iReselect,false,true,"D");
		}
		else {
			//hide Security details tabs
			tblSecurityDtlsTab.style.display="none";
			G_SelectedSecurity=0;
		}		
		
		EvaluateAppBRS(oSecs,true);
		
		//requires validation of the all sops 
		//due to customer address has been deleted
		var oDocEl=xml_master.XMLDocument.documentElement;
		var oSPsCnt = oDocEl.selectNodes('StatementsOfPosition/StatementOfPosition');
		if (oSPsCnt.length>0) EvaluateAppBRS(oDocEl.selectSingleNode("//StatementsOfPosition"));
			
		//EvaluateAppBRS(oDocEl.selectSingleNode("//Securities"));
		
		var bResult = EvaluateAppBRS(oDocEl.selectSingleNode("//Securities"),true,false);
		
		EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);
		
		FlushToDisk();	
		
	}
	catch (e)
	{
		displayError(e,"DeleteSecurity");
	}
}

//==============================================================
//	Function Name:	AddUpdateSecurityAddress
//	Parameters:		recNo - (Optional numeric) Record number of address to update
//	Return:			Nil
//	Description:	Adds or updates a current address using address dialog
//==============================================================
function AddUpdateSecurityAddress(recNo)
{
	try 
	{
		var AdrId = 0;
		var bNewAddr=0;
		var oSec = ds_security.XMLDocument.documentElement;
		var oDocEl = xml_master.XMLDocument.documentElement;
		var oSecAddrs=oSec.selectSingleNode("SecurityAddresses");
		var oSecAdr;
		var bSecAddr;
		var bChecked;
	
		if (recNo)
		{
			oSecAdr = oSecAddrs.childNodes(recNo-1);
			var AdrId = oSecAdr.selectSingleNode("AddressID").text;
			var SecID = oSec.selectSingleNode("SecurityID").text;
			
		//see if any other securities are linked to this address
			var oSecs = oDocEl.selectNodes("//Securities/Security[SecurityID!="+ SecID + " and AddressID="+AdrId+"]");
			
		//See if this address has been linked to the current security
			bChecked = (document.all.chkSecAddrApplicable.length > 0)? document.all.chkSecAddrApplicable(recNo-1).status:document.all.chkSecAddrApplicable.status;
			
		//if oSecs exists or address checked then show in sec addr dialog
			bSecAddr = ((oSecs.length>0) || bChecked)? ((oSecs.length>0) || bChecked):"-1";
		} 
		else 
		{
			bNewAddr=-1;
			bSecAddr=-1;
		}
		var oAdr = AddUpdateAddress(AdrId,bSecAddr);
		if (oAdr)
		{
		//add/update address to the current dso
			
		//add new sec address from stub
			if (!oSecAdr) oSecAdr=xml_AddrLnkStub.XMLDocument.documentElement.selectSingleNode("//SecurityAddress").cloneNode(true);
				
		//set the address details attribute
			var sAddrDetails = oAdr.getAttribute("AddressDetails")
			oSecAdr.setAttribute("AddressDetails",sAddrDetails);
			
		//Set the address details attribute for other linked securities summary
			if (oSecs)
			{
				for(var i=0;i<oSecs.length;i++)
					oSecs(i).setAttribute("AddressDtls",sAddrDetails);
			}
			
		//set the overseas indicator\
			var OS = VBTrim(oAdr.selectSingleNode("OverseasAddress").text);
			//var sAddrLine3 = VBTrim(oAdr.selectSingleNode("AddressLine3").text);
			var bOS;
			var bAddrL3;
			
			//Check is overseas address is present
			bOS = (OS=="" || OS=="0")? 0:-1;

			//Check if an address line 3 is present
			//bAddrL3 = (sAddrLine3=="")? 0:-1;
			
			//IF OS or AddrL3 then address is not applicable
			var bApplicable =(!bOS);
			
			//link address if new address and applicable
			if (bNewAddr && bApplicable)
			{
				//get the address ID
				AdrId = oAdr.selectSingleNode("AddressID").text;
			
				//remove any existing links
				var oOldLink = oSecAddrs.selectSingleNode("SecurityAddress[AddressID!='" + AdrId + "' and @Linked='-1']");
				if (oOldLink) oOldLink.setAttribute("Linked",0);
				
				//Set the linked attribute 
				oSecAdr.setAttribute("Linked",-1);
				
				//set the address ID in the security dso
				ds_security.XMLDocument.documentElement.selectSingleNode("AddressID").text = AdrId;
			}
			
			oSecAdr.setAttribute("Applicable",bApplicable);
			if (!recNo) 
			{
				oSecAdr.selectSingleNode("AddressID").text=oAdr.selectSingleNode("AddressID").text;
				oSecAddrs.appendChild(oSecAdr);
			}
			
			disableUnapplicableAddresses(document.all.tblSecAddresses);
		}
	}
	catch (e)
	{
		displayError (e,"AddUpdateSecurityAddress");
	}
}

//==============================================================
//	Function Name:	DeleteSecurityAddress
//	Parameters:		recNo - (Numeric) Record number of address to delete
//	Return:			Nil	
//	Description:	Deletes an address
//==============================================================
function DeleteSecurityAddress(recNo)
{
	try 
	{	
		var oSec = ds_security.XMLDocument.documentElement;
		var cust_recNo="";
		var sec_recNo = recNo;
		DeleteCustomerSecurityAddress(cust_recNo,sec_recNo,oSec,"S");
	}
	catch (e)
	{
		displayError(e,"DeleteSecurityAddress");
	} 
}

//==============================================================
//	Function Name:	SelectSecurity
//	Parameters:		recNo - (numeric) record number of security to select
//					newRec - (boolean) Flag for new record
//					bFromScreen - (boolean) Flag for event from scree
//	Return:			Nil	
//	Description:	Selects an new security node and loads it into the screen
//==============================================================
function SelectSecurity(recNo, newRec, bFromScreen,scrn_falg)
{
	try
	{	
		if (G_SelectedSecurity>0) SaveSecurity(true);
		
		//WR1970 - Added to incorporate cancel button click in security screen warning
		if(G_bStayInSecScreen)
		{
			if (G_SelectedSecurity > 1)
			{
				document.all.SecRowSelector(G_SelectedSecurity-1).focus();
				document.all.SecRowSelector(G_SelectedSecurity-1).checked=true;
			}
			G_bStayInSecScreen=false;
			return;
		}
		
		var oSecs = xml_master.XMLDocument.documentElement.selectSingleNode("Securities");
		if (recNo > oSecs.childNodes.length) recNo = oSecs.childNodes.length;
		if ((!recNo)&&(oSecs.childNodes.length)) recNo = 1;
			
		G_SelectedSecurity = recNo;
		if (!recNo) return; 
	
		var oSelected = oSecs.childNodes(recNo-1);
		ds_security.XMLDocument.async=false;
		ds_security.src = ds_security.src;
		ds_security.XMLDocument.replaceChild(oSelected.cloneNode(true),ds_security.XMLDocument.documentElement);
		var oSecDocEl = ds_security.XMLDocument.documentElement;
		
		//WR9170 - Initializing Security Given By with xsl
		//************************************************
		
		//initilize Security Given By with XSL
		oSelected.setAttribute("current","1");
		xml_master.XMLDocument.documentElement.transformNodeToObject(xsl_SecCustRefresh.XMLDocument, xml_temp.XMLDocument);
		oSelected.setAttribute("current","0");

		var oR=oSecDocEl.selectSingleNode("//SecuritiesGivenBy");
		var oN=xml_temp.XMLDocument.documentElement.cloneNode(true);
		ds_security.XMLDocument.documentElement.replaceChild(oN,oR);
		
		//*************************************************
		
		if (oSecDocEl.selectSingleNode("SecurityType").text=="New Entry") oSecDocEl.selectSingleNode("SecurityType").text="";
	
		document.all.tblSecurityDtlsTab.style.display="block";
	
		//initilize Security addresses with XSL
		oSelected.setAttribute("current","1");
		xml_master.XMLDocument.documentElement.transformNodeToObject(xsl_SecAdrRefresh.XMLDocument, xml_temp.XMLDocument);
		oSelected.setAttribute("current","0");

		var oR=oSecDocEl.selectSingleNode("//SecurityAddresses");
		var oN=xml_temp.XMLDocument.documentElement.cloneNode(true);
		ds_security.XMLDocument.documentElement.replaceChild(oN,oR);
		
		//initilize Construction Details
		ds_construction.src=ds_construction.src;
		var oConstruct=oSecDocEl.selectSingleNode("ConstructionDetails");
		if (oConstruct) 
			if (oConstruct.hasChildNodes()) ds_construction.XMLDocument.replaceChild(oConstruct.cloneNode(true),ds_construction.XMLDocument.documentElement);	
			
		if (bFromScreen) SwitchSecurityTab(0);
			
		//Initialise fields
		SetUpSecurity(newRec);
		
		//set focus on the chkSecDtlsTBA checkbox or if disabled inpSecGivenBy1
		var bSetSecTBA =document.all.chkSecDtlsTBA.disabled;
		SetFocusOnElement((!bSetSecTBA)? "chkSecDtlsTBA":"inpSecGivenBy1");
		
		G_bSecurityDirty=false;

		
		if (scrn_falg != "D")
		{
			SetRowSelectors(document.all.SecRowSelector,recNo); // By Default 
		}
		else
		{
			SetRowSelectors(document.all.SecRowSelector,recNo-1);
			EvaluateAppBRS(oSecDocEl);
			SetRowSelectors(document.all.SecRowSelector,recNo);
		}
		
		var oDocEl=xml_master.XMLDocument.documentElement;
		var oSecs = oDocEl.selectNodes("Securities/Security");
		if (oSecs.length>0) 
		{ 
			EvaluateAppBRS(oDocEl.selectSingleNode("//Securities"),true);
		}
	}
	catch (e)
	{
		displayError(e,"SelectSecurity");
	}
}

//==============================================================
//	Function Name:	SetUpSecurity
//	Parameters:		bNewRec - (boolean) Flag for a new security
//	Return:			Nil	
//	Description:	Instigate setting up the forms for a new security
//==============================================================
function SetUpSecurity(bNewRec)
{
	try 
	{
		(bNewRec)? SecurityTypeChange(-1,bNewRec):SecurityTypeChange(-1,bNewRec);
	}
	catch (e)
	{
		displayError(e,"SetUpSecurity");
	}
}

//==============================================================
//	Function Name:	SecurityScreenShow
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Shows the security screen
//==============================================================
function SecurityScreenShow()
{
	try
	{
		
		if (!G_oScreens["ScrSecDetails"].ListsPopulated)
		{
			//security
			populateList("A_TS_SEC_TYPES", document.all.cboSecType, null, 'TYPE_CODE', 'CODE_DEESC', false); 
			populateList("A_TS_SEC_STATUS_CODES", document.all.cboSecStatus, null, 'STATUS_CODE', 'CODE_DESC', false); 
			populateList("A_TS_PROP_STATUS_CODES", document.all.cboSecPropStatus, null, 'STATUS_CODE', 'CODE_DESC', false); 
			populateList("A_TS_SEC_TITLE_TYPES", document.all.cboSecTitleType, null , 'TYPE_CODE', 'CODE_DESC', false); 
			populateList("A_TS_PROP_TENURE_CODES", document.all.cboSecPropTenure, null , 'TENURE_CODE', 'CODE_DESC', false); 
			populateList("A_TS_PROP_ZONING_CODES", document.all.cboSecPropZoning, null , 'ZONING_CODE', 'CODE_DESC', false); 
			populateList("A_TS_PROP_USE_CODES", document.all.cboSecPropUse, null , 'USE_CODE', 'CODE_DESC', false);
			//WR - MT0420 - Disable the security given by fields
			DisableElement(document.all.inpSecGivenBy1, false);
			DisableElement(document.all.inpSecGivenBy2, false); 
			//populateList("A_TS_SEC_NATURE_CODES", document.all.cboSecNature, null , 'NATURE_CODE', 'CODE_DESC', false); 
			//populateList("A_TS_SEC_MORTGAGEE_CODES", document.all.cboSecFirstMort, null , 'MORTGAGEE_CODE', 'CODE_DESC', false); 
			G_oScreens["ScrSecDetails"].ListsPopulated = true;
		}

		//Show security
		G_bStayInSecScreen=false;
		
		G_pScreenSaveFunction = SaveSecurity;
		ShowAddSecurityButton();
		var oN = xml_master.XMLDocument.selectSingleNode("//Security");
		if (oN)
		{
			SelectSecurity(1,false,true,"S");
		} 
		else 
		{
			G_SelectedSecurity=0;
			document.all.tblSecurityDtlsTab.style.display = 'none';
		}
	}
	catch (e)
	{
		displayError(e,"SecurityScreenShow");
	}
}

//==============================================================
//	Function Name:	AddSecurity
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Adds a new security to the application
//==============================================================
function AddSecurity()
{
	try
	{
		if (G_SelectedSecurity > 0) SaveSecurity();
		
		//WR1970 - Added to incorporate cancel button click in security screen warning
		if(G_bStayInSecScreen)
		{
			G_bStayInSecScreen=false;
			return;
		}
			
		var oMasterDE = xml_master.XMLDocument.documentElement;
		var oSecurities = oMasterDE.selectSingleNode("Securities");
		ds_security.src=ds_security.src;
		var oNewSecurity = ds_security.XMLDocument.documentElement.cloneNode(true);
		InitilizeAppBRS(oNewSecurity);
		//set id
		oNewSecurity.selectSingleNode("SecurityID").text = allocateNewID("maxSecurityID");
		
		//WR1970 - Removed security given by 1 & 2 in version 2
		/*
		//Default Security given by1 to name of primary applicant and given by 2 to the first co-owner
		var oCustName = oMasterDE.selectSingleNode("//Customers/Customer[CustomerType='SOL' or CustomerType='COF']/CustomerName");
		if (oCustName) oNewSecurity.selectSingleNode("SecurityGivenBy1").text =oCustName.text;
		var oCustName = oMasterDE.selectSingleNode("//Customers/Customer[CustomerType='COO']/CustomerName");
		if (oCustName) oNewSecurity.selectSingleNode("SecurityGivenBy2").text =oCustName.text;
		*/
		
		//Set default sec type to B - registered mortgage
		oNewSecurity.selectSingleNode("SecurityType").text="B";
		
		//Remove Addresses	
		var remAdrCh=oNewSecurity.selectSingleNode("SecurityAddresses");
		remAdrCh.removeChild(remAdrCh.selectSingleNode("SecurityAddress"));
		
		//Initialise Construction details
		ds_construction.src=ds_construction.src;
		var oNewConstruct = ds_construction.XMLDocument.documentElement.cloneNode(true);
	
		oSecurities.appendChild(oNewSecurity);
		var RecNo = oSecurities.childNodes.length;
	
		ShowAddSecurityButton();
		
		//select added Security
		SelectSecurity(RecNo, true,true,"A");
		
		G_bSecurityDirty=true;
		
		document.getElementById("chkSecDtlsTBA").checked = false;
		
	}
	catch (e)
	{
		displayError(e,"AddSecurity");
	}
}

//==============================================================
//	Function Name:	SecurityTypeChange
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (Boolean) Flag for a new security
//	Return:			Nil	
//	Description:	Sets up the entire security screen according to type of security
//==============================================================
function SecurityTypeChange(bFromFile,bNewRec)
{	
	try 
	{	
		var sSecTypeCode = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("SecurityType").text:document.all("cboSecType").value;
			//Check if its property based - Show hide Property/ non-property based section
		var oSecType = getSingleRDRow ("A_TS_SEC_TYPES", "@TYPE_CODE='" + sSecTypeCode + "'");
		 
		if(sSecTypeCode!='B') {cleanAddressdetails();}
		//Set up sec screen if a sec node could be selected for the selected sec type
		if (oSecType)
		{
			//show/hide propertybased/ non-propertybased if PROPERTY_BASED=-1
			var bPropBased = (oSecType.getAttribute("PROPERTY_BASED")!="0");
			
			//clear fields for non-property type security
			if (!bFromFile) clearNonPropSec();
			
			//If security is type P then treat as property based
			if(sSecTypeCode=="P") bPropBased=-1;
			
			//Set property based attribute
			ds_security.XMLDocument.documentElement.setAttribute("PropBased",((bPropBased)? -1:0));
			
			//Set default sec status to T - To Be Taken as Application source = "O"
			if (!bFromFile || bNewRec) ds_security.recordset.fields("SecurityStatus").value = "T";
			
			//Show/Hide appropriate property type section
			setupPropertyBased(bPropBased);
			
			//Enable disable prop type detail fields
			if (!isSharedMortgage(sSecTypeCode)) SetupPropBasedFields(bPropBased,bFromFile);
			
			//remove linked addresses
			if (!bFromFile && !bNewRec) removeLinkedAddresses(bPropBased);
			
			//Enable/Disable Security Details to be announced
			setupSecTBA(oSecType);
			
			//Set up the guarantee section
			setupGuarantee(sSecTypeCode, oSecType,bNewRec);
			
			//Set up the first mortgagor section
			setupFirstMortgagor(sSecTypeCode,oSecType, bNewRec);
			
			//Enable/Disable fair market value details
			setupFMV(sSecTypeCode, oSecType, bNewRec);
			
			//Check if type = Other
			setupOther(sSecTypeCode, oSecType,bNewRec);
			
			//Check if a deposit product is available for this product
			setupDepositProduct(sSecTypeCode, oSecType,bNewRec);
			
			//Enable/disable non-prop desc1 and 2
			setupPropertyDescriptions(bPropBased);

			/* Setup stamping types
			setupStamping(sSecTypeCode, oSecType, bNewRec); */
				
			//setup for property purchase security
			// Changed for Defect - TBA - Property Purchase to be default Checked = True
			var sSecTBA = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("SecurityDetailsTBA").text:document.all("chkSecDtlsTBA").value;
			setupPropertyPurchase(sSecTypeCode,bNewRec,bFromFile,sSecTBA);
			
			//Set title defaults if security is property based
			if(bPropBased) SetPropertyTitleDefaults(bFromFile, bNewRec);
			
			//WR1970
			//****************************************************************************
			
			//Enable/Disable Address and Construction Tab and clearing the existing fields
			setupAddrConstrTab(sSecTypeCode);
			
			//Set Property Tenure defaults if security is property based
			if(bPropBased) SetPropertyTenureDefaults(bFromFile, bNewRec);
			
			//Set Property Zoning defaults if security is property based
			if(bPropBased) SetPropertyZoningDefaults(bFromFile, bNewRec);

			//Setup Security Details
			setupSecurityDetails(sSecTypeCode);
					
			//****************************************************************************
			
			var sSecTypeUse = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("PropertyUse").text:document.all("cboSecPropUse").value;
			var sSecTypeZone = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("PropertyZoning").text:document.all("cboSecPropZoning").value;
			
			if ((sSecTypeZone=='R') || (sSecTypeZone=='F'))
			{
				sSecTypeZone="R";
			}
			
			if((sSecTypeZone=='R') && (sSecTypeUse=="I"))
			{
				DisableElement(document.all.inpSecInvestmentExpense, true);				
			}
			else{
				ds_security.recordset.fields("SecInvestmentExpense").value="0.00";
				DisableElement(document.all.inpSecInvestmentExpense,false);
			}
			
		}
			
		//Set up other default fields
		CheckTBA(-1,bNewRec);
		
	}
	catch (e)
	{
		displayError(e,"SecurityTypeChange");
	}
}	

function cleanAddressdetails()
 {
  document.getElementById("trSecAdrTBA").style.display ="none";		
 }

//==============================================================
//	Function Name:	setupPropertyBased
//	Parameters:		bPropBased - (boolean) Flag indicating if security is property based
//	Return:			Nil
//	Description:	Show or hide property and non-property based details
//==============================================================
function setupPropertyBased(bPropBased)
{	
	try 
	{	
		var EnableImg;
		
		//WR1970
		//*****************************************************************************
		var bNonPropType = false;
		
		//Hide/show proptype and non-proptype sections
		document.all.tblSecPropTypeDetails.style.display =  DSSwitch(bPropBased);
		document.all.tblSecNonPropTypeDetails.style.display =  DSSwitch(bNonPropType);
		
		if (bPropBased)
		{
			EnableImg=".gif";
			if (G_iCurSecTabIdx==1) EnableImg = "_dn.gif";	
		} 
		else 
		{
	
			EnableImg="_faded.gif";
		}
		document.all.ScrSecDetails.all.imgSecurityDtlsTab(1).src = "../images/tabs/" + aSecTabImgs[1] + EnableImg;
	}
	catch (e)
	{
		displayError(e,"setupPropertyBased");
	}
}

//==============================================================
//	Function Name:	SetupPropBasedFields
//	Parameters:		bPropBased - (boolean) Flag indicating if security is property based
//					bFromFile - (boolean) Flag indicating if called from file
//	Return:			Nil
//	Description:	Handles enabling and disabling security details fields
//==============================================================
function SetupPropBasedFields(bPropBased, bFromFile)
{	
	try 
	{
		//Enable/Disable property purchase
		if (!bPropBased || !bFromFile)ds_security.recordset.fields("PropertyPurchase").value="0";
		DisableElement(document.all.chkSecPropPurch, bPropBased);
		
		//Clear on market transaction
		if (!bPropBased || !bFromFile){ 
			ds_security.recordset.fields("OnMarketTransaction").value="0";
			DisableElement(document.all.chkSecOnMarket, false);
			
			//WR1970 - Clear Purchase Off The Plan
			
			ds_security.recordset.fields("PurchaseOffThePlan").value="0";
			DisableElement(document.all.chkSecPurchasePlan, false);
			
		}
	
		//Enable/disable Property Status
		var bEnablePropertyStatus = ((G_oCompanyOptions.SEC_PROP_STATUS!="N") && bPropBased);
		if (!bEnablePropertyStatus || !bFromFile)ds_security.recordset.fields("PropertyStatus").value="";
		DisableElement(document.all.cboSecPropStatus, bEnablePropertyStatus);
			
		//Enable/Disable Property Type
		var bEnablePropertyType = ((G_oCompanyOptions.SEC_PROP_TYPE!="N") && bPropBased);
		if (!bEnablePropertyType || !bFromFile)ds_security.recordset.fields("PropertyType").value="";
		DisableElement(document.all.cboSecPropType, bEnablePropertyType);
			
		//Enable/Disable Security Title Type
		var bEnableSecTitleType = ((G_oCompanyOptions.SEC_TITLE_TYPE!="N") && bPropBased);
		if (!bEnableSecTitleType || !bFromFile)ds_security.recordset.fields("SecurityTitleType").value="";
		DisableElement(document.all.cboSecTitleType, bEnableSecTitleType);
			
		//Enable/Disable Security Tenure
		var bEnableSecTenure = ((G_oCompanyOptions.SEC_PROP_TENURE!="N") && bPropBased);
		if (!bEnableSecTenure || !bFromFile)ds_security.recordset.fields("PropertyTenure").value="";
		DisableElement(document.all.cboSecPropTenure, bEnableSecTenure);
			
		//Enable/Disable Security property zoning
		var bEnableSecPropZone = ((G_oCompanyOptions.SEC_PROP_ZONING!="N") && bPropBased);
		if (!bEnableSecPropZone || !bFromFile)ds_security.recordset.fields("PropertyZoning").value="";
		DisableElement(document.all.cboSecPropZoning, bEnableSecPropZone);
			
		//Enable/Disable Security property use
		var bEnableSecPropUse = ((G_oCompanyOptions.SEC_PROP_USE!="N") && bPropBased);
		if (!bEnableSecPropUse || !bFromFile)ds_security.recordset.fields("PropertyUse").value="";
		DisableElement(document.all.cboSecPropUse, bEnableSecPropUse);
	
		//Enable/ Disable Customer stated value
		var bEnableCustStatVal=(G_oCompanyOptions.SEC_CUS_STAT_VAL!="N" && bPropBased);
		if (!bEnableCustStatVal || !bFromFile)ds_security.recordset.fields("CustomerStatedValue").value="0";
		DisableElement(document.all.inpSecCustStateValue, bEnableCustStatVal);
	
		//Enable/Disable Contract of sale date
		if (!bPropBased)ds_security.recordset.fields("ContractOfSaleDate").value="";
		DisableElement(document.all.inpSecContOfSaleDate, bPropBased);
		
		
		//Card - 259 and Card - 260 Starts
		
		//Enable/Disable Contract of SecurityLimitedValue
		
		if (!bPropBased || !bFromFile)ds_security.recordset.fields("SecurityLimitedValue").value="0";
		//Disabled Security Limited value as it is calculated from Garauntee value
		DisableElement(document.all.inpSecLimitedToVal, false);
		setSecLtdValue();
		
		//Enable/Disable Contract of SecRentalIncome
		
		if (!bPropBased || !bFromFile)ds_security.recordset.fields("SecRentalIncome").value="0";
		DisableElement(document.all.inpSecOfRentalIncome, bPropBased);
		
		//Enable/Disable Contract of SecFloorAreaLand
		
		if (!bPropBased || !bFromFile)ds_security.recordset.fields("SecFloorAreaLand").value="0";
		DisableElement(document.all.inpSecOfFloorAreaLand, bPropBased);
		
		//Card - 259 and Card - 260 Ends
		
		//Card - 784 Starts
			//Enable/ Disable Investment Property Running Cost$ 
			if (ds_security.recordset.fields("PropertyZoning").value=='F')
			{
				var Zonestr='R';
			}
			if (ds_security.recordset.fields("PropertyZoning").value=='R')
			{
				var Zonestr='R';
			}
			
			//var bEnableCustStatVal=(ds_security.recordset.fields("PropertyUse").value=="I" && Zonestr=="R");
			if ((Zonestr=='R') && (ds_security.recordset.fields("PropertyUse").value=='I') )
			{
			
				DisableElement(document.all.inpSecInvestmentExpense, true);
				DisableElement(document.all.chkShortSty, true);
			}
			else
			{
				DisableElement(document.all.inpSecInvestmentExpense,false);
				ds_security.recordset.fields("SecInvestmentExpense").value="0";
				DisableElement(document.all.chkShortSty, false);
				ds_security.recordset.fields("SecShortStay").value="0";
			}
			//Card - 784 Ends
	}
	catch (e)
	{
		displayError(e,"SetupPropBasedFields");
	}
}

//==============================================================
//	Function Name:	removeLinkedAddresses
//	Parameters:		bPropBased - (boolean) Flag indicating if security is property based
//	Return:			Nil
//	Description:	remove linked addresses if not property based security
//==============================================================
function removeLinkedAddresses(bPropBased)
{	
	try 
	{	
		if (!bPropBased)
		{
			var oSec = ds_security.XMLDocument.documentElement;
			if (oSec)
			{
				//Clear the address ID in the security dso
				oSec.selectSingleNode("AddressID").text = "";
				
				//Select the security adresses
				var oSecAddrs=oSec.selectSingleNode("SecurityAddresses");
				if (oSecAddrs)
				{
					//remove any existing links
					var oLinkedAddrs = oSecAddrs.selectNodes("SecurityAddress[@Linked='-1']");
					for (var i=0;i<oLinkedAddrs.length;i++)
						oLinkedAddrs(i).setAttribute("Linked",0);
				}
			}
		}
	}
	catch (e)
	{
		displayError(e,"removeLinkedAddresses");
	}
}

//==============================================================
//	Function Name:	setupSecTBA
//	Parameters:		oSecType - (XML Node) Ref data node for security type
//	Return:			Nil
//	Description:	Setup Sec Details TBA check box
//==============================================================
function setupSecTBA(oSecType)
{
	try 
	{	
		var bDtlsTBA = (oSecType.getAttribute("ALW_DTLS_TBA")!="0");
		if (!bDtlsTBA) ds_security.recordset.fields("SecurityDetailsTBA").value="0";
		DisableElement(document.all.chkSecDtlsTBA, bDtlsTBA);
		DisableElement(document.all.chkSecPropPurch, bDtlsTBA);
		
	}
	catch (e)
	{
		displayError (e,"setupSecTBA");
	}
}

//==============================================================
//	Function Name:	setupGuarantee
//	Parameters:		sSecTypeCode - (string) Security type code
//					oSecType - (XML Node) Ref data node for security type
//					bNewRec - (boolean) flag indicating if new security
//	Return:			Nil	
//	Description:	Set up the guarantee section
//==============================================================
function setupGuarantee(sSecTypeCode, oSecType, bNewRec)
{
	try 
	{	
		var EnableImg;
		//Enable/Disable Unlimited Guarantee
		var bGuarUnlimApp = (oSecType.getAttribute("ALW_GUARANTEE_UNLMTD")!="0");
		//if (!bGuarUnlimApp) ds_security.recordset.fields("GuaranteeUnlimited").value=0; removed because no guarantees
		DisableElement(document.all.inpSecUnlimGuar, bGuarUnlimApp);
			
		//Enable/Disable Guarantee Amount
		var bGuarAmtApp = (oSecType.getAttribute("GAMT_APPLICABLE")!="0");
		var bGuarUnlimited = (ds_security.recordset.fields("GuaranteeUnlimited").value=="-1");
		var bEnableGuarUnlim = (bGuarAmtApp && (!bGuarUnlimited));
		if (!bEnableGuarUnlim) ds_security.recordset.fields("GuaranteeAmount").value="0";
		//DisableElement(document.all.inpSecGuarAmt, bEnableGuarUnlim);
		
		//WR1970 - Enabling Guarantee Amount textbox for Security Type = Guarantee
		DisableElement(document.all.inpSecGuarAmt, bGuarAmtApp);
		
		DisableElement(document.all.cboSecStatus, !bGuarAmtApp);
		if(bGuarAmtApp)
		{
			ds_security.recordset.fields("SecurityStatus").value = "T";
			document.all.iTypeofGuarantee.style.display = "block";
			
			EnableImg=".gif";
			if (G_iCurSecTabIdx==1) EnableImg = "_dn.gif";
		}
		else
		{			
			document.all.iTypeofGuarantee.style.display = "none";
			ds_security.recordset.fields("SecGuaranteeType").value="";
			
			EnableImg="_faded.gif";
		}
		document.all.ScrSecDetails.all.imgSecurityDtlsTab(1).src = "../images/tabs/" + aSecTabImgs[1] + EnableImg;
		//Set up default description
		if (bGuarAmtApp) setGuaranteeDesc(bEnableGuarUnlim);
	
		//WR1970 - Showing the Guarantee section for security type = Guarantee
		//var bDisplay = (bGuarUnlimApp || bGuarAmtApp);
					
		//Show/ Hide Guarantee section
		document.all.tblSecGuaranteeDetails.style.display =  DSSwitch(bGuarAmtApp);
	}
	catch (e)
	{
		displayError(e,"setupGuarantee");
	}
}

//==============================================================
//	Function Name:	setGuaranteeDesc
//	Parameters:		bSet - (boolean) Flag indicating if description should be set
//	Return:			Nil	
//	Description:	Defaults guarantee description
//==============================================================
function setGuaranteeDesc(bSet)
{
	try 
	{	
		var sDesc="";
		if (bSet)
		{
			var sGuaranteeAmt = VBTrim(ds_security.recordset.fields("GuaranteeAmount").value);
			if (sGuaranteeAmt) sDesc = "Guarantee limited to " + VBFormatCurrency(sGuaranteeAmt,0);	
		}
		ds_security.recordset.fields("SecurityDescription1").value= sDesc
	}
	catch (e)
	{
		displayError(e,"setGuaranteeDesc");
	}
}

//==============================================================
//	Function Name:	setupFirstMortgagor
//	Parameters:		sSecTypeCode - (string) Security type code
//					oSecType - (XML Node) Ref data node for security type
//					bNewRec - (boolean) flag indicating if new security
//	Return:			Nil	
//	Description:	Set up the first mortgagor section
//==============================================================
function setupFirstMortgagor(sSecTypeCode, oSecType,bNewRec)
{
	try 
	{	
		//Enable/disable FirstMortage value if M1V_APPLICABLE = -1 
		var bFirstMortVal = (oSecType.getAttribute("M1V_APPLICABLE")!="0");
		if (!bFirstMortVal) ds_security.recordset.fields("FirstMortgageValue").value="0";
		DisableElement(document.all.inpSecFirstMortVal, bFirstMortVal);
				
		//Check if type C - Second registered mortgage
		var bSecType_C = (sSecTypeCode=="C");
		if (!bSecType_C) ds_security.recordset.fields("FirstMortgagee").value="";
		DisableElement(document.all.cboSecFirstMort, bSecType_C);
		firstMortgageeChange(-1,bNewRec);
	
		//WR1970 - Applicable only for Security Type = Registered Mortgage
		//Show/ Hide First Mortgagor section
		document.all.tblSecFirstMortDetails.style.display =  DSSwitch(bFirstMortVal);
	}
	catch (e)
	{
		displayError(e,"setupFirstMortgagor");
	}
}

//==============================================================
//	Function Name:	setupOther
//	Parameters:		sSecTypeCode - (string) Security type code
//					oSecType - (XML Node) Ref data node for security type
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			Nil	
//	Description:	Setup for security type O
//==============================================================
function setupOther(sSecTypeCode, oSecType,bNewRec)
{
	try 
	{	
		var bSecOther = (sSecTypeCode=="O"); 
		(bSecOther)? SecNatureChange(-1,bNewRec): ds_security.recordset.fields("NatureOfSecurity").value="";
		DisableElement(document.all.cboSecNature, bSecOther);
	}
	catch (e)
	{
		displayError(e,"setupOther");
	}
}

//==============================================================
//	Function Name:	setupDepositProduct
//	Parameters:		sSecTypeCode - (string) Security type code
//					oSecType - (XML Node) Ref data node for security type
//					bNewRec - (boolean) flag indicating if new security
//	Return:			Nil	
//	Description:	Setup deposit product
//==============================================================
function setupDepositProduct(sSecTypeCode, oSecType,bNewRec)
{
	try
	 {	
		var sDepProd = VBTrim(oSecType.getAttribute("DEPOSIT_PRODUCT"));
		var bEnable= (sDepProd.length!=0);
	
		if (!bEnable)
		{
			ds_security.recordset.fields("CertificateNumber").value="";
			ds_security.recordset.fields("AccountNumber").value="";
		}
		DisableElement(document.all.inpSecCertNumber, bEnable);
		DisableElement(document.all.inpSecAccNumber, bEnable);
	}
	catch (e)
	{
		displayError(e,"setupDepositProduct");
	}
}

//==============================================================
//	Function Name:	setupPropertyDescriptions
//	Parameters:		bPropBased - (boolean) Flag indicating if security is propery based
//	Return:			Nil	
//	Description:	setup property descriptions
//==============================================================
function setupPropertyDescriptions(bPropBased)
{
	try 
	{	
		if (bPropBased)
		{
			ds_security.recordset.fields("SecurityDescription1").value="";
			DisableElement(document.all.inpSecDesc1, false);
			ds_security.recordset.fields("SecurityDescription2").value="";
			DisableElement(document.all.inpSecDesc2, false);
		} else {
			DisableElement(document.all.inpSecDesc1, true);
			DisableElement(document.all.inpSecDesc2, true);
		}
	}
	catch (e)
	{
		displayError(e,"setupPropertyDescriptions");
	}
}

//==============================================================
//	Function Name:	setupFMV
//	Parameters:		sSecTypeCode - (string) Security type code
//					oSecType - (XML Node) Ref data node for security type
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			Nil	
//	Description:	Setup fair market value
//==============================================================
function setupFMV(sSecTypeCode, oSecType, bNewRec)
{
	try 
	{	
		var bSecFMVApplicable = (oSecType.getAttribute("FMV_APPLICABLE")!="0");

		var bEnableFMV = bSecFMVApplicable;
		if (!bEnableFMV) ds_security.recordset.fields("SecurityValue").value="0";
		DisableElement(document.all.inpSecFMValue, bEnableFMV);
			
		//if(bSecCalcFMV) Calculate fair market value - NZ only
	}
	catch (e)
	{
		displayError(e,"setupFMV");
	}			
}

//==============================================================
//	Function Name:	setupPropertyPurchase
//	Parameters:		sSecTypeCode - (string) Security type code
//					bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			NIl	
//	Description:	setup for property purchase security
//==============================================================
function setupPropertyPurchase(sSecTypeCode, bNewRec, bFromFile,sSecTBA)
{			
	try 
	{	
		//Check property purchase
		if (sSecTypeCode=="P")
		{
			//Default Property Purchase to "Y - Yes (-1)"
			ds_security.recordset.fields("PropertyPurchase").value = "-1";
			DisableElement(document.all.chkSecPropPurch, false);
		} 
		else
		{
			if (!bFromFile || bNewRec)
			{
				//Default Property Purchase to "N - No (0)" if property type is not p
				var bNotCheckedTBA = (ds_security.recordset.fields("SecurityDetailsTBA").value==0);
				if (bNotCheckedTBA) 
				{
					ds_security.recordset.fields("PropertyPurchase").value = "0";
				}
				else
				{
					DisableElement(document.all.chkSecPropPurch, false);
				}
			}
			else if ((sSecTBA == -1) && (!bNewRec))
			{
				ds_security.recordset.fields("PropertyPurchase").value = "-1";
			}
		}
	}
	catch (e)
	{
		displayError(e,"setupPropertyPurchase");
	}
}

//==============================================================
//	Function Name:	SetPropertyTitleDefaults
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			Nil	
//	Description:	Set defaults for the property title
//==============================================================
function SetPropertyTitleDefaults(bFromFile, bNewRec)
{
	try 
	{	
		if (!bFromFile || bNewRec)
		{
			var sSecType = (bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("SecurityType").text:document.all("cboSecType").value;
			if (sSecType)
			{
				var oDefTitle = getSingleRDRow ("A_TS_SEC_TYPES", "@TYPE_CODE='" + sSecType + "'");
				var sDefTitle = oDefTitle.getAttribute("DEF_TITLE_TYPE");
				(sDefTitle)? ds_security.recordset.fields("SecurityTitleType").value=sDefTitle:ds_security.recordset.fields("SecurityTitleType").value="";
			}
		}
	}
	catch (e)
	{
		displayError(e,"SetPropertyTitleDefaults");
	}
}

//==============================================================
//	Function Name:	PropPurchClick
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security		
//	Return:			Nil	
//	Description:	Handle Click events of the Security Property Purchase check box
//==============================================================
function PropPurchClick(bFromFile, bNewRec)
{
	try 
	{	
		var bCheckedPropPurch = (ds_security.recordset.fields("PropertyPurchase").value!=0);
		//Disable or enable on market check box
		if (!bCheckedPropPurch)
		{
			ds_security.recordset.fields("TransferOfLandValue").value="0";
			ds_security.recordset.fields("OnMarketTransaction").value="0";
			
			//WR1970 - Clearing the value of PurchaseOffThePlan
			ds_security.recordset.fields("PurchaseOffThePlan").value="0";
			PropStatusPopulate();
		}
		DisableElement(document.all.chkSecOnMarket, bCheckedPropPurch);
		DisableElement(document.all.inpSecTransLandValue, bCheckedPropPurch);
		//WR1970 - Disable or enable off the plan checkbox
		DisableElement(document.all.chkSecPurchasePlan, bCheckedPropPurch);
	}
	catch (e)
	{
		displayError(e,"PropPurchClick");
	}
}

//==============================================================
//	Function Name:	CheckTBA
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security		
//	Return:			Nil	
//	Description:	Handle TBA Check
//==============================================================
function CheckTBA(bFromFile, bNewRec)
{
	try 
	{	
		var bCheckedTBA = (ds_security.recordset.fields("SecurityDetailsTBA").value!=0);
		var bNewPropStatus=(!bFromFile || bNewRec);
		var sSecTypeCode = ds_security.recordset.fields("SecurityType").value;
		var oSec = ds_security.XMLDocument.documentElement;
		if (bNewPropStatus)
		{
			if (bCheckedTBA)
			{
				//Default security type top B - registered mortgage
				ds_security.recordset.fields("SecurityType").value="B";
				
				// DEFECT - 9656 STARTS
				
				ds_security.recordset.fields("AddressID").value = "";
				sAddrID = ds_security.recordset.fields("AddressID").value;
				
				
				var oSecAddrs=oSec.selectSingleNode("SecurityAddresses");
				var oOldLink = oSecAddrs.selectSingleNode("SecurityAddress[AddressID!='" + sAddrID + "' and @Linked='-1']");
				if (oOldLink) oOldLink.setAttribute("Linked",0);
				
				// DEFECT - 9656 ENDS
				
				//WR1970 - Showing the Security Details section
				SecurityTypeChange(bFromFile,bNewRec);
				
				//Default security status to "T - To Be Taken"
				ds_security.recordset.fields("SecurityStatus").value = "T";
				//Default Property Purchase to "Y - Yes (-1)"
				ds_security.recordset.fields("PropertyPurchase").value = "-1";
				DisableElement(document.all.chkSecPropPurch, bCheckedTBA);
				//Default property status to "E- Established"
				if (G_oCompanyOptions.SEC_PROP_STATUS!="N")
				ds_security.recordset.fields("PropertyStatus").value = "E";	
				document.all.trSecAdrTBA.style.display = "block";
			} 
			else 
			{
				//Default Property Purchase to "N - No (0)" if property type is not p
				if (sSecTypeCode!="P")
				{
					ds_security.recordset.fields("PropertyPurchase").value = "0";
					ds_security.recordset.fields("PropertyStatus").value = "";
				}
	            document.all.trSecAdrTBA.style.display = "none";
				DisableElement(document.all.chkSecPropPurch, (!bCheckedTBA));
	            oSec = ds_security.XMLDocument.documentElement;
	            oSec.selectSingleNode("SecurityTBASubUrb").text = "";
	            oSec.selectSingleNode("SecurityTBAState").text = "";
	            oSec.selectSingleNode("SecurityTBAPostCode").text = "";
		    	}
		}
		//SecurityTypeChange(-1);
		SecPropStatusChange(-1,bNewPropStatus);
		RefreshPropTypeList(-1,bNewPropStatus);
		SecStatusChange(-1,bNewRec);
		PropPurchClick(-1,bNewRec);
		SecPropUseChange(-1,bNewPropStatus);
		if(bCheckedTBA)
		{
			document.all.ScrSecDetails.all.imgSecurityDtlsTab(1).src = "../images/tabs/security_address_faded.gif";
			document.all.trSecAdrTBA.style.display = "block";
			DisableElement(document.all.chkSecPropPurch, (!bCheckedTBA));
		}			
		else
		{
			var currimg=document.all.ScrSecDetails.all.imgSecurityDtlsTab(1).src;
			if ((sSecTypeCode == "B") && (currimg.indexOf("_faded.gif")>=0))
			{
				document.all.ScrSecDetails.all.imgSecurityDtlsTab(1).src = "../images/tabs/security_address.gif";
				 
				var oDocEl=xml_master.XMLDocument.documentElement;
				var oSecs = oDocEl.selectNodes("Securities/Security");
				if (oSecs.length>0) 
				{ 
					EvaluateAppBRS(oDocEl.selectSingleNode("//Securities"),true);
				}
			}
		   document.all.trSecAdrTBA.style.display = "none";
		   
		}
	}
	catch (e)
	{
		displayError(e,"CheckTBA");
	}
}

//==============================================================
//	Function Name:	clearNonPropSec
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Clear non-property based security fields
//==============================================================
function clearNonPropSec()
{
	try 
	{	
		var oSec = ds_security.XMLDocument.documentElement;
		oSec.selectSingleNode("NatureOfSecurity").text="";
		oSec.selectSingleNode("SecurityDescription1").text="";
		oSec.selectSingleNode("SecurityDescription2").text="";
		oSec.selectSingleNode("AccountNumber").text="";
		oSec.selectSingleNode("CertificateNumber").text="";	
	}
	catch (e)
	{
		displayError(e,"clearNonPropSec");
	}
}

//==============================================================
//	Function Name:	DSSwitch
//	Parameters:		bShow - (boolean) Flag for show or hide
//	Return:			String - "block" or "none"	
//	Description:	returns block or return depending on passed field for display style
//==============================================================
function DSSwitch(bShow)
{
	var sRet = (bShow)? "block": "none";
	return sRet;
}

//==============================================================
//	Function Name:	SecPropStatusChange
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security		
//	Return:			Nil	
//	Description:	Handle Purchase Status change
//==============================================================
function SecPropStatusChange(bFromFile,bNewRec)
{
	try 
	{	
		var sSecPropStatus = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("PropertyStatus").text:document.all("cboSecPropStatus").value;
		//RefreshPropTypeList(sSecPropStatus);
		    	RefreshConstructionDetails(sSecPropStatus);
		//Check is status is established
		//if (!bFromFile || bNewRec) 
		//	(sSecPropStatus=="E")? ds_security.recordset.fields("PropertyZoning").value="R":(ds_security.recordset.fields("PropertyZoning").value="", ds_security.recordset.fields("PropertyType").value="");

		//check if contruction is required
		CheckConstructionReq(sSecPropStatus);
	}
	catch (e)
	{
		displayError(e,"SecPropStatusChange");
	}
}

//==============================================================
//	Function Name:	RefreshPropTypeList
//	Parameters:		sSecPropStatus - (string) Property Status
//	Return:			Nil	
//	Description:	Refresh property type list according to Property status change
//==============================================================
function RefreshPropTypeList(bFromFile, bNewRec)
{
	try 
	{	
		var sSecPropStatus = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("PropertyZoning").text:document.all("cboSecPropZoning").value;
			
		// reload property type Codes list
		if (sSecPropStatus) populateList("A_TS_PROP_TYPE_STATUS", document.all.cboSecPropType, "@STATUS_CODE='" + sSecPropStatus +"'" , 'TYPE_CODE', 'CODE_DESC', false);
		//(sSecPropStatus=="R")? ds_security.recordset.fields("PropertyType").value="R":ds_security.recordset.fields("PropertyType").value="";
		
		if (bFromFile == 0) ds_security.recordset.fields("PropertyType").value="";
		
		//LixiV2 Changes Start
		var sSecPropUse = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("PropertyUse").text:document.all("cboSecPropUse").value;
		if (ds_security.recordset.fields("PropertyZoning").value=='F')
			{
				var sSecPropStatus='R';
			}
			if (ds_security.recordset.fields("PropertyZoning").value=='R')
			{
				var sSecPropStatus='R';
			}
		if ((sSecPropUse=='I') && (sSecPropStatus=='R')) 
		{
	
			DisableElement(document.all.inpSecInvestmentExpense, true);
			DisableElement(document.all.chkShortSty, true);
		}
		else
		{
			DisableElement(document.all.inpSecInvestmentExpense,false);
			ds_security.recordset.fields("SecInvestmentExpense").value="0.00";
			DisableElement(document.all.chkShortSty, false);
			ds_security.recordset.fields("SecShortStay").value="0";
		}
		//LixiV2 Changes End
	}
	catch (e)
	{
		displayError(e,"RefreshPropTypeList");
	}	
}

//==============================================================
//	Function Name:	SecStatusChange
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			Nil	
//	Description:	handle security status change
//==============================================================
function SecStatusChange(bFromFile, bNewRec)
{
	try 
	{	
		var sSecStatus = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("SecurityStatus").text:document.all("cboSecStatus").value;
		var sSecTypeCode = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("SecurityType").text:document.all("cboSecType").value;
		//var oSecType = getSingleRDRow ("A_TS_SEC_TYPES", "@TYPE_CODE='" + sSecTypeCode + "'"); 
		//if (oSecType) var bELAApplicable = (oSecType.getAttribute("ELA_APPLICABLE")!="0");
	
		//Check if status is held 
		//var bEnable = (sSecStatus=="H" && bELAApplicable);
		//WR1970_CMR003 Changed sSecTypeCode != "D" to sSrcTypeCode != "A"
		var bEnable = (sSecStatus=="H" && sSecTypeCode != "A");
		if (!bEnable) ds_security.recordset.fields("ExistingLoanAmount").value="0";
		DisableElement(document.all.inpSecExistLoanAmt, bEnable);
		//WR1970_Defect 125 - To hide "Exisiting ANZ Mortgage Loan Details:" for Security Status = Guarantee
		if (sSecTypeCode == "D") bEnable = false;
		//Show/ Hide Stamping section
		document.all.tblSecStampingDetails.style.display =  DSSwitch(bEnable);
		
	}
	catch (e)
	{
		displayError(e,"SecStatusChange");
	}
}

//==============================================================
//	Function Name:	SecNatureChange
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			Nil	
//	Description:	Handle security nature change
//==============================================================
function SecNatureChange(bFromFile, bNewRec)
{
	try 
	{	
		var sSecNature = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("NatureOfSecurity").text:document.all("cboSecNature").value;
		var bEnableValue=false;
		var bEnableCustStatVal=false;
		var bShared=false;
	
		if (sSecNature)
		{
			var oSecNature = getSingleRDRow ("A_TS_SEC_NATURE_CODES", "@NATURE_CODE='" + sSecNature + "'");
			bShared = (oSecNature.getAttribute("SHARE_MORTGAGE")!="0");	
			if (bShared)
			{
				bEnableValue=true;
				SetPropertyTitleDefaults(0, 0);
			} 
			else
			{
				ds_security.recordset.fields("SecurityValue").value="0";
			}
				
			//Set property based attribute
			ds_security.XMLDocument.documentElement.setAttribute("PropBased",((bShared)? -1:0));
				
			//Set up property based security fields
			SetupPropBasedFields(bShared,-1);
			document.all.tblSecPropTypeDetails.style.display=DSSwitch(bShared);
		}
		//Enable/Disable FMV
		DisableElement(document.all.inpSecFMValue, bEnableValue);
	}
	catch (e)
	{
		displayError(e,"SecNatureChange");
	}
}

//==============================================================
//	Function Name:	CheckConstructionReq
//	Parameters:		sSecPropStatus - (string) Property Status
//	Return:			Nil	
//	Description:	Check if contruction details are required
//==============================================================
function CheckConstructionReq(sSecPropStatus)
{
	try 
	{	
		//get the property status node from refdata
		var oSecPropStatus = getSingleRDRow ("A_TS_PROP_STATUS_CODES", "@STATUS_CODE='" + sSecPropStatus + "'");
		var bConstructReq=false;
		var bConstructReqMajorRenovation = false;
		var oSec = ds_security.XMLDocument.documentElement;
		
		var bProgDraw = (sSecPropStatus)? (ds_security.recordset.fields("MajorRenovation").value=="-1"):document.all.chkSecRenovation.status;
		
		if (oSecPropStatus)
		{
			bConstructReq = (oSecPropStatus.getAttribute("CONSTRUCT_DTLS_REQ")!="0") || bProgDraw ;
			bConstructReqMajorRenovation = bProgDraw;
		
			var EnableImg=".gif";
			if (G_iCurSecTabIdx==3) EnableImg = "_dn.gif";
				
			document.all.ScrSecDetails.all.imgSecurityDtlsTab(3).src = "../images/tabs/" + aSecTabImgs[3] + (((bConstructReq) || (bConstructReqMajorRenovation))? EnableImg:"_faded.gif");
	
		}
		else 
		{
			document.all.ScrSecDetails.all.imgSecurityDtlsTab(3).src = "../images/tabs/" + aSecTabImgs[3] + "_faded.gif";
		}
	
		//Amend or replace the construction details required attribute
		if (!bConstructReq)ds_construction.src=ds_construction.src;
		oSec.setAttribute("ConstructDtlsReq",(bConstructReq)? -1:0);
	
		//set up construction details
		setUpConstructionDtls();
	}
	catch (e)
	{
		displayError(e,"CheckConstructionReq");
	}
}

//==============================================================
//	Function Name:	setUpConstructionDtls
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Set up the construction fields	
//==============================================================
function setUpConstructionDtls()
{
	try 
	{	
		//Get the value of the Reg builder check box
		var sRegBuilder = (ds_construction.recordset.fields("RegisteredBuilder").value!=0)? "Y":"N";
	
		//Get the ref data node for the appropriate reg builder status
		var oConstDtlsOps = getSingleRDRow ("A_TS_CONSTRUCT_DTLS_OPTIONS", "@REGISTERED_BUILDER='" + sRegBuilder + "'");
	
		//Temp attribute value
		var bAllow;
	
		if (oConstDtlsOps)
		{
			//Approval plans held
			bAllow = (oConstDtlsOps.getAttribute("ALW_APPROVAL_HELD")!="0");
			if (!bAllow) ds_construction.recordset.fields("ApprovalHeld").value=0;
			DisableElement(document.all.chkCouncilAppHeld,bAllow);
			
			//Construction Insurance Held
			bAllow = (oConstDtlsOps.getAttribute("ALW_INSURANCE_HELD")!="0");
			if (!bAllow) ds_construction.recordset.fields("ConstructionInsuranceHeld").value=0;
			DisableElement(document.all.chkConstructInsur,bAllow);
			
			//Signed Fixed price contract held
			bAllow = (oConstDtlsOps.getAttribute("ALW_CONTRACT_HELD")!="0");
			if (!bAllow) ds_construction.recordset.fields("SignedFixPriceBuilderContractHeld").value=0;
			DisableElement(document.all.chkFixPriceCont,bAllow);
			
			//Similar project in last 2 years
			bAllow = (oConstDtlsOps.getAttribute("ALW_PROJECT_L2YRS")!="0");
			//Hide/Show second contruction section
			(bAllow)? document.all.tblConstructDtlsNonRegBuilder.style.display = "block":document.all.tblConstructDtlsNonRegBuilder.style.display="none";
			if (!bAllow) ds_construction.recordset.fields("SimilarProjectInLastTwoYears").value=0;
			DisableElement(document.all.chkSimilarProj,bAllow);
			
			//First time builder
			bAllow = (oConstDtlsOps.getAttribute("ALW_FIRST_TIME_BUILDER")!="0");
			if (!bAllow) ds_construction.recordset.fields("FirstTimeBuilder").value=0;
			DisableElement(document.all.chkFirstTimeBuild,bAllow);
			
			//Works in building industry
			bAllow = (oConstDtlsOps.getAttribute("ALW_WRKS_IN_INDUSTRY")!="0");
			if (!bAllow) ds_construction.recordset.fields("WorksInBuildingIndustry").value=0;
			DisableElement(document.all.chkWrkBuildInd,bAllow);
			
			//Other Experience
			bAllow = (oConstDtlsOps.getAttribute("ALW_OTHER_EXPERIENCE")!="0");
			if (!bAllow) ds_construction.recordset.fields("OtherExperience").value=0;
			DisableElement(document.all.chkOthrBldExp,bAllow);
			
			//Costings Held
			bAllow = (oConstDtlsOps.getAttribute("ALW_COSTING_HELD")!="0");
			if (!bAllow) ds_construction.recordset.fields("DetailedCostingsHeld").value=0;
			DisableElement(document.all.chkDtldCostings,bAllow);
			
			//License Held
			bAllow = (oConstDtlsOps.getAttribute("ALW_LICENSE_HELD")!="0");
			if (!bAllow) ds_construction.recordset.fields("BuilderLicenseHeld").value=0;
			DisableElement(document.all.chkRegBuilderLic,bAllow);
			
			//Cash Deposit Held
			bAllow = (oConstDtlsOps.getAttribute("ALW_DEPOSIT_HELD")!="0");
			if (!bAllow) ds_construction.recordset.fields("CashDepositheld").value=0;
			DisableElement(document.all.chkDepHeld,bAllow);	
		}
	}
	catch (e)
	{
		displayError(e,"setUpConstructionDtls");
	}
}

//==============================================================
//	Function Name:	firstMortgageeChange
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			Nil	
//	Description:	Handle changes to the first mortgagee field
//==============================================================
function firstMortgageeChange(bFromFile, bNewRec)
{
	try 
	{	
		var sSecTypeCode = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("SecurityType").text:document.all("cboSecType").value;
		var sFirstMortgagee = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("FirstMortgagee").text:document.all("cboSecFirstMort").value;
		var bEnableOFI = (sSecTypeCode=="C" && sFirstMortgagee=="05");
	
		if (!bEnableOFI) ds_security.recordset.fields("OtherFirstMortgagee").value="";
		DisableElement(document.all.inpSecOtherFinInst,bEnableOFI);
	}
	catch (e)
	{
		displayError(e,"firstMortgageeChange");
	}
}

//==============================================================
//	Function Name:	UnlimitedGuaranteeCheck
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Handle checks of the unlimited guarantee check box
//==============================================================
function UnlimitedGuaranteeCheck()
{
	try 
	{	
		var bCheckedUnlimGuar = (ds_security.recordset.fields("GuaranteeUnlimited").value!=0);
		setGuaranteeDesc(!bCheckedUnlimGuar);
		if (bCheckedUnlimGuar) ds_security.recordset.fields("GuaranteeAmount").value="0";
		DisableElement(document.all.inpSecGuarAmt,!bCheckedUnlimGuar);
	}
	catch (e)
	{
		displayError(e,"UnlimitedGuaranteeCheck");
	}
}

//==============================================================
//	Function Name:	isSharedMortgage
//	Parameters:		sSecTypeCode - (string) Security Type Code
//	Return:			Boolean - Flag stating 	
//	Description:	Returns true if nature of security is shared mortgage
//==============================================================
function isSharedMortgage(sSecTypeCode){
	
	try 
	{	
		var bRetVal=false;
	
		if (sSecTypeCode=="O")
		{
			var sSecNature = ds_security.XMLDocument.documentElement.selectSingleNode("NatureOfSecurity").text;
			var oSecNature = getSingleRDRow ("A_TS_SEC_NATURE_CODES", "@NATURE_CODE='" + sSecNature + "'");
			if (oSecNature)
				bRetVal = (oSecNature.getAttribute("SHARE_MORTGAGE")!="0");
		}
	
		return bRetVal;
	}
	catch (e)
	{
		displayError(e,"isSharedMortgage");
	}
}

//==============================================================
//	Function Name:	updateDescriptions
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Add descriptions from combo boxes
//==============================================================
function updateDescriptions()
{
	try
	{
		var oSec = ds_security.XMLDocument.documentElement;
		
		//Update sec descriptions
		oSec.setAttribute("SecurityTypeDescription",getListText(document.all.cboSecType));
		oSec.setAttribute("SecurityStatusDescription",getListText(document.all.cboSecStatus));
		oSec.setAttribute("NatureOfSecurityDescription",getListText(document.all.cboSecNature));
		oSec.setAttribute("PropertyTypeDescription",getListText(document.all.cboSecPropType));
		oSec.setAttribute("PropertyStatusDescription",getListText(document.all.cboSecPropStatus));
		oSec.setAttribute("PropertyTenureDescription",getListText(document.all.cboSecPropTenure));
		oSec.setAttribute("PropertyZoningDescription",getListText(document.all.cboSecPropZoning));
		oSec.setAttribute("PropertyUseDescription",getListText(document.all.cboSecPropUse));
		oSec.setAttribute("SecurityTitleTypeDescription",getListText(document.all.cboSecTitleType));
		oSec.setAttribute("FirstMortgageeDescription",getListText(document.all.cboSecFirstMort));
		//oSec.setAttribute("StampingTypeDescription",getListText(document.all.cboSecStampType));
		
		
			//Copy Security Address 
		
			var oSecAddress = oSec.selectSingleNode("SecurityAddresses/SecurityAddress[@Linked='-1']")
		
			if (oSecAddress)
			{
				var sAddr = oSecAddress.getAttribute("AddressDetails");
				oSec.setAttribute("AddressDtls",sAddr);
			}
			else
			{
				oSec.setAttribute("AddressDtls","");
			}
		
			
		//Copy Security Amount
		
		//WR1970 - If the SecurityValue field is empty or zero and the value in CustStateValue
		//field is not empty or zero, copy CustStateValue to the SecurityValue column in the
		//Security Summary table. If the SecurityValue field is not zero or empty then display 
		//SecurityValue field in the Security Summary Table
		
		var sCustStatedValue = oSec.selectSingleNode("CustomerStatedValue").text;
		var sSecValue = oSec.selectSingleNode("SecurityValue").text;
		var sSectype = oSec.selectSingleNode("SecurityType").text;
		
		if(sSecValue != "0")
		{
			if(sSectype != "B")
				oSec.setAttribute("Value",VBFormatCurrency(sSecValue,0));
			else
				oSec.setAttribute("Value",VBFormatCurrency(sCustStatedValue,0));
		}
		else
		{
			if(sCustStatedValue != "0")
				oSec.setAttribute("Value",VBFormatCurrency(sCustStatedValue,0));
			else
				oSec.setAttribute("Value","$0");
		}
		//(sSecValue)? oSec.setAttribute("Value",VBFormatCurrency(sSecValue,0)):oSec.setAttribute("Value","$0");
		
	}
	catch (e)
	{
		displayError(e,"updateDescriptions");
	}
}

//==============================================================
//	Function Name:	ShowAddSecurityButton
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Shows or adds the security add button depending on number of secuities added
//==============================================================
function ShowAddSecurityButton()
{
	try
	{
		var nSecs=xml_master.XMLDocument.documentElement.selectNodes("Securities/Security").length;
		document.all.AddSecCmd.style.display = (nSecs<12)? "":"none";
		document.all.MaxSecMsg.style.display = (nSecs>=12)? "":"none";			
	}
	catch (e)
	{
		displayError(e,"ShowAddSecurityButton");
	}
}

//==============================================================
//	Function Name:	SetSecurityDirty
//	Parameters:		Nil
//	Return:			Nil	
//	Description: Signify data has changed
//==============================================================
function SetSecurityDirty()
{
	G_bSecurityDirty=true;

}

//WR1970 - New functions added for version 2

//======================================================================================
//Function Name:	setupAddrConstrTab
//Paramaters:		sSecTypeCode - (string) Security Type Code
//Return:			Nil
//Description:		Disabling the Address and Construction Details tab depending on the
//					Security Type value selected. Also clearing the existing fields
//======================================================================================
function setupAddrConstrTab(sSecTypeCode)
{
	try
	{
			
		if(sSecTypeCode == "B") return;
		
		//Disabling Address and Construction Tab
		if(sSecTypeCode != "D")
			document.all.ScrSecDetails.all.imgSecurityDtlsTab(1).src = "../images/tabs/" + aSecTabImgs[1] + "_faded.gif";
		document.all.ScrSecDetails.all.imgSecurityDtlsTab(3).src = "../images/tabs/" + aSecTabImgs[3] + "_faded.gif";
		
			
		var oSec = ds_security.XMLDocument.documentElement;
		var oCurConstruct=oSec.selectSingleNode("ConstructionDetails");
		if(sSecTypeCode != "D")
		{
			//Clearing address fields
			var oSecAddrs = oSec.selectSingleNode("AddressID");
			if (oSecAddrs)
			{
				var oRepSecAddr = oSecAddrs.cloneNode(false);
				oSec.replaceChild(oRepSecAddr,oSecAddrs);
			}	
		}
		//Clearing Construction fields
		var oConstr = oSec.selectSingleNode("ConstructionDetails");
		if (oConstr)
		{
			var oRepConstr = oConstr.cloneNode(false);
			oSec.replaceChild(oRepConstr,oConstr);
		}
		
		FlushToDisk();
				
	}
	catch(e)
	{
		displayError(e, "setupAddrConstrTab");
	}
}

//============================================================================
//	Function Name:	SecGivenByClick
//	Parameters:		RecNo - (numeric) CustomerID
//	Return:			Nil	
//	Description:	Linking the selected customer to the security
//============================================================================
function SecGivenByClick(RecNo)
{
	try
	{
		if (RecNo-1<0) return;
	
		var oSecDocEl = ds_security.XMLDocument.documentElement;
		var oSecGivenBy=oSecDocEl.selectNodes('SecuritiesGivenBy/SecurityGivenBy');
		var oC = oSecGivenBy(RecNo-1);
		var bLinked=(oC.getAttribute('Linked')=='-1');
				
	}
	catch(e)
	{
		displayError(e, "SecGivenByClick");
	}
}

//===========================================================================================
//	Function Name:	ShowClickHelp
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Showing the click help text depending on the security type value selected
//===========================================================================================
function ShowClickHelp()
{
	try
	{
		var sSecTypeCode = ds_security.recordset.fields("SecurityType").value;
		
		if(sSecTypeCode == "A")
			popup('ANZTermDepositSecurityValue');
		else
			popup('SecurityValue');
	}
	catch(e)
	{
		displayError(e, "ShowClickHelp");
	}
}

//==============================================================
//	Function Name:	SetPropertyTenureDefaults
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			Nil	
//	Description:	Set defaults for the property tenure
//==============================================================
function SetPropertyTenureDefaults(bFromFile, bNewRec)
{
	try 
	{	
		if (!bFromFile || bNewRec)
		{
			var sSecType = (bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("SecurityType").text:document.all("cboSecType").value;
			
			if (sSecType && sSecType == "B")
			{
				var sPropTenureDefault = G_sPropTenureDefault;
				(sPropTenureDefault)? ds_security.recordset.fields("PropertyTenure").value=sPropTenureDefault:ds_security.recordset.fields("PropertyTenure").value="";
			}
		}
	}
	catch (e)
	{
		displayError(e,"SetPropertyTenureDefaults");
	}
}

//==============================================================
//	Function Name:	SetPropertyZoningDefaults
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security	
//	Return:			Nil	
//	Description:	Set defaults for the property zoning
//==============================================================
function SetPropertyZoningDefaults(bFromFile, bNewRec)
{
	try 
	{	
		if (!bFromFile || bNewRec)
		{
			var sSecType = (bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("SecurityType").text:document.all("cboSecType").value;
			
			if (sSecType && sSecType == "B")
			{
				var sPropZoningDefault = G_sPropZoningDefault;
				(sPropZoningDefault) ? ds_security.recordset.fields("PropertyZoning").value=sPropZoningDefault:ds_security.recordset.fields("PropertyZoning").value="";
			}
			
		}
	}
	catch (e)
	{
		displayError(e,"SetPropertyZoningDefaults");
	}
}

//=============================================================================================
//	Name:		CheckExistingLoanAmt
//	Parameters:	None
//	Return:		boolean
//	Purpose:	Checks if the Existing Loan Amount value is changed to a value other than zero.
//=============================================================================================
function CheckExistingLoanAmt()
{
	try
	{
		var oSecNode=ds_security.XMLDocument.documentElement;
		var iSecID = oSecNode.selectSingleNode("SecurityID").text
		var sExistingLoanAmt=oSecNode.selectSingleNode("ExistingLoanAmount").text;
		var bNotZero= (sExistingLoanAmt!=0);
		var bResponse;

		if(!iSecID) return;
				
		if (bNotZero)
		{
			bResponse=window.showModalDialog('ExistingLoanAmtWarn.htm','','dialogHeight:160px;dialogWidth:670px;help:No;resizable:No;status:No;scroll:No;');
			G_bStayInSecScreen=false;
			return(bResponse);
		}
		else
		{
			G_bStayInSecScreen=false;
			return(true);
		}
		
		
	}
	catch (e)
	{
		displayError(e,"CheckExistingLoanAmt");
	}
}

//===================================================================================
//	Name:		setupSecurityDetails
//	Parameters:	sSecTypeCode - (string) Security Type Code
//	Return:		boolean
//	Purpose:	Hiding/Displaying the controls depending on the value selected for Security Type
//===================================================================================
function setupSecurityDetails(sSecTypeCode)
{

	try
	{
		if(sSecTypeCode == "A" )
		{	
			document.all.tblSecValueDetails.style.display = "block";
			document.all.trCustStatedVal.style.display = "none";
			document.all.trInvetsProprncost.style.display = "none";
			document.all.trTranLandVal.style.display = "none";
			// Card - 259 Starts -->
			document.all.trSecLtdVal.style.display = "none";
			// Card - 259 Ends -->

			document.all.trContSaleDate.style.display = "none";
			document.getElementById("spnSecValue").innerHTML = "Security Value $:";
			document.all.tblSecGuaranteeDetails.style.display = "none";
			// Card - 260 Starts tblSecAddInfoDetails
			document.all.trPropIncome.style.display = "none";
			document.all.trPropSize.style.display = "none";
			// Card - 260 Ends
			
		}
		else if(sSecTypeCode == "D")
		{
			document.all.tblSecValueDetails.style.display = "none";
			document.all.tblSecGuaranteeDetails.style.display = "block";
			document.getElementById("spnGuanDtls").innerHTML = "Value Details";
			document.all.trUnGuar.style.display = "none";
			// Card - 259 Starts -->
			document.all.trSecLtdVal.style.display = "none";
			// Card - 259 Ends -->

		}
		else
		{
			document.all.tblSecPropTypeDetails.style.display = "block";
			// Card - 260 Starts tblSecAddInfoDetails
			document.all.trPropIncome.style.display = "block";
			document.all.trPropSize.style.display = "block";
			document.all.trInvetsProprncost.style.display = "block";			
			//ds_security.recordset.fields("SecFloorAreaLand").value= "0";
			//ds_security.recordset.fields("SecRentalIncome").value= "0";
			// Card - 260 Ends
			document.all.tblSecValueDetails.style.display = "block";
			document.all.trCustStatedVal.style.display = "block";
			document.all.trTranLandVal.style.display = "block";
			// Card - 259 Starts -->
			document.all.trSecLtdVal.style.display = "block";
			// Card - 259 Ends -->
			document.all.trContSaleDate.style.display = "block";
			document.getElementById("spnSecValue").innerHTML = "Security value (FMV) $:";
			document.all.tblSecGuaranteeDetails.style.display = "none";
		}
		
	}
	catch(e)
	{
		displayError(e, "setupSecurityDetails");
	}

}

//=============================================================================================
//	Name:		UpdateSecGivenBy
//	Parameters:	oSec - Security Node object
//	Return:		Nil
//	Purpose:	Add/Update Customer Names to SecGivenBy1 and SecGivenBy2.
//=============================================================================================
function UpdateSecGivenBy()
{
	try
	{
		var oSec = ds_security.XMLDocument.documentElement;
				
		var oCusts=oSec.selectNodes("SecuritiesGivenBy/SecurityGivenBy[@Linked='-1']");
		
		oSec.selectSingleNode("SecurityGivenBy1").text = "";
		oSec.selectSingleNode("SecurityGivenBy2").text = "";
		
		if(oCusts.length > 0)
		{
			if(oCusts.length==1)
			{
				var sCustName = oCusts.item(0).getAttributeNode("CustomerName").value;
				oSec.selectSingleNode("SecurityGivenBy1").text = (sCustName!="") ? sCustName:"";
			}
			if(oCusts.length==2)
			{
				var sCustName1 = oCusts.item(0).getAttributeNode("CustomerName").value;
				oSec.selectSingleNode("SecurityGivenBy1").text = (sCustName1!="") ? sCustName1:"";
				var sCustName2 = oCusts.item(1).getAttributeNode("CustomerName").value;
				oSec.selectSingleNode("SecurityGivenBy2").text = (sCustName2!="") ? sCustName2:"";
			}
			if(oCusts.length>2)
			{
				var sLongName = "";
				var arNames;
				var iIndex;
				var sTempName;
				var iLastIndex;
				var sPrimCustName="";
				var sSecCustName="";
				var sGuaCustName="";
				var sCustName="";
				
				for(iIndex=0; iIndex<oCusts.length; iIndex++)
					if(oCusts(iIndex).getAttributeNode("CustomerTypeDescription").value == "Primary Co-owner")
						sPrimCustName = sPrimCustName + oCusts(iIndex).getAttributeNode("CustomerName").value
					else if(oCusts(iIndex).getAttributeNode("CustomerTypeDescription").value == "Other Co-owner" || oCusts(iIndex).getAttributeNode("CustomerTypeDescription").value == "Co-owner")
						sSecCustName = sSecCustName + oCusts(iIndex).getAttributeNode("CustomerName").value + "|";
					else
						sGuaCustName = sGuaCustName + oCusts(iIndex).getAttributeNode("CustomerName").value + "|";
						
				if(sPrimCustName.length>0)
					sCustName = sPrimCustName + "|";
					
				if(sSecCustName.length>0)
					sCustName = sCustName + sSecCustName;
					
				if(sGuaCustName.length>0)
					sCustName = sCustName + sGuaCustName;
					
				for(iIndex=0; iIndex<oCusts.length; iIndex++)
					arNames = arNames + oCusts(iIndex).getAttributeNode("CustomerName").value + "|";
				
				arNames = sCustName.split("|");
								
				for(iIndex=0; iIndex<arNames.length-1; iIndex++)
				{
					sTempName = sLongName + arNames[iIndex];
					
					if(sTempName.length <= 40)
					{
						sLongName = sTempName + ", ";
					}
					else
					{
						iLastIndex = iIndex;
						break;
					}
				}
				sLongName = VBMid(sLongName);
				
				oSec.selectSingleNode("SecurityGivenBy1").text = sLongName;
				
				if(iLastIndex < arNames.length)
				{
					sLongName = "";
					sTempName = "";
					for(iIndex=iLastIndex; iIndex<arNames.length-1; iIndex++)
					{
						sTempName = sLongName + arNames[iIndex];
						
						if(sTempName.length <= 40)
						{
							sLongName = sTempName + ", ";
						}
						else
							break;
					}
					sLongName = VBMid(sLongName);
					oSec.selectSingleNode("SecurityGivenBy2").text = sLongName;
				}
				else
				{
					oSec.selectSingleNode("SecurityGivenBy2").text = "";
				}
			}
		}
		
	}
	catch(e)
	{
		displayError(e, "UpdateSecGivenBy");
	}
}
//WR1970_CMR004
//=============================================================================================
//	Name:		PropStatusPopulate
//	Parameters:	blnFromScreen - Indicates whether the function is being called from the screen
//	Return:		Nil
//	Purpose:	Populating the Property Status dropdown menu depending on the status of Off The 
//				Plan checkbox.
//=============================================================================================
function PropStatusPopulate(blnFromScreen)
{
	try
	{
		var sCriteria="";
		if((ds_security.recordset.fields("PurchaseOffThePlan").value == "-1") && (ds_security.recordset.fields("PropertyPurchase").value == "-1"))
		{
			sCriteria = "@STATUS_CODE='N' or @STATUS_CODE='B'";				
			populateList("A_TS_PROP_STATUS_CODES", document.all.cboSecPropStatus, sCriteria, 'STATUS_CODE', 'CODE_DESC', false);
		}
		else
		{
			populateList("A_TS_PROP_STATUS_CODES", document.all.cboSecPropStatus, null, 'STATUS_CODE', 'CODE_DESC', false); 
		}
		//To display blank for property status and property type, when the Off the plan checkbox value changes.
		if(blnFromScreen == true)
		{
			ds_security.recordset.fields("PropertyStatus").value = "";
			ds_security.recordset.fields("PropertyType").value = "";
		}
		 
	}
	catch(e)
	{
		displayError(e, "PropStatusPopulate");
	}
}
//==============================================================
//	Function Name:	SearchTBAAddress
//	Parameters:		Nil
//	Return:			
//	Description:	
//==============================================================
function SearchAddressTBA()
{
	try
	{
    
		var sCity = ds_security.XMLDocument.documentElement.selectSingleNode("SecurityTBASubUrb").text;
		if (sCity)
		{
			var oReturn =  window.showModalDialog("CityStatePostcodeSelector.html", sCity, "dialogHeight:335px;dialogWidth:550px;help:No;resizable:No;status:No;scroll:No;");
			if (oReturn) { 
			oResults = oReturn.split(';');
			var oAdr = ds_security.XMLDocument.documentElement
			oAdr.selectSingleNode("SecurityTBASubUrb").text =oResults[0];
			oAdr.selectSingleNode("SecurityTBAState").text=oResults[1];
			oAdr.selectSingleNode("SecurityTBAPostCode").text =oResults[2];
			}
		}
		else
		{
			VBMsgBox("Please enter part of the city, town or suburb name into the 'City' field.", G_iVB_WARNING, G_sAPPLICATION_TITLE);
			return;
		}


	}
	catch (e)
	{
	    displayError(e, "SearchAddressTBA");
	}
}
//==============================================================
//	Function Name:	fnShowClickHelp
//	Parameters:		None
//	Return:			None
//	Description:	Used to display the related click help for 
//					"City/Suburb, State and Postcode combination" text.
//==============================================================
function fnShowClickHelp()
{
	try
	{
		if(G_bSecAddress)
		{
			popup('CityStatePostcodeComboSecurity');
		}
		else
		{
			popup('CityStatePostcodeComboCustomer');
		}
	}
	catch (e)
	{
		displayError(e,"fnShowClickHelp");
	}
}

//==============================================================
//	Function Name:	SecPropUseChange
//	Parameters:		bFromFile - (boolean) Flag indicating if called from file
//					bNewRec - (boolean) flag indicating if new security		
//	Return:			Nil	
//	Description:	Handle Purchase Status change
//==============================================================
function SecPropUseChange(bFromFile,bNewRec)
{
	try 
	{	
		var sSecPropUse = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("PropertyUse").text:document.all("cboSecPropUse").value;
		
		if (!(sSecPropUse=="I")) ds_security.recordset.fields("SecRentalIncome").value="0.00";
		DisableElement(document.all.inpSecOfRentalIncome,(sSecPropUse=="I"));
		//LIXIV2 Changes Start
		var sSecPropZone = (bFromFile || bNewRec)? ds_security.XMLDocument.documentElement.selectSingleNode("PropertyZoning").text:document.all("cboSecPropZoning").value;
		//var bEnableDisableInvst=((sSecPropUse=="I") && (sSecPropZone=="R"))
		if (ds_security.recordset.fields("PropertyZoning").value=='F' )
			{
				var sSecPropZone='R';
			}
			if (ds_security.recordset.fields("PropertyZoning").value=='R')
			{
				var sSecPropZone='R';
			}
			if ((sSecPropUse=='I') && (sSecPropZone=='R')) 
			{
				DisableElement(document.all.inpSecInvestmentExpense,true);
				DisableElement(document.all.chkShortSty,true);
			}
			else
			{
				DisableElement(document.all.inpSecInvestmentExpense,false);
				ds_security.recordset.fields("SecInvestmentExpense").value="0.00";
				DisableElement(document.all.chkShortSty,false);
				ds_security.recordset.fields("SecShortStay").value="0";
				
			}
		//LIXIV2 Changes End
				
	}
	catch (e)
	{
		displayError(e,"SecPropUseChange");
	}
}


//==============================================================
//	Function Name:	setSecLtdValue
//	Parameters:	Nil
//	Return:			Nil
//	Description:	Setup Sec Limited value of GuaranteeAmt
//			in Reg. Mortg based on same address.
//==============================================================
function setSecLtdValue()
{
	try 
	{	
		var objSec = ds_security.XMLDocument.documentElement;
		var oDocEl=xml_master.XMLDocument.documentElement;

		//if Security exists then proceed
		if (oDocEl.selectSingleNode('Securities/Security'))
		{
			if (objSec != null)
			{
			if('B' == objSec.selectSingleNode('SecurityType').text)
			{
			
				var oGuaranteeAmt = 0;	
				var oSecGuaranteeList = oDocEl.selectNodes('Securities/Security[SecurityType="D"]');
				for (var i=0; i<oSecGuaranteeList.length; i++)
				{	
					//var sSecAddrID=oSecGuaranteeList(i).selectSingleNode('SecurityID').text;
					var sSecAddrID=oSecGuaranteeList(i).selectSingleNode('AddressID').text;
					if (sSecAddrID)
					{
						if(objSec.selectSingleNode('AddressID').text==sSecAddrID)
						{	
							oGuaranteeAmt += parseInt(oSecGuaranteeList(i).selectSingleNode('GuaranteeAmount').text);
						}				
					}
				}
				ds_security.recordset.fields("SecurityLimitedValue").value=oGuaranteeAmt;
			}
			}
		}
	}
	catch (e)
	{
		displayError (e,"setSecLtdValue");
	}
}

//==============================================================
//	Function Name:	RefreshConstructionDetails
//	Parameters:		sSecPropStatus - (string) Property Status
//	Return:			Nil	
//	Description:	Refresh property type list according to Property status change
//==============================================================

 function RefreshConstructionDetails(sSecPropStatus)
{
  try
   {
    var datarow = document.getElementById('tblConstructiondtls').rows;
	if (document.getElementById("inpSecBuildCntractAmt").value != "0")
	{
		document.getElementById("inpSecBuildCntractAmt").value = "0";
		for(var i=1;i<datarow.length;i++)
		{
			var chkBox = datarow[i].getElementsByTagName("input")[0];
			if(chkBox.type == "checkbox")
			{
			  chkBox.checked = false;
			}
		}
	}
  }
   catch(e)
   {
    displayError(e,"RefreshConstructionDetails");
   }
}
