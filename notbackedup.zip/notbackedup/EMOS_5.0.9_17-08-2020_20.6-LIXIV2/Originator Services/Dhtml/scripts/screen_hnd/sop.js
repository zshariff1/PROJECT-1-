	//<SCRIPT>
//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.7  $
//	$Author:   valana  $
//	$Workfile:   sop.js  $
//	$Modtime:   Jan 04 2013 20:25:36  $	
//============================================================-->

//===========================
// Declare global variables
//===========================
var G_bSOPDirty = false;
var G_SelectedStatement = 0;
var G_iCurStatementTabIdx = 0;
var GSecIPRCExpns=0;
// The array of img name used when switching tab
var aStatementTabImgs = Array ('create_sp', 'assets', 'liabilities', 'income', 'expenditure');


//=====================================================================
//	Function Name:	StatementScreenShow
//	Parameters:		nil
//	Return:			nil
//	Description:	Used when clicking the menu item to show HTML with
//						- Totols calculation
//						- Removal of any unrelated customers
//						- Show/Hide [Add S/P] button 
//=====================================================================
function StatementScreenShow()
{
	try
	{
		//Calculate all totals after PAYE has changed in Customer screen
		var oSPs = xml_master.XMLDocument.documentElement.selectSingleNode('StatementsOfPosition');
		var oSPCustsOld, oSPCustsNew;
		//initilize SPCustomers with XSL, calculate totals and remove cutomer unrelated for all SOPs
		for (var i=0;i<oSPs.childNodes.length; i++)
		{
			oSPs.childNodes(i).setAttribute('current','1');
			xml_master.XMLDocument.documentElement.transformNodeToObject(xsl_SPCustRefresh.XMLDocument, xml_temp.XMLDocument);
			oSPs.childNodes(i).setAttribute('current','0')
			oSPCustsOld=oSPs.childNodes(i).selectSingleNode('SPCustomers');
			oSPCustsNew=xml_temp.XMLDocument.documentElement.cloneNode(true);
			oSPs.childNodes(i).replaceChild(oSPCustsNew,oSPCustsOld);
				
			CalculateTotals(oSPs.childNodes(i));
				
			for (var c=oSPCustsNew.childNodes.length-1; c>=0; c--)
				if (oSPCustsNew.childNodes(c).getAttribute('Related')!='-1') oSPCustsNew.removeChild(oSPCustsNew.childNodes(c));
		}
		var oSOPs = xml_master.XMLDocument.documentElement.selectSingleNode("//StatementsOfPosition");
		var oSOP = oSOPs.selectNodes("StatementOfPosition");
		for (i=0;i<=oSOP.length-1;i++)
		{
			var sSPIDs = oSOP(i).selectSingleNode('StatementOfPositionID').text;
			SelectStatement(sSPIDs,false,true);
		}
		
		G_pScreenSaveFunction = SaveStatement;
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		var oN = xml_master.XMLDocument.selectSingleNode('//StatementOfPosition');
		if (oN) 
			SelectStatement(1,false,true);
		else
		{
			G_SelectedStatement=0;
			document.all.tblStatementTab.style.display = 'none';
		}
		ShowAddSPButton();
	}
	catch (e)
	{
		displayError(e,'StatementScreenShow');	
	}
}


//==========================================================
//	Function Name:	AddStatement
//	Parameters:		nil
//	Return:			nil
//	Description:	When click [Add S/P] button
//						- Remove empty child nodes
//						- Allocate StatementOfPositionID
//						- Show/Hide [Add S/P] button
//						- Select the current statement
//==========================================================  
function AddStatement()
{
	try
	{
		if (G_SelectedStatement>0) SaveStatement();
		var oSPs = xml_master.XMLDocument.documentElement.selectSingleNode('//StatementsOfPosition');
		ds_statement.src=ds_statement.src;
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		//initilize - Remove children of SPCustomers, Assets, Liabilities, Incomes, Expenses
		var oStDoc=ds_statement.XMLDocument.documentElement;
		var remNodes = oStDoc.selectSingleNode('SPCustomers');
		remNodes.removeChild(remNodes.childNodes(0));
		remNodes = oStDoc.selectSingleNode('Assets');
		remNodes.removeChild(remNodes.childNodes(0));
		remNodes = oStDoc.selectSingleNode('Liabilities');
		remNodes.removeChild(remNodes.childNodes(0));
		remNodes = oStDoc.selectSingleNode('Incomes');
		remNodes.removeChild(remNodes.childNodes(0));
		remNodes = oStDoc.selectSingleNode('Expenses');
		remNodes.removeChild(remNodes.childNodes(0));

		var oNewSP = oStDoc.cloneNode(true);
		InitilizeAppBRS(oNewSP);
		//set id
		oNewSP.selectSingleNode('StatementOfPositionID').text = allocateNewID('maxStatementOfPositionID');
	
		// Insert the new statement template from the stub to the master
		oSPs.appendChild(oNewSP);
		var RecNo = oSPs.childNodes.length;
	
		if (oSPs.childNodes.length==1) document.all.tblStatementTab.style.display='block';

		ShowAddSPButton();
			
		SelectStatement(RecNo, true,true);
	}
	catch (e)
	{
		displayError(e,'AddStatement');
	}
}


//================================================================================
//	Function Name:	SelectStatement
//	Parameters:		recNo - the selected item 
//					newRec - not used
//					bFromScreen - whether from selecting the record from screen 
//									or under another function  
//	Return:			nil
//	Description:	When select the statement including initialising SPCustomers & 
//						Incomes from XSLs and Calculate the total.
//=================================================================================
function SelectStatement(recNo, newRec, bFromScreen)
{
	try
	{
		if (G_SelectedStatement>0) SaveStatement(true);
		//WR4354 - To add an Breakfree Credit card liability
	    	AddUpdLiability();	
		var oSPs = xml_master.XMLDocument.documentElement.selectSingleNode('//StatementsOfPosition');
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		if (recNo > oSPs.childNodes.length) recNo = oSPs.childNodes.length;
		if ((!recNo)&&(oSPs.childNodes.length)) recNo = 1;
			
		G_SelectedStatement = recNo;
		if (!recNo) return; 
	
		var oSelected = oSPs.childNodes(recNo-1);
		ds_statement.XMLDocument.async=false;
		ds_statement.src = ds_statement.src;
		ds_statement.XMLDocument.replaceChild(oSelected.cloneNode(true),ds_statement.XMLDocument.documentElement);
		var oSPDocEl = ds_statement.XMLDocument.documentElement;
	
		if (oSPDocEl.selectSingleNode('SPDescription').text=='New Entry')
			oSPDocEl.selectSingleNode('SPDescription').text='';
	
		document.all.tblStatementTab.style.display='block';

		if (bFromScreen) 
		{	
			SwitchStatementTab(0);
			SetFocusOnElement("inpSPDate");
		}

		//initilize SPCustomers with XSL
		oSelected.setAttribute('current','1');
		xml_master.XMLDocument.documentElement.transformNodeToObject(xsl_SPCustRefresh.XMLDocument, xml_temp.XMLDocument);
		oSelected.setAttribute('current','0')
		var oSPCustsOld=oSPDocEl.selectSingleNode('//SPCustomers');
		var oSPCustsNew=xml_temp.XMLDocument.documentElement.cloneNode(true);
		ds_statement.XMLDocument.documentElement.replaceChild(oSPCustsNew,oSPCustsOld);
	
	//WR1970 - To display the Income Type in the format "<Type> - <Status> - <Customer full Name>" - Start

		//Commented - Start
		/* 
		//add PAYE from SPCustomer to Income
		var oIncomes = ds_statement.XMLDocument.documentElement.selectSingleNode('Incomes');
		var oIncome = ds_statement_temp.XMLDocument.documentElement.selectSingleNode('Incomes/Income');
		var oIncomeNew, sAmount;
		for (var c=oSPCustsNew.childNodes.length-1; c>=0; c--)
		{
			if (oSPCustsNew.childNodes(c).getAttribute('Related')!='-1') continue;
	
			sAmount = GetCustomerPAYEIncome(oSPCustsNew.childNodes(c));
			if (!sAmount) continue;
			
			oIncomeNew = oIncome.cloneNode(true);
			oIncomeNew.setAttribute('TypeDescription', 'PAYE - '+oSPCustsNew.childNodes(c).getAttribute('CustomerName'));
			oIncomeNew.childNodes(1).text = sAmount;
			oIncomeNew.setAttribute('fmtAmount', VBFormatCurrency(sAmount,0));
			oIncomes.insertBefore(oIncomeNew, oIncomes.childNodes(0));	
		}
		*/  
		//Commented - End
			
		var oSDocEl = ds_statement.XMLDocument.documentElement;
		var oSPCusts=oSDocEl.selectNodes('SPCustomers/SPCustomer');
					
		//To loop through all the customers.
		var intCount;
		for(intCount=0;intCount<=oSPCusts.length-1;intCount++)
		{			
			var oC = oSPCusts.nextNode;
			var bRelated=(oC.getAttribute('Related')=='-1');
			IncomeFormat(oC, oSDocEl, bRelated);
		}
		
	//WR1970 - To display the Income Type in the format "<Type> - <Status> - <Customer full Name>" - End
	//WR1970 - To add the expenses corresponding to Liabilities - Start
		AddUpdExpenses();
	//WR1970 - To add the expenses corresponding to Liabilities - End	
	
	//Card : 395 - To add the Income corresponding to Asset. - Start
		AddUpdIncomesByAsset();
	//Card : 395 - To add the Income corresponding to Asset. - End
	
		//set SOP row selector
		SetRowSelectors(document.all.inpStatementRowSelector,recNo); 
		
		var oAssetsNode = ds_statement.XMLDocument.documentElement.selectSingleNode("Assets");
		ValAssetsUpgrade(oAssetsNode);
		
		var oLiabilitiesNode = ds_statement.XMLDocument.documentElement.selectSingleNode("Liabilities");
		ValLiabilitiesUpgrade(oLiabilitiesNode);
		
		// CFDS -672 Starts
		var oIncomeNode = ds_statement.XMLDocument.documentElement.selectSingleNode("Incomes");
		ValIncomeUpgrade(oIncomeNode);
		// CFDS - 672 Ends
		Residential_Investment_Property_Running_Cost();
	}
	catch (e)
	{
		displayError(e,'SelectStatement');
	}
}


//==========================================================
//	Function Name:	DeleteStatement
//	Parameters:		recNo - the specified item
//	Return:			nil
//	Description:	When delete SP record:
//						- Delete the record
//						- Reselect record
//						- Show/Hide the [Add S/P] button
//						- Validate
//						- FlushToDisk
//========================================================== 
function DeleteStatement(recNo)
{
	try
	{
		if (!ConfirmDelete()) return;
	
		var oSPs = xml_master.XMLDocument.documentElement.selectSingleNode('//StatementsOfPosition');
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		var iCurrentSelected = G_SelectedStatement;
	
		//find which one to select after deleting
		var iReselect = iCurrentSelected
		if (iCurrentSelected > recNo) iReselect = iReselect - 1;
		var bFirstTab=false;
		if (iCurrentSelected!=recNo) SaveStatement()		
			else bFirstTab=true;
					
		var oRemove = oSPs.childNodes(recNo-1);
		oSPs.removeChild(oRemove);

		if (oSPs.childNodes.length)
			SelectStatement(iReselect,false,bFirstTab);
		else
		{
			//hide SP details tabs
			tblStatementTab.style.display='none';
			G_SelectedStatement=0;
		}		
	
		ShowAddSPButton();
	
		EvaluateAppBRS(oSPs,true);
		EvaluateAppBRS(xml_master.XMLDocument.documentElement,true);
		FlushToDisk();	
		Residential_Investment_Property_Running_Cost();
	}
	catch (e)
	{
		displayError(e,'DeleteStatement');	
	}
}


//====================================================================
//	Function Name:	SaveStatement
//	Parameters:		NoReselect - whether to select record after save
//					bSaveOnCustomerLink - not used
//	Return:			nil
//	Description:	Wnen click Save - including 
//					- Remove unrelated customers and PAYE incomes
//					- Calculate Total fields then save to master xml
//					- Validation
//					- FlushToDisk
//===================================================================== 
function SaveStatement(NoReselect, bSaveOnCustomerLink)
{
	try
	{
		if (!G_bSOPDirty) return;
			
		//set ID
		var SPID = ds_statement.recordset.fields('StatementOfPositionID').value;
		var oSP = ds_statement.XMLDocument.documentElement;
	
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		
		var oMDocEl = xml_master.XMLDocument.documentElement;
		
		
		
		//remove SPcustomers not related to this statement 
		if (bSaveOnCustomerLink!='N')
		{
		var oSPCusts = oSP.selectNodes('//SPCustomer');
		for (var c=oSPCusts.length-1; c>=0; c--)
			if (oSPCusts(c).getAttribute('Related')!='-1') oSPCusts(c).parentNode.removeChild(oSPCusts(c));
		}
		//remove PAYE Incomes (IncomeType is null and TypDecription not 'PAYE') from this statement
		var oIncomes = oSP.selectNodes('//Income');
	
	//WR1970 - Added another condition for the if statement - Start
		for (var i=0; i<oIncomes.length; i++)
		{
			//if (!oIncomes(i).childNodes(0).text && (oIncomes(i).getAttribute('TypeDescription').indexOf('PAYE')!=-1) oIncomes(i).parentNode.removeChild(oIncomes(i));
			if (!oIncomes(i).childNodes(0).text && (oIncomes(i).getAttribute('TypeDescription').indexOf('PAYE')!=-1 || oIncomes(i).getAttribute('TypeDescription').indexOf('SE')!=-1)) oIncomes(i).parentNode.removeChild(oIncomes(i));
		}
	//WR1970 - Added another condition for the if statement - End
	
	//WR1970 - To pass Yes/No for 'LiabilityToContinue' field to MOS depending on 'LiabToClrFrmLn' field value - Start
		var oLiability = oMDocEl.selectNodes('//StatementsOfPosition/StatementOfPosition/Liabilities/Liability');
		for(var j=0; j<oLiability.length; j++)
		{	
			if(oLiability(j).selectSingleNode("LiabToClrFrmLn").text == "0")
			{
				oLiability(j).selectSingleNode("LiabilityToContinue").text = "-1";
			}
			else if(oLiability(j).selectSingleNode("LiabToClrFrmLn").text == "-1")
			{
				oLiability(j).selectSingleNode("LiabilityToContinue").text = "0";
			}
		}
	//WR1970 - To pass Yes/No for 'LiabilityToContinue' field to MOS depending on 'LiabToClrFrmLn' field value - End	
	
		//calculate all totals
		CalculateTotals(oSP); 

		RefreshPercentageSplitup();

		//save statement to master
		var oNewSP = oSP.cloneNode(true);
		var xPath = '//StatementsOfPosition/StatementOfPosition[StatementOfPositionID=' + SPID + ']';
		var oReplSP = oMDocEl.selectSingleNode(xPath);
		if (oReplSP)
			oMDocEl.selectSingleNode("StatementsOfPosition").replaceChild(oNewSP,oReplSP);
	
		EvaluateAppBRS(oNewSP);
		EvaluateAppBRS(oMDocEl.selectSingleNode('StatementsOfPosition'),true);
		
		// Added for Re-valuating the Security Screen - Starts
		var oSecs;
		oSecs = oMDocEl.selectSingleNode("Securities");
		if (oSecs.childNodes.length>0) {
			EvaluateAppBRS(oMDocEl.selectSingleNode("//Securities"));
		}
		// Added for Re-valuating the Security Screen - Ends
		EvaluateAppBRS(oMDocEl,true);
		G_bSOPDirty=false;
		FlushToDisk();
	
		if (!NoReselect) SelectStatement(G_SelectedStatement);
	}
	catch (e)
	{
		displayError(e,'SaveStatement');
	}
}


//=============================================================
//	Function Name:	SwitchStatementTab
//	Parameters:		iTabIdx
//					sFocusControl
//	Return:			nil
//	Description:	When switching tab
//=============================================================
function SwitchStatementTab(iTabIdx, sFocusControl)
{
	try
	{	
		var oTabs = document.all.ScrStatement.all.StatementTab;		// Statement of Position tabs
	
		if (G_iCurStatementTabIdx != null)
		{
			oTabs(G_iCurStatementTabIdx).style.display = 'none';
			document.all.ScrStatement.all.imgStatementTab(G_iCurStatementTabIdx).src = '../images/tabs/' + aStatementTabImgs[G_iCurStatementTabIdx] + '.gif';
			document.all.ScrStatement.all.imgStatementTab(G_iCurStatementTabIdx).style.cursor = 'hand';
		}
			
		oTabs(iTabIdx).style.display = 'block';
		document.all.ScrStatement.all.imgStatementTab(iTabIdx).src = '../images/tabs/' + aStatementTabImgs[iTabIdx] + '_dn.gif';
		document.all.ScrStatement.all.imgStatementTab(iTabIdx).style.cursor = 'default';
		G_iCurStatementTabIdx = iTabIdx;
		window.scrollTo(0,0); 
		if (sFocusControl && document.all(sFocusControl)) document.all(sFocusControl).focus();
	}
	catch (e)
	{
		displayError(e,'SwitchStatementTab');	
	}
}


//===========================================================================================
//	Function Name:	AddUpdateSPChildren
//	Parameters:		recNo		- Add when the value is 0.  Otherwise, Edit the exiting record.
//					sNodeNm		- ie. Assets, Liabilities, Incomes & Expenses
//					sChildNm	- ie. Asset, Liability, Income & Expense
//					sURL		- html for Add/Edit data
//	Return:			nil
//	Description:	This function is generic to S/P used when Add/Edit Asset, Liabilty, 
//					Income and Expense.  It pops up a window for editing - passing data (xml)
//					as window parameter and return the data to the fumction.
//					SaveStatment() is call at the end of the function. 
//===========================================================================================
function AddUpdateSPChildren(recNo, sNodeNm, sChildNm, sURL)
{
	try
	{
		var oItems = ds_statement.XMLDocument.documentElement.selectSingleNode(sNodeNm);
		var oEdtItem;
		var oRepl;
		var dHeight='500px';
		var oObjArrParam = new Array();
		var oDocMEle = xml_master.XMLDocument.documentElement;
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		var oAddrsNew;
		
		switch (sNodeNm)
		{
			case 'Assets': 
				dHeight='237px';
				break;
			case 'Liabilities':
			//WR1970 - Height for the popup window changed due to addition of 2 more fields - Start
				//dHeight='240px';
				dHeight='360px';
			//WR1970 - Height for the popup window changed due to addition of 2 more fields - End
				break;
			case 'Incomes':
				dHeight='154px';
				break;
			case 'Expenses':
				dHeight='205px';
				break;
		}
		if (recNo)
		{	// Edit existing record
			oRepl = oItems.childNodes(recNo-1);		// Because childNodes index begin at 0.
			if ((sNodeNm=='Expenses') || (sNodeNm=='Assets'))
			{	// Get all Expense records
				oItems.setAttribute('RecIndex', recNo-1);
				oEdtItem = oItems.cloneNode(true);
			}
			else
			{	// Get only edit record
				oEdtItem = oRepl.cloneNode(true);		
				if((oAddrsNew != null) && (sNodeNm == "Liabilities")){
						oEdtItem.appendChild(oAddrsNew);
					}
			}
		}
		else
		{	// Add new record
			if (sNodeNm=='Expenses'||sNodeNm=='Assets')
			{	// Create a new empty record and get all Expense records
				oRepl = ds_statement_temp.XMLDocument.documentElement.selectSingleNode(sNodeNm+'/'+sChildNm).cloneNode(true);
				oItems.setAttribute('RecIndex', '-1');
				oEdtItem = oItems.cloneNode(true);
				oEdtItem.insertBefore(oRepl, oEdtItem.childNodes(0));			
			}
			else
			{	// Create a new empty record
				oEdtItem = ds_statement_temp.XMLDocument.documentElement.selectSingleNode(sNodeNm+'/'+sChildNm).cloneNode(true);
				if((oAddrsNew != null) && (sNodeNm == "Liabilities")){
						oEdtItem.appendChild(oAddrsNew);
				}
			}
		}

    var sEdtItemType
    switch (sNodeNm) {
        case 'Assets':
            sEdtItemType = 'Asset';
            break;
        case 'Liabilities':
            sEdtItemType = 'Liability';
            break;
        case 'Incomes':
            sEdtItemType = 'Income';
            break;
        case 'Expenses':
            sEdtItemType = 'Expense';
            break;
    }

    //We need to pass the address only for Assets and Liabilities
    if (sEdtItemType == 'Asset' || sEdtItemType == 'Liability') 
	{
		if (sEdtItemType == 'Asset') {
            oEdtItem.setAttribute("ParentSPID", ds_statement.XMLDocument.documentElement.selectSingleNode("StatementOfPositionID").text);
        }
        //Creating an array to pass both item to edit and the Mater XML
		if((oEdtItem != null) || (oEdtItem != undefined))
		{
			oObjArrParam[0] = oEdtItem;
		}
		var oMDocElAdd = xml_master.XMLDocument.documentElement;
        if((oMDocElAdd != null) || (oMDocElAdd != undefined))
		{
			oObjArrParam[1] = oMDocElAdd.cloneNode(true);
		}
		if((recNo != null) || (recNo != undefined) || (recNo != ""))
		{
			oObjArrParam[2] = recNo;
		}
		
		var oObjParamOut = window.showModalDialog(sURL, oObjArrParam, 'dialogHeight:' + dHeight + ';dialogWidth:700px;help:No;resizable:No;status:No;scroll:No;');

        if (oObjParamOut == null) return null;
        var SOPChildPassed = oObjParamOut.documentElement.selectSingleNode(sEdtItemType);

        //Update the address only for Assets and Liabilities
        var AddressNodesFromPopup = oObjParamOut.documentElement.selectSingleNode("Addresses");
        var xPathAddr = '//Application/Addresses';
		var oReplAddr = xml_master.XMLDocument.documentElement.selectSingleNode(xPathAddr);

        xml_master.XMLDocument.documentElement.replaceChild(AddressNodesFromPopup, xml_master.XMLDocument.documentElement.selectSingleNode(xPathAddr));
        SetMaxAddrID();

        if (SOPChildPassed == null) return null;
        else {
            oEdtItem = SOPChildPassed;
        }

    }
    else {
		oEdtItem = window.showModalDialog(sURL, oEdtItem, 'dialogHeight:' + dHeight + ';dialogWidth:700px;help:No;resizable:No;status:No;scroll:No;');
    }
	
	// CFDS - 672 -- When applicant is un-employed he/she can select Govt Benefits income fields - Starts	
	/* else if (sEdtItemType == 'Income') 
	{
		
		//Creating an array to pass both item to edit and the Mater XML
		if((oEdtItem != null) || (oEdtItem != undefined))
		{
			oObjArrParam[0] = oEdtItem;
		}
		var oMDocElAdd = xml_master.XMLDocument.documentElement;
        if((oMDocElAdd != null) || (oMDocElAdd != undefined))
		{
			oObjArrParam[1] = oMDocElAdd.cloneNode(true);
		}
		
		//Creating an array to pass both item to edit and the Mater XML
        var oObjParamOut = window.showModalDialog(sURL, oObjArrParam, 'dialogHeight:' + dHeight + ';dialogWidth:700px;help:No;resizable:No;status:No;scroll:No;');
		if (oObjParamOut == null) return null;
		
		var SOPChildPassed = oObjParamOut.documentElement.selectSingleNode(sEdtItemType);
		//alert("SOP OUTPUT==> " + SOPChildPassed.xml);
		if (SOPChildPassed == null) {return null;}
        else {
			oEdtItem = SOPChildPassed;
		}
    } */
	// CFDS - 672 -- When applicant is self employed he/she cannot select Bonus and Commission income fields - Ends

		if (oEdtItem==null) return null;
				
		if (recNo) 
		{
			oItems.replaceChild(oEdtItem,oRepl);
		}
		else 
		{
			oItems.appendChild(oEdtItem);
		}

		if(sNodeNm == "Liabilities") AddUpdExpenses();
		if(sNodeNm == "Assets") AddUpdIncomesByAsset();
		
		G_bSOPDirty=true;	
		SaveStatement();
		if(sNodeNm == "Assets") 
		{
			Residential_Investment_Property_Running_Cost();
			
		}
		
	}
	catch (e)
	{
		displayError(e,'AddUpdateSPChildren');	
	}
}

//=================================================================================
//	Function Name:	DeleteSPChildren
//	Parameters:		recNo - spacified item
//					sXPath - path of the item in ds_statement to be removed
//	Return:			nil
//	Description:	This function is generic to S/P 
//					- used for deleting Asset, Liability, Income or Expense
//					depending on the paramenter sXPath. 
//=================================================================================
function DeleteSPChildren(recNo, sXPath)
{
	try
	{
		//confirm deletion
		//WR1970 - To make the delete confirmation consistent throughout the application
		if(!ConfirmDelete()) return;
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		//remove the item from current dso
		var oItems = ds_statement.XMLDocument.documentElement.selectSingleNode(sXPath);
		oItems.removeChild(oItems.childNodes(recNo-1));
	//WR1970 - To delete the corresponding expense record when a liability is deleted - Start
		if(sXPath == "Liabilities") 
		{	
			AddUpdExpenses();
		}
	//WR1970 - To delete the corresponding expense record when a liability is deleted - Start
	
	//Card : 395 - To delete the corresponding Income record when a Asset record is deleted. - Start
		if(sXPath == "Assets") 
		{	
			AddUpdIncomesByAsset();
		}
	//Card : 395 - To delete the corresponding Income record when a Asset record is deleted. - End
		G_bSOPDirty=true;	
		SaveStatement();
		if(sXPath == "Assets") 
		{
		Residential_Investment_Property_Running_Cost();
		}
	}
	catch (e)
	{
		displayError(e,'DeleteSPChildren');	
	}
}	


//===========================================================================
//	Function Name:	CalculateTotals
//	Parameters:		oSPNode - <StatementOfPosition> node
//	Return:			nil
//	Descriiption:	Calculate all totals of the <StatementOfPosition> node.
//===========================================================================
function CalculateTotals(oSPNode)
{
	try
	{
		var sAmount = CalculateSPTotal(oSPNode, 'Assets/Asset/AssetValue');
		var cursym = "$";
		
		oSPNode.setAttribute('TotAsset', sAmount);
		oSPNode.setAttribute('fmtTotAsset', VBFormatCurrency(sAmount,0));
	
		sAmount = CalculateSPTotal(oSPNode, 'Liabilities/Liability/AmountOwing');
		oSPNode.setAttribute('TotLiability', sAmount);
		oSPNode.setAttribute('fmtTotLiability', VBFormatCurrency(sAmount,0));
	
		sAmount = CalculateSPTotal(oSPNode, 'Incomes/Income/NetMonthlyIncome') + CalculateIncomePAYE(oSPNode);
		oSPNode.setAttribute('TotIncome', sAmount);
		oSPNode.setAttribute('fmtTotIncome', cursym.concat(parseFloat(sAmount).toFixed(2)));
				
		var oSPCusts = oSPNode.selectNodes('SPCustomers/SPCustomer');
		var totSecInc=0;
		for (var i=0; i<oSPCusts.length; i++)
			if (oSPCusts(i).getAttribute('Related')=='-1')
			{
				totSecInc += GetSecurityIncome(oSPCusts(i));
			}
		oSPNode.setAttribute('TotSecIncome', (totSecInc.toFixed(2)));
		
		sAmount = CalculateSPTotal(oSPNode, 'Expenses/Expense/DeclaredAmount');
		oSPNode.setAttribute('TotExpense', sAmount);
		oSPNode.setAttribute('fmtTotExpense', cursym.concat((sAmount.toFixed(2))));
	}
	catch (e)
	{
		displayError(e,'CalculateTotals');
	}
}


//======================================================================================
//	Function Name:	CalculateSPTotal
//	Parameters:		oDocEl - <StatementOfPosition>
//					sXPath - path to calculate Assets, Liabilities, Incomes or Expenses  
//	Return:			tot - Calculated total
//	Description:	Calculate total of the passing value sXPath.
//======================================================================================
function CalculateSPTotal(oDocEl, sXPath)
{
	try
	{
		var oItems = oDocEl.selectNodes(sXPath);
		var tot=0, sNum;
		for (var i=0; i<oItems.length; i++)
		{
			sNum = 	oItems(i).text;
			tot += (!sNum || isNaN(sNum)) ? 0: parseFloat(sNum);
		}
		return tot;
	}
	catch (e)
	{
		displayError(e,'CalculateSPTotal');
	}
}


//=======================================================================
//	Function Name:	CalculateIncomePAYE
//	Parameters:		oDocEl - <StatementOfPosition>
//	Return:			tot - Calculated PAYE Total
//	Description:	Calculate PAYE Incomes of all related customers 
//					from <Customers> in xml_master. 
//=======================================================================
function CalculateIncomePAYE(oDocEl)
{
	try
	{
		var oSPCusts = oDocEl.selectNodes('SPCustomers/SPCustomer');
		var tot=0, sNum;
		for (var i=0; i<oSPCusts.length; i++)
			if (oSPCusts(i).getAttribute('Related')=='-1')
			{
				tot += GetCustomerPAYEIncome(oSPCusts(i)) + GetSecurityIncome(oSPCusts(i));
			}
		return tot;	
	}
	catch (e)
	{
		displayError(e,'CalculateIncomePAYE');
	}
}


//=========================================================================
//	Function Name:	GetCustomerPAYEIncome
//	Parameters:		oSPCustomer - related customer records
//	Return:			PAYE income amount
//	Description:	Get PAYE income from <Customers> in xml_master.
//=========================================================================
function GetCustomerPAYEIncome(oSPCustomer)
{
	try
	{
		if (!oSPCustomer) return 0;
	
		var sCustId = oSPCustomer.selectSingleNode("CustomerID").text;
		var oMDocEl = xml_master.XMLDocument.documentElement;
	//WR1970 - To get all the current employment incomes - Start
		//var sCustInc = "Customers/Customer[CustomerID='"+sCustId+"']/CustomerEmployments/EmploymentDetails[PreviousEmployment=0]/NetMonthlyIncome";
		var sCustInc = "Customers/Customer[CustomerID='"+sCustId+"']/CustomerEmployments/EmploymentDetails[EmploymentStatusDesc='Current Employment - Primary' or EmploymentStatusDesc='Current Employment - Secondary']/NetMonthlyIncome";
		//var oCustNetIncome = oMDocEl.selectSingleNode(sCustInc);
		var oCustNetIncome = oMDocEl.selectNodes(sCustInc);
		//var CustInc = (oCustNetIncome)?  GetIntVal(oCustNetIncome.text):0; 
		var CustInc = 0;
		for(var x=0; x<=oCustNetIncome.length-1; x++)
		{
			oCustNetIncome.nextNode;
			CustInc += (oCustNetIncome(x))?  GetIntVal(oCustNetIncome(x).text):0; 
		}
	//WR1970 - To get all the current employment incomes - End
		return (isNaN(CustInc))? 0:CustInc;
	}
	catch (e)
	{
		displayError(e,'GetCustomerPAYEIncome');
	}	
}

//=========================================================================
//	Function Name:	GetSecurityIncome
//	Parameters:		oSPCustomer - related customer records
//	Return:			Security income amount
//	Description:	Get Security income from <Customers> in xml_master.
//=========================================================================
function GetSecurityIncome(oSPCustomer)
{
	try
	{
		if (!oSPCustomer) return 0;
		var sCustId = oSPCustomer.selectSingleNode("CustomerID").text;
		var oMDocEl = xml_master.XMLDocument.documentElement;
		var sSecInc = "Securities/Security[SecRentalIncome > 0]/SecuritiesGivenBy/SecurityGivenBy[@Linked='-1' and CustomerID='"+sCustId+"' and CustomerID [not(. > ../../SecurityGivenBy/CustomerID)][1]]";
		var oSecRentalIncome = oMDocEl.selectNodes(sSecInc);
		var SecInc = 0;
		for(var x=0; x<=oSecRentalIncome.length-1; x++)
		{	
			oSecRentalIncome.nextNode;
			var SecRentInc = oSecRentalIncome(x).selectSingleNode("../../SecRentalIncome").text;
			SecInc += (oSecRentalIncome(x))?  parseFloat(SecRentInc) : 0; 
		}
		return (isNaN(SecInc))? 0.00:SecInc;
	}
	catch (e)
	{
		displayError(e,'GetSecurityIncome');
	}	
}

//WR1970 - Function Description changed
//===========================================================================
//	Function Name:	disableAction
//	Parameters:		tbl - <table> element
//	Return:			nil
//	Description:	1. Disable the Edit/Delete actions when the income is PAYE or SE.
//					2. Disable the Edit/Delete actions when the expense is added as liability.
//===========================================================================
function disableAction(tbl)
{
	try
	{
		if (tbl.readyState!='complete') return;
	//WR1970 - if condition added for the Income part - Start
		if(tbl.id == 'tblIncome')
	//WR1970 - if condition added for the Income part - End
		{
			var oIncomes=ds_statement.XMLDocument.documentElement.selectNodes('Incomes/Income');
			for (var i=0; i<oIncomes.length; i++)
			{
				//WR1970 - If condition changed to make it work for the "SE -" prefixed records also.
				//if (!oIncomes(i).childNodes(0).text && oIncomes(i).getAttribute('TypeDescription').indexOf('PAYE')!='-1')
				if ((!oIncomes(i).childNodes(0).text && oIncomes(i).getAttribute('TypeDescription').indexOf('PAYE - ')!='-1')||
	+			  (!oIncomes(i).childNodes(0).text && oIncomes(i).getAttribute('TypeDescription').indexOf('SE - ')!='-1')||
	+			  (!oIncomes(i).childNodes(0).text && oIncomes(i).getAttribute('TypeDescription').indexOf('SEC - ')!='-1'))
				{
					if (oIncomes.length==1)
					{
						tbl.all.lnkEditDisabled.style.display = 'block';
						tbl.all.lnkEditEnabled.style.display = 'none';
						tbl.all.lnkDeleteDisabled.style.display = 'block';
						tbl.all.lnkDeleteEnabled.style.display = 'none';
					}
					else
					{
						tbl.all.lnkEditDisabled(i).style.display = 'block';
						tbl.all.lnkEditEnabled(i).style.display = 'none';
						tbl.all.lnkDeleteDisabled(i).style.display = 'block';
						tbl.all.lnkDeleteEnabled(i).style.display = 'none';
					}
				}
				else if((oIncomes(i).getAttribute('TypeDescription') != "Dividends")&&
+					  (oIncomes(i).getAttribute('TypeDescription') != "Interest")&&
+					  (oIncomes(i).getAttribute('TypeDescription') != "Rental"))
				{
						tbl.all.lnkEditDisabled(i).style.display = 'none';
						tbl.all.lnkEditEnabled(i).style.display = 'block';
						tbl.all.lnkDeleteDisabled(i).style.display = 'none';
						tbl.all.lnkDeleteEnabled(i).style.display = 'block';
				}
				else
					{
						if (oIncomes.length==1)
						{
						tbl.all.lnkEditDisabled.style.display = 'block';
						tbl.all.lnkEditEnabled.style.display = 'none';
						tbl.all.lnkDeleteDisabled.style.display = 'block';
						tbl.all.lnkDeleteEnabled.style.display = 'none';
						
						}
						else
						{
						tbl.all.lnkEditDisabled(i).style.display = 'block';
						tbl.all.lnkEditEnabled(i).style.display = 'none';
						tbl.all.lnkDeleteDisabled(i).style.display = 'block';
						tbl.all.lnkDeleteEnabled(i).style.display = 'none';
						}
					}
				
			}
	//WR1970 - if condition added for the Income part - Start
		}
	//WR1970 - if condition added for the Income part - End
	
	//WR1970 - To hide the 'Edit' and 'Delete' links if the expense record is a liability - Start
		
		if(tbl.id == 'tblExpense')
		{
			var oExpenses=ds_statement.XMLDocument.documentElement.selectNodes('Expenses/Expense');
			for (var i=0; i<oExpenses.length; i++)
			{
				if((oExpenses(i).getAttribute('TypeDescription') != "Child and Spousal Maintenance")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "General Basic Insurances")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Other")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Childcare")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Clothing and personal care")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Public or government primary and secondary education")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Groceries")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Medical and health")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Primary Residence Running Costs")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Recreation and entertainment")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Telephone, internet, pay TV and media streaming subscriptions")&&
//BOLE2 Changes for 20.1 Starts
+					  (oExpenses(i).getAttribute('TypeDescription') != "Private Schooling And Tuition")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Sickness and personal accident insurance, life insurance")&&
//BOLE2 Changes for 20.1 Ends
+					  (oExpenses(i).getAttribute('TypeDescription') != "Transport")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Board")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Rent")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Pet Care")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Higher Education, Vocational Training and Professional Fees")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Health Insurance")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Body Corporate Fees, Strata Fees and Land Tax on Owner Occupied Principal Place of Residence")&&
+					  (oExpenses(i).getAttribute('TypeDescription') != "Secondary Residence Running Costs"))
				{
					if (oExpenses.length==1)
					{
						tbl.all.lnkEditDisabledExp.style.display = 'block';
						tbl.all.lnkEditEnabledExp.style.display = 'none';
						tbl.all.lnkDeleteDisabledExp.style.display = 'block';
						tbl.all.lnkDeleteEnabledExp.style.display = 'none';
					}
					else
					{
						tbl.all.lnkEditDisabledExp(i).style.display = 'block';
						tbl.all.lnkEditEnabledExp(i).style.display = 'none';
						tbl.all.lnkDeleteDisabledExp(i).style.display = 'block';
						tbl.all.lnkDeleteEnabledExp(i).style.display = 'none';
					}
				}
			}
		}
		
	//WR1970 - To hide the 'Edit' and 'Delete' links if the expense record is a liability - End
	//WR4354 - NCCP2 CR024 Breakfree changes - Start
		if(tbl.id == 'tblLiability')
		{
			var oLiability=ds_statement.XMLDocument.documentElement.selectNodes('Liabilities/Liability');
			for (var i=0; i<=oLiability.length; i++)
			{
				if ((oLiability(i).selectSingleNode('BFANZCreditCard').text == '1')&&
+					(oLiability(i).selectSingleNode('LiabilityType').text == '003'))
				{
						if(oLiability.length==1)
						{
							tbl.all.lnkDeleteEnabledLiab.style.display = 'none';
							tbl.all.lnkDeleteDisabledLiab.style.display = 'block';
							if(oLiability(i).selectSingleNode('BreakFreeCardType').text != "New Credit Card" && oLiability(i).selectSingleNode('LiabilityDescription').text.length > 0)
							{
								tbl.all.labelBFCC.innerText = 'BREAKFREE PACKAGE CREDIT CARD-'+oLiability(i).selectSingleNode('LiabilityDescription').text;
							}else{
								tbl.all.labelBFCC.innerText = 'BREAKFREE PACKAGE CREDIT CARD';
							}
							tbl.all.labelBFCC.style.display = 'block';
							tbl.all.LiabilityDescription.style.display = 'none';
						}
						else
						{
							tbl.all.lnkDeleteEnabledLiab(i).style.display = 'none';
							tbl.all.lnkDeleteDisabledLiab(i).style.display = 'block';
							if(oLiability(i).selectSingleNode('BreakFreeCardType').text != "New Credit Card" && oLiability(i).selectSingleNode('LiabilityDescription').text.length > 0)
							{
								tbl.all.labelBFCC(i).innerText = 'BREAKFREE PACKAGE CREDIT CARD-'+oLiability(i).selectSingleNode('LiabilityDescription').text;
							}else{
								tbl.all.labelBFCC(i).innerText = 'BREAKFREE PACKAGE CREDIT CARD';
							}
							tbl.all.labelBFCC(i).style.display = 'block';
							tbl.all.LiabilityDescription(i).style.display = 'none';
						}
				}
				else
				{
						
						if(oLiability.length==1)
						{
							tbl.all.lnkDeleteDisabledLiab.style.display = 'none';
							tbl.all.lnkDeleteEnabledLiab.style.display = 'block';
							tbl.all.labelBFCC.style.display = 'none';
							tbl.all.LiabilityDescription.style.display = 'block';
							tbl.all.labelBFCC.style.display = 'none';
						}
						else
						{
							tbl.all.lnkDeleteDisabledLiab(i).style.display = 'none';
							tbl.all.lnkDeleteEnabledLiab(i).style.display = 'block';
							tbl.all.labelBFCC(i).style.display = 'none';
							tbl.all.LiabilityDescription(i).style.display = 'block';
							tbl.all.labelBFCC(i).style.display = 'none';
						}
				}
				
			}
		}
	//WR4354 - NCCP2 Breakfree changes - end
	}
	catch (e)
	{
		//ignore error (assinchronous event)
	}
}

//=================================================================================
//	Function Name:	disableSPSigned
//	Parameters:		tbl - <table> element
//	Return:			nil
//	Description:	Disable inpSPSigned element when field 'Related' is unchecked.
//=================================================================================
function disableSPSigned(tbl)
{
	try
	{
		// to make sure that the elements in the table have been parsed and exist before proceed
		if (tbl.readyState!='complete') return;

		var oSPCusts=ds_statement.XMLDocument.documentElement.selectNodes('SPCustomers/SPCustomer');
		for (var i=0; i<oSPCusts.length; i++)
			if (oSPCusts(i).getAttribute('Related')!='-1')
				if (oSPCusts.length==1) tbl.all.inpSPSigned.disabled = true
					else tbl.all.inpSPSigned(i).disabled = true;
	}			
	catch (e)
	{
		//ignore error (assinchronous event)
	}
}

//===========================================================================
//	Function Name:	relateCustomer
//	Parameters:		RecNo - specified item
//	Return:			nil
//	Description:	When click on field 'inpRelated'
//						- if related - add PAYE income record
//						- otherwise - remove PAYE income record
//===========================================================================
function relateCustomer(RecNo)
{
	try
	{
		if (RecNo-1<0) return;
	
		var oSDocEl = ds_statement.XMLDocument.documentElement;
		var oSPCusts=oSDocEl.selectNodes('SPCustomers/SPCustomer');
		var oC = oSPCusts(RecNo-1);
		var bRelated=(oC.getAttribute('Related')=='-1');
	
		if (document.all.tblSPCustomer.all.inpRelated.length)
			document.all.tblSPCustomer.all.inpSPSigned(RecNo-1).disabled = !bRelated
		else
			document.all.tblSPCustomer.all.inpSPSigned.disabled = !bRelated;

	//WR1970 - Removed the section to add PAYE customers and added a function call to add all the customer employment records into the Income summary table - Start
		IncomeFormat(oC, oSDocEl, bRelated);
	//WR1970 - Removed the section to add PAYE customers and added a function call to add all the customer employment records into the Income summary table - End
	
		disableAction(document.all.tblIncome);
		
	//WR1970 - Added to reset the Expenses tab summary records - Start
		disableAction(document.all.tblExpense);
	//WR1970 - Added to reset the Expenses tab summary records - End
		disableAction(document.all.tblLiability);
		G_bSOPDirty=true;	
		Residential_Investment_Property_Running_Cost();
	}
	catch (e)
	{
		displayError(e,'relateCustomer');	
	}
}

//=====================================================================
//	Function Name:	ShowSPWizard
//	Purpose:		Shows SP wizard dialog window.
//					Saves returned SP details back to the master.	
//=====================================================================
function ShowSPWizard()
{
	var oSPW = window.showModalDialog('SPWizard.htm', '', 'dialogHeight:530px;dialogWidth:863px;help:No;resizable:No;status:No;scroll:No;');
	if (oSPW==null) return;

	//add items from wizard
	var oSPDocEl = ds_statement.XMLDocument.documentElement;
	if 	(oSPW.selectSingleNode('SPDate').text != '')
		oSPDocEl.selectSingleNode('SPDate').text = oSPW.selectSingleNode('SPDate').text;
	if 	(oSPW.selectSingleNode('SPDescription').text != '')		
		oSPDocEl.selectSingleNode('SPDescription').text = oSPW.selectSingleNode('SPDescription').text;

	var aEntities = Array ('Assets', 'Liabilities', 'Incomes', 'Expenses');
	var oEntity;
	var oItm;
	var sType='';
	var sOPS='';
	var oRepl;
	var bAppend = true;
	
	for (var i=0; i<aEntities.length; i++)
	{
		oEntity = oSPW.selectSingleNode(aEntities[i]);
		for (var itm=0; itm<oEntity.childNodes.length; itm++)
		{
			bAppend = true;
			oItm = oEntity.childNodes(itm).cloneNode(true);
			if (aEntities[i]=='Assets')
			{
				//check if the Asset record is ONE_PER_SOP, it should be replaced, not appended
				sType = oItm.selectSingleNode('AssetType').text;
				sOPS = oSPW.selectSingleNode('A_TS_ASSET_TYPES/R[@TYPE_CODE="'+sType+'"]').getAttribute('ONE_PER_SOP');
				if (sOPS != '0') 
				{
					//find Asset to replace
					oRepl = oSPDocEl.selectSingleNode('Assets/Asset[AssetType="'+sType+'"]')
					if (oRepl) bAppend = false;
				}
			}
			if (aEntities[i]=='Expenses')
			{
				//check if the Expense record is ONE_PER_SOP, it should be replaced, not appended
				sType = oItm.selectSingleNode('ExpenseType').text;
				sOPS = oSPW.selectSingleNode('A_TS_EXPENSE_TYPES/R[@TYPE_CODE="'+sType+'"]').getAttribute('ONE_PER_SOP');
				if (sOPS != '0') 
				{
					//find Asset to replace
					oRepl = oSPDocEl.selectSingleNode('Expenses/Expense[ExpenseType="'+sType+'"]')
					
					ExpenseSelected(xml_refData);
					if (oRepl) bAppend = false;
				}
			}
			if (bAppend)
				oSPDocEl.selectSingleNode(aEntities[i]).appendChild(oItm);
			else
				oSPDocEl.selectSingleNode(aEntities[i]).replaceChild(oItm,oRepl);
		}
	}
	
	//WR1970 - Added to update the expense cells for liabilities field
	AddUpdExpenses();
	
	G_bSOPDirty=true;	
	SaveStatement();
}

//===========================================================================
//	Function Name:	ShowAddSPButton
//	Parameters:		nil
//	Return:			nil
//	Description:	Check whether to show/hide the [add S/P] button.
//===========================================================================
function ShowAddSPButton()
{
	try
	{
		// The maximum number of SP�s is only limited by the number of customers in the application.
		var oMDocEl=xml_master.XMLDocument.documentElement;
		SOPMasterXML = xml_master.XMLDocument.documentElement;
		var oCustCnt=oMDocEl.selectNodes('Customers/Customer').length;
		var oSPCnt = oMDocEl.selectNodes('StatementsOfPosition/StatementOfPosition').length;
		document.all.cmdAddStatementDiv.style.display = (oCustCnt>oSPCnt)? "":"none"
		document.all.MaxSOPMsg.style.display = (oCustCnt>oSPCnt)? "none":"";
	}
	catch (e)
	{
		displayError(e,'ShowAddSPButton');
	}
}

//===========================================================================
//	Function Name:	SetSOPDirty
//	Parameters:		nil
//	Return:			nil
//	Description:	Set the screen to dirty - whether to save the SP or not.
//===========================================================================
function SetSOPDirty()
{
	G_bSOPDirty = true;
}

//WR1970 - Function added for Adding/updating an Expense record when a Liability record is added. - Start
//===========================================================================
//	Function Name:	AddUpdExpenses
//	Parameters:		nil
//	Return:			nil
//	Description:	Adding/updating an Expense record when a Liability record is added.
//===========================================================================
function AddUpdExpenses()
{
	try
	{
		var oExpenses = ds_statement.XMLDocument.documentElement.selectSingleNode("Expenses");
				
		var oExp = oExpenses.selectNodes("Expense");
		/*if(oExp.length > 0)
		{
			for(intCounter=0;intCounter<=(oExp.length-1);intCounter++)
			{
				if((oExp(intCounter).getAttribute('TypeDescription') != "Other Commitments")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Rent/Board")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Total Living Expenses"))
				{
					oExpenses.removeChild(oExp(intCounter));
				}
			}
		}*/
		if(oExp.length > 0)
		{
			for(intCounter=0;intCounter<=(oExp.length-1);intCounter++)
			{				
				if((oExp(intCounter).getAttribute('TypeDescription') != "Child and Spousal Maintenance")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "General Basic Insurances")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Other")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Childcare")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Clothing and personal care")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Public or government primary and secondary education")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Groceries")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Medical and health")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Primary Residence Running Costs")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Recreation and entertainment")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Telephone, internet, pay TV and media streaming subscriptions")&&
//BOLE2 Changes for 20.1 Starts
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Private Schooling And Tuition")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Sickness and personal accident insurance, life insurance")&&
//BOLE2 Changes for 20.1 Ends
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Transport")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Board")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Rent")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Pet Care")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Higher Education, Vocational Training and Professional Fees")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Health Insurance")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Body Corporate Fees, Strata Fees and Land Tax on Owner Occupied Principal Place of Residence")&&
+					  (oExp(intCounter).getAttribute('TypeDescription') != "Secondary Residence Running Costs"))
				{
					oExpenses.removeChild(oExp(intCounter));
				}
			}
		}
				
		var oLiabs = ds_statement.XMLDocument.documentElement.selectSingleNode("Liabilities");
				
		var oLiab = oLiabs.selectNodes("Liability");
				
		if(oLiab.length > 0)
		{
			for(intCounter=0;intCounter<=(oLiab.length-1);intCounter++)
			{
				var oExpense = ds_statement.XMLDocument.createNode(1, "Expense", "");
					
				oExpense.appendChild(ds_statement.XMLDocument.createNode(1, "ExpenseType", ""));
				oExpense.appendChild(ds_statement.XMLDocument.createNode(1, "DeclaredAmount", ""));
				oExpense.appendChild(ds_statement.XMLDocument.createNode(1, "ExpenseDescription", ""));
				
				var strLibDesc;
				var strLibCode;
				
				switch (oLiab(intCounter).getAttribute('TypeDescription'))
				{
					case 'ANZ Credit Cards': 
						strLibDesc='Credit/Store Cards';
						strLibCode = '003';
						break;
					case 'Other Fin Inst Credit/Store Cards': 
						strLibDesc='Credit/Store Cards';
						strLibCode = '003';
						break;
					case 'ANZ Mortgages': 
						strLibDesc='Other Loans at ANZ';
						strLibCode = '001';
						break;
					case 'ANZ Other Loans': 
						strLibDesc='Other Loans at ANZ';
						strLibCode = '001';
						break;
					case 'Hire Purchase/Lease Liabilities': 
						strLibDesc='Hire Purchase/Lease Payments';
						strLibCode = '004';
						break;
					case 'Other Fin Inst Mortgages': 
						strLibDesc='Other Fin Inst Loans';
						strLibCode = '002';
						break;
					case 'Other Fin Inst Other Loans': 
						strLibDesc='Other Fin Inst Loans';
						strLibCode = '002';
						break;
					case 'Other Liabilities': 
						strLibDesc='Other Fin Inst Loans';
						strLibCode = '002';
						break;
				}
				
				oExpense.setAttribute('TypeDescription', strLibDesc);
				oExpense.setAttribute('fmtAmount', VBFormatCurrency(oLiab(intCounter).selectSingleNode("MthlyExp").text,0));
				
				oExpense.selectSingleNode("ExpenseType").text = strLibCode;
				oExpense.selectSingleNode("DeclaredAmount").text = oLiab(intCounter).selectSingleNode("MthlyExp").text;
				
				if(oLiab(intCounter).selectSingleNode("BFANZCreditCard").text == '1')
				{
					oExpense.selectSingleNode("ExpenseDescription").text = "L-BREAKFREE PACKAGE CREDIT CARD";
					if((oLiab(intCounter).selectSingleNode("LiabilityDescription").text).length>0) 
							oExpense.selectSingleNode("ExpenseDescription").text += "-";
					oExpense.selectSingleNode("ExpenseDescription").text += oLiab(intCounter).selectSingleNode("LiabilityDescription").text;
				}	
				else
				{
					oExpense.selectSingleNode("ExpenseDescription").text = "L-" + oLiab(intCounter).selectSingleNode("LiabilityDescription").text;
				}
				oExpenses.appendChild(oExpense);
			}
		}
	}
	catch (e)
	{
		displayError(e,'AddUpdExpenses');
	}
}
//WR1970 - Function added for Adding/updating an Expense record when a Liability record is added. - End

//Card : 395 - Function added for Adding/updating an Income record when a Asset record is added. - Start
//===========================================================================
//	Function Name:	AddUpdIncomesByAsset
//	Parameters:		nil
//	Return:			nil
//	Description:	Adding/updating an Income record when a Asset record is added.
//===========================================================================
function AddUpdIncomesByAsset()
{
	try
	{
		var oIncomes = ds_statement.XMLDocument.documentElement.selectSingleNode("Incomes");
				
		var oInc = oIncomes.selectNodes("Income");
		if(oInc.length > 0)
		{
			for(intCounter=0;intCounter<=(oInc.length-1);intCounter++)
			{				
				if((oInc(intCounter).getAttribute('TypeDescription') == "Dividends")||
+					  (oInc(intCounter).getAttribute('TypeDescription') == "Interest")||
+					  (oInc(intCounter).getAttribute('TypeDescription') == "Rental"))
				{
					oIncomes.removeChild(oInc(intCounter));
				}
			}
		}
				
		var oAssets = ds_statement.XMLDocument.documentElement.selectSingleNode("Assets");
				
		var oAsset = oAssets.selectNodes("Asset");
		if(oAsset.length > 0)
		{
			for(intCounter=0;intCounter<=(oAsset.length-1);intCounter++)
			{
				if((oAsset(intCounter).getAttribute('TypeDescription') != "Household Furniture & Effects") &&
				+ (oAsset(intCounter).getAttribute('TypeDescription') != "Other") &&
				+ (oAsset(intCounter).getAttribute('TypeDescription') != "Vehicle"))
				{
				var oIncome = ds_statement.XMLDocument.createNode(1, "Income", "");
					
				oIncome.appendChild(ds_statement.XMLDocument.createNode(1, "IncomeType", ""));
				oIncome.appendChild(ds_statement.XMLDocument.createNode(1, "NetMonthlyIncome", ""));
				oIncome.appendChild(ds_statement.XMLDocument.createNode(1, "IncomeVerified", ""));
				oIncome.appendChild(ds_statement.XMLDocument.createNode(1, "EvidenceOfTenancyHeld", ""));
				
				var strAssetDesc;
				var strAssetCode;
				
				switch (oAsset(intCounter).getAttribute('TypeDescription'))
				{
					case 'ANZ Cash': 
						strAssetDesc='Interest';
						strAssetCode = '005';
						break;
					case 'Deposit': 
						strAssetDesc='Interest';
						strAssetCode = '005';
						break;
					case 'Other Fin Inst Cash': 
						strAssetDesc='Interest';
						strAssetCode = '005';
						break;
					case 'Superannuation': 
						strAssetDesc='Interest';
						strAssetCode = '005';
						break;
					case 'Property': 
						strAssetDesc='Rental';
						strAssetCode = '003';
						break;
					case 'Shares/Unit Trust': 
						strAssetDesc='Dividends';
						strAssetCode = '006';
						break;
				}
						// For Not Adding in Income Tab , if it is not Investment Starts
						var assetRental = oAsset(intCounter).selectSingleNode("AssetMonthlyIncome").text;
						if((oAsset(intCounter).selectSingleNode("AssetPropertyUse").text != "R") && (assetRental > 0))
						{
							oIncome.setAttribute('TypeDescription', strAssetDesc);
							var cursym = "$";
							oIncome.setAttribute('fmtAmount', cursym.concat((assetRental)));
							oIncome.selectSingleNode("IncomeType").text = strAssetCode;
							oIncome.selectSingleNode("NetMonthlyIncome").text = assetRental;
							oIncome.selectSingleNode("IncomeVerified").text = 0;
							oIncomes.appendChild(oIncome);
						}
						// For Not Adding in Income Tab , if it is not Investment Ends
				}
			}
		}
	}
	catch (e)
	{
		displayError(e,'AddUpdIncomesByAsset');
	}
}
//Card : 395 - Function added for Adding/updating an Income record when a Asset record is added. - End

//WR1970 - Functions added for getting the format for the Income records liked to customers - Start
//===========================================================================
//	Function Name:	IncomeFormat
//	Parameters:		oC, oSDocEl, bRelated
//	Return:			nil
//	Description:	Calls the function getIncomeFormat to Get the format for the Income records liked to customers
//===========================================================================
function IncomeFormat(oC, oSDocEl, bRelated)
{
	try
	{
		var sCustId = oC.selectSingleNode("CustomerID").text;
		var sCustDet = "Customers/Customer[CustomerID='"+sCustId+"']/CustomerEmployments/EmploymentDetails[EmploymentStatusDesc='Current Employment - Secondary' and EmploymentType!='NE']";
		getIncomeFormat(oC, oSDocEl, bRelated, sCustDet)
		var sCustDet = "Customers/Customer[CustomerID='"+sCustId+"']/CustomerEmployments/EmploymentDetails[EmploymentStatusDesc='Current Employment - Primary' and EmploymentType!='NE']";
		getIncomeFormat(oC, oSDocEl, bRelated, sCustDet)
		getSecIncomeFormat(oC, oSDocEl, bRelated, sCustDet);
	}
	catch (e)
	{
		displayError(e,'IncomeFormat');
	}
}

//===========================================================================
//	Function Name:	getIncomeFormat
//	Parameters:		oC, oSDocEl, bRelated, sCustDet
//	Return:			nil
//	Description:	Gets the format for the Income records liked to customers
//===========================================================================
function getIncomeFormat(oC, oSDocEl, bRelated, sCustDet)
{
	try
	{
		//var sCustId = oC.selectSingleNode("CustomerID").text;
		var oMDocEl = xml_master.XMLDocument.documentElement;
		//var sCustDet = "Customers/Customer[CustomerID='"+sCustId+"']/CustomerEmployments/EmploymentDetails[EmploymentStatusDesc='Current Employment - Primary' or EmploymentStatusDesc='Current Employment - Secondary']";
		var oCustDet = oMDocEl.selectNodes(sCustDet);
			
		var iNoOfEmplnts = oCustDet.length;
			
		//To loop through all the employments of the customer.
		var intIndex;
		for(intIndex=0;intIndex<iNoOfEmplnts;intIndex++)
		{
			var oTempNode = oCustDet.nextNode;
						
			//To get the Employment Type - Whether "Private Sector" or "Public Sector" or "Self Employed"
			var sEmplntType = oTempNode.selectSingleNode("EmployerType").text;
						
			if(sEmplntType == 'PU'||sEmplntType == 'PR')
			{
				var sEmplntTypeCode = "PAYE - ";
			}
			else
			{
				var sEmplntTypeCode = "SE - ";
			}
						
			//To get the Employment Status - Whether "Current Employment - Primary" or "Current Employment - Secondary"
			var sEmplntStatus = oTempNode.selectSingleNode("PrimaryEmployment").text;
			if(sEmplntStatus == -1)
			{
				var sEmplntStatusCode = "Primary - ";
			}
			else
			{
				var sEmplntStatusCode = "Secondary - ";
			}
			
			//To get the customer's full name
			var sCustFullName = "";
			sCustFullName = oTempNode.selectSingleNode("../../CustomerName").text 
			var sIncTypeDesc=sEmplntTypeCode + sEmplntStatusCode + sCustFullName;
						
			if (bRelated) 
			{		
				//add PAYE income record
				var CustEmpInc = oTempNode.selectSingleNode("NetMonthlyIncome").text;  //GetCustomerPAYEIncome(oC); 
				if (CustEmpInc)
				{	
					var oIncs = oSDocEl.selectSingleNode('Incomes');
					var oIncNew = ds_statement_temp.XMLDocument.documentElement.selectSingleNode('Incomes/Income').cloneNode(true);
					oIncNew.setAttribute('TypeDescription', sIncTypeDesc);
					oIncNew.childNodes(1).text = CustEmpInc;
					oIncNew.setAttribute('fmtAmount', VBFormatCurrency(CustEmpInc,0));
					oIncs.insertBefore(oIncNew, oIncs.childNodes(0));
				}
			}
			else
			{
				//remove PAYE income record
				var oPIncome = oSDocEl.selectSingleNode('Incomes/Income[@TypeDescription="'+ sIncTypeDesc + '"]');
				if (oPIncome) oPIncome.parentNode.removeChild(oPIncome);
							
				oC.selectSingleNode('SPSigned').text = '0';
			}
		}
	}
	catch (e)
	{
		displayError(e,'getIncomeFormat');
	}
}

//===========================================================================
//	Function Name:	getSecIncomeFormat
//	Parameters:		oC, oSDocEl, bRelated, sCustDet
//	Return:			nil
//	Description:	Gets the format for the Income records liked to Security customers
//===========================================================================
function getSecIncomeFormat(oC, oSDocEl, bRelated, sCustDet)
{
	try
	{
		var sCustId = oC.selectSingleNode("CustomerID").text;
		var oMDocEl = xml_master.XMLDocument.documentElement;
		if (oMDocEl.selectSingleNode('Securities/Security'))
		{		
			if(bRelated)
			{
				var sIncTypeDesc= "SEC - Rental";
				var oSecRentalIncList = oMDocEl.selectNodes('Securities/Security[SecurityType="B" and SecRentalIncome > 0]');

				//remove
				var oPIncome = oMDocEl.selectSingleNode('Incomes/Income[@TypeDescription="'+ sIncTypeDesc + '"]');
				if (oPIncome) oPIncome.parentNode.removeChild(oPIncome);
							
				for (var i=0; i<oSecRentalIncList.length; i++)
				{	
					var sSecCustList=oSecRentalIncList(i).selectNodes('SecuritiesGivenBy/SecurityGivenBy[@Linked="-1"]');
					if (sSecCustList.length > 0)
					{
					var sSecCustId = sSecCustList(0).selectSingleNode('CustomerID').text;
						if(sCustId==sSecCustId)
						{	
							//add SEC income record
							var SecRentInc = oSecRentalIncList(i).selectSingleNode("SecRentalIncome").text;
							if (SecRentInc)
							{	
								var oIncs = oSDocEl.selectSingleNode('Incomes');
								var oIncNew = ds_statement_temp.XMLDocument.documentElement.selectSingleNode('Incomes/Income').cloneNode(true);
								oIncNew.setAttribute('TypeDescription', sIncTypeDesc);
								oIncNew.childNodes(1).text = SecRentInc;
								var cursym = "$";
								oIncNew.setAttribute('fmtAmount', cursym.concat((SecRentInc)));
								oIncs.insertBefore(oIncNew, oIncs.childNodes(0));
							}
								
						}
					}
				}
			}
			else
			{
				//remove SEC income record
				var oPIncome = oSDocEl.selectSingleNode('Incomes/Income[@TypeDescription="'+ sIncTypeDesc + '"]');
				if (oPIncome) oPIncome.parentNode.removeChild(oPIncome);
			}
		}
	}
	catch (e)
	{
		displayError(e,'getSecIncomeFormat');
	}
}

//WR1970 - Functions added for getting the format for the Income records liked to customers - End

//WR4354 - NCCP2 CR024 - Add liability record Automatic - Start

//===========================================================================
//	Function Name:	AddUpdLiability
//	Parameters:		   nil
//	Return:			nil
//	Description:	Auto populate liability record for Breakfree Credit Card
//===========================================================================

function AddUpdLiability()
{
	
 try
	{
	   // var oProduct = xml_master.XMLDocument.documentElement.selectSingleNode("//Packages[DiscountPackage='PSPW' or DiscountPackage='PSPX']");
		
		 var oProduct = xml_master.XMLDocument.documentElement.selectSingleNode("//Packages[DiscountPackage='PSPW']");
	    //var oProduct = xml_master.XMLDocument.documentElement.selectSingleNode("//Packages[HaveBreakFreePackage = '-1' or HaveBreakFreePackage = '-2']");
		var oEdtItem;
		var oItems;
		if (oProduct)
		{
		    var oDiscountPackage = oProduct.selectSingleNode('DiscountPackage').text; 
		    var oBreakFreeCard = oProduct.selectSingleNode('BreakFreeType').text;
		    var oBreakFreeCardLimit = oProduct.selectSingleNode('BreakFreeAmount').text; 
			var oSOPs = xml_master.XMLDocument.documentElement.selectSingleNode("//StatementsOfPosition");
			var oSOP = oSOPs.selectNodes("StatementOfPosition");
			
			//Start - SAP BreakFree Production issues
			if (oDiscountPackage == 'PSPX') {
			    oBreakFreeCard = "Existing Card - No Change"
			}
			if ((oBreakFreeCardLimit) == '') {
			    oBreakFreeCardLimit = 0
			}

			//End - SAP BreakFree production issues
			
			if (oSOP.length > 0)
			{
				for(intCounter=0;intCounter<=(oSOP.length-1);intCounter++)
				{
					// Add breakfree credit card in liability
					oLiabs = oSOP(intCounter).selectSingleNode("Liabilities/Liability [BFANZCreditCard = 1]");
					if(!oLiabs)
					{
						oItems = oSOP(intCounter).selectSingleNode("Liabilities");
						oEdtItem = ds_statement_temp.XMLDocument.documentElement.selectSingleNode('Liabilities/Liability').cloneNode(true);
						oEdtItem.selectSingleNode("LiabilityType").text = "003";
						oEdtItem.setAttribute("TypeDescription", "ANZ Credit Cards");
						oEdtItem.selectSingleNode("JointOwner").text = "0";
						oEdtItem.selectSingleNode("LiabToClrFrmLn").text = "0";
						oEdtItem.selectSingleNode("LiabilityToContinue").text = "-1";
						oEdtItem.selectSingleNode("BFANZCreditCard").text = "1";
						oItems.appendChild(oEdtItem);
					}
					// Assigning the Credit Card limit from Loan details screen and calculate 3.8% of Limit for Monthly expences
					oLiabs = oSOP(intCounter).selectSingleNode("Liabilities/Liability [BFANZCreditCard = 1]");
					oLiabs.selectSingleNode("Limit").text = oBreakFreeCardLimit;
					oLiabs.selectSingleNode("BreakFreeCardType").text = oBreakFreeCard;
					oLiabs.selectSingleNode("MthlyExp").text = parseFloat(oBreakFreeCardLimit) * 0.038;
					var inpAmountOwing = oLiabs.selectSingleNode("AmountOwing").text;
					oLiabs.selectSingleNode("AmountOwing").text = "0";
					if(oBreakFreeCard == "New Credit Card")
					{
						//BREAKFREE PACKAGE CREDIT CARD
						oLiabs.selectSingleNode("LiabilityDescription").text = "";
						oLiabs.setAttribute("fmtAmount",VBFormatCurrency(0,0));
					}
					else if (oBreakFreeCard.indexOf("No Change") != -1)
					{
						oLiabs.setAttribute("fmtAmount",VBFormatCurrency(0,0));
					}
					else
					{
						oLiabs.selectSingleNode("AmountOwing").text = inpAmountOwing;
						oLiabs.setAttribute("fmtAmount",VBFormatCurrency(inpAmountOwing, 0));
					}
					// Add breakfree credit card in Expense
					var oExpense = oSOP(intCounter).selectSingleNode("Expenses/Expense [contains(ExpenseDescription,'BREAKFREE PACKAGE')]");
					if(!oExpense)
					{
						oItems = oSOP(intCounter).selectSingleNode("Expenses");
						oEdtItem = ds_statement_temp.XMLDocument.documentElement.selectSingleNode('Expenses/Expense').cloneNode(true);
						oEdtItem.selectSingleNode('ExpenseType').text =  '003';
						oEdtItem.selectSingleNode('ExpenseDescription').text =  'L-BREAKFREE PACKAGE CREDIT CARD';
						oEdtItem.setAttribute('TypeDescription', 'Credit/Store Cards');
						oItems.appendChild(oEdtItem);
					}	
					oExpense = oSOP(intCounter).selectSingleNode("Expenses/Expense [contains(ExpenseDescription, 'BREAKFREE PACKAGE CREDIT CARD')]");
					oExpense.selectSingleNode('DeclaredAmount').text = parseFloat(oBreakFreeCardLimit) * 0.038;
					oExpense.setAttribute('fmtAmount', parseFloat(oBreakFreeCardLimit) * 0.038);
				}
			}	
		}
		else
		{
			DeleteANZCCLiability();
		}
		G_bSaveIsAllowed = true;
		FlushToDisk();
	}
	catch (e)
	{
		displayError(e,'AddUpdLiability');
	}
}

//===========================================================================
//	Function Name:	DeleteANZCCLiability
//	Parameters:		     nil
//	Return:			nil
//	Description:	Delete the auto populated liability record for Breakfree Credit Card
//===========================================================================
function DeleteANZCCLiability()
{	
	try
	{
	    var oProduct = xml_master.XMLDocument.documentElement.selectSingleNode("//Packages[DiscountPackage='PSPW']");	
	    //var oProduct = xml_master.XMLDocument.documentElement.selectSingleNode("//Packages[HaveBreakFreePackage = '-1' or HaveBreakFreePackage = '-2']");
		if (!oProduct)
		{ 
			var oSOPs = xml_master.XMLDocument.documentElement.selectSingleNode("//StatementsOfPosition");
			var oSOP = oSOPs.selectNodes("StatementOfPosition");
			
			if(oSOP.length > 0)
			{
				for(intCounter1=0;intCounter1<=(oSOP.length-1);intCounter1++)
				{
					//Removing Breakfree liability
					var oLiability = oSOP(intCounter1).selectNodes("Liabilities/Liability");
					if(oLiability.length > 0)
					{
						for(intCounter=0;intCounter<=(oLiability.length-1);intCounter++)
						{
							if((oLiability(intCounter).getAttribute('TypeDescription') == 'ANZ Credit Cards')&&
+					  (oLiability(intCounter).selectSingleNode('BFANZCreditCard').text == '1'))
							{
								oLiability(intCounter).parentNode.removeChild(oLiability(intCounter));
							}
						}
					}
					G_bSaveIsAllowed = true;
					FlushToDisk();	
				}	
				//Removing Breakfree Expence
				for(intCounter1=0;intCounter1<=(oSOP.length-1);intCounter1++)
				{
					var oExpense = oSOP(intCounter1).selectNodes("Expenses/Expense");
					
					if(oExpense.length > 0)
					{
					    for(var intCounter2=0;intCounter2<(oExpense.length);intCounter2++)
						{	
						var tempExpDescription = oExpense(intCounter2).selectSingleNode("ExpenseDescription").text;
						if((oExpense(intCounter2).getAttribute('TypeDescription') == 'Credit/Store Cards')&&
+					  (tempExpDescription.indexOf("BREAKFREE PACKAGE CREDIT CARD")!=-1))
							{
								oExpense(intCounter2).parentNode.removeChild(oExpense(intCounter2));
							}							
						}
					}
					
					G_bSaveIsAllowed = true;
					FlushToDisk();
				}	
			}
		}
	}
	catch (e)
	{
		displayError(e,'DeleteANZCCLiability');
	}
}
//===========================================================================
//	Function Name:	CalculateBFCCTotals
//	Parameters:		Nil
//	Return:			nil
//	Descriiption:	Calculate all totals of the <StatementOfPosition> node.
//===========================================================================
function CalculateBFCCTotals()
{
	var oSOPs = xml_master.XMLDocument.documentElement.selectSingleNode("//StatementsOfPosition");
	var oSOP = oSOPs.selectNodes("StatementOfPosition");
	
	if(oSOP.length > 0)
	{
		for(intCounter=0;intCounter<=(oSOP.length-1);intCounter++)
		{
			CalculateTotals(oSOP(intCounter));
		}
	}	
}

//WR4354 - NCCP2 CR024 - Add liability record Automatic - End

//===========================================================================
//	Function Name:	RefreshPercentageSplitup
//	Parameters:		None
//	Return:			nil
//	Description:	Makes sure that the percentage split up is refreshed to 
//                  remove un mapped customers
//===========================================================================

function RefreshPercentageSplitup() {

    try {
        var oSPCusts;// = ds_statement.XMLDocument.documentElement.selectNodes('SPCustomers/SPCustomer');
        var intCount, intCountAsset,intCountOwner;
        var oAssetNodes, oAssetNode;
        var oOwnerNodes, oOwnerNode;
        var iPercentOwnedCust;
        var bFound;

       oAssetNodes = ds_statement.XMLDocument.documentElement.selectNodes('Assets/Asset');
        for (intCountAsset = 0; intCountAsset <= oAssetNodes.length - 1; intCountAsset++) {
            oAssetNode = oAssetNodes[intCountAsset];
            var oTempOwnershipNode = oAssetNode.selectSingleNode('OwneshipProportion').cloneNode(true); ;
            //  oOwnerNodes = oAssetNode.selectSingleNode('OwneshipProportion').selectNodes('Customer');

            oOwnerNodes = oTempOwnershipNode.selectNodes('Customer');

            for (intCountOwner = 0; intCountOwner <= oOwnerNodes.length - 1; intCountOwner++) {
                oOwnerNode = oOwnerNodes[intCountOwner];
                if (oOwnerNode == null)
                    break;
                else {
                        iPercentOwnedCust = oOwnerNode.getAttribute('ID');
                        oSPCusts = ds_statement.XMLDocument.documentElement.selectNodes('SPCustomers/SPCustomer');
                        bFound = false;
                        for (intCount = 0; intCount <= oSPCusts.length - 1; intCount++) {
                            var oCust = oSPCusts[intCount];
                            if (oCust == null)
                                break;
                            else {
                                if (Number(oCust.selectSingleNode("CustomerID").text) == Number(iPercentOwnedCust)) {
                                    bFound = true;
                                    break;
                                }
                            }
                        }
                        if (bFound == false) {
                            oTempOwnershipNode.removeChild(oOwnerNode);
                            oAssetNode.replaceChild(oTempOwnershipNode, oAssetNode.selectSingleNode('OwneshipProportion'));
                            RefreshPercentageSplitup();
                        } 
                }
                }
        }

    }
    catch (e) {
        displayError(e, "RefreshPercentageSplitup");
    }
}
//===========================================================================
//	Function Name:	Residential_Investment_Property_Running_Cost
//	Parameters:		nil
//	Return:			nil
//	Description:	Add Expense records if Residential Investment Property Running Cost(monthly)>0
//===========================================================================
function Residential_Investment_Property_Running_Cost() {
	try 
	{
		var oSDocEl = ds_statement.XMLDocument.documentElement;
		var oSPCusts=oSDocEl.selectNodes('SPCustomers/SPCustomer');
		var oSOPs = xml_master.XMLDocument.documentElement.selectSingleNode("//StatementsOfPosition");
		var oSOP = oSOPs.selectNodes("StatementOfPosition");
		
		var SecInvstCost=0;		
		var AssetInvetVal=0;		
		var intCount;
		var TotalAssetInvetVal=0;
		GSecIPRCExpns=0;
		for(intCount=0;intCount<=oSPCusts.length-1;intCount++)
		{			
			var oC = oSPCusts.nextNode;
			var bRelated=(oC.getAttribute('Related')=='-1');
			
			
			var sCustId = oC.selectSingleNode("CustomerID").text;
			
			var sCustDet = "Customers/Customer[CustomerID='"+sCustId+"']/CustomerEmployments/EmploymentDetails[EmploymentStatusDesc='Current Employment - Primary' and EmploymentType!='NE']";
									//add SEC income record
				SecInvstCost = getSecExpenseFormat(oC,oSDocEl,bRelated,sCustId,oSOP.length);
				GSecIPRCExpns=GSecIPRCExpns+SecInvstCost
			if(intCount==0)
			{			
				var oTotPropAsset = "//Assets/Asset";
				
				
				var SecRPRC = 0;
				var TotalSec = 0;
				
				var oTotAssetsCnt = oSDocEl.selectNodes(oTotPropAsset);
				
				
				if(oTotAssetsCnt.length > 0)
				{
					for(var iTotAssetCount=0; iTotAssetCount<=oTotAssetsCnt.length-1; iTotAssetCount++)
					{
						
						AssetInvetVal=oTotAssetsCnt(iTotAssetCount).selectSingleNode("AssetMonthlyInvestment").text
						if (AssetInvetVal>0)
						{
							TotalAssetInvetVal=parseFloat(AssetInvetVal)+parseFloat(TotalAssetInvetVal)
							
						}
					}
				}
			}
		}
		SecInvstCost = parseFloat(TotalAssetInvetVal)+parseFloat(GSecIPRCExpns);
		SecInvstCost = (SecInvstCost.toFixed(2));
		sExpTypeDesc = "Residential Investment Property Running Costs";
		var oSDocEl2 = ds_statement.XMLDocument.documentElement.selectSingleNode("Expenses");
		var oIncs = oSDocEl2.selectSingleNode('Expenses');
		var oPExpense = oSDocEl2.selectSingleNode('//Expense[@TypeDescription="'+ sExpTypeDesc + '"]');
		if (oPExpense) 
		{
			oPExpense.parentNode.removeChild(oPExpense);
		}			
		if (SecInvstCost>0)
		{	
			var sExpTypeDesc = "Residential Investment Property Running Costs";
			var oPExpense = oSDocEl2.selectSingleNode('Expenses/Expense[@TypeDescription="'+ sExpTypeDesc + '"]');
			if (oPExpense) oPExpense.parentNode.removeChild(oPExpense);
			
			
			var oExpense = ds_statement.XMLDocument.createNode(1, "Expenses", "");
			
			oExpense.appendChild(ds_statement.XMLDocument.createNode(1, "ExpenseType", ""));
			oExpense.appendChild(ds_statement.XMLDocument.createNode(1, "ExpenseDescription", ""));
			oExpense.appendChild(ds_statement.XMLDocument.createNode(1, "DeclaredAmount", ""));
			oItems = ds_statement.XMLDocument.documentElement.selectSingleNode("Expenses");
			oExpense = ds_statement_temp.XMLDocument.documentElement.selectSingleNode('Expenses/Expense').cloneNode(true);
			oExpense.selectSingleNode('ExpenseType').text =  '049';
			oExpense.selectSingleNode('ExpenseDescription').text =  '';
			oExpense.setAttribute('TypeDescription', 'Residential Investment Property Running Costs');
			oExpense.selectSingleNode('DeclaredAmount').text = SecInvstCost;
			var cursym = "$";
			SecInvstCost = (cursym.concat(SecInvstCost));
			oExpense.setAttribute('fmtAmount', SecInvstCost);
			oItems.appendChild(oExpense);
			
		}
		else
		{
			//remove record
			var sExpTypeDesc = "Residential Investment Property Running Costs";
			var oPExpense = oSDocEl.selectSingleNode('Expenses/Expense[@TypeDescription="'+ sExpTypeDesc + '"]');
			if (oPExpense) oPExpense.parentNode.removeChild(oPExpense);
		}
		
		var oSP = ds_statement.XMLDocument.documentElement;
		CalculateTotals(oSP); 
		
		SaveStatement(true,'N');
		
		var oSPCust = oSDocEl.selectNodes('SPCustomers/SPCustomer');
		var intCount;
		for(intCount=0;intCount<=oSPCust.length-1;intCount++)
		{			
			var oC = oSPCust.nextNode;
			var bRelated = (oC.getAttribute('Related')=='-1');
			IncomeFormat(oC, oSDocEl, bRelated);
		}
		
		disableAction(document.all.tblExpense);
					
					
		
	}
		 
			
	catch (e)
	{
		displayError(e,"AddAssetInvestmentPropertyRunningCost");
	}
}
//===========================================================================
//	Function Name:	getSecExpenseFormat
//	Parameters:		oC, oSDocEl, bRelated, sCustDet
//	Return:			nil
//	Description:	Gets the format for the Expense records liked to Security customers
//===========================================================================
function getSecExpenseFormat(oC, oSDocEl, bRelated, sCustId,SOPCont)
{
	try
	{
		var sCustId = oC.selectSingleNode("CustomerID").text;
		var oMDocEl = xml_master.XMLDocument.documentElement;
		if (oMDocEl.selectSingleNode('Securities/Security'))
		var SecInvstCost=0;
		var SplitSec=0;
		{		
			if(bRelated)
			{
				
				var oSecRiprCstList = oMDocEl.selectNodes('Securities/Security[SecurityType="B" and SecInvestmentExpense > 0]');

				for (var i=0; i<oSecRiprCstList.length; i++)	
				{	
					var sSecCustList=oSecRiprCstList(i).selectNodes('SecuritiesGivenBy/SecurityGivenBy[@Linked="-1"]');
					if (sSecCustList.length > 0)
					{
					for (var j=0; j<sSecCustList.length; j++)	
					{	
						if (SOPCont>1)
						{
						var sSecCustId = sSecCustList(j).selectSingleNode('CustomerID').text;
						
							if(sCustId==sSecCustId)
							{	
								//add SEC income record
								SplitSec = parseFloat(oSecRiprCstList(i).selectSingleNode("SecInvestmentExpense").text)/sSecCustList.length;
								
								SecInvstCost = parseFloat(SecInvstCost) +  parseFloat(SplitSec);
								

							}
						}
						else
						{
							var sSecCustId = sSecCustList(j).selectSingleNode('CustomerID').text;
							
							if(sCustId==sSecCustId)
							{
							SplitSec = parseFloat(oSecRiprCstList(i).selectSingleNode("SecInvestmentExpense").text)/sSecCustList.length;
							SecInvstCost = parseFloat(SecInvstCost) +  parseFloat(SplitSec);
							}
							
						}
					}
					}
				}
			}
			
		}
			
			SecInvstCost=(isNaN(SecInvstCost))? 0:SecInvstCost;
			return SecInvstCost;	
	}
	catch (e)
	{
		displayError(e,'getSecExpenseFormat');
	}
}


