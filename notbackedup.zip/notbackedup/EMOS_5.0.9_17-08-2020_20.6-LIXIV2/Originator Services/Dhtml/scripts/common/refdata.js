//<SCRIPT>
//==========================================================
//	(C) Copyright 1996 - 2003
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision: 1
//	Author: Eugene Elutine
//	Workfile:  
//	ModTtime: 2003/03/04
//  File: refData.js	
//============================================================


//==============================================================
//	Function Name:	initRefData
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Initialise reference data
//==============================================================
function initRefData()
{
	try
	{
		xml_refData.XMLDocument.async=false;
		xml_refData.setProperty("SelectionLanguage","XPath");
		oxmlRefData = document.all("xml_refData").XMLDocument;
		GetCompanyOptions();
	}
	catch (e)
	{
		displayError(e,"initRefData");
	}	
}

//==============================================================
//	Name:		UCaseNode
//	Parameters:	Nil	
//	Return:		Nil	
//	Purpose:	Sets an given attribute to upper case for a given table
//				node's child row nodes
//==============================================================
function UCaseNode(sNodeName, sAttName)
{
	try
	{
		var oNodeList = getRDRows(sNodeName);
		var sAttValue = new String("");
		for (var i=0; i < oNodeList.length; i++)
		{
			sAttValue = oNodeList[i].getAttribute(sAttName);
			sAttValue = sAttValue.toUpperCase();
			oNodeList[i].setAttribute(sAttName, sAttValue);
		}
	}
	catch (e)
	{
		displayError(e,"UCaseNode");
	}
}


//==============================================================
//	Function Name:	GetCompanyOptions
//	Parameters:		Nil
//	Return:			Nil	
//	Description:	Creates the object 'G_oCompanyOptions' to hold company options
//==============================================================
function GetCompanyOptions()
{
	try
	{
		var oCompOptNode = findRDNode("A_TS_COMPANY_OPTIONS"); 
	
		if (!oCompOptNode)return;
	
		var oNodes = oCompOptNode.selectNodes("R");
	
		for (var i=0; i < oNodes.length; i++)
		{
			var oRow = oNodes[i];
			G_oCompanyOptions[oRow.getAttribute ("CONTEXT")] = oRow.getAttribute ("OPTION_CODE");
		}
	}
	catch (e)
	{
		displayError(e,"GetCompanyOptions");
	}

}

//==============================================================
//	Function Name:	findRDNode
//	Parameters:		sRefDataName - (string) node name
//	Return:			Node - Selected Ref data node	
//	Description:	Selects a reference data node for the given name
//==============================================================
function findRDNode (sRefDataName,sCriteria)
{
	try
	{
		if(sRefDataName=="A_TS_PURP_CODE_DESC" || sRefDataName=="A_TS_SEC_TYPES" || sRefDataName=="A_TS_SEC_STATUS_CODES")
		{
			xml_refDataPurpSec.XMLDocument.async=false;
			xml_refDataPurpSec.setProperty("SelectionLanguage","XPath");
			oxmlRefDataPurpSec = document.all("xml_refDataPurpSec").XMLDocument;
			return oxmlRefDataPurpSec.selectSingleNode ('/' + '*' + '/' + sRefDataName);
		}
		//Start : Card 388
		else if((sRefDataName=="A_E_TSR_PC") || ((sCriteria == "EMPOVR") && (sRefDataName=="A_TS_COUNTRY_CODES")))
		{
			xml_refDataAddr.XMLDocument.async=false;
			xml_refDataAddr.setProperty("SelectionLanguage","XPath");
			oxmlRefDataAddr = document.all("xml_refDataAddr").XMLDocument;
			return oxmlRefDataAddr.selectSingleNode ('/' + '*' + '/' + sRefDataName);
		}
		//End : Card 388
		else
			return oxmlRefData.selectSingleNode ('/' + '*' + '/' + sRefDataName);
	}
	catch (e)
	{
		displayError(e,"findRDNode");
	}
}

//==============================================================
//	Function Name:	getSingleRDRow
//	Parameters:		sRefDataName - (string) Node name
//					sCriteria - (string) XPath compliant criteria
//	Return:			Node - selected Row node	
//	Description:	Selects a single row node from a given ref data table node
//==============================================================
function getSingleRDRow (sRefDataName, sCriteria)
{
	try
	{	
		var oRefDTbl = findRDNode (sRefDataName);
		if (sCriteria)
		{
			return oRefDTbl.selectSingleNode ('R[' + sCriteria + ']');
		}
		else
		{
			return oRefDTbl.firstChild;
		}
	}
	catch (e)
	{
		displayError(e,"getSingleRDRow");
	}
}

//==============================================================
//	Function Name:	getRDRowObject
//	Parameters:		sRefDataName - (string) Node name
//					sCriteria - (string) XPath compliant criteria	
//	Return:			Object - Returns a row node as an object	
//	Description:	Returns the selected row as an object with its
//					fields as parameters
//==============================================================
function getRDRowObject (sRefDataName, sCriteria)
{
	try
	{	
		var oRow = getSingleRDRow (sRefDataName, sCriteria);
		if (!oRow) return null;
			
		var jsoRowObj = new Object;
		for (var i=0; i< oRow.attributes.length; i++)
		{
			vVal = oRow.attributes(i).text; 
			if (VBIsNumeric(vVal)&& !isNaN(parseFloat(vVal))) 
				vVal = parseFloat (vVal);
			 
			jsoRowObj[oRow.attributes(i).nodeName] = vVal;
		}

		return jsoRowObj;
	}
	catch (e)
	{
		displayError(e,"getRDRowObject");
	}
	 
}

//==============================================================
//	Function Name:	getRDRows
//	Parameters:		sRefDataName - (string) Node name
//					sCriteria - (string) XPath compliant criteria		
//	Return:			Node List	
//	Description:	returns the row nodes for a given table node
//==============================================================
function getRDRows (sRefDataName, sCriteria)
{
	try
	{
		var oRefNode = findRDNode(sRefDataName,sCriteria);
		if (!sCriteria)
			return oRefNode.childNodes;
		
		if(sCriteria=="EMPOVR")
			return oRefNode.childNodes;

		return oRefNode.selectNodes ('R[' + sCriteria + ']');
	}
	catch (e)
	{
		displayError(e,"getRDRows");
	}
		
}

//==============================================================
//	Function Name:	populateList
//	Parameters:		sRefDataName - (string) Reference data table name
//					lbId - (pointer to list box)
//					sCriteria - (string) Xpath compliant criteria
//					sValColName - (string) field name for value column of list box
//					sDescColName - (string) field name for description column of list box
//					bEmptyOption - (boolean) Flag for adding an empty option
//					bUseDHTML - (boolean) Flag for writing options as DHTML
//	Return:			Nil	
//	Description:	Populates a given list box with selected ref data
//==============================================================
function populateList(sRefDataName, lbId, sCriteria, sValColName, sDescColName, bEmptyOption, bUseDHTML)
{
	var oRefDataNodes = getRDRows (sRefDataName, sCriteria);
	
	var sHTML = lbId.outerHTML; 
	
	var iPos1 = sHTML.indexOf (">");
	
	var sOptHTML = "";
	
	var df=lbId.dataFld;
	var ds=lbId.dataSrc;
	lbId.dataFld="";
	lbId.dataSrc="";
	
	// clear list
	for (i = lbId.options.length-1; i>=0; i--)
		lbId.options.remove(i);
		
	if (bEmptyOption)
	{
		var emptopt = document.createElement("OPTION");
		lbId.options.add (emptopt);
		emptopt.value = "";
		emptopt.innerText = "";
	}
	
	for (var i=0; i < oRefDataNodes.length; i++)
	{
		var oRow = oRefDataNodes[i];
		var sVal = oRow.getAttribute(sValColName);
		var sDesc = oRow.getAttribute(sDescColName);

		if (bUseDHTML)
		{
			sOptHTML += '<OPTION VALUE="' + sVal + '">' + sDesc + "</OPTION>";
		}
		else
		{
			var opt = document.createElement("OPTION");
			lbId.options.add (opt);
			opt.value = sVal;
			opt.innerText = sDesc;
		}
	}
	
	if (bUseDHTML)
	{
		sHTML = sHTML.substr(0,  iPos1+1) + sOptHTML + "</SELECT>";
		lbId.outerHTML = sHTML;
	}

	lbId.dataSrc=ds;
	lbId.dataFld=df;
}

