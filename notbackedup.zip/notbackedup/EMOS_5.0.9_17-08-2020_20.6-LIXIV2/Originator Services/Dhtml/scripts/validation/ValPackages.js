//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.13  $
//	$Author:   SK  $
//	$Workfile:   valPackages.js  $
//	$Modtime:   Aug 14 2012 19:54:12  $	
//============================================================-->
//<SCRIPT>

//Check the field UseExistingPackage as mandatory
function Valexistingpackage(oPackages) {
    try {
        var oPck = oPackages.selectSingleNode("HaveBreakFreePackage");
        return (oPck && oPck.text == "-1") ?
					CheckMandatoryFld(oPackages.selectSingleNode("UseExistingPackage")) : true;
    }
    catch (e) {
        displayError(e, 'Valexistingpackage');
    }
}

//Check the field RequireNewPackage as mandatory
function ValRequireNewPackage(oPackages) {
    try {
        var oPck1 = oPackages.selectSingleNode("UseExistingPackage");
        var oPck2 = oPackages.selectSingleNode("HaveBreakFreePackage");
        return ((oPck1 && oPck1.text == "-2") || (oPck2 && oPck2.text == "-2")) ?
					CheckMandatoryFld(oPackages.selectSingleNode("RequireNewPackage")) : true;
    }
    catch (e) {
        displayError(e, 'Valexistingpackage');
    }
}

//Check the field RequireCreditCard as mandatory Rel 19.6 - refer the true false block
function ValRequireCreditCard(oPackages) {
    try {
        var oPck1 = oPackages.selectSingleNode("UseExistingPackage");		
        var oPck2 = oPackages.selectSingleNode("HaveBreakFreePackage");
		var oPck3 = oPackages.selectSingleNode("RequireNewPackage");
		var oPck4 = oPackages.selectSingleNode("RequireCreditCard");
		
	if(oPackages.selectSingleNode("RequireCreditCard")!=null){	
		if((oPck2.text == "-2") && (oPck3.text == "-2"))
		{
			return true;
		}
		else if((oPck1.text == "-2") && (oPck3.text == "-2"))
		{
			return true;
		}
		else if((oPck1.text == "-2") && (oPck3.text == "-1") && (oPck4.text == "-1"))
		{
					//CheckMandatoryFld(oPackages.selectSingleNode("RequireCreditCard")) : true;
					return true;
		}
		else if((oPck1.text == "-2") && (oPck3.text == "-1") && (oPck4.text == "-2"))
		{
			return true;
		}
		else if((oPck2.text == "-2") && (oPck3.text == "-1") && (oPck4.text == "-2"))
		{
			return true;
		}
		else if((oPck1.text == "-1") && (oPck2.text == "-1"))
		{			
			return true;
		}
		else if(oPck2.text == "-2" && oPck3.text == "-1" && oPck4.text == "-1")
		{
			return true;
		}
	}	
		
    }
    catch (e) {
        displayError(e, 'ValRequireCreditCard');
    }
}

//Check the field UseExistingPackage as mandatory
function Valhavepackage(oPackages) {
    try {
        var oPck = oPackages.selectSingleNode("HaveBreakFreePackage");
        return (oPck && oPck.text == "-1") ?
					CheckMandatoryFld(oPackages.selectSingleNode("UseExistingPackage")) : true;
    }
    catch (e) {
        displayError(e, 'Valhavepackage');
    }
}

//Check the field PrimaryCardHolder as mandatory
function ValPrimaryCardHolder(oPackages) 
{
    try 
	{
		var valid_PCH = true;
    		//var oPck = oPackages.selectSingleNode("RequireNewPackage");
		var oPck = oPackages.selectSingleNode("RequireCreditCard");
		if((oPck != null) && (oPck.text != -1)) return true;
		
		if(oPackages.selectSingleNode("PrimaryCardHolder")!=null) {
			if(oPackages.selectSingleNode("PrimaryCardHolder").text != "") {
				var dpdwn_PCH = Validate_PCH_ACH_OnLoad(oPackages.selectSingleNode("PrimaryCardHolder"));
				if(dpdwn_PCH)
				{
					var oPCHID = oPackages.selectSingleNode("PrimaryCardHolder").text;
					if(oPackages.selectSingleNode("AdditionalCardHolderCustID")!=null) 
					{
						var dpdwn_ACH = Validate_PCH_ACH_OnLoad(oPackages.selectSingleNode("AdditionalCardHolderCustID"));
						if(dpdwn_ACH)
						{
							var oACHID = oPackages.selectSingleNode("AdditionalCardHolderCustID").text;
							if((oACHID != "")) {
								if((oPCHID != oACHID)){
									valid_PCH = oPCHID && oACHID;	
								}
								else {
									valid_PCH = false;
								}	
							}
							else 
							{
								valid_PCH = oPCHID;
							}
						}
						else
						{
							valid_PCH = dpdwn_ACH;
						}
					}
					else 
					{
						valid_PCH = oPCHID;
					}
				}
				else
				{
					valid_PCH = dpdwn_PCH;
				}
			}
			else 
			{
				valid_PCH = false;
			}
		}
		return valid_PCH;
    }
    catch (e) 
	{
        displayError(e, 'ValPrimaryCardHolder');
    }
}

//Check the field AdditionalCardHolder as mandatory
function ValCheckPackACH(oPackages)
{
	try
	{
		//var oPck = oPackages.selectSingleNode("RequireNewPackage"); 
		var oPck = oPackages.selectSingleNode("RequireCreditCard");
		return (oPck && oPck.text == "-1") ? CheckMandatoryFld(oPackages.selectSingleNode("AdditionalCardHolder")) : true;
	}
	catch(e)
	{
		displayError(e,"ValCheckPackACH");
	}
}

//Check the field BreakFreeType as mandatory
function ValBreakFreeType(oPackages) {
    try {
        //var oPck = oPackages.selectSingleNode("RequireNewPackage");
        var oPck = oPackages.selectSingleNode("RequireCreditCard"); 
		
		return (oPck && oPck.text == "-1") ?
					CheckMandatoryFld(oPackages.selectSingleNode("BreakFreeType")) : true;
    }
    catch (e) { 
        displayError(e, 'ValBreakFreeType');
    }
}

//Check the field CreditCradType as mandatory Added by Vishwanath
function ValCreditCardType(oPackages) {
    try {
        //var oPck = oPackages.selectSingleNode("RequireNewPackage"); 
		var oPck = oPackages.selectSingleNode("RequireCreditCard"); 
		var oPckBFT = oPackages.selectSingleNode("BreakFreeType");
		if (oPck && (oPckBFT.text == "Existing Card - No Change")) {
			oPackages.selectSingleNode("CreditCardType").text = "";oPackages.selectSingleNode("BreakFreeCard").text = "";
			oPackages.selectSingleNode("BreakFreeAmount").text = "0";oPackages.selectSingleNode("QantasCardNumber").text = "";
			return (oPck && oPck.text == "-1") ? (oPckBFT.text == "Existing Card - No Change") : true;
		}
		else{
			return (oPck && oPck.text == "-1") ? CheckMandatoryFld(oPackages.selectSingleNode("CreditCardType")) : true;
		}
	}
    catch (e) {
        displayError(e, 'ValCreditCardType');
    }
}

//Check the field BreakFreeCard as mandatory
function ValBreakFreeCard(oPackages) {
    try {

        var oPck = oPackages.selectSingleNode("CreditCardType");
        var oPck1 = oPackages.selectSingleNode("BreakFreeType");
        var oPcktype = oPackages.selectSingleNode("BreakFreeCard");

        if (oPck1 && (oPck1.text == "Existing Card - No Change")) {
            oPackages.selectSingleNode("BreakFreeAmount").text = 0;
            oPackages.selectSingleNode("QantasCardNumber").text = "";
        } 
	
        if (oPcktype && (oPcktype.text == -1 || oPcktype.text == -2 || oPcktype.text == -3 || oPcktype.text == -4 || oPcktype.text == -7)) {
            if (oPackages.selectSingleNode("AnzBlockCardDec")) {
                oPackages.selectSingleNode("AnzBlockCardDec").text = "";
            }
        }
        if (oPcktype && (oPcktype.text == -1 || oPcktype.text == -3 || oPcktype.text == -4 || oPcktype.text == -5 || oPcktype.text == -7)) {
            if (oPackages.selectSingleNode("QantasCardNumber")) {
                oPackages.selectSingleNode("QantasCardNumber").text = "";
            }
        }


        return (oPck && (oPck.text == "Rewards cards with flexible rewards options" || oPck.text == "ANZ Frequent Flyer cards with Qantas points" || oPck.text == "A card with a low ongoing interest rate on everyday purchases" || oPck.text == "Simple Everyday card" || oPck.text == "All cards")) ?
		CheckMandatoryFld(oPackages.selectSingleNode("BreakFreeCard")) : true;



    }
    catch (e) {
        displayError(e, 'ValBreakFreeCard');
    }
}

//Validate the credit limit amount 
function ValBFCreditLimitAmount(oPackages) {
    try {
        var valid = true;
        var CCLimit = oPackages.selectSingleNode("BreakFreeAmount");
        var CCardProduct = oPackages.selectSingleNode("BreakFreeCard");
        var CardType = oPackages.selectSingleNode("BreakFreeType");

        if (CardType && (CardType.text == "New Credit Card" || CardType.text == "Existing Card - Change to Platinum or Black")) {
            valid = false;
            if (CCLimit && CCardProduct) {
                var CCLimit = oPackages.selectSingleNode("BreakFreeAmount").text;
                var CCardProduct = oPackages.selectSingleNode("BreakFreeCard").text;
                if ((CCardProduct == -5) || (CCardProduct == -6)) {
                    if ((CCLimit >= 15000) && (CCLimit <= 75000) && (CCLimit % 500 == 0)) {
                        valid = true;
                    }
                }
				else if ((CCardProduct == -4))  {
                    if ((CCLimit >= 1000) && (CCLimit <= 50000) && (CCLimit % 500 == 0)) {
                        valid = true;
                    }
				}
                else {
                    if ((CCLimit >= 6000) && (CCLimit <= 50000) && (CCLimit % 500 == 0)) {
                        valid = true;
                    }
                }
            }
        }
        return valid;
    }
    catch (e) {
        displayError(e, 'ValBFCreditLimitAmount');
    }
}

//Check the field AnzBlockCardDec as mandatory
function ValAnzBlockCardopt(oPackages) {
	var valid = false;
    try {
        var oPck = oPackages.selectSingleNode("BreakFreeCard");
        return (oPck && ((oPck.text == -5) || (oPck.text == -6))) ?
					CheckMandatoryFld(oPackages.selectSingleNode("AnzBlockCardDec")) : true;
    }
    catch (e) {
        displayError(e, 'ValAnzBlockCardopt');
    }
}

//Check the field RequireANZAssuredFacility as mandatory
function ValRequireANZAssuredFacility(oPackages) {
	
    try {
		var valid = false;
		
		var oPck1="";
		var oPck2="";
		var oPck3="";
		var oPck4="";
		var oPck5="";
		
		var oPck = oPackages.selectSingleNode("//Packages");  
				
		if (oPck.selectSingleNode("HaveBreakFreePackage") != null) 
		{
			var oPck1 = oPck.selectSingleNode("HaveBreakFreePackage");  
		}
		else if (oPck.selectSingleNode("HaveBreakFreePackage") == null)
		{
			var oPck1 = 0;
		}
		
		if (oPck1.text == -1) 
		{
			oPck2 = oPck.selectSingleNode("UseExistingPackage");  
			
			// Does customer require an ANZ assured facility? to mandatory this question - enable
			oPck3 = oPck.selectSingleNode("RequireNewPackage"); 
		}
		else if (oPck1.text == -2) 
		{
			oPck2 = oPck.selectSingleNode("RequireNewPackage");  
			oPck5 = oPck.selectSingleNode("RequireCreditCard");  
		}
		else if (typeof(oPck1.text) == "undefined") 
		{
			if (typeof(oPck2.text) == "undefined")
			{
				oPck3.text = "undefined";		
				oPck4.text = "undefined";
			}
		}
		if (typeof(oPck1.text) == "undefined" && typeof(oPck2.text) == "undefined" && typeof(oPck3.text) == "undefined" && typeof(oPck4.text) == "undefined")
		{
			valid = true;
			return valid;
		}
		if (oPck1.text == -2 && oPck2.text == -2)
		{
			valid = true;
			return valid;
			
		}
		else if (oPck1.text == -1 && oPck2.text == -2) 
		{
			oPck3 = oPck.selectSingleNode("RequireNewPackage");  
			oPck5 = oPck.selectSingleNode("RequireCreditCard");
			
		}
		if (oPck3.text == null)
		{
			oPck3.text = 0;
		}
			oPck4 = oPck.selectSingleNode("RequireANZAssuredFacility");  
		if (oPck4.text == null)
		{
			oPck4.text = 0;
		}
		if (oPck1.text == -1 && oPck2.text == -2 && oPck3.text == -1)
		{			
			
			valid=true;
		}
		else if(oPck1.text == -1 && oPck2.text == -2 && oPck3.text == -1 && oPck5.text == -2)
		{ 
			valid=true;
		}
		else if (oPck1.text == -1 && oPck2.text == -2 && oPck3.text == -1 && oPck5.text == -1)
		{
			
			if (oPck4.text == 0)
			{
				valid = true; 				
			}
			else if (oPck4.text == -1 || oPck4.text == -2)
			{
				valid = true;
			}
		}
		
		//Rel 19.6
		else if (oPck1.text == -1 && oPck2.text == -2 && oPck3.text == -2)
		{
			
			if (oPck4.text == 0)
			{
				valid = true; 		
				return valid;	
			}
			else if (oPck4.text == -1 || oPck4.text == -2)
			{
				valid = true;
				return valid;
			}
				//valid=true;
		}
		
		//Rel 19.6
		
		else if ((oPck1.text == -1) && (oPck2.text == -2) && (oPck3.text == -1) && (oPck5.text == -2))
		{
			valid=true;
		}
		
		
		else if (oPck1.text == -1 && oPck2.text == -2 && oPck3.text == -2 && oPck.text == -2)
		{		
			oPck4 = oPck.selectSingleNode("RequireANZAssuredFacility");  
			if (oPck4.text == null)
			{
				oPck4.text = 0;
			}
			if (oPck4.text == 0)
			{
				valid = true;
			}
			else if (oPck4.text == -1 || oPck4.text == -2)
			{
				valid = true;
			}
		}
		else if (oPck1.text == -1 && oPck2.text == -1)
		{
			if (oPck4.text == 0)
			{
				valid = false;
			}
			else if (oPck4.text == -1)
			{
				valid = true;
			}
			else
			{
				valid = true;
			}
		}
		else if (oPck1.text == -2 && oPck2.text == -1)
		{
			if (oPck4.text == 0)
			{
				valid = true;
			}
			else if (oPck4.text == -1)
			{
				valid = true;
			}
			else
			{
				valid = true;
			}
		}
		
		//Rel 19.6
		else if (oPck1.text == -2 && oPck3.text == -1  && oPck5.text == -1)
		{			
			if (oPck4.text == 0)
			{
				valid = false;
			}
			else if (oPck4.text == -1 || oPck4.text == -2 )
			{
				valid = true;
			}			
		}
		
		else if (oPck1.text == -1 && oPck2.text == -2)
		{
			valid = false;
		}
		else if (oPck1.text == -1 && oPck2.text == -2 && oPck3.text == -1)
		{
			if (oPck4.text == 0)
			{
				valid = true;
			}
			else if (oPck4.text == -1 || oPck4.text == -2)
			{
				valid = true;
			}
			else
			{
				valid = true;
			}
		}
		else if (oPck1.text == -1 && oPck2.text == -2 && oPck4.text == -2)
		{
			if (oPck4.text == 0)
			{
				valid = true;
			}
			else if (oPck4.text == -1 || oPck4.text == -2)
			{
				valid = true;
			}
			else
			{
				valid = true;
			}
		}
		else if (oPck1.text == -1 && oPck2.text == -2 && oPck4.text == -1)
		{
			if (oPck4.text == 0)
			{
				valid = false;
			}
			else if (oPck4.text == -1 || oPck4.text == -2)
			{
				valid = true;
			}
			else
			{
				valid = true;
			}
		}	
		
			if (oPck4.text == 0)
			{
				valid = false;
			}
			else if (oPck4.text == -1 || oPck4.text == -2 )
			{
				valid = true;
			}
			else
			{
				valid = true;
			}
		
		return valid;
    }
    catch (e) {
        displayError(e, 'ValRequireANZAssuredFacility');
    }
}

//Check the field AssuredCoverTemporaryExpense as mandatory
function ValAssuredCoverTemporaryExpense(oPackages) {
	var valid = false;
    try {
        var oPck = oPackages.selectSingleNode("RequireANZAssuredFacility"); 

		return (oPck && oPck.text == -1) ?
		CheckMandatoryFld(oPackages.selectSingleNode("AssuredCoverTemporaryExpense")) : true;
		
		return (oPck && oPck.text == -2) ?
		CheckMandatoryFld(oPackages.selectSingleNode("AssuredCoverTemporaryExpense")) : false;
    }
    catch (e) {
        displayError(e, 'ValRequireANZAssuredFacility');
    }
}

//Check the field AssuredFacilitySelected as mandatory
function ValAssuredFacilitySelected(oPackages) {
    try {
        var oPck = oPackages.selectSingleNode("AssuredCoverTemporaryExpense"); 

		return (oPck && oPck.text == -1) ?
		CheckMandatoryFld(oPackages.selectSingleNode("AssuredFacilitySelected")) : true;
		
		return (oPck && oPck.text == -2) ?
		CheckMandatoryFld(oPackages.selectSingleNode("AssuredFacilitySelected")) : false;
    }
    catch (e) {
        displayError(e, 'ValAssuredFacilitySelected');
    }
}

//Check the field AssuredFacilitySelected as mandatory
function ValAssuredConsentToBeConsidered(oPackages) {
    try {
        var oPck = oPackages.selectSingleNode("AssuredFacilitySelected"); 

		return (oPck && oPck.text == 1000) ?
		CheckMandatoryFld(oPackages.selectSingleNode("AssuredConsentToBeConsidered")) : true;
		
		return (oPck && oPck.text == 500 || oPck.text == 0)  ?
		CheckMandatoryFld(oPackages.selectSingleNode("AssuredConsentToBeConsidered")) : false;
    }
    catch (e) {
        displayError(e, 'ValAssuredConsentToBeConsidered');
    }
}

//==============================================================
//	Name:		Validate_PrimaryCardHolder,AdditionalCardHolder_OnLoad
//	Purpose:	Validates PrimaryCardHolder and AdditionalCardHolder
//	Parameters:	txtNode - (XML node) single package XML element
//	Return:		boolean - true, if the PrimaryCardHolder and AdditionalCardHolder preferred is valid,
//							otherwise - false
//==============================================================
function Validate_PCH_ACH_OnLoad(txtNode)
{
	try
	{
		if(txtNode != null) 
		{
			if(txtNode.text != "") 
			{
				txtNode.text = (txtNode.text).replace(/\D+/g, "");
				var regexval = /^[0-9]+$/;
				var nValue=(regexval.test(txtNode.text));
				if((nValue==true)) 
				{
					var nTextVal = ((txtNode.text).replace(/\s/g, ""));
					if(nTextVal != "") {
						nTextVal = nTextVal;
							txtNode.text =  nTextVal;
							return ((txtNode.text) && (true));
						}
						else{
							return ((txtNode.text) && (false));		
						}
				}
				else 
				{
					txtNode.text = (txtNode.text).replace(/\D+/g, "");
					return ((txtNode.text) && (false));		
				}
			}
			else 
			{
				return ((true));		
			}
		}
		else 
		{
			return (true);		
		}
		
	}
    catch(e)
    {
       displayError(e,"Validate_PhNumbers_OnLoad");
    }
}
