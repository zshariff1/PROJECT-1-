//<!-- ==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//==============================================================
//
//**Start Encode**
//
//	$Revision:   1.11  $
//	$Author:   valana  $
//	$Workfile:   valpurpprod.js  $
//	$Modtime:   Dec 14 2012 19:53:54  $	
//============================================================-->
//<SCRIPT>

//============================================================================
//	Function Name:	ValEstSettleDate
//	Parameters:		oPurpose - <Purpose> node
//	Return:			Validation boolean
//	Description:	Validate EstimatedSettlementDate using VB function
//					under emos/DHTML/script/common/vbfuncs.vbs. 
//	Modified: Holiday check code is added to fix the IE9 issue
//============================================================================
function ValEstSettleDate(oPurpose)
{
	try
	{
		var bValid;
		
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '0' ) 		
		{
			bValid = VBValidatePurpEstSettleDate(oPurpose.selectSingleNode("EstimatedSettlementDate").text); 
			if (bValid == true)
			{
				if (getSingleRDRow("A_TSR_HOLIDAYS","@H_DAY='" + oPurpose.selectSingleNode("EstimatedSettlementDate").text + "'") == null)
				{
					bValid = true;
				}
				else
				{
					bValid = false;
				}
			}
		}
		else
		{
			bValid=VBValidatePurpEstSettleDate(oPurpose.selectSingleNode("EstimatedSettlementDate").text); 
			if (bValid == true)
			{
				if (getSingleRDRow("A_TSR_HOLIDAYS","@H_DAY='" + oPurpose.selectSingleNode("EstimatedSettlementDate").text + "'") == null)
				{
					bValid = true;
				}
				else
				{
					bValid = false;
				}
			}
			dtPFLimitEndDate = (xml_master.XMLDocument.documentElement.selectSingleNode('Portfolio/PfLimitEndDate').text);
			if (dtPFLimitEndDate == "")
				bValid=bValid && true;
			else
			{
				if (VBIsDate(dtPFLimitEndDate) && VBIsDate(oPurpose.selectSingleNode("EstimatedSettlementDate").text))
				{
				if(VBDateDiff("d", dtPFLimitEndDate, oPurpose.selectSingleNode("EstimatedSettlementDate").text) < 0)
				bValid=bValid && true;
				else
				bValid=bValid && false;
				}
			}
		}
		return bValid;	
	}
	catch (e)
	{
		displayError(e,'ValEstSettleDate');
	}
}


//============================================================================
//	Function Name:	ValPurpAmountSought
//	Parameters:		oPurpose - <Purpose> node
//	Return:			Validation boolean
//	Description:	Validate Purpose's AmountSought
//============================================================================
function ValPurpAmountSought(oPurpose)
{
	try
	{    
	    
       // if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1') return true;        // If portfolio don't do the validation 
        
        //validate it's beetwen min and max
		//get lending purpose setup		
		
		var sPurpCat = oPurpose.selectSingleNode("Category").text;	
		if (sPurpCat.length==0) return false;
		var TotalAmt = oPurpose.getAttribute("TotalAmount");			
		TotalAmt = (isNaN(TotalAmt))? 0:parseFloat(TotalAmt);				
		
		//get rules for customer type
		var oR = getRDRowObject('A_TS_PURPOSE_CATEGORIES','@CATEGORY_CODE="' + sPurpCat + '"');	
				
		//get sum of products amount sought and limit amounts
		var SumPrd = 0;
		var oILSPrds = oPurpose.selectNodes("./Products/Product/LoanDetails/AmountSought");			
		for (var i=0; i<oILSPrds.length; i++)
			SumPrd = SumPrd + parseFloat("0" + oILSPrds(i).text);		
		
		var oDDAPrds = oPurpose.selectNodes("./Products/Product/DepositDetails/LimitAmount"); 				
		for (var i=0; i<oDDAPrds.length; i++)
			SumPrd = SumPrd + parseFloat("0" + oDDAPrds(i).text);		
		if (oILSPrds.length==0 && oDDAPrds.length==0) SumPrd = TotalAmt;					
		return ((TotalAmt >= oR.MIN_AMT_SOUGHT) & (TotalAmt <= oR.MAX_AMT_SOUGHT) & (TotalAmt==SumPrd) & ValPFAmountSought());		
		
	}
	
	catch (e)
	{
		displayError(e,'ValPurpAmountSought');
	}
}


//==============================================================
//	Name:		ValPFAmountSought
//	Purpose:	
//	Parameters:	none
//==============================================================

function ValPFAmountSought()
{
	try
	{
		var oPurposes;		
		oPurposes= xml_master.XMLDocument.documentElement.selectSingleNode("Purposes")
			
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '0') return true; // If Non portfolio don't do the validation
			
		var TotalPfAmt = (xml_master.XMLDocument.documentElement.selectSingleNode('Portfolio/@PortfolioAmount').text);
					
		TotalPfAmt = (isNaN(TotalPfAmt))? 0:parseFloat(TotalPfAmt);				    
	    
	    var TotAppAmount = 0;
	    var oILSPrds;
	    var oDDAPrds;
	    var oPurpose;
	    var iPurpCount;
	    var iPurpIndex;
	    var iPurpNodeCollection;
	    	    	    
	    iPurpCount=oPurposes.selectNodes("Purpose").length;
	    	    
	    iPurpNodeCollection=oPurposes.selectNodes("Purpose");
	    
	    for(iPurpIndex=0;iPurpIndex<iPurpCount;iPurpIndex++)
	    {
			oPurpose=iPurpNodeCollection(iPurpIndex);
			
			TotAppAmount=TotAppAmount + parseFloat("0" + oPurpose.selectSingleNode("@TotalAmount").text);			
	    }
	    
	    var bValid = true;
	    
		if (TotalPfAmt<TotAppAmount)
			bValid = bValid && false;
		else
			bValid = bValid && true;
			
		return bValid;
	
	}
	catch (e)
	{
		displayError(e,'ValPFAmountSought');
	}
}


//============================================================================
//	Function Name:	ValProdAmountSought
//	Parameters:		oProdLoan - <Product> node
//	Return:			Validation boolean
//	Description:	Validate Product's AmountSought
//============================================================================
function ValProdAmountSought(oProdLoan)
{
	try
	{
		var valid = false;
		if (!oProdLoan.hasChildNodes) return false;
		var nAmtSought = GetIntVal(oProdLoan.selectSingleNode("AmountSought").text);
		var sSubPrdCd = oProdLoan.parentNode.selectSingleNode("SubProductCode").text;
		var oR_ANZLP = getRDRowObject('A_TSR_ANZLP','@PRODUCT_CD="ILS" and @SUB_PROD_CODE="' + sSubPrdCd + '"');
		valid = (nAmtSought > 0) && (nAmtSought >= oR_ANZLP.MIN_AMT) && (nAmtSought <= oR_ANZLP.MAX_AMT);
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValProdAmountSought');
	}
}


//============================================================================
//	Function Name:	ValAmountThisAdvance
//	Parameters:		oProdLoan - <Product> node
//	Return:			Validation boolean
//	Description:	Validate AmountThisAdvance
//============================================================================
function ValAmountThisAdvance(oProdLoan)
{
	try
	{
		var valid = false;
		if (!oProdLoan.hasChildNodes) return false;
		var nAmtSought = GetIntVal(oProdLoan.selectSingleNode("AmountSought").text);
		var nAmtTA = GetIntVal(oProdLoan.selectSingleNode("AmountThisAdvance").text);
		var bRevolv = (oProdLoan.getAttribute("RevolvCredit")=="-1");
		var bProgDraw = (oProdLoan.selectSingleNode("ProgressiveDraw").text=="-1");
		
		valid = !(
					(nAmtTA > nAmtSought) ||
					((!bRevolv) && (bProgDraw) && (nAmtTA == 0)) ||
					((!bRevolv) && (bProgDraw) && (nAmtTA == nAmtSought)) ||
					((!bRevolv) && (!bProgDraw) && (nAmtTA != nAmtSought)) 
				  );
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValAmountThisAdvance');
	}
	
}


//============================================================================
//	Function Name:	ValLoanTerm
//	Parameters:		oProdLoan - <Product> node
//	Return:			Validation boolean
//	Description:	Validate LoanTerm
//============================================================================
function ValLoanTerm(oProdLoan)
{
	try
	{
	  	var valid = false;
		if (!oProdLoan.hasChildNodes) return false;
		var mm=GetIntVal(oProdLoan.getAttribute("LoanTermMM"));
		var yy=GetIntVal(oProdLoan.getAttribute("LoanTermYY"));			
		if (mm>11) return false;		
		var nLoanTerm = GetIntVal(oProdLoan.selectSingleNode("LoanTerm").text);
		var bPfdate=true;
		var sSubPrdCd = oProdLoan.parentNode.selectSingleNode("SubProductCode").text;
		
		var oR_ANZLP = getRDRowObject('A_TSR_ANZLP','@PRODUCT_CD="ILS" and @SUB_PROD_CODE="' + sSubPrdCd + '"');
		var oR_LENDP = getRDRowObject('A_TSR_LENDPOLICY','@PRODUCT_CD="ILS" and @SUB_PROD_CD="' + sSubPrdCd + '"');	
		var bRevolv = (oProdLoan.getAttribute("RevolvCredit")=="-1");
		
		valid = (bRevolv && (nLoanTerm==0)) || 
				((!bRevolv) && (nLoanTerm >= oR_ANZLP.MIN_TERM) && (nLoanTerm <= oR_LENDP.MAX_INI_RP_TERM));
	
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1')
			{	
			     			
  				dtPFLimitEndDate = (xml_master.XMLDocument.documentElement.selectSingleNode('Portfolio/PfLimitEndDate').text);	  				  				  	
				if (dtPFLimitEndDate!="") 
					{
						var dtEstPurpDate = (xml_master.XMLDocument.documentElement.selectSingleNode('Purposes/Purpose/EstimatedSettlementDate').text);						   					   
						var MonthAdded = VBDateAdd("m", mm, dtEstPurpDate);						   
						var dtValidILS = VBDateAdd("yyyy", yy, MonthAdded);									   						
						if (VBIsDate(dtValidILS) && VBIsDate(dtPFLimitEndDate))
						bPfdate = (VBDateDiff("d", dtValidILS, dtPFLimitEndDate ) >= 0);
					}					      		
			}					
	
	return valid && bPfdate ;
		
	}
	catch (e)
	{
		displayError(e,'ValLoanTerm');
	}
}

//============================================================================
//	Function Name:	ValFixedRateTerm
//	Parameters:		oProdLoan - <Product> node
//	Return:			Validation boolean
//	Description:	Validate FixedRateTerm
//============================================================================
function ValFixedRateTerm(oProdLoan)
{
	try
	{
		var valid = false;
		if (!oProdLoan.hasChildNodes) return false;
		var mm=GetIntVal(oProdLoan.getAttribute("FixedRateTermMM"));
		if (mm>11) return false;
		var nLoanTerm = GetIntVal(oProdLoan.selectSingleNode("LoanTerm").text);
		var nFixedTerm = GetIntVal(oProdLoan.selectSingleNode("FixedRateTerm").text);
		var sSubPrdCd = oProdLoan.parentNode.selectSingleNode("SubProductCode").text;
		var sCond='@LOAN_TYPE="' + sSubPrdCd + '"';
		var sIndexCode = sCond + ' and @INDEX_CODE="' + oProdLoan.selectSingleNode("FixedRateIndex").text + '"';
		var sIntFreq =  sCond + ' and @INT_CHG_FREQ="' + oProdLoan.selectSingleNode("InterestFrequency").text + '"';
		var oR_TIER = getRDRowObject('A_TSRR_TIER', sCond);
		var minTerm = (oR_TIER)? oR_TIER.MIN_FROM_TERM:0;
		var maxTerm = (oR_TIER)? oR_TIER.MAX_TO_TERM:0;
		valid = (nFixedTerm <= nLoanTerm) && (nFixedTerm >= minTerm) && (nFixedTerm <= maxTerm);
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValFixedRateTerm');
	}
}


//============================================================================
//	Function Name:	ValIntOnlyTerm
//	Parameters:		oProdLoan - <Product> node
//	Return:			Validation boolean
//	Description:	Validate InterestOnlyTerm
//============================================================================
function ValIntOnlyTerm(oProdLoan)
{
	try
	{
		var valid = false;
		if (!oProdLoan.hasChildNodes) return false;
		var mm=GetIntVal(oProdLoan.getAttribute("InterestOnlyTermMM"));
		if (mm>11) return false;
		var nLoanTerm = GetIntVal(oProdLoan.selectSingleNode("LoanTerm").text);
		var nIntTerm = GetIntVal(oProdLoan.selectSingleNode("InterestOnlyTerm").text);
		var nFixedTerm = GetIntVal(oProdLoan.selectSingleNode("FixedRateTerm").text);
		var sSubPrdCd = oProdLoan.parentNode.selectSingleNode("SubProductCode").text;
		var oR_ANZLP = getRDRowObject('A_TSR_ANZLP','@PRODUCT_CD="ILS" and @SUB_PROD_CODE="' + sSubPrdCd + '"');
		
		var bRequired = (oR_ANZLP.INT_ONLY_INDC=="Y") && 
						(oR_ANZLP.INT_ONLY_CD_1 != "N") && 
						(oR_ANZLP.INT_ONLY_CD_2 != "N");
						
		var bOptional = (oR_ANZLP.INT_ONLY_INDC == "Y") || 
						(oR_ANZLP.INT_ONLY_CD_1 == "Y") || 
						(oR_ANZLP.INT_ONLY_CD_2 == "Y");
		
		if (bRequired && (nIntTerm == 0)) 
			valid = false;
		else
		{	
          if ((bOptional || bRequired) && (nIntTerm > 0))
          {
			valid = (nIntTerm >= oR_ANZLP.MIN_TERM) &&
					 (nIntTerm <= oR_ANZLP.MAX_I_ONLY_TERM) &&
					 (nIntTerm <= nLoanTerm);
					 
			if ((nFixedTerm > 0)&&(nIntTerm!=nFixedTerm)) valid = false;
          }
          else
          {
			valid = (nIntTerm == 0);          
		  }
		}	
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValIntOnlyTerm');
	}
}


//============================================================================
//	Function Name:	ValLimitAmount
//	Parameters:		oProdLoan - <DepositDetails> node under <Product> node
//	Return:			Validation boolean
//	Description:	Validate Product-DDA's LimitAmount
//============================================================================
function ValLimitAmount(oProdDDA)
{
	try
	{
		var valid = false;
		if (!oProdDDA.hasChildNodes) return false;
		var nLimitAmt = oProdDDA.selectSingleNode("LimitAmount").text;
		var sSubPrdCd = oProdDDA.parentNode.selectSingleNode("SubProductCode").text;
		var oR_OD = getRDRowObject('A_TSR_DEPODSC','@SUB_PRODUCT_CODE="' + sSubPrdCd + '"');
		var minAmt = 0;
		var maxAmt = ((oR_OD) && (oR_OD.ODSC_LIMIT>0))? oR_OD.ODSC_LIMIT:999999999;
		
		valid = ((nLimitAmt>=minAmt) && (nLimitAmt <= maxAmt));
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValLimitAmount');
	}
}


//============================================================================
//	Function Name:	ValLimitStartDate
//	Parameters:		oProdLoan - <DepositDetails> node under <Product> node
//	Return:			Validation boolean
//	Description:	Validate Product-DDA's LimitStartDate
//============================================================================
function ValLimitStartDate(oProdDDA)
{
	try
	{
		var valid = false;
		if (!oProdDDA.hasChildNodes) return false;
		var dtStartDate = oProdDDA.selectSingleNode("LimitStartDate").text;
		var oPurp = oProdDDA.parentNode.parentNode.parentNode;
		var dtEstPurpDate = oPurp.selectSingleNode("EstimatedSettlementDate").text;
		
		if (VBIsDate(dtStartDate) && VBIsDate(dtEstPurpDate))		
			valid = (VBDateDiff("d", dtEstPurpDate, dtStartDate ) >= 0);
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValLimitStartDate');
	}
}


//============================================================================
//	Function Name:	ValLimitEndDate
//	Parameters:		oProdLoan - <DepositDetails> node under <Product> node
//	Return:			Validation boolean
//	Description:	Validate Product-DDA's LimitEndDate       MN
//============================================================================

function ValLimitEndDate(oProdDDA)
{
	try
	{
		var valid = false;
		var validPf= false;
		var PrimaryAcnt_PFLimit_date= false;
		if (!oProdDDA.hasChildNodes) return false;
		var dtStartDate = oProdDDA.selectSingleNode("LimitStartDate").text;
		var dtEndDate = oProdDDA.selectSingleNode("LimitEndDate").text;        
		var dtPFLimitEndDate,PFprimaryAccount,dtPFLimitEndDate;
        var PrimaryAcnt_PFLimit_date=false;
        var SubAccount_PFLimit_date=false;
       
        if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
        //The application is a portfolio app
		{			
			dtPFLimitEndDate = (xml_master.XMLDocument.documentElement.selectSingleNode('Portfolio/PfLimitEndDate').text);		
			PFprimaryAccount = (oProdDDA.selectSingleNode("PortfolioPrimaryAccount").text=="-1")? true:false; 				
			var dtEndPrimaryAccount = oProdDDA.selectSingleNode("LimitEndDate").text;			
			if (PFprimaryAccount==true) 
			//The account is primary       
			{	
				if (dtPFLimitEndDate!="") 
				//Account is primary and there is an end date			
				{			 	
			 		if (dtEndPrimaryAccount!= dtPFLimitEndDate) 
			 		//primary acnt and Portfolio end date not matching
					{
						PrimaryAcnt_PFLimit_date = false;
					    validPf= false;
															
					}
					else
					//primary acnt and Portfolio end date is matching
					{
						PrimaryAcnt_PFLimit_date = true;
						validPf= true;					
					}
				}
				else
				//Account is primary and there is no end date
				{
					var bNoEnddateForPrimSub;
					bNoEnddateForPrimSub=false;
					bNoEnddateForPrimSub=(oProdDDA.selectSingleNode("NoEndDateYN").text=="-1")? true:false;
					//If the the no end date is checked return true
					if (bNoEnddateForPrimSub)
					{
						validPf=true;
					}
					else
					{
						validPf=false;
					}
				}					
           	}             		
           	else 
           	//The account is not primary
           	{
           		if (dtPFLimitEndDate!="")
           		//There is a limit end date, so sub acc end date should be less than that
           		{
           			if (dtEndDate=="")
					{
						validPf= false;				
					}
					else
					{ 
					if (VBIsDate(dtPFLimitEndDate) && VBIsDate(dtEndDate))
           				if(VBDateDiff("d", dtPFLimitEndDate, dtEndDate ) <= 0)
           				validPf= true;
           			}
           		}
           		else
           		//There is no end date for portfolio so we don't have to worry abt sub acct.
           		{
           			validPf= true;
           		}
           	}      					
		}

		else 
		//The app is not a portfolio so we don't have to worry about Pf so set it to True.
		{
			validPf=true;
		}
		
		//Existing validation for end date.
		if (dtEndDate=="")
		{
			valid = (oProdDDA.selectSingleNode("NoEndDateYN").text=="0")? false:true;
		}
		else
		{
			if (VBIsDate(dtStartDate) && VBIsDate(dtEndDate))		
				valid = (VBDateDiff("d", dtStartDate, dtEndDate ) > 0);
		}
		
		valid = valid && validPf;
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValLimitEndDate');
	}
}



//============================================================================ 
//	Function Name:	ValProdsForPortfolioPrimCount
//	Parameters:		
//	Return:		 Validation boolean
//	Description:	 Validate PortfolioPrimary Account/s  
//============================================================================
function ValProdsForPortfolioPrimCount(oPfPrim)
{
	try
	{   
		var DepositNodes;
		var oPurposes;
		
		
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
		{		
			oPurposes=xml_master.XMLDocument.documentElement.selectSingleNode("Purposes");		
		
			DepositNodes=oPurposes.selectNodes("Purpose/Products/Product/DepositDetails[PortfolioPrimaryAccount=-1]");
	
			var DepCount;
			DepCount=DepositNodes.length;	
			
		
			if (DepCount!=1)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return true;
		}
	}
              
	catch (e)
	{
		displayError(e,'ValProdsForPortfolioPrimCount');
	}
	
	
}

//============================================================================
//	Function Name:	ValATOType
//	Parameters:		oProdLoan - <DepositDetails> node under <Product> node
//	Return:			Validation boolean
//	Description:	Validate Product-DDA's ATOType
//============================================================================
function ValATOType(oProdDDA)
{
	try
	{
		var valid = false;
		if (!oProdDDA.hasChildNodes) return false;
		var sATO = oProdDDA.selectSingleNode("ATOType").text;
		valid = ((G_oCompanyOptions.ATO_TYPE=="R")&&(sATO!="")) ||
				((G_oCompanyOptions.ATO_TYPE!="R")&&(sATO==""));
		return valid;
	}
	catch (e)
	{
		displayError(e,'ValATOType');
	}
}

//==============================================================
//	Name:		ValProductRelCusts
//	Purpose:	
//	Parameters:	
//==============================================================


function ValProductRelCusts(oRelCusts)
{
	try
	{
		var valid = false;
		var bGTRValid=true;

		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '0' ) return true;
		
		if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '1' )
		{	

		   	var iPrimaryOwners = 0;	
			var iDirectOwners = 0;
			var allvalid=true;			
			var iGuarantors=0;
			var iUnoCount=0;
			var iAlowMltDirect =true;
			var oCustList; 	
			var iPurpIndex,iProdIndex,iPurpCount,iProdCount;			
			var oApplevelRelCusts;			
			var oCustsNode;
			var intAppLvlCustInd,intPrdLvlCustInd;
			var AppLvlCustCount,PrdLvlCustCount;
			var oAppLevelRelCustList;
			var AppLvlCustID,PrdLvlCustID;
			var AppLvlCustRel,PrdLvlCustRel;		
			var oPrdRelCustNode;
		
	
			oCustsNode=xml_master.XMLDocument.documentElement.selectSingleNode("Customers"); 
			oCustsNode.transformNodeToObject(xsl_RelatedCustRefresh.XMLDocument, xml_temp.XMLDocument);

			oCustList = oRelCusts.selectNodes("RelatedCustomers/RelatedCustomer"); 
			oApplevelRelCusts=xml_temp.XMLDocument;
			
			oAppLevelRelCustList=oApplevelRelCusts.documentElement.selectNodes("RelatedCustomer");
			AppLvlCustCount=oAppLevelRelCustList.length;
			PrdLvlCustCount=oCustList.length;		

			for(intAppLvlCustInd=0;intAppLvlCustInd<AppLvlCustCount;intAppLvlCustInd++)
			{

				if (oAppLevelRelCustList(intAppLvlCustInd))
				{
					AppLvlCustID = oAppLevelRelCustList(intAppLvlCustInd).selectSingleNode("CustomerID").text;
					AppLvlCustRel = oAppLevelRelCustList(intAppLvlCustInd).selectSingleNode("Relationship").text;
			
					if(oRelCusts.selectSingleNode("RelatedCustomers/RelatedCustomer[CustomerID="+ AppLvlCustID +"]"))
					{
				
						oPrdRelCustNode= oRelCusts.selectSingleNode("RelatedCustomers/RelatedCustomer[CustomerID="+ AppLvlCustID +"]");

						PrdLvlCustRel=oPrdRelCustNode.selectSingleNode("Relationship").text;
						
						if (AppLvlCustRel=="GTR" && PrdLvlCustRel!="GTR")
						{
							bGTRValid = bGTRValid && false;					
							break;
						}
					}
				
				}
				
			}
			
			oCustList = oRelCusts.selectNodes("RelatedCustomers/RelatedCustomer"); 			          
					
			for (i=0; i<oCustList.length; i++)
			{
				var oCust=oCustList(i);
				var sCustType = oCust.selectSingleNode("Relationship").text;
				if (sCustType.length>0)
				{
					//get rules for customer type					
					var oR = getRDRowObject('A_TS_CUS_REL_CONTROL','@CATEGORY="ACCU" and @RELATIONSHIP_CODE="' + sCustType + '" and @PRODUCT_CODE="MOS"');
					if (oR.PRIMARY_OWNER_YN) iPrimaryOwners++;
					if (oR.DIRECT_OWNER_YN) iDirectOwners++;											
					if (oR.RELATIONSHIP_CODE=='GTR') iGuarantors++;
					if (oR.RELATIONSHIP_CODE=='UNO') iUnoCount++;
													
					iAlowMltDirect = iAlowMltDirect && oR.MULTIPLE_DIRECT_ALLOW_YN;
				 }
				 else
				 {
					allvalid = false;
					break;
				 }
			} 	
			
			iDirectOwners=iDirectOwners-iUnoCount;

			if (oCustList.length)
			{
				allvalid = allvalid && !((iAlowMltDirect)&&(iDirectOwners==1));
				allvalid = allvalid && !((!iAlowMltDirect)&&(iDirectOwners>1));
				allvalid = allvalid && (iPrimaryOwners==1);
				allvalid = allvalid && (iDirectOwners<=12);							
				
				allvalid = allvalid && (iGuarantors<=4);				
			}
			valid = allvalid;
		}
		 
		valid=bGTRValid && valid;				
		return valid;		
	}
	catch (e)
	{
		displayError(e,'ValProductRelCusts');
	}
}	

//==============================================================
//	Name:		ValPurposesForPortfolioPrimary
//	Purpose:	Validation introduced as a part of portfolio.
//				Validates if at least one DDA primary account is present in the portfolio app.
//	Parameters:	
//==============================================================

function ValPurposesForPortfolioPrimary()
{
	try
	{
	    if (xml_master.XMLDocument.documentElement.getAttribute('PortfolioApp') == '0') return true; // If Non portfolio don't do the validation
	    var iDDAAccCount =xml_master.XMLDocument.documentElement.selectNodes("Purposes/Purpose/Products/Product/DepositDetails").length;
	    if (iDDAAccCount == 0)
			return false;
		else
	    {
			var iPrimAccCount =xml_master.XMLDocument.documentElement.selectNodes("Purposes/Purpose/Products/Product/DepositDetails[PortfolioPrimaryAccount='-1']").length;
			if (iPrimAccCount == 0)
				return false;
			else
				return true;
	    }
	    	
	}
	catch (e)
	{
		displayError(e,'ValPurposes');
	}
}


//============================================================================
//	Function Name:	ValBreakFreeCreditLimitAmount
//	Parameters:		oProdLoan - <DepositDetails> node under <Product> node
//	Return:			Validation boolean
//	Description:	
//============================================================================
/*function ValBreakFreeCreditLimitAmount(oProdLoan)
{
	try
	{
	    var valid = false;
	    var CCLimit = oProdLoan.selectSingleNode("BreakFreeCardLimit").text;
	    if (oProdLoan.selectSingleNode("BreakFreeCard").text != "New Credit Card") {
	        if (CCLimit == 0) {
	            valid = true;
	        }
	    }
	    if (( CCLimit >= 6000) && ( CCLimit <= 50000) &&  (CCLimit%500 == 0)) {
	        valid =true;
	    }
	    return valid;
	}
	catch (e)
	{
		displayError(e,'ValBreakFreeCreditLimitAmount');
	}
}*/


//=======================================================================
//	Function Name:	ValOffsetAccNo			
//	Parameters:		oProdLoan - <oProdLoan> node
//	Return:			Validation boolean
//	Description:	Validate field OffsetAccNo.
//=======================================================================
function ValOffsetAccNo(oProdLoan) 
{
    try
	{
        var oFld = oProdLoan.selectSingleNode("OffsetReqd");
        if (oFld && oFld.text == "1") {
            var oFld1 = oProdLoan.selectSingleNode("OffsetAccNo").text;
            if ((oFld1.length < 9 && oFld1.length > 0)) {
                return false;
            }
        }
        return true;

    }
    catch (e) 
	{
        displayError(e, 'ValOffsetAccNo');
    }
}
//==============================================================
//	Function Name:	showDiv
//	Parameters:		Div tag id
//	Return:			Nil
//	Description:	Show the div tag content
//==============================================================
function showDiv(divName) 
{
	try
	{
		var objDivStyle = eval('document.all.' + divName + '.style');
		objDivStyle.visibility = 'visible';
		objDivStyle.display = "block";
	}
	catch(e)
	{
		displayError(e,"showDiv");
	}
}

//==============================================================
//	Function Name:	hideDiv
//	Parameters:		Div tag id
//	Return:			Nil
//	Description:	Hide the div tag content
//==============================================================
function hideDiv(divName)
{
	try
	{
		var objDivStyle = eval('document.all.' + divName + '.style');
		objDivStyle.visibility = 'hidden';
		objDivStyle.display = "none";
	}
	catch(e)
	{
		displayError(e,"hideDiv");
	}
}


//==============================================================
//	Name:		ValReasonForInterestonly
//	Purpose:	Validates the reason for interest only
//	Return:		boolean - true, if it is valid,
//							otherwise - false
//==============================================================

function ValReasonForInterestOnly(oProdLoan)
{
	try
	{
		var valid = false;		
		if (!oProdLoan.hasChildNodes) return false;
		if(oProdLoan.selectSingleNode("InterestOnlyTerm")===null) return false;
		if(oProdLoan.selectSingleNode("ReasonForInterestOnly")===null) return false;
		var nIntTerm = GetIntVal(oProdLoan.selectSingleNode("InterestOnlyTerm").text);
		var sReasonForInterestonly = oProdLoan.selectSingleNode("ReasonForInterestOnly").text;
		
		if ((GetIntVal(nIntTerm) > 0) && (sReasonForInterestonly.length  == 0))
			valid = false; 
		else
			valid = true;
		return valid;
	
	}
	catch(e)
	{
		displayError(e,"ValReasonForInterestOnly");
	}
}


//==============================================================
//	Name:		ValOtherReasonIntOnly
//	Purpose:	Validates reason for refinance if other as reason for refinance
//	Return:		boolean - true, if it as value,
//							otherwise - false
//==============================================================
function ValOtherReasonIntOnly(oProdLoan)
{
	try
	{	
		 if (!oProdLoan.hasChildNodes) return false;
		 if(oProdLoan.selectSingleNode("ReasonForInterestOnly")===null) return false;
		 var sReasonForInterestonly = oProdLoan.selectSingleNode("ReasonForInterestOnly").text;
		 var sOtherReasonForInterestonly = oProdLoan.selectSingleNode("OtherReasonForInterestOnly").text;

		 return(sReasonForInterestonly == 'Other (please provide reason in description box)' && sOtherReasonForInterestonly.length == 0)? false : true;
		
	
	return true;
	}
	catch(e)
	{
		displayError(e,"ValOtherReasonIntOnly");
	}
}

//==============================================================
//	Name:		IsAlphaNumeric
//	Purpose:	Validates other as reason is Alphanumeric
//	Return:		boolean - true, if it as value,
//							otherwise - false
//==============================================================
function IsAlphaNumeric(e) 
{		
	var keyCode = e.keyCode ;           
	var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || (keyCode == 32));           
	return ret;
}
	