//<!--==========================================================
//	(C) Copyright 1996 - 2002
//	Australia and New Zealand Banking Group Limited
//	ABN 11 005 357 522
//	============================================================
//
//**Start Encode**
//
//	Revision:	1.0
//	Author:		Suresh K C
//	Workfile:	ValMortgageInterviewGuide.js
//	Created ON:	18/05/2011
//============================================================-->
//<SCRIPT>


//==============================================================
//	Name:		ValChangeInFinancialStatus
//	Purpose:	Validates is there any change in the financial status
//	Return:		boolean - true, if it is changed,
//							otherwise - false
//==============================================================
function ValChangeInFinancialStatus()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var sIsChangeInFinancialStatus = (oMIGDetails.selectSingleNode('IsChangeInFinancialStatus'))? oMIGDetails.selectSingleNode('IsChangeInFinancialStatus').text:'';
		var sChangeInFinancialStatus = (oMIGDetails.selectSingleNode('ChangeInFinancialStatus'))? oMIGDetails.selectSingleNode('ChangeInFinancialStatus').text:'';
		
		return (sIsChangeInFinancialStatus == 1 && sChangeInFinancialStatus.length == 0)? false : true;
	}
	catch(e)
	{
		displayError(e,"ValChangeInFinancialStatus");
	}
}

//==============================================================
//	Name:		ValRepaymentPlan
//	Purpose:	Validates the Repayment Plan when there is any reduced income
//	Return:		boolean - true, if it is reduced income,
//							otherwise - false
//==============================================================
function ValRepaymentPlan()
{
	try
	{
		var oMIGDetails = xml_master.XMLDocument.documentElement.selectSingleNode('//MIG');
		var sIsChangeInFinancialStatus = (oMIGDetails.selectSingleNode('IsChangeInFinancialStatus'))? oMIGDetails.selectSingleNode('IsChangeInFinancialStatus').text:'';
		var sRepaymentPlan = (oMIGDetails.selectSingleNode('RepaymentPlan'))? oMIGDetails.selectSingleNode('RepaymentPlan').text:'';
		
		return (sIsChangeInFinancialStatus == 1 && sRepaymentPlan.length == 0)? false : true;
	}
	catch(e)
	{
		displayError(e,"ValRepaymentPlan");
	}
}


